# RegisterCertificate — Request - clinicalprocess: healthcond: certificate v4.1.0-rc1

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **RegisterCertificate — Request**

## Logical Model: RegisterCertificate — Request 

| | |
| :--- | :--- |
| *Official URL*:https://fhir.inera.se/ig/clinicalprocess-healthcond-certificate/StructureDefinition/registercertificate-request | *Version*:3.1 |
| Draft as of 2026-11-09 | *Computable Name*:RegisterCertificateRequest |
| **Copyright/Legal**: Copyright 2024 Inera AB. Licensieras under Creative Commons Attribution 4.0. | |

 
Logisk modell för requestparametrar i RegisterCertificate. 

**Usages:**

* This Logical Model is not used by any profiles in this Specification

You can also check for [usages in the FHIR IG Statistics](https://packages2.fhir.org/xig/resource/inera.clinicalprocess-healthcond-certificate|current/StructureDefinition/StructureDefinition-registercertificate-request.json)

### Formal Views of Profile Content

 [Description of Profiles, Differentials, Snapshots and how the different presentations work](http://build.fhir.org/ig/FHIR/ig-guidance/readingIgs.html#structure-definitions). 

 

Other representations of profile: [CSV](StructureDefinition-registercertificate-request.csv), [Excel](StructureDefinition-registercertificate-request.xlsx) 



## Resource Content

```json
{
  "resourceType" : "StructureDefinition",
  "id" : "registercertificate-request",
  "extension" : [{
    "url" : "http://hl7.org/fhir/StructureDefinition/structuredefinition-type-characteristics",
    "valueCode" : "can-be-target"
  }],
  "url" : "https://fhir.inera.se/ig/clinicalprocess-healthcond-certificate/StructureDefinition/registercertificate-request",
  "version" : "3.1",
  "name" : "RegisterCertificateRequest",
  "title" : "RegisterCertificate — Request",
  "status" : "draft",
  "date" : "2026-11-09T03:21:30+00:00",
  "contact" : [{
    "name" : "Inera Arkitektur",
    "telecom" : [{
      "system" : "url",
      "value" : "https://www.inera.se"
    }]
  }],
  "description" : "Logisk modell för requestparametrar i RegisterCertificate.",
  "copyright" : "Copyright 2024 Inera AB. Licensieras under Creative Commons Attribution 4.0.",
  "fhirVersion" : "4.0.1",
  "kind" : "logical",
  "abstract" : false,
  "type" : "https://fhir.inera.se/ig/clinicalprocess-healthcond-certificate/StructureDefinition/registercertificate-request",
  "baseDefinition" : "http://hl7.org/fhir/StructureDefinition/Base",
  "derivation" : "specialization",
  "differential" : {
    "element" : [{
      "id" : "registercertificate-request",
      "path" : "registercertificate-request",
      "short" : "RegisterCertificate — Request",
      "definition" : "Logisk modell för requestparametrar i RegisterCertificate."
    },
    {
      "id" : "registercertificate-request.svarPa",
      "path" : "registercertificate-request.svarPa",
      "short" : "MeddelandeReferens",
      "definition" : "Om intyget utfärdas som ett svar på en fråga från intygsmottagaren (t.ex. en begäran om komplettering) ska referens till meddelandet skickas.",
      "comment" : "TKB-fält: `svarPa*` (`MeddelandeReferens (se 7.1.7)`, kardinalitet 0..1).\n\n**Mappning DIM:** Meddelande.meddelande-id, Meddelande.referens-id",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "Base"
      }]
    },
    {
      "id" : "registercertificate-request.svarPa.meddelande-id",
      "path" : "registercertificate-request.svarPa.meddelande-id",
      "short" : "meddelande-id",
      "definition" : "meddelande-id",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "registercertificate-request.svarPa.referens-id",
      "path" : "registercertificate-request.svarPa.referens-id",
      "short" : "referens-id",
      "definition" : "referens-id",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "registercertificate-request.intyg",
      "path" : "registercertificate-request.intyg",
      "short" : "Intyg",
      "definition" : "Ett intyg.",
      "comment" : "TKB-fält: `intyg*` (`Intyg (se 7.1.5)`, kardinalitet 1..1).\n\n**Mappning DIM:** Intyg, Intygsmottagare.part, Patient, HoS-personal, Enhet, Vårdgivare, Relation, Status, Part, Svar, Delsvar, Fråga.fråge-id, Delfråga.delfråge-id, Metadata.signerattidpunkt",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "Base"
      }]
    },
    {
      "id" : "registercertificate-request.intyg.intygs-id",
      "path" : "registercertificate-request.intyg.intygs-id",
      "short" : "IntygId",
      "definition" : "intygs-id",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "Base"
      }]
    },
    {
      "id" : "registercertificate-request.intyg.mottagare",
      "path" : "registercertificate-request.intyg.mottagare",
      "short" : "Part",
      "definition" : "mottagare",
      "min" : 0,
      "max" : "*",
      "type" : [{
        "code" : "Base"
      }]
    },
    {
      "id" : "registercertificate-request.intyg.typ",
      "path" : "registercertificate-request.intyg.typ",
      "short" : "TypAvIntyg",
      "definition" : "typ",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "Base"
      }]
    },
    {
      "id" : "registercertificate-request.intyg.version",
      "path" : "registercertificate-request.intyg.version",
      "short" : "version",
      "definition" : "version",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "registercertificate-request.intyg.signeringstidpunkt",
      "path" : "registercertificate-request.intyg.signeringstidpunkt",
      "short" : "signeringstidpunkt",
      "definition" : "signeringstidpunkt",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "dateTime",
        "profile" : ["https://fhir.inera.se/ig/clinicalprocess-healthcond-certificate/StructureDefinition/TimeStampType"]
      }]
    },
    {
      "id" : "registercertificate-request.intyg.skickatTidpunkt",
      "path" : "registercertificate-request.intyg.skickatTidpunkt",
      "short" : "skickatTidpunkt",
      "definition" : "skickatTidpunkt",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "dateTime",
        "profile" : ["https://fhir.inera.se/ig/clinicalprocess-healthcond-certificate/StructureDefinition/TimeStampType"]
      }]
    },
    {
      "id" : "registercertificate-request.intyg.patient",
      "path" : "registercertificate-request.intyg.patient",
      "short" : "Patient",
      "definition" : "patient",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "Base"
      }]
    },
    {
      "id" : "registercertificate-request.intyg.patient.person-id",
      "path" : "registercertificate-request.intyg.patient.person-id",
      "short" : "PersonId",
      "definition" : "person-id",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "Base"
      }]
    },
    {
      "id" : "registercertificate-request.intyg.patient.fornamn",
      "path" : "registercertificate-request.intyg.patient.fornamn",
      "short" : "fornamn",
      "definition" : "fornamn",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "registercertificate-request.intyg.patient.efternamn",
      "path" : "registercertificate-request.intyg.patient.efternamn",
      "short" : "efternamn",
      "definition" : "efternamn",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "registercertificate-request.intyg.patient.mellannamn",
      "path" : "registercertificate-request.intyg.patient.mellannamn",
      "short" : "mellannamn",
      "definition" : "mellannamn",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "registercertificate-request.intyg.patient.postadress",
      "path" : "registercertificate-request.intyg.patient.postadress",
      "short" : "postadress",
      "definition" : "postadress",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "registercertificate-request.intyg.patient.postnummer",
      "path" : "registercertificate-request.intyg.patient.postnummer",
      "short" : "postnummer",
      "definition" : "postnummer",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "registercertificate-request.intyg.patient.postort",
      "path" : "registercertificate-request.intyg.patient.postort",
      "short" : "postort",
      "definition" : "postort",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "registercertificate-request.intyg.patient.kallaAdressuppgifter",
      "path" : "registercertificate-request.intyg.patient.kallaAdressuppgifter",
      "short" : "KallaAdressuppgifterType",
      "definition" : "kallaAdressuppgifter",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "Base"
      }]
    },
    {
      "id" : "registercertificate-request.intyg.skapadAv",
      "path" : "registercertificate-request.intyg.skapadAv",
      "short" : "HosPersonal",
      "definition" : "skapadAv",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "Base"
      }]
    },
    {
      "id" : "registercertificate-request.intyg.skapadAv.personal-id",
      "path" : "registercertificate-request.intyg.skapadAv.personal-id",
      "short" : "HsaId",
      "definition" : "HSA-id, o.i.d för HSA-id är 1.2.752.129.2.1.4.1",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "Base"
      }]
    },
    {
      "id" : "registercertificate-request.intyg.skapadAv.fullstandigtNamn",
      "path" : "registercertificate-request.intyg.skapadAv.fullstandigtNamn",
      "short" : "Förnamn + efternamn sammanslaget. Är tomt om personen har en skyddad identitet.",
      "definition" : "Förnamn + efternamn sammanslaget. Är tomt om personen har en skyddad identitet.",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "registercertificate-request.intyg.skapadAv.forskrivarkod",
      "path" : "registercertificate-request.intyg.skapadAv.forskrivarkod",
      "short" : "forskrivarkod",
      "definition" : "forskrivarkod",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "registercertificate-request.intyg.skapadAv.befattning",
      "path" : "registercertificate-request.intyg.skapadAv.befattning",
      "short" : "Befattning",
      "definition" : "befattning",
      "min" : 0,
      "max" : "*",
      "type" : [{
        "code" : "Base"
      }]
    },
    {
      "id" : "registercertificate-request.intyg.skapadAv.enhet",
      "path" : "registercertificate-request.intyg.skapadAv.enhet",
      "short" : "Enhet",
      "definition" : "enhet",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "Base"
      }]
    },
    {
      "id" : "registercertificate-request.intyg.skapadAv.enhet.enhets-id",
      "path" : "registercertificate-request.intyg.skapadAv.enhet.enhets-id",
      "short" : "HsaId",
      "definition" : "HSA-id, o.i.d för HSA-id är 1.2.752.129.2.1.4.1",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "Base"
      }]
    },
    {
      "id" : "registercertificate-request.intyg.skapadAv.enhet.arbetsplatskod",
      "path" : "registercertificate-request.intyg.skapadAv.enhet.arbetsplatskod",
      "short" : "ArbetsplatsKod",
      "definition" : "o.i.d för arbetsplatskod är 1.2.752.29.4.71",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "Base"
      }]
    },
    {
      "id" : "registercertificate-request.intyg.skapadAv.enhet.enhetsnamn",
      "path" : "registercertificate-request.intyg.skapadAv.enhet.enhetsnamn",
      "short" : "enhetsnamn",
      "definition" : "enhetsnamn",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "registercertificate-request.intyg.skapadAv.enhet.postadress",
      "path" : "registercertificate-request.intyg.skapadAv.enhet.postadress",
      "short" : "postadress",
      "definition" : "postadress",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "registercertificate-request.intyg.skapadAv.enhet.postnummer",
      "path" : "registercertificate-request.intyg.skapadAv.enhet.postnummer",
      "short" : "postnummer",
      "definition" : "postnummer",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "registercertificate-request.intyg.skapadAv.enhet.postort",
      "path" : "registercertificate-request.intyg.skapadAv.enhet.postort",
      "short" : "postort",
      "definition" : "postort",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "registercertificate-request.intyg.skapadAv.enhet.telefonnummer",
      "path" : "registercertificate-request.intyg.skapadAv.enhet.telefonnummer",
      "short" : "telefonnummer",
      "definition" : "telefonnummer",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "registercertificate-request.intyg.skapadAv.enhet.epost",
      "path" : "registercertificate-request.intyg.skapadAv.enhet.epost",
      "short" : "epost",
      "definition" : "epost",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "registercertificate-request.intyg.skapadAv.enhet.vardgivare",
      "path" : "registercertificate-request.intyg.skapadAv.enhet.vardgivare",
      "short" : "Vardgivare",
      "definition" : "vardgivare",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "Base"
      }]
    },
    {
      "id" : "registercertificate-request.intyg.skapadAv.enhet.vardgivare.vardgivare-id",
      "path" : "registercertificate-request.intyg.skapadAv.enhet.vardgivare.vardgivare-id",
      "short" : "HsaId",
      "definition" : "HSA-id, o.i.d för HSA-id är 1.2.752.129.2.1.4.1",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "Base"
      }]
    },
    {
      "id" : "registercertificate-request.intyg.skapadAv.enhet.vardgivare.vardgivarnamn",
      "path" : "registercertificate-request.intyg.skapadAv.enhet.vardgivare.vardgivarnamn",
      "short" : "vardgivarnamn",
      "definition" : "vardgivarnamn",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "registercertificate-request.intyg.skapadAv.specialistkompetens",
      "path" : "registercertificate-request.intyg.skapadAv.specialistkompetens",
      "short" : "Specialistkompetens",
      "definition" : "specialistkompetens",
      "min" : 0,
      "max" : "*",
      "type" : [{
        "code" : "Base"
      }]
    },
    {
      "id" : "registercertificate-request.intyg.skapadAv.specialistkompetens.code",
      "path" : "registercertificate-request.intyg.skapadAv.specialistkompetens.code",
      "short" : "code",
      "definition" : "code",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "registercertificate-request.intyg.skapadAv.specialistkompetens.displayName",
      "path" : "registercertificate-request.intyg.skapadAv.specialistkompetens.displayName",
      "short" : "displayName",
      "definition" : "displayName",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "registercertificate-request.intyg.skapadAv.legitimeratYrke",
      "path" : "registercertificate-request.intyg.skapadAv.legitimeratYrke",
      "short" : "LegitimeratYrkeType",
      "definition" : "legitimeratYrke",
      "min" : 0,
      "max" : "*",
      "type" : [{
        "code" : "Base"
      }]
    },
    {
      "id" : "registercertificate-request.intyg.relation",
      "path" : "registercertificate-request.intyg.relation",
      "short" : "Relation",
      "definition" : "relation",
      "min" : 0,
      "max" : "*",
      "type" : [{
        "code" : "Base"
      }]
    },
    {
      "id" : "registercertificate-request.intyg.relation.typ",
      "path" : "registercertificate-request.intyg.relation.typ",
      "short" : "TypAvRelation",
      "definition" : "typ",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "Base"
      }]
    },
    {
      "id" : "registercertificate-request.intyg.relation.intygs-id",
      "path" : "registercertificate-request.intyg.relation.intygs-id",
      "short" : "IntygId",
      "definition" : "intygs-id",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "Base"
      }]
    },
    {
      "id" : "registercertificate-request.intyg.status",
      "path" : "registercertificate-request.intyg.status",
      "short" : "IntygsStatus",
      "definition" : "status",
      "min" : 0,
      "max" : "*",
      "type" : [{
        "code" : "Base"
      }]
    },
    {
      "id" : "registercertificate-request.intyg.status.part",
      "path" : "registercertificate-request.intyg.status.part",
      "short" : "Part",
      "definition" : "part",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "Base"
      }]
    },
    {
      "id" : "registercertificate-request.intyg.status.status",
      "path" : "registercertificate-request.intyg.status.status",
      "short" : "Statuskod",
      "definition" : "status",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "Base"
      }]
    },
    {
      "id" : "registercertificate-request.intyg.status.tidpunkt",
      "path" : "registercertificate-request.intyg.status.tidpunkt",
      "short" : "tidpunkt",
      "definition" : "tidpunkt",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "dateTime",
        "profile" : ["https://fhir.inera.se/ig/clinicalprocess-healthcond-certificate/StructureDefinition/TimeStampType"]
      }]
    },
    {
      "id" : "registercertificate-request.intyg.svar",
      "path" : "registercertificate-request.intyg.svar",
      "short" : "Svar",
      "definition" : "svar",
      "min" : 0,
      "max" : "*",
      "type" : [{
        "code" : "Base"
      }]
    },
    {
      "id" : "registercertificate-request.intyg.svar.instans",
      "path" : "registercertificate-request.intyg.svar.instans",
      "short" : "instans",
      "definition" : "instans",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "integer"
      }]
    },
    {
      "id" : "registercertificate-request.intyg.svar.delsvar",
      "path" : "registercertificate-request.intyg.svar.delsvar",
      "short" : "(anonym typ)",
      "definition" : "delsvar",
      "min" : 1,
      "max" : "*",
      "type" : [{
        "code" : "Base"
      }]
    },
    {
      "id" : "registercertificate-request.intyg.svar.delsvar.id",
      "path" : "registercertificate-request.intyg.svar.delsvar.id",
      "short" : "id",
      "definition" : "id (XML-attribut)",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "string",
        "profile" : ["https://fhir.inera.se/ig/clinicalprocess-healthcond-certificate/StructureDefinition/DelfrageIdType"]
      }]
    },
    {
      "id" : "registercertificate-request.intyg.svar.id",
      "path" : "registercertificate-request.intyg.svar.id",
      "short" : "id",
      "definition" : "id (XML-attribut)",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "string",
        "profile" : ["https://fhir.inera.se/ig/clinicalprocess-healthcond-certificate/StructureDefinition/FrageIdType"]
      }]
    },
    {
      "id" : "registercertificate-request.intyg.underskrift",
      "path" : "registercertificate-request.intyg.underskrift",
      "short" : "UnderskriftType",
      "definition" : "underskrift",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "Base"
      }]
    },
    {
      "id" : "registercertificate-request.intyg.underskrift.Signature",
      "path" : "registercertificate-request.intyg.underskrift.Signature",
      "short" : "SignatureType",
      "definition" : "Signature",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "Base"
      }]
    },
    {
      "id" : "registercertificate-request.intyg.underskrift.Signature.SignedInfo",
      "path" : "registercertificate-request.intyg.underskrift.Signature.SignedInfo",
      "short" : "SignedInfoType",
      "definition" : "SignedInfo",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "Base"
      }]
    },
    {
      "id" : "registercertificate-request.intyg.underskrift.Signature.SignedInfo.CanonicalizationMethod",
      "path" : "registercertificate-request.intyg.underskrift.Signature.SignedInfo.CanonicalizationMethod",
      "short" : "CanonicalizationMethodType",
      "definition" : "CanonicalizationMethod",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "Base"
      }]
    },
    {
      "id" : "registercertificate-request.intyg.underskrift.Signature.SignedInfo.CanonicalizationMethod.Algorithm",
      "path" : "registercertificate-request.intyg.underskrift.Signature.SignedInfo.CanonicalizationMethod.Algorithm",
      "short" : "Algorithm",
      "definition" : "Algorithm (XML-attribut)",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "uri"
      }]
    },
    {
      "id" : "registercertificate-request.intyg.underskrift.Signature.SignedInfo.SignatureMethod",
      "path" : "registercertificate-request.intyg.underskrift.Signature.SignedInfo.SignatureMethod",
      "short" : "SignatureMethodType",
      "definition" : "SignatureMethod",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "Base"
      }]
    },
    {
      "id" : "registercertificate-request.intyg.underskrift.Signature.SignedInfo.SignatureMethod.HMACOutputLength",
      "path" : "registercertificate-request.intyg.underskrift.Signature.SignedInfo.SignatureMethod.HMACOutputLength",
      "short" : "HMACOutputLength",
      "definition" : "HMACOutputLength",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "integer"
      }]
    },
    {
      "id" : "registercertificate-request.intyg.underskrift.Signature.SignedInfo.SignatureMethod.Algorithm",
      "path" : "registercertificate-request.intyg.underskrift.Signature.SignedInfo.SignatureMethod.Algorithm",
      "short" : "Algorithm",
      "definition" : "Algorithm (XML-attribut)",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "uri"
      }]
    },
    {
      "id" : "registercertificate-request.intyg.underskrift.Signature.SignedInfo.Reference",
      "path" : "registercertificate-request.intyg.underskrift.Signature.SignedInfo.Reference",
      "short" : "ReferenceType",
      "definition" : "Reference",
      "min" : 1,
      "max" : "*",
      "type" : [{
        "code" : "Base"
      }]
    },
    {
      "id" : "registercertificate-request.intyg.underskrift.Signature.SignedInfo.Reference.Transforms",
      "path" : "registercertificate-request.intyg.underskrift.Signature.SignedInfo.Reference.Transforms",
      "short" : "TransformsType",
      "definition" : "Transforms",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "Base"
      }]
    },
    {
      "id" : "registercertificate-request.intyg.underskrift.Signature.SignedInfo.Reference.Transforms.Transform",
      "path" : "registercertificate-request.intyg.underskrift.Signature.SignedInfo.Reference.Transforms.Transform",
      "short" : "TransformType",
      "definition" : "Transform",
      "min" : 1,
      "max" : "*",
      "type" : [{
        "code" : "Base"
      }]
    },
    {
      "id" : "registercertificate-request.intyg.underskrift.Signature.SignedInfo.Reference.Transforms.Transform.XPath",
      "path" : "registercertificate-request.intyg.underskrift.Signature.SignedInfo.Reference.Transforms.Transform.XPath",
      "short" : "XPath",
      "definition" : "XPath",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "registercertificate-request.intyg.underskrift.Signature.SignedInfo.Reference.Transforms.Transform.Algorithm",
      "path" : "registercertificate-request.intyg.underskrift.Signature.SignedInfo.Reference.Transforms.Transform.Algorithm",
      "short" : "Algorithm",
      "definition" : "Algorithm (XML-attribut)",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "uri"
      }]
    },
    {
      "id" : "registercertificate-request.intyg.underskrift.Signature.SignedInfo.Reference.DigestMethod",
      "path" : "registercertificate-request.intyg.underskrift.Signature.SignedInfo.Reference.DigestMethod",
      "short" : "DigestMethodType",
      "definition" : "DigestMethod",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "Base"
      }]
    },
    {
      "id" : "registercertificate-request.intyg.underskrift.Signature.SignedInfo.Reference.DigestMethod.Algorithm",
      "path" : "registercertificate-request.intyg.underskrift.Signature.SignedInfo.Reference.DigestMethod.Algorithm",
      "short" : "Algorithm",
      "definition" : "Algorithm (XML-attribut)",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "uri"
      }]
    },
    {
      "id" : "registercertificate-request.intyg.underskrift.Signature.SignedInfo.Reference.DigestValue",
      "path" : "registercertificate-request.intyg.underskrift.Signature.SignedInfo.Reference.DigestValue",
      "short" : "DigestValue",
      "definition" : "DigestValue",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "base64Binary"
      }]
    },
    {
      "id" : "registercertificate-request.intyg.underskrift.Signature.SignedInfo.Reference.Id",
      "path" : "registercertificate-request.intyg.underskrift.Signature.SignedInfo.Reference.Id",
      "short" : "Id",
      "definition" : "Id (XML-attribut)",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "registercertificate-request.intyg.underskrift.Signature.SignedInfo.Reference.URI",
      "path" : "registercertificate-request.intyg.underskrift.Signature.SignedInfo.Reference.URI",
      "short" : "URI",
      "definition" : "URI (XML-attribut)",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "uri"
      }]
    },
    {
      "id" : "registercertificate-request.intyg.underskrift.Signature.SignedInfo.Reference.Type",
      "path" : "registercertificate-request.intyg.underskrift.Signature.SignedInfo.Reference.Type",
      "short" : "Type",
      "definition" : "Type (XML-attribut)",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "uri"
      }]
    },
    {
      "id" : "registercertificate-request.intyg.underskrift.Signature.SignedInfo.Id",
      "path" : "registercertificate-request.intyg.underskrift.Signature.SignedInfo.Id",
      "short" : "Id",
      "definition" : "Id (XML-attribut)",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "registercertificate-request.intyg.underskrift.Signature.SignatureValue",
      "path" : "registercertificate-request.intyg.underskrift.Signature.SignatureValue",
      "short" : "SignatureValueType",
      "definition" : "SignatureValue",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "Base"
      }]
    },
    {
      "id" : "registercertificate-request.intyg.underskrift.Signature.SignatureValue.value",
      "path" : "registercertificate-request.intyg.underskrift.Signature.SignatureValue.value",
      "short" : "Textinnehåll",
      "definition" : "Elementets textinnehåll i XML (simpleContent).",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "base64Binary"
      }]
    },
    {
      "id" : "registercertificate-request.intyg.underskrift.Signature.SignatureValue.Id",
      "path" : "registercertificate-request.intyg.underskrift.Signature.SignatureValue.Id",
      "short" : "Id",
      "definition" : "Id (XML-attribut)",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "registercertificate-request.intyg.underskrift.Signature.KeyInfo",
      "path" : "registercertificate-request.intyg.underskrift.Signature.KeyInfo",
      "short" : "KeyInfoType",
      "definition" : "KeyInfo",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "Base"
      }]
    },
    {
      "id" : "registercertificate-request.intyg.underskrift.Signature.KeyInfo.KeyName",
      "path" : "registercertificate-request.intyg.underskrift.Signature.KeyInfo.KeyName",
      "short" : "KeyName",
      "definition" : "KeyName",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "registercertificate-request.intyg.underskrift.Signature.KeyInfo.KeyValue",
      "path" : "registercertificate-request.intyg.underskrift.Signature.KeyInfo.KeyValue",
      "short" : "KeyValueType",
      "definition" : "KeyValue",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "Base"
      }],
      "constraint" : [{
        "key" : "registercertificaterequest-choice-1",
        "severity" : "error",
        "human" : "Exakt ett av DSAKeyValue, RSAKeyValue ska anges (xs:choice i schemat).",
        "expression" : "DSAKeyValue.exists() xor RSAKeyValue.exists()",
        "source" : "https://fhir.inera.se/ig/clinicalprocess-healthcond-certificate/StructureDefinition/registercertificate-request"
      }]
    },
    {
      "id" : "registercertificate-request.intyg.underskrift.Signature.KeyInfo.KeyValue.DSAKeyValue",
      "path" : "registercertificate-request.intyg.underskrift.Signature.KeyInfo.KeyValue.DSAKeyValue",
      "short" : "DSAKeyValueType",
      "definition" : "DSAKeyValue",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "Base"
      }]
    },
    {
      "id" : "registercertificate-request.intyg.underskrift.Signature.KeyInfo.KeyValue.DSAKeyValue.P",
      "path" : "registercertificate-request.intyg.underskrift.Signature.KeyInfo.KeyValue.DSAKeyValue.P",
      "short" : "P",
      "definition" : "P",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "base64Binary"
      }]
    },
    {
      "id" : "registercertificate-request.intyg.underskrift.Signature.KeyInfo.KeyValue.DSAKeyValue.Q",
      "path" : "registercertificate-request.intyg.underskrift.Signature.KeyInfo.KeyValue.DSAKeyValue.Q",
      "short" : "Q",
      "definition" : "Q",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "base64Binary"
      }]
    },
    {
      "id" : "registercertificate-request.intyg.underskrift.Signature.KeyInfo.KeyValue.DSAKeyValue.G",
      "path" : "registercertificate-request.intyg.underskrift.Signature.KeyInfo.KeyValue.DSAKeyValue.G",
      "short" : "G",
      "definition" : "G",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "base64Binary"
      }]
    },
    {
      "id" : "registercertificate-request.intyg.underskrift.Signature.KeyInfo.KeyValue.DSAKeyValue.Y",
      "path" : "registercertificate-request.intyg.underskrift.Signature.KeyInfo.KeyValue.DSAKeyValue.Y",
      "short" : "Y",
      "definition" : "Y",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "base64Binary"
      }]
    },
    {
      "id" : "registercertificate-request.intyg.underskrift.Signature.KeyInfo.KeyValue.DSAKeyValue.J",
      "path" : "registercertificate-request.intyg.underskrift.Signature.KeyInfo.KeyValue.DSAKeyValue.J",
      "short" : "J",
      "definition" : "J",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "base64Binary"
      }]
    },
    {
      "id" : "registercertificate-request.intyg.underskrift.Signature.KeyInfo.KeyValue.DSAKeyValue.Seed",
      "path" : "registercertificate-request.intyg.underskrift.Signature.KeyInfo.KeyValue.DSAKeyValue.Seed",
      "short" : "Seed",
      "definition" : "Seed",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "base64Binary"
      }]
    },
    {
      "id" : "registercertificate-request.intyg.underskrift.Signature.KeyInfo.KeyValue.DSAKeyValue.PgenCounter",
      "path" : "registercertificate-request.intyg.underskrift.Signature.KeyInfo.KeyValue.DSAKeyValue.PgenCounter",
      "short" : "PgenCounter",
      "definition" : "PgenCounter",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "base64Binary"
      }]
    },
    {
      "id" : "registercertificate-request.intyg.underskrift.Signature.KeyInfo.KeyValue.RSAKeyValue",
      "path" : "registercertificate-request.intyg.underskrift.Signature.KeyInfo.KeyValue.RSAKeyValue",
      "short" : "RSAKeyValueType",
      "definition" : "RSAKeyValue",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "Base"
      }]
    },
    {
      "id" : "registercertificate-request.intyg.underskrift.Signature.KeyInfo.KeyValue.RSAKeyValue.Modulus",
      "path" : "registercertificate-request.intyg.underskrift.Signature.KeyInfo.KeyValue.RSAKeyValue.Modulus",
      "short" : "Modulus",
      "definition" : "Modulus",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "base64Binary"
      }]
    },
    {
      "id" : "registercertificate-request.intyg.underskrift.Signature.KeyInfo.KeyValue.RSAKeyValue.Exponent",
      "path" : "registercertificate-request.intyg.underskrift.Signature.KeyInfo.KeyValue.RSAKeyValue.Exponent",
      "short" : "Exponent",
      "definition" : "Exponent",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "base64Binary"
      }]
    },
    {
      "id" : "registercertificate-request.intyg.underskrift.Signature.KeyInfo.RetrievalMethod",
      "path" : "registercertificate-request.intyg.underskrift.Signature.KeyInfo.RetrievalMethod",
      "short" : "RetrievalMethodType",
      "definition" : "RetrievalMethod",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "Base"
      }]
    },
    {
      "id" : "registercertificate-request.intyg.underskrift.Signature.KeyInfo.RetrievalMethod.Transforms",
      "path" : "registercertificate-request.intyg.underskrift.Signature.KeyInfo.RetrievalMethod.Transforms",
      "short" : "TransformsType",
      "definition" : "Transforms",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "Base"
      }]
    },
    {
      "id" : "registercertificate-request.intyg.underskrift.Signature.KeyInfo.RetrievalMethod.Transforms.Transform",
      "path" : "registercertificate-request.intyg.underskrift.Signature.KeyInfo.RetrievalMethod.Transforms.Transform",
      "short" : "TransformType",
      "definition" : "Transform",
      "min" : 1,
      "max" : "*",
      "type" : [{
        "code" : "Base"
      }]
    },
    {
      "id" : "registercertificate-request.intyg.underskrift.Signature.KeyInfo.RetrievalMethod.Transforms.Transform.XPath",
      "path" : "registercertificate-request.intyg.underskrift.Signature.KeyInfo.RetrievalMethod.Transforms.Transform.XPath",
      "short" : "XPath",
      "definition" : "XPath",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "registercertificate-request.intyg.underskrift.Signature.KeyInfo.RetrievalMethod.Transforms.Transform.Algorithm",
      "path" : "registercertificate-request.intyg.underskrift.Signature.KeyInfo.RetrievalMethod.Transforms.Transform.Algorithm",
      "short" : "Algorithm",
      "definition" : "Algorithm (XML-attribut)",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "uri"
      }]
    },
    {
      "id" : "registercertificate-request.intyg.underskrift.Signature.KeyInfo.RetrievalMethod.URI",
      "path" : "registercertificate-request.intyg.underskrift.Signature.KeyInfo.RetrievalMethod.URI",
      "short" : "URI",
      "definition" : "URI (XML-attribut)",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "uri"
      }]
    },
    {
      "id" : "registercertificate-request.intyg.underskrift.Signature.KeyInfo.RetrievalMethod.Type",
      "path" : "registercertificate-request.intyg.underskrift.Signature.KeyInfo.RetrievalMethod.Type",
      "short" : "Type",
      "definition" : "Type (XML-attribut)",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "uri"
      }]
    },
    {
      "id" : "registercertificate-request.intyg.underskrift.Signature.KeyInfo.X509Data",
      "path" : "registercertificate-request.intyg.underskrift.Signature.KeyInfo.X509Data",
      "short" : "X509DataType",
      "definition" : "X509Data",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "Base"
      }],
      "constraint" : [{
        "key" : "registercertificaterequest-choice-6",
        "severity" : "error",
        "human" : "Exakt ett av X509IssuerSerial, X509SKI, X509SubjectName, X509Certificate, X509CRL ska anges (xs:choice i schemat).",
        "expression" : "iif(X509IssuerSerial.exists(), 1, 0) + iif(X509SKI.exists(), 1, 0) + iif(X509SubjectName.exists(), 1, 0) + iif(X509Certificate.exists(), 1, 0) + iif(X509CRL.exists(), 1, 0) = 1",
        "source" : "https://fhir.inera.se/ig/clinicalprocess-healthcond-certificate/StructureDefinition/registercertificate-request"
      }]
    },
    {
      "id" : "registercertificate-request.intyg.underskrift.Signature.KeyInfo.X509Data.X509IssuerSerial",
      "path" : "registercertificate-request.intyg.underskrift.Signature.KeyInfo.X509Data.X509IssuerSerial",
      "short" : "X509IssuerSerialType",
      "definition" : "X509IssuerSerial",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "Base"
      }]
    },
    {
      "id" : "registercertificate-request.intyg.underskrift.Signature.KeyInfo.X509Data.X509IssuerSerial.X509IssuerName",
      "path" : "registercertificate-request.intyg.underskrift.Signature.KeyInfo.X509Data.X509IssuerSerial.X509IssuerName",
      "short" : "X509IssuerName",
      "definition" : "X509IssuerName",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "registercertificate-request.intyg.underskrift.Signature.KeyInfo.X509Data.X509IssuerSerial.X509SerialNumber",
      "path" : "registercertificate-request.intyg.underskrift.Signature.KeyInfo.X509Data.X509IssuerSerial.X509SerialNumber",
      "short" : "X509SerialNumber",
      "definition" : "X509SerialNumber",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "integer"
      }]
    },
    {
      "id" : "registercertificate-request.intyg.underskrift.Signature.KeyInfo.X509Data.X509SKI",
      "path" : "registercertificate-request.intyg.underskrift.Signature.KeyInfo.X509Data.X509SKI",
      "short" : "X509SKI",
      "definition" : "X509SKI",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "base64Binary"
      }]
    },
    {
      "id" : "registercertificate-request.intyg.underskrift.Signature.KeyInfo.X509Data.X509SubjectName",
      "path" : "registercertificate-request.intyg.underskrift.Signature.KeyInfo.X509Data.X509SubjectName",
      "short" : "X509SubjectName",
      "definition" : "X509SubjectName",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "registercertificate-request.intyg.underskrift.Signature.KeyInfo.X509Data.X509Certificate",
      "path" : "registercertificate-request.intyg.underskrift.Signature.KeyInfo.X509Data.X509Certificate",
      "short" : "X509Certificate",
      "definition" : "X509Certificate",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "base64Binary"
      }]
    },
    {
      "id" : "registercertificate-request.intyg.underskrift.Signature.KeyInfo.X509Data.X509CRL",
      "path" : "registercertificate-request.intyg.underskrift.Signature.KeyInfo.X509Data.X509CRL",
      "short" : "X509CRL",
      "definition" : "X509CRL",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "base64Binary"
      }]
    },
    {
      "id" : "registercertificate-request.intyg.underskrift.Signature.KeyInfo.PGPData",
      "path" : "registercertificate-request.intyg.underskrift.Signature.KeyInfo.PGPData",
      "short" : "PGPDataType",
      "definition" : "PGPData",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "Base"
      }],
      "constraint" : [{
        "key" : "registercertificaterequest-choice-11",
        "severity" : "error",
        "human" : "Exakt ett av PGPKeyID, PGPKeyPacket ska anges (xs:choice i schemat).",
        "expression" : "PGPKeyID.exists() xor PGPKeyPacket.exists()",
        "source" : "https://fhir.inera.se/ig/clinicalprocess-healthcond-certificate/StructureDefinition/registercertificate-request"
      }]
    },
    {
      "id" : "registercertificate-request.intyg.underskrift.Signature.KeyInfo.PGPData.PGPKeyID",
      "path" : "registercertificate-request.intyg.underskrift.Signature.KeyInfo.PGPData.PGPKeyID",
      "short" : "PGPKeyID",
      "definition" : "PGPKeyID",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "base64Binary"
      }]
    },
    {
      "id" : "registercertificate-request.intyg.underskrift.Signature.KeyInfo.PGPData.PGPKeyPacket",
      "path" : "registercertificate-request.intyg.underskrift.Signature.KeyInfo.PGPData.PGPKeyPacket",
      "short" : "PGPKeyPacket",
      "definition" : "PGPKeyPacket",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "base64Binary"
      }]
    },
    {
      "id" : "registercertificate-request.intyg.underskrift.Signature.KeyInfo.SPKIData",
      "path" : "registercertificate-request.intyg.underskrift.Signature.KeyInfo.SPKIData",
      "short" : "SPKIDataType",
      "definition" : "SPKIData",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "Base"
      }]
    },
    {
      "id" : "registercertificate-request.intyg.underskrift.Signature.KeyInfo.SPKIData.SPKISexp",
      "path" : "registercertificate-request.intyg.underskrift.Signature.KeyInfo.SPKIData.SPKISexp",
      "short" : "SPKISexp",
      "definition" : "SPKISexp",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "base64Binary"
      }]
    },
    {
      "id" : "registercertificate-request.intyg.underskrift.Signature.KeyInfo.MgmtData",
      "path" : "registercertificate-request.intyg.underskrift.Signature.KeyInfo.MgmtData",
      "short" : "MgmtData",
      "definition" : "MgmtData",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "registercertificate-request.intyg.underskrift.Signature.KeyInfo.Id",
      "path" : "registercertificate-request.intyg.underskrift.Signature.KeyInfo.Id",
      "short" : "Id",
      "definition" : "Id (XML-attribut)",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "registercertificate-request.intyg.underskrift.Signature.Object",
      "path" : "registercertificate-request.intyg.underskrift.Signature.Object",
      "short" : "ObjectType",
      "definition" : "Object",
      "min" : 0,
      "max" : "*",
      "type" : [{
        "code" : "Base"
      }]
    },
    {
      "id" : "registercertificate-request.intyg.underskrift.Signature.Object.Id",
      "path" : "registercertificate-request.intyg.underskrift.Signature.Object.Id",
      "short" : "Id",
      "definition" : "Id (XML-attribut)",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "registercertificate-request.intyg.underskrift.Signature.Object.MimeType",
      "path" : "registercertificate-request.intyg.underskrift.Signature.Object.MimeType",
      "short" : "MimeType",
      "definition" : "MimeType (XML-attribut)",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "registercertificate-request.intyg.underskrift.Signature.Object.Encoding",
      "path" : "registercertificate-request.intyg.underskrift.Signature.Object.Encoding",
      "short" : "Encoding",
      "definition" : "Encoding (XML-attribut)",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "uri"
      }]
    },
    {
      "id" : "registercertificate-request.intyg.underskrift.Signature.Id",
      "path" : "registercertificate-request.intyg.underskrift.Signature.Id",
      "short" : "Id",
      "definition" : "Id (XML-attribut)",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    }]
  }
}

```
