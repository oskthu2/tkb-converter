# CertificateStatusUpdateForCare — Request - clinicalprocess: healthcond: certificate v4.1-RC1

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **CertificateStatusUpdateForCare — Request**

## Logical Model: CertificateStatusUpdateForCare — Request 

| | |
| :--- | :--- |
| *Official URL*:https://fhir.inera.se/ig/clinicalprocess-healthcond-certificate/StructureDefinition/certificatestatusupdateforcare-request | *Version*:4.1-RC1 |
| Draft as of 2026-09-26 | *Computable Name*:CertificateStatusUpdateForCareRequest |
| **Copyright/Legal**: Copyright 2024 Inera AB. Licensieras under Creative Commons Attribution 4.0. | |

 
Logisk modell för requestparametrar i CertificateStatusUpdateForCare. 

**Usages:**

* This Logical Model is not used by any profiles in this Specification

You can also check for [usages in the FHIR IG Statistics](https://packages2.fhir.org/xig/resource/inera.clinicalprocess-healthcond-certificate|current/StructureDefinition/StructureDefinition-certificatestatusupdateforcare-request.json)

### Formal Views of Profile Content

 [Description of Profiles, Differentials, Snapshots and how the different presentations work](http://build.fhir.org/ig/FHIR/ig-guidance/readingIgs.html#structure-definitions). 

 

Other representations of profile: [CSV](StructureDefinition-certificatestatusupdateforcare-request.csv), [Excel](StructureDefinition-certificatestatusupdateforcare-request.xlsx) 



## Resource Content

```json
{
  "resourceType" : "StructureDefinition",
  "id" : "certificatestatusupdateforcare-request",
  "extension" : [{
    "url" : "http://hl7.org/fhir/StructureDefinition/structuredefinition-type-characteristics",
    "valueCode" : "can-be-target"
  }],
  "url" : "https://fhir.inera.se/ig/clinicalprocess-healthcond-certificate/StructureDefinition/certificatestatusupdateforcare-request",
  "version" : "4.1-RC1",
  "name" : "CertificateStatusUpdateForCareRequest",
  "title" : "CertificateStatusUpdateForCare — Request",
  "status" : "draft",
  "date" : "2026-09-26T19:18:18+00:00",
  "contact" : [{
    "name" : "Inera Arkitektur",
    "telecom" : [{
      "system" : "url",
      "value" : "https://www.inera.se"
    }]
  }],
  "description" : "Logisk modell för requestparametrar i CertificateStatusUpdateForCare.",
  "copyright" : "Copyright 2024 Inera AB. Licensieras under Creative Commons Attribution 4.0.",
  "fhirVersion" : "4.0.1",
  "kind" : "logical",
  "abstract" : false,
  "type" : "https://fhir.inera.se/ig/clinicalprocess-healthcond-certificate/StructureDefinition/certificatestatusupdateforcare-request",
  "baseDefinition" : "http://hl7.org/fhir/StructureDefinition/Base",
  "derivation" : "specialization",
  "differential" : {
    "element" : [{
      "id" : "certificatestatusupdateforcare-request",
      "path" : "certificatestatusupdateforcare-request",
      "short" : "CertificateStatusUpdateForCare — Request",
      "definition" : "Logisk modell för requestparametrar i CertificateStatusUpdateForCare."
    },
    {
      "id" : "certificatestatusupdateforcare-request.intyg",
      "path" : "certificatestatusupdateforcare-request.intyg",
      "short" : "Intygsutkast eller signerat intyg",
      "definition" : "Intygsutkast eller signerat intyg",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "BackboneElement"
      }]
    },
    {
      "id" : "certificatestatusupdateforcare-request.intyg.intygsId",
      "path" : "certificatestatusupdateforcare-request.intyg.intygsId",
      "short" : "Unikt ID för intyget",
      "definition" : "Unikt ID för intyget",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "Identifier"
      }]
    },
    {
      "id" : "certificatestatusupdateforcare-request.intyg.typAvIntyg",
      "path" : "certificatestatusupdateforcare-request.intyg.typAvIntyg",
      "short" : "Typ av intyg",
      "definition" : "Typ av intyg",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "CodeableConcept"
      }]
    },
    {
      "id" : "certificatestatusupdateforcare-request.intyg.signeringsTidpunkt",
      "path" : "certificatestatusupdateforcare-request.intyg.signeringsTidpunkt",
      "short" : "Tidpunkt då intyget signerades (saknas för utkast)",
      "definition" : "Tidpunkt då intyget signerades (saknas för utkast)",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "dateTime"
      }]
    },
    {
      "id" : "certificatestatusupdateforcare-request.intyg.patient",
      "path" : "certificatestatusupdateforcare-request.intyg.patient",
      "short" : "Patientuppgifter",
      "definition" : "Patientuppgifter",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "BackboneElement"
      }]
    },
    {
      "id" : "certificatestatusupdateforcare-request.intyg.patient.personId",
      "path" : "certificatestatusupdateforcare-request.intyg.patient.personId",
      "short" : "Person- eller samordningsnummer",
      "definition" : "Person- eller samordningsnummer",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "Identifier"
      }]
    },
    {
      "id" : "certificatestatusupdateforcare-request.intyg.skapadAv",
      "path" : "certificatestatusupdateforcare-request.intyg.skapadAv",
      "short" : "HoS-personal",
      "definition" : "HoS-personal",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "BackboneElement"
      }]
    },
    {
      "id" : "certificatestatusupdateforcare-request.intyg.skapadAv.personalId",
      "path" : "certificatestatusupdateforcare-request.intyg.skapadAv.personalId",
      "short" : "HSA-id",
      "definition" : "HSA-id",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "Identifier"
      }]
    },
    {
      "id" : "certificatestatusupdateforcare-request.intyg.skapadAv.enhet",
      "path" : "certificatestatusupdateforcare-request.intyg.skapadAv.enhet",
      "short" : "Enhet",
      "definition" : "Enhet",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "BackboneElement"
      }]
    },
    {
      "id" : "certificatestatusupdateforcare-request.intyg.skapadAv.enhet.enhetsId",
      "path" : "certificatestatusupdateforcare-request.intyg.skapadAv.enhet.enhetsId",
      "short" : "HSA-id för enheten",
      "definition" : "HSA-id för enheten",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "Identifier"
      }]
    },
    {
      "id" : "certificatestatusupdateforcare-request.intyg.skapadAv.enhet.vardgivare",
      "path" : "certificatestatusupdateforcare-request.intyg.skapadAv.enhet.vardgivare",
      "short" : "Vårdgivare",
      "definition" : "Vårdgivare",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "BackboneElement"
      }]
    },
    {
      "id" : "certificatestatusupdateforcare-request.intyg.skapadAv.enhet.vardgivare.vardgivareId",
      "path" : "certificatestatusupdateforcare-request.intyg.skapadAv.enhet.vardgivare.vardgivareId",
      "short" : "HSA-id för vårdgivaren",
      "definition" : "HSA-id för vårdgivaren",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "Identifier"
      }]
    },
    {
      "id" : "certificatestatusupdateforcare-request.intyg.status",
      "path" : "certificatestatusupdateforcare-request.intyg.status",
      "short" : "Intygsstatus",
      "definition" : "Intygsstatus",
      "min" : 0,
      "max" : "*",
      "type" : [{
        "code" : "BackboneElement"
      }]
    },
    {
      "id" : "certificatestatusupdateforcare-request.intyg.status.part",
      "path" : "certificatestatusupdateforcare-request.intyg.status.part",
      "short" : "Part",
      "definition" : "Part",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "CodeableConcept"
      }],
      "binding" : {
        "strength" : "required",
        "valueSet" : "https://fhir.inera.se/ig/clinicalprocess-healthcond-certificate/ValueSet/part-vs"
      }
    },
    {
      "id" : "certificatestatusupdateforcare-request.intyg.status.statuskod",
      "path" : "certificatestatusupdateforcare-request.intyg.status.statuskod",
      "short" : "Statuskod",
      "definition" : "Statuskod",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "CodeableConcept"
      }],
      "binding" : {
        "strength" : "required",
        "valueSet" : "https://fhir.inera.se/ig/clinicalprocess-healthcond-certificate/ValueSet/statuskod-vs"
      }
    },
    {
      "id" : "certificatestatusupdateforcare-request.intyg.status.tidpunkt",
      "path" : "certificatestatusupdateforcare-request.intyg.status.tidpunkt",
      "short" : "Tidpunkt",
      "definition" : "Tidpunkt",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "dateTime"
      }]
    },
    {
      "id" : "certificatestatusupdateforcare-request.handelse",
      "path" : "certificatestatusupdateforcare-request.handelse",
      "short" : "Information om händelsen som ger upphov till uppdateringen",
      "definition" : "Information om händelsen som ger upphov till uppdateringen",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "BackboneElement"
      }]
    },
    {
      "id" : "certificatestatusupdateforcare-request.handelse.handelsekod",
      "path" : "certificatestatusupdateforcare-request.handelse.handelsekod",
      "short" : "Händelsetyp",
      "definition" : "Händelsetyp",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "CodeableConcept"
      }],
      "binding" : {
        "strength" : "required",
        "valueSet" : "https://fhir.inera.se/ig/clinicalprocess-healthcond-certificate/ValueSet/handelskod-vs"
      }
    },
    {
      "id" : "certificatestatusupdateforcare-request.handelse.tidpunkt",
      "path" : "certificatestatusupdateforcare-request.handelse.tidpunkt",
      "short" : "Tidpunkt då händelsen inträffade",
      "definition" : "Tidpunkt då händelsen inträffade",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "dateTime"
      }]
    },
    {
      "id" : "certificatestatusupdateforcare-request.handelse.amne",
      "path" : "certificatestatusupdateforcare-request.handelse.amne",
      "short" : "Ämne (gäller vid ärendekommunikationshändelser)",
      "definition" : "Ämne (gäller vid ärendekommunikationshändelser)",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "CodeableConcept"
      }],
      "binding" : {
        "strength" : "required",
        "valueSet" : "https://fhir.inera.se/ig/clinicalprocess-healthcond-certificate/ValueSet/amneskod-vs"
      }
    },
    {
      "id" : "certificatestatusupdateforcare-request.handelse.sistaDatumForSvar",
      "path" : "certificatestatusupdateforcare-request.handelse.sistaDatumForSvar",
      "short" : "Sista datum för svar vid kompletteringsbegäran",
      "definition" : "Sista datum för svar vid kompletteringsbegäran",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "date"
      }]
    },
    {
      "id" : "certificatestatusupdateforcare-request.skickadeFragor",
      "path" : "certificatestatusupdateforcare-request.skickadeFragor",
      "short" : "Frågor rörande intyget skickade från vården",
      "definition" : "Frågor rörande intyget skickade från vården",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "BackboneElement"
      }]
    },
    {
      "id" : "certificatestatusupdateforcare-request.skickadeFragor.totalt",
      "path" : "certificatestatusupdateforcare-request.skickadeFragor.totalt",
      "short" : "Totalt antal skickade frågor",
      "definition" : "Totalt antal skickade frågor",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "integer"
      }]
    },
    {
      "id" : "certificatestatusupdateforcare-request.skickadeFragor.ejBesvarade",
      "path" : "certificatestatusupdateforcare-request.skickadeFragor.ejBesvarade",
      "short" : "Antal obesvarade frågor",
      "definition" : "Antal obesvarade frågor",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "integer"
      }]
    },
    {
      "id" : "certificatestatusupdateforcare-request.skickadeFragor.besvarade",
      "path" : "certificatestatusupdateforcare-request.skickadeFragor.besvarade",
      "short" : "Antal besvarade frågor",
      "definition" : "Antal besvarade frågor",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "integer"
      }]
    },
    {
      "id" : "certificatestatusupdateforcare-request.skickadeFragor.hanterade",
      "path" : "certificatestatusupdateforcare-request.skickadeFragor.hanterade",
      "short" : "Antal hanterade frågor",
      "definition" : "Antal hanterade frågor",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "integer"
      }]
    },
    {
      "id" : "certificatestatusupdateforcare-request.mottagnaFragor",
      "path" : "certificatestatusupdateforcare-request.mottagnaFragor",
      "short" : "Frågor rörande intyget skickade från intygsmottagare",
      "definition" : "Frågor rörande intyget skickade från intygsmottagare",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "BackboneElement"
      }]
    },
    {
      "id" : "certificatestatusupdateforcare-request.mottagnaFragor.totalt",
      "path" : "certificatestatusupdateforcare-request.mottagnaFragor.totalt",
      "short" : "Totalt antal mottagna frågor",
      "definition" : "Totalt antal mottagna frågor",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "integer"
      }]
    },
    {
      "id" : "certificatestatusupdateforcare-request.mottagnaFragor.ejBesvarade",
      "path" : "certificatestatusupdateforcare-request.mottagnaFragor.ejBesvarade",
      "short" : "Antal obesvarade mottagna frågor",
      "definition" : "Antal obesvarade mottagna frågor",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "integer"
      }]
    },
    {
      "id" : "certificatestatusupdateforcare-request.mottagnaFragor.besvarade",
      "path" : "certificatestatusupdateforcare-request.mottagnaFragor.besvarade",
      "short" : "Antal besvarade mottagna frågor",
      "definition" : "Antal besvarade mottagna frågor",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "integer"
      }]
    },
    {
      "id" : "certificatestatusupdateforcare-request.mottagnaFragor.hanterade",
      "path" : "certificatestatusupdateforcare-request.mottagnaFragor.hanterade",
      "short" : "Antal hanterade mottagna frågor",
      "definition" : "Antal hanterade mottagna frågor",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "integer"
      }]
    },
    {
      "id" : "certificatestatusupdateforcare-request.ref",
      "path" : "certificatestatusupdateforcare-request.ref",
      "short" : "Referens till entitet i integrerande vårdsystem (t.ex. vårdkontakt-id)",
      "definition" : "Referens till entitet i integrerande vårdsystem (t.ex. vårdkontakt-id)",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "certificatestatusupdateforcare-request.hanteratAv",
      "path" : "certificatestatusupdateforcare-request.hanteratAv",
      "short" : "HSA-id för HoS-personal som hanterar intyget",
      "definition" : "HSA-id för HoS-personal som hanterar intyget",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "Identifier"
      }]
    }]
  }
}

```
