# inera.clinicalprocess-healthcond-certificate#4.1-RC1: clinicalprocess: healthcond: certificate

## Pages

* [Hem](index.md)
* [7 Tjänstekontrakt](7-tjanstekontrakt.md)
* [5 Tjänstedomänens meddelandemodeller](5-tjanstedomanens-meddelandemodeller.md)
* [Artifacts Summary](artifacts.md)
* [6 Gemensamma informationskomponenter](6-gemensamma-informationskomponenter.md)
* [3 Tjänstedomänens arkitektur](3-tjanstedomanens-arkitektur.md)
* [4 Tjänstedomänens krav och regler](4-tjanstedomanens-krav-och-regler.md)
* [2 Versionsinformation](2-versionsinformation.md)
* [1 Inledning](1-inledning.md)

## Resources

### CodeSystems

* [Ämneskod](CodeSystem-amneskod-cs.md)
* [Fel-ID](CodeSystem-errorid-cs.md)
* [Händelsekod](CodeSystem-handelskod-cs.md)
* [Part](CodeSystem-part-cs.md)
* [Resultatkod](CodeSystem-resultkod-cs.md)
* [Statuskod](CodeSystem-statuskod-cs.md)

### ValueSets

* [Ämneskod — ValueSet](ValueSet-amneskod-vs.md)
* [Fel-ID — ValueSet](ValueSet-errorid-vs.md)
* [Händelsekod — ValueSet](ValueSet-handelskod-vs.md)
* [Part — ValueSet](ValueSet-part-vs.md)
* [Resultatkod — ValueSet](ValueSet-resultkod-vs.md)
* [Statuskod — ValueSet](ValueSet-statuskod-vs.md)

### Logicals

* [CertificateStatusUpdateForCare — Request](StructureDefinition-certificatestatusupdateforcare-request.md)
* [CertificateStatusUpdateForCare](StructureDefinition-certificatestatusupdateforcare.md)
* [CreateDraftCertificate — Request](StructureDefinition-createdraftcertificate-request.md)
* [CreateDraftCertificate](StructureDefinition-createdraftcertificate.md)
* [GetCertificate — Request](StructureDefinition-getcertificate-request.md)
* [GetCertificate](StructureDefinition-getcertificate.md)
* [ListCertificatesForCare — Request](StructureDefinition-listcertificatesforcare-request.md)
* [ListCertificatesForCare](StructureDefinition-listcertificatesforcare.md)
* [ListCertificatesForCareWithQA — Request](StructureDefinition-listcertificatesforcarewithqa-request.md)
* [ListCertificatesForCareWithQA](StructureDefinition-listcertificatesforcarewithqa.md)
* [ListCertificatesForCitizen — Request](StructureDefinition-listcertificatesforcitizan-request.md)
* [ListCertificatesForCitizen](StructureDefinition-listcertificatesforcitizan.md)
* [ListSickLeavesForCare — Request](StructureDefinition-listsickleavesforcare-request.md)
* [ListSickLeavesForCare](StructureDefinition-listsickleavesforcare.md)
* [RegisterCertificate — Request](StructureDefinition-registercertificate-request.md)
* [RegisterCertificate](StructureDefinition-registercertificate.md)
* [RevokeCertificate — Request](StructureDefinition-revokecertificate-request.md)
* [RevokeCertificate](StructureDefinition-revokecertificate.md)
* [SendCertificateToRecipient — Request](StructureDefinition-sendcertificatetorecipient-request.md)
* [SendCertificateToRecipient](StructureDefinition-sendcertificatetorecipient.md)
* [SendMessageToCare — Request](StructureDefinition-sendmessagetocare-request.md)
* [SendMessageToCare](StructureDefinition-sendmessagetocare.md)
* [SendMessageToRecipient — Request](StructureDefinition-sendmessagetorecipient-request.md)
* [SendMessageToRecipient](StructureDefinition-sendmessagetorecipient.md)
* [SetCertificateStatus — Request](StructureDefinition-setcertificatestatus-request.md)
* [SetCertificateStatus](StructureDefinition-setcertificatestatus.md)

### ImplementationGuides

* [clinicalprocess: healthcond: certificate](index.md)
