# Hem - clinicalprocess: healthcond: certificate v4.1-RC1

* [**Table of Contents**](toc.md)
* **Hem**

## Hem

| | |
| :--- | :--- |
| *Official URL*:https://fhir.inera.se/ig/clinicalprocess-healthcond-certificate/ImplementationGuide/inera.clinicalprocess-healthcond-certificate | *Version*:4.1-RC1 |
| Draft as of 2026-09-09 | *Computable Name*:clinicalprocesshealthcondcertificate |
| **Copyright/Legal**: Copyright 2024 Inera AB. Licensieras under Creative Commons Attribution 4.0. | |

# clinicalprocess: healthcond: certificate

## Översikt

FHIR Implementation Guide för tjänstedomänen **clinicalprocess: healthcond: certificate** version 4.1-RC1. Genererad från Ineras Tjänstekontraktsbeskrivning (TKB).

Domänen hanterar digitala intyg och tillhörande kommunikation inom hälso- och sjukvården. Den inkluderar tjänstekontrakt för att registrera, hämta, makulera och skicka intyg samt ärendekommunikation kring intyg.

Domänen innehåller följande tjänstekontrakt:

| | | |
| :--- | :--- | :--- |
| [GetCertificate](7-tjanstekontrakt.md#getcertificate) | 2.1 | Hämtar ett enskilt intyg och tillhörande metadata |
| [ListCertificatesForCare](7-tjanstekontrakt.md#listcertificatesforcare) | 3.1 | Listar intyg för en patient på en eller flera enheter (vård) |
| [ListCertificatesForCitizen](7-tjanstekontrakt.md#listcertificatesforcitizan) | 4.0 | Listar intyg för en patient (invånartjänst) |
| [RegisterCertificate](7-tjanstekontrakt.md#registercertificate) | 3.1 | Registrerar ett intyg i en intygstjänst |
| [RevokeCertificate](7-tjanstekontrakt.md#revokecertificate) | 2.1 | Makulerar ett registrerat intyg |
| [SendCertificateToRecipient](7-tjanstekontrakt.md#sendcertificatetorecipient) | 2.1 | Skickar ett intyg till en intygsmottagare |
| [SendMessageToCare](7-tjanstekontrakt.md#sendmessagetocare) | 2.0 | Skickar meddelande från intygsmottagare till vården |
| [SendMessageToRecipient](7-tjanstekontrakt.md#sendmessagetorecipient) | 2.1 | Skickar meddelande från vården till intygsmottagare |
| [SetCertificateStatus](7-tjanstekontrakt.md#setcertificatestatus) | 2.0 | Sätter status för ett intyg |
| [CreateDraftCertificate](7-tjanstekontrakt.md#createdraftcertificate) | 3.2 | Skapar ett intygsutkast i en intygsapplikation |
| [CertificateStatusUpdateForCare](7-tjanstekontrakt.md#certificatestatusupdateforcare) | 3.1 | Skickar uppdateringar om ett intyg och ärendekommunikation |
| [ListCertificatesForCareWithQA](7-tjanstekontrakt.md#listcertificatesforcarewithqa) | 3.2 | Listar intyg med händelser och ärendekommunikation |
| [ListSickLeavesForCare](7-tjanstekontrakt.md#listsickleavesforcare) | 1.0 | Listar pågående sjukfall på en enhet |

## Innehåll

* [1 Inledning](1-inledning.md)
* [2 Versionsinformation](2-versionsinformation.md)
* [3 Tjänstedomänens arkitektur](3-tjanstedomanens-arkitektur.md)
* [4 Tjänstedomänens krav och regler](4-tjanstedomanens-krav-och-regler.md)
* [5 Tjänstedomänens meddelandemodeller](5-tjanstedomanens-meddelandemodeller.md)
* [6 Gemensamma informationskomponenter](6-gemensamma-informationskomponenter.md)
* [7 Tjänstekontrakt](7-tjanstekontrakt.md)
* [Artefakter](artifacts.md)

