# Hem - clinicalprocess: healthcond: certificate v4.1.0-rc1

* [**Table of Contents**](toc.md)
* **Hem**

## Hem

| | |
| :--- | :--- |
| *Official URL*:https://fhir.inera.se/ig/clinicalprocess-healthcond-certificate/ImplementationGuide/inera.clinicalprocess-healthcond-certificate | *Version*:4.1.0-rc1 |
| Draft as of 2026-10-12 | *Computable Name*:clinicalprocesshealthcondcertificate |
| **Copyright/Legal**: Copyright 2024 Inera AB. Licensieras under Creative Commons Attribution 4.0. | |

# clinicalprocess: healthcond: certificate

**TKB-version:** 4.1_RC1 · **IG-version:** 4.1.0-rc1 · **Källa:** Bitbucket-commit `be04ee5a3fad`, efter taggen `4.1_RC1` 

## Översikt

* Beskrivning: Svenskt kortnamn
  * Domänens syfte är att möjliggöra elektronisk hantering av intyg, samt att göra det möjligt för intygsutfärdare och intygsmottagare att kommunicera i arbetet med ett intyg. De informationsflöden som stöds av domänen kan delas in i tre olika perspektiv: Det första är informationsöverföring mellan ett vårdinformationssystem (journalsystem) och en intygsapplikation, vilket gör det möjligt för hälso- och sjukvårdspersonal att hantera delar av intygsutfärdandeprocessen i det system där de huvudsakligen arbetar. Det andra är informationsöverföring mellan en intygsapplikation och en central intygstjänst, vilket möjliggör vidare användning av elektroniska intyg såsom elektronisk överföring till intygsmottagare, åtkomst till elektroniska intyg för patienter, statistikbearbetning, och användning för uppföljning. Det tredje är informationsöverföring mellan en central intygstjänst och system som tillhör intygsmottagare.: Intygshantering
* Beskrivning: Svenskt namn
  * Domänens syfte är att möjliggöra elektronisk hantering av intyg, samt att göra det möjligt för intygsutfärdare och intygsmottagare att kommunicera i arbetet med ett intyg. De informationsflöden som stöds av domänen kan delas in i tre olika perspektiv: Det första är informationsöverföring mellan ett vårdinformationssystem (journalsystem) och en intygsapplikation, vilket gör det möjligt för hälso- och sjukvårdspersonal att hantera delar av intygsutfärdandeprocessen i det system där de huvudsakligen arbetar. Det andra är informationsöverföring mellan en intygsapplikation och en central intygstjänst, vilket möjliggör vidare användning av elektroniska intyg såsom elektronisk överföring till intygsmottagare, åtkomst till elektroniska intyg för patienter, statistikbearbetning, och användning för uppföljning. Det tredje är informationsöverföring mellan en central intygstjänst och system som tillhör intygsmottagare.: vård- och omsorg kärnprocess:hälsorelaterade tillstånd:intygshantering
* Beskrivning: Typ
  * Domänens syfte är att möjliggöra elektronisk hantering av intyg, samt att göra det möjligt för intygsutfärdare och intygsmottagare att kommunicera i arbetet med ett intyg. De informationsflöden som stöds av domänen kan delas in i tre olika perspektiv: Det första är informationsöverföring mellan ett vårdinformationssystem (journalsystem) och en intygsapplikation, vilket gör det möjligt för hälso- och sjukvårdspersonal att hantera delar av intygsutfärdandeprocessen i det system där de huvudsakligen arbetar. Det andra är informationsöverföring mellan en intygsapplikation och en central intygstjänst, vilket möjliggör vidare användning av elektroniska intyg såsom elektronisk överföring till intygsmottagare, åtkomst till elektroniska intyg för patienter, statistikbearbetning, och användning för uppföljning. Det tredje är informationsöverföring mellan en central intygstjänst och system som tillhör intygsmottagare.: Nationell tjänstedomän
* Beskrivning: Källkod
  * Domänens syfte är att möjliggöra elektronisk hantering av intyg, samt att göra det möjligt för intygsutfärdare och intygsmottagare att kommunicera i arbetet med ett intyg. De informationsflöden som stöds av domänen kan delas in i tre olika perspektiv: Det första är informationsöverföring mellan ett vårdinformationssystem (journalsystem) och en intygsapplikation, vilket gör det möjligt för hälso- och sjukvårdspersonal att hantera delar av intygsutfärdandeprocessen i det system där de huvudsakligen arbetar. Det andra är informationsöverföring mellan en intygsapplikation och en central intygstjänst, vilket möjliggör vidare användning av elektroniska intyg såsom elektronisk överföring till intygsmottagare, åtkomst till elektroniska intyg för patienter, statistikbearbetning, och användning för uppföljning. Det tredje är informationsöverföring mellan en central intygstjänst och system som tillhör intygsmottagare.: [Bitbucket](https://bitbucket.org/rivta-domains/riv.clinicalprocess.healthcond.certificate/src)
* Beskrivning: Ärenden
  * Domänens syfte är att möjliggöra elektronisk hantering av intyg, samt att göra det möjligt för intygsutfärdare och intygsmottagare att kommunicera i arbetet med ett intyg. De informationsflöden som stöds av domänen kan delas in i tre olika perspektiv: Det första är informationsöverföring mellan ett vårdinformationssystem (journalsystem) och en intygsapplikation, vilket gör det möjligt för hälso- och sjukvårdspersonal att hantera delar av intygsutfärdandeprocessen i det system där de huvudsakligen arbetar. Det andra är informationsöverföring mellan en intygsapplikation och en central intygstjänst, vilket möjliggör vidare användning av elektroniska intyg såsom elektronisk överföring till intygsmottagare, åtkomst till elektroniska intyg för patienter, statistikbearbetning, och användning för uppföljning. Det tredje är informationsöverföring mellan en central intygstjänst och system som tillhör intygsmottagare.: [Bitbucket issues](https://bitbucket.org/rivta-domains/riv.clinicalprocess.healthcond.certificate/issues)
* Beskrivning: Underlag för denna IG
  * Domänens syfte är att möjliggöra elektronisk hantering av intyg, samt att göra det möjligt för intygsutfärdare och intygsmottagare att kommunicera i arbetet med ett intyg. De informationsflöden som stöds av domänen kan delas in i tre olika perspektiv: Det första är informationsöverföring mellan ett vårdinformationssystem (journalsystem) och en intygsapplikation, vilket gör det möjligt för hälso- och sjukvårdspersonal att hantera delar av intygsutfärdandeprocessen i det system där de huvudsakligen arbetar. Det andra är informationsöverföring mellan en intygsapplikation och en central intygstjänst, vilket möjliggör vidare användning av elektroniska intyg såsom elektronisk överföring till intygsmottagare, åtkomst till elektroniska intyg för patienter, statistikbearbetning, och användning för uppföljning. Det tredje är informationsöverföring mellan en central intygstjänst och system som tillhör intygsmottagare.: Version 4.1_RC1 ·[tagg 4.1_RC1](https://bitbucket.org/rivta-domains/riv.clinicalprocess.healthcond.certificate/src/4.1_RC1)
* Beskrivning: RIV-TA-portalen
  * Domänens syfte är att möjliggöra elektronisk hantering av intyg, samt att göra det möjligt för intygsutfärdare och intygsmottagare att kommunicera i arbetet med ett intyg. De informationsflöden som stöds av domänen kan delas in i tre olika perspektiv: Det första är informationsöverföring mellan ett vårdinformationssystem (journalsystem) och en intygsapplikation, vilket gör det möjligt för hälso- och sjukvårdspersonal att hantera delar av intygsutfärdandeprocessen i det system där de huvudsakligen arbetar. Det andra är informationsöverföring mellan en intygsapplikation och en central intygstjänst, vilket möjliggör vidare användning av elektroniska intyg såsom elektronisk överföring till intygsmottagare, åtkomst till elektroniska intyg för patienter, statistikbearbetning, och användning för uppföljning. Det tredje är informationsöverföring mellan en central intygstjänst och system som tillhör intygsmottagare.: [Alla tjänstedomäner](https://oskthu2.github.io/tkb-converter/rivta-portal/tjanstedomaner.html)·[Alla tjänstekontrakt](https://oskthu2.github.io/tkb-converter/rivta-portal/tjanstekontrakt.html)

FHIR Implementation Guide för tjänstedomänen **clinicalprocess: healthcond: certificate** version 4.1_RC1. Genererad från Ineras Tjänstekontraktsbeskrivning (TKB).

Domänen hanterar digitala intyg och tillhörande kommunikation inom hälso- och sjukvården. Den inkluderar tjänstekontrakt för att registrera, hämta, makulera och skicka intyg samt ärendekommunikation kring intyg.

Domänen innehåller följande tjänstekontrakt:

| | | |
| :--- | :--- | :--- |
| [GetCertificate](7-tjanstekontrakt.md#getcertificate) | 2.1 | Hämtar ett enskilt intyg och tillhörande metadata |
| [ListCertificatesForCare](7-tjanstekontrakt.md#listcertificatesforcare) | 3.1 | Listar intyg för en patient på en eller flera enheter (vård) |
| [ListCertificatesForCitizen](7-tjanstekontrakt.md#listcertificatesforcitizen) | 4.0 | Listar intyg för en patient (invånartjänst) |
| [RegisterCertificate](7-tjanstekontrakt.md#registercertificate) | 3.1 | Registrerar ett intyg i en intygstjänst |
| [RevokeCertificate](7-tjanstekontrakt.md#revokecertificate) | 2.1 | Makulerar ett registrerat intyg |
| [SendCertificateToRecipient](7-tjanstekontrakt.md#sendcertificatetorecipient) | 2.1 | Skickar ett intyg till en intygsmottagare |
| [SendMessageToCare](7-tjanstekontrakt.md#sendmessagetocare) | 2.0 | Skickar meddelande från intygsmottagare till vården |
| [SendMessageToRecipient](7-tjanstekontrakt.md#sendmessagetorecipient) | 2.1 | Skickar meddelande från vården till intygsmottagare |
| [SetCertificateStatus](7-tjanstekontrakt.md#setcertificatestatus) | 2.0 | Sätter status för ett intyg |
| [CreateDraftCertificate](7-tjanstekontrakt.md#createdraftcertificate) | 3.2 | Skapar ett intygsutkast i en intygsapplikation |
| [CertificateStatusUpdateForCare](7-tjanstekontrakt.md#certificatestatusupdateforcare) | 3.1 | Skickar uppdateringar om ett intyg och ärendekommunikation |
| [ListCertificatesForCareWithQA](7-tjanstekontrakt.md#listcertificatesforcarewithqa) | 3.2 | Listar intyg med händelser och ärendekommunikation |
| [ListSickLeavesForCare](7-tjanstekontrakt.md#listsickleavesforcare) | 1.0 | Listar pågående sjukfall på en enhet |

### Versioner och granskningar

| | | | |
| :--- | :--- | :--- | :--- |
| 4.0.5 | AB, TKB, IS | [Arkitektur & Regelverk: Teknik: Godkänd](http://rivta.se/downloads//clinicalprocess_healthcond_certificate/4.0.5/T-granskning_clinicalprocess_healthcond_certificate_4.0.5.docx)[Arkitektur & Regelverk: Säkerhet: Godkänd](http://rivta.se/downloads//clinicalprocess_healthcond_certificate/4.0.5/VIS_granskning_clinicalprocess.healthcond.certificate_4.0.5.docx)[Arkitektur & Regelverk: Informatik: Godkänd](http://rivta.se/downloads//clinicalprocess_healthcond_certificate/4.0.5/VIS_granskning_clinicalprocess.healthcond.certificate_4.0.5.docx) | [zip](http://rivta.se/downloads//clinicalprocess_healthcond_certificate/4.0.5/ServiceContracts_clinicalprocess_healthcond_certificate_4.0.5.zip)·[källkod](https://bitbucket.org/rivta-domains/riv.clinicalprocess.healthcond.certificate/src/4.0.5) |
| 4.0.4 | AB, IS, TKB | [Arkitektur & Regelverk: Teknik: Godkänd](http://rivta.se/downloads//clinicalprocess_healthcond_certificate/4.0.4/T-granskning_clinicalprocess_healthcond_certificate_4.0.4.dotx) | [zip](http://rivta.se/downloads//clinicalprocess_healthcond_certificate/4.0.4/ServiceContracts_clinicalprocess_healthcond_certificate_4.0.4.zip)·[källkod](https://bitbucket.org/rivta-domains/riv.clinicalprocess.healthcond.certificate/src/4.0.4) |
| trunk | AB, IS, TKB |  | [källkod](https://bitbucket.org/rivta-domains/riv.clinicalprocess.healthcond.certificate/src/master) |

*Källa: ögonblicksbild av DOMDB från 2021-08-24, via RIV-TA-portalen.*

## Innehåll

* [1 Inledning](1-inledning.md)
* [2 Versionsinformation](2-versionsinformation.md)
* [3 Tjänstedomänens arkitektur](3-tjanstedomanens-arkitektur.md)
* [4 Tjänstedomänens krav och regler](4-tjanstedomanens-krav-och-regler.md)
* [5 Tjänstedomänens meddelandemodeller](5-tjanstedomanens-meddelandemodeller.md)
* [6 Gemensamma informationskomponenter](6-gemensamma-informationskomponenter.md)
* [7 Tjänstekontrakt](7-tjanstekontrakt.md)
* [Artefakter](artifacts.md)

