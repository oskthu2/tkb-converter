# Hem - infrastructure: directory: synchronization v1.0.0-rc3

* [**Table of Contents**](toc.md)
* **Hem**

## Hem

| | |
| :--- | :--- |
| *Official URL*:https://fhir.inera.se/ig/infrastructure-directory-synchronization/ImplementationGuide/inera.infrastructure-directory-synchronization | *Version*:1.0.0-rc3 |
| Draft as of 2026-10-08 | *Computable Name*:infrastructuredirectorysynchronization |
| **Copyright/Legal**: Copyright 2024 Inera AB. Licensieras under Creative Commons Attribution 4.0. | |

# infrastructure: directory: synchronization

**TKB-version:** 1.0_RC3 · **IG-version:** 1.0.0-rc3 · **Källa:** Bitbucket-tagg `1.0_RC3` 

## Översikt

FHIR Implementation Guide för tjänstedomänen **infrastructure: directory: synchronization** (katalogtjänstsynkronisering) version 1.0_RC3. Genererad från Ineras Tjänstekontraktsbeskrivning (TKB), version 1.0_RC3 (2018-09-21), och domänens WSDL- och XSD-filer (tagg 1.0_RC3).

Domänen låter ett system med lokala kopior av masterdata (t.ex. vård- och omsorgsutbud) hämta information om vilka poster som har skapats, ändrats eller tagits bort i masterdatakällan under en tidsperiod. Domänen finns bara som release candidate.

Domänen innehåller följande tjänstekontrakt:

| | | |
| :--- | :--- | :--- |
| [GetMasterDataChangeSet](7-tjanstekontrakt.md#getmasterdatachangeset) | 1.0 | Hämtar information om masterdata som förändrats i en masterdatakälla baserat på sökkriterier. Sökkriterierna specificerar typ av förändring, datum för förändringen samt vilken typ av masterdata som efterfrågas. Masterdatakällan svarar med en lista innehållande id på poster som förändrats enligt sökkriterierna. |

## Innehåll

* [1 Inledning](1-inledning.md)
* [2 Versionsinformation](2-versionsinformation.md)
* [3 Tjänstedomänens arkitektur](3-tjanstedomanens-arkitektur.md)
* [4 Tjänstedomänens krav och regler](4-tjanstedomanens-krav-och-regler.md)
* [5 Tjänstedomänens meddelandemodeller](5-tjanstedomanens-meddelandemodeller.md)
* [6 Gemensamma informationskomponenter](6-gemensamma-informationskomponenter.md)
* [7 Tjänstekontrakt](7-tjanstekontrakt.md)
* [Artefakter](artifacts.md)

