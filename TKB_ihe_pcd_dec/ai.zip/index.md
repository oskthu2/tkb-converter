# Hem - ihe: pcd: dec v1.0.1

* [**Table of Contents**](toc.md)
* **Hem**

## Hem

| | |
| :--- | :--- |
| *Official URL*:https://fhir.inera.se/ig/ihe-pcd-dec/ImplementationGuide/inera.ihe-pcd-dec | *Version*:1.0.1 |
| Active as of 2026-10-12 | *Computable Name*:ihepcddec |
| **Copyright/Legal**: Copyright 2024 Inera AB. Licensieras under Creative Commons Attribution 4.0. | |

# ihe: pcd: dec

**TKB-version:** 1.0.1 · **IG-version:** 1.0.1 · **Källa:** Bitbucket-tagg `1.0.1` 

## Översikt

* Beskrivning: Svenskt kortnamn
  * Denna tjänstedomän beskriver den svenska tillämpningen av IHE-profilen PCD-01 inom ramen för Continua Guidelines 2016, Observation Upload. Domänen innehåller ett tjänstekontrakt för inrapportering av mätdata från personliga insamlingspunkter (exempelvis "back-end" från en monitoreringsapp med anslutna sensorer) och från medicinteknisk utrustning. Tjänsteproducenten som tar emot inrapporterad mätdata är ett försystem till journalsystemet. Mottagen mätdata kan tillämpas som kliniskt beslutsunderlag men blir inte en journalhandling i och med mottagandet.: mätdata från mätutrustning
* Beskrivning: Svenskt namn
  * Denna tjänstedomän beskriver den svenska tillämpningen av IHE-profilen PCD-01 inom ramen för Continua Guidelines 2016, Observation Upload. Domänen innehåller ett tjänstekontrakt för inrapportering av mätdata från personliga insamlingspunkter (exempelvis "back-end" från en monitoreringsapp med anslutna sensorer) och från medicinteknisk utrustning. Tjänsteproducenten som tar emot inrapporterad mätdata är ett försystem till journalsystemet. Mottagen mätdata kan tillämpas som kliniskt beslutsunderlag men blir inte en journalhandling i och med mottagandet.: vård- och omsorg kärnprocess: hantera hälsorelaterade tillstånd
* Beskrivning: Typ
  * Denna tjänstedomän beskriver den svenska tillämpningen av IHE-profilen PCD-01 inom ramen för Continua Guidelines 2016, Observation Upload. Domänen innehåller ett tjänstekontrakt för inrapportering av mätdata från personliga insamlingspunkter (exempelvis "back-end" från en monitoreringsapp med anslutna sensorer) och från medicinteknisk utrustning. Tjänsteproducenten som tar emot inrapporterad mätdata är ett försystem till journalsystemet. Mottagen mätdata kan tillämpas som kliniskt beslutsunderlag men blir inte en journalhandling i och med mottagandet.: Nationell tjänstedomän
* Beskrivning: Anmärkning
  * Denna tjänstedomän beskriver den svenska tillämpningen av IHE-profilen PCD-01 inom ramen för Continua Guidelines 2016, Observation Upload. Domänen innehåller ett tjänstekontrakt för inrapportering av mätdata från personliga insamlingspunkter (exempelvis "back-end" från en monitoreringsapp med anslutna sensorer) och från medicinteknisk utrustning. Tjänsteproducenten som tar emot inrapporterad mätdata är ett försystem till journalsystemet. Mottagen mätdata kan tillämpas som kliniskt beslutsunderlag men blir inte en journalhandling i och med mottagandet.: dold på rivta.se
* Beskrivning: Källkod
  * Denna tjänstedomän beskriver den svenska tillämpningen av IHE-profilen PCD-01 inom ramen för Continua Guidelines 2016, Observation Upload. Domänen innehåller ett tjänstekontrakt för inrapportering av mätdata från personliga insamlingspunkter (exempelvis "back-end" från en monitoreringsapp med anslutna sensorer) och från medicinteknisk utrustning. Tjänsteproducenten som tar emot inrapporterad mätdata är ett försystem till journalsystemet. Mottagen mätdata kan tillämpas som kliniskt beslutsunderlag men blir inte en journalhandling i och med mottagandet.: [Bitbucket](https://bitbucket.org/rivta-domains/riv.ihe.pcd.dec/src)
* Beskrivning: Ärenden
  * Denna tjänstedomän beskriver den svenska tillämpningen av IHE-profilen PCD-01 inom ramen för Continua Guidelines 2016, Observation Upload. Domänen innehåller ett tjänstekontrakt för inrapportering av mätdata från personliga insamlingspunkter (exempelvis "back-end" från en monitoreringsapp med anslutna sensorer) och från medicinteknisk utrustning. Tjänsteproducenten som tar emot inrapporterad mätdata är ett försystem till journalsystemet. Mottagen mätdata kan tillämpas som kliniskt beslutsunderlag men blir inte en journalhandling i och med mottagandet.: [Bitbucket issues](https://bitbucket.org/rivta-domains/riv.ihe.pcd.dec/issues)
* Beskrivning: Underlag för denna IG
  * Denna tjänstedomän beskriver den svenska tillämpningen av IHE-profilen PCD-01 inom ramen för Continua Guidelines 2016, Observation Upload. Domänen innehåller ett tjänstekontrakt för inrapportering av mätdata från personliga insamlingspunkter (exempelvis "back-end" från en monitoreringsapp med anslutna sensorer) och från medicinteknisk utrustning. Tjänsteproducenten som tar emot inrapporterad mätdata är ett försystem till journalsystemet. Mottagen mätdata kan tillämpas som kliniskt beslutsunderlag men blir inte en journalhandling i och med mottagandet.: Version 1.0.1 ·[tagg 1.0.1](https://bitbucket.org/rivta-domains/riv.ihe.pcd.dec/src/1.0.1)·[zip](https://bitbucket.org/rivta-domains/riv.ihe.pcd.dec/get/1.0.1.zip)
* Beskrivning: RIV-TA-portalen
  * Denna tjänstedomän beskriver den svenska tillämpningen av IHE-profilen PCD-01 inom ramen för Continua Guidelines 2016, Observation Upload. Domänen innehåller ett tjänstekontrakt för inrapportering av mätdata från personliga insamlingspunkter (exempelvis "back-end" från en monitoreringsapp med anslutna sensorer) och från medicinteknisk utrustning. Tjänsteproducenten som tar emot inrapporterad mätdata är ett försystem till journalsystemet. Mottagen mätdata kan tillämpas som kliniskt beslutsunderlag men blir inte en journalhandling i och med mottagandet.: [Alla tjänstedomäner](https://oskthu2.github.io/tkb-converter/rivta-portal/tjanstedomaner.html)·[Alla tjänstekontrakt](https://oskthu2.github.io/tkb-converter/rivta-portal/tjanstekontrakt.html)

FHIR Implementation Guide för tjänstedomänen **ihe: pcd: dec** (Mätdata från mätutrustning) version 1.0.1. Genererad från Ineras Tjänstekontraktsbeskrivning (TKB), version 1.0.1 (2017-10-18), och domänens WSDL- och XSD-filer (tagg 1.0.1).

Tjänstedomänen överför observationer och mätdata från mätutrustning, till exempel i hemmet, till verksamhetens system med IHE-profilen PCD-01 (HL7 v2.6 ORU^R01) enligt Continua Design Guidelines.

Domänen innehåller följande tjänstekontrakt:

| | | |
| :--- | :--- | :--- |
| [DeviceObservationConsumer](7-tjanstekontrakt.md#deviceobservationconsumer) | 1.0 | Detta tjänstekontrakt avser att stödja överföring av observationer och mätdata ifrån ett producerande system eller mellanlagrande system med hjälp av profilen IHE-PCD-01 och uppträder således i segmentet Services-IF enligt Continuas e2e arkitektur. |

### Versioner och granskningar

| | | | |
| :--- | :--- | :--- | :--- |
| 1.0 | AB, TKB | [Arkitektur & Regelverk: Teknik: Godkänd](http://rivta.se/downloads//ihe_pcd_dec/1.0/T-granskning%20-%20riv.ihe.pcd.dec_1.0.docx) | [zip](http://rivta.se/downloads//ihe_pcd_dec/1.0/ServiceContracts_IHE_PCD_DEC_1.0.zip)·[källkod](https://bitbucket.org/rivta-domains/riv.ihe.pcd.dec/src/1.0) |
| trunk | AB, TKB |  | [källkod](https://bitbucket.org/rivta-domains/riv.ihe.pcd.dec/src/master) |

*Källa: ögonblicksbild av DOMDB från 2021-08-24, via RIV-TA-portalen.*

## Innehåll

* [1 Inledning](1-inledning.md)
* [2 Versionsinformation](2-versionsinformation.md)
* [3 Tjänstedomänens arkitektur](3-tjanstedomanens-arkitektur.md)
* [4 Tjänstedomänens krav och regler](4-tjanstedomanens-krav-och-regler.md)
* [5 Tjänstedomänens meddelandemodeller](5-tjanstedomanens-meddelandemodeller.md)
* [6 Gemensamma informationskomponenter](6-gemensamma-informationskomponenter.md)
* [7 Tjänstekontrakt](7-tjanstekontrakt.md)
* [Artefakter](artifacts.md)

