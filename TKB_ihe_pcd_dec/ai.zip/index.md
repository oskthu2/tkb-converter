# Hem - ihe: pcd: dec v1.0.1

* [**Table of Contents**](toc.md)
* **Hem**

## Hem

| | |
| :--- | :--- |
| *Official URL*:https://fhir.inera.se/ig/ihe-pcd-dec/ImplementationGuide/inera.ihe-pcd-dec | *Version*:1.0.1 |
| Active as of 2026-10-08 | *Computable Name*:ihepcddec |
| **Copyright/Legal**: Copyright 2024 Inera AB. Licensieras under Creative Commons Attribution 4.0. | |

# ihe: pcd: dec

**TKB-version:** 1.0.1 · **IG-version:** 1.0.1 · **Källa:** Bitbucket-tagg `1.0.1` 

## Översikt

FHIR Implementation Guide för tjänstedomänen **ihe: pcd: dec** (Mätdata från mätutrustning) version 1.0.1. Genererad från Ineras Tjänstekontraktsbeskrivning (TKB), version 1.0.1 (2017-10-18), och domänens WSDL- och XSD-filer (tagg 1.0.1).

Tjänstedomänen överför observationer och mätdata från mätutrustning, till exempel i hemmet, till verksamhetens system med IHE-profilen PCD-01 (HL7 v2.6 ORU^R01) enligt Continua Design Guidelines.

Domänen innehåller följande tjänstekontrakt:

| | | |
| :--- | :--- | :--- |
| [DeviceObservationConsumer](7-tjanstekontrakt.md#deviceobservationconsumer) | 1.0 | Detta tjänstekontrakt avser att stödja överföring av observationer och mätdata ifrån ett producerande system eller mellanlagrande system med hjälp av profilen IHE-PCD-01 och uppträder således i segmentet Services-IF enligt Continuas e2e arkitektur. |

## Innehåll

* [1 Inledning](1-inledning.md)
* [2 Versionsinformation](2-versionsinformation.md)
* [3 Tjänstedomänens arkitektur](3-tjanstedomanens-arkitektur.md)
* [4 Tjänstedomänens krav och regler](4-tjanstedomanens-krav-och-regler.md)
* [5 Tjänstedomänens meddelandemodeller](5-tjanstedomanens-meddelandemodeller.md)
* [6 Gemensamma informationskomponenter](6-gemensamma-informationskomponenter.md)
* [7 Tjänstekontrakt](7-tjanstekontrakt.md)
* [Artefakter](artifacts.md)

