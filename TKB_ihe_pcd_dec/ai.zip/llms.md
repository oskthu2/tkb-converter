# inera.ihe-pcd-dec#1.0.1: ihe: pcd: dec

## Pages

* [Hem](index.md)
* [7 Tjänstekontrakt](7-tjanstekontrakt.md)
* [5 Tjänstedomänens meddelandemodeller](5-tjanstedomanens-meddelandemodeller.md)
* [Artifacts Summary](artifacts.md)
* [6 Gemensamma informationskomponenter](6-gemensamma-informationskomponenter.md)
* [3 Tjänstedomänens arkitektur](3-tjanstedomanens-arkitektur.md)
* [4 Tjänstedomänens krav och regler](4-tjanstedomanens-krav-och-regler.md)
* [2 Versionsinformation](2-versionsinformation.md)
* [1 Inledning](1-inledning.md)

## Resources

### Logicals

* [DeviceObservationConsumer — Request](StructureDefinition-deviceobservationconsumer-request.md)
* [DeviceObservationConsumer — Response](StructureDefinition-deviceobservationconsumer.md)

### ImplementationGuides

* [ihe: pcd: dec](index.md)
