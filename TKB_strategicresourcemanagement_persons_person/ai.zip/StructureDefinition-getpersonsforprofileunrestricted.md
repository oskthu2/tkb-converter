# GetPersonsForProfileUnrestricted — Response - strategicresourcemanagement: persons: person v5.1.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **GetPersonsForProfileUnrestricted — Response**

## Logical Model: GetPersonsForProfileUnrestricted — Response 

| | |
| :--- | :--- |
| *Official URL*:https://fhir.inera.se/ig/strategicresourcemanagement-persons-person/StructureDefinition/getpersonsforprofileunrestricted | *Version*:5.1.0 |
| Draft as of 2026-09-28 | *Computable Name*:GetPersonsForProfileUnrestricted |
| **Copyright/Legal**: Copyright 2024 Inera AB. Licensieras under Creative Commons Attribution 4.0. | |

 
Logisk modell för svaret i GetPersonsForProfileUnrestricted (urn:riv:strategicresourcemanagement:persons:person:GetPersonsForProfileUnrestrictedResponder:5, GetPersonsForProfileUnrestrictedResponseType). 

**Usages:**

* This Logical Model is not used by any profiles in this Specification

You can also check for [usages in the FHIR IG Statistics](https://packages2.fhir.org/xig/resource/inera.strategicresourcemanagement-persons-person|current/StructureDefinition/StructureDefinition-getpersonsforprofileunrestricted.json)

### Formal Views of Profile Content

 [Description of Profiles, Differentials, Snapshots and how the different presentations work](http://build.fhir.org/ig/FHIR/ig-guidance/readingIgs.html#structure-definitions). 

 

Other representations of profile: [CSV](StructureDefinition-getpersonsforprofileunrestricted.csv), [Excel](StructureDefinition-getpersonsforprofileunrestricted.xlsx) 



## Resource Content

```json
{
  "resourceType" : "StructureDefinition",
  "id" : "getpersonsforprofileunrestricted",
  "extension" : [{
    "url" : "http://hl7.org/fhir/StructureDefinition/structuredefinition-type-characteristics",
    "valueCode" : "can-be-target"
  }],
  "url" : "https://fhir.inera.se/ig/strategicresourcemanagement-persons-person/StructureDefinition/getpersonsforprofileunrestricted",
  "version" : "5.1.0",
  "name" : "GetPersonsForProfileUnrestricted",
  "title" : "GetPersonsForProfileUnrestricted — Response",
  "status" : "draft",
  "date" : "2026-09-28T09:23:04+00:00",
  "contact" : [{
    "name" : "Inera Arkitektur",
    "telecom" : [{
      "system" : "url",
      "value" : "https://www.inera.se"
    }]
  }],
  "description" : "Logisk modell för svaret i GetPersonsForProfileUnrestricted\n(urn:riv:strategicresourcemanagement:persons:person:GetPersonsForProfileUnrestrictedResponder:5, GetPersonsForProfileUnrestrictedResponseType).",
  "copyright" : "Copyright 2024 Inera AB. Licensieras under Creative Commons Attribution 4.0.",
  "fhirVersion" : "4.0.1",
  "kind" : "logical",
  "abstract" : false,
  "type" : "https://fhir.inera.se/ig/strategicresourcemanagement-persons-person/StructureDefinition/getpersonsforprofileunrestricted",
  "baseDefinition" : "http://hl7.org/fhir/StructureDefinition/Base",
  "derivation" : "specialization",
  "differential" : {
    "element" : [{
      "id" : "getpersonsforprofileunrestricted",
      "path" : "getpersonsforprofileunrestricted",
      "short" : "GetPersonsForProfileUnrestricted — Response",
      "definition" : "Logisk modell för svaret i GetPersonsForProfileUnrestricted\n(urn:riv:strategicresourcemanagement:persons:person:GetPersonsForProfileUnrestrictedResponder:5, GetPersonsForProfileUnrestrictedResponseType)."
    },
    {
      "id" : "getpersonsforprofileunrestricted.requestedPersonRecord",
      "path" : "getpersonsforprofileunrestricted.requestedPersonRecord",
      "short" : "requestedPersonRecord",
      "definition" : "requestedPersonRecord",
      "min" : 1,
      "max" : "*",
      "type" : [{
        "code" : "BackboneElement"
      }]
    },
    {
      "id" : "getpersonsforprofileunrestricted.requestedPersonRecord.requestedPersonalIdentity",
      "path" : "getpersonsforprofileunrestricted.requestedPersonRecord.requestedPersonalIdentity",
      "short" : "requestedPersonalIdentity",
      "definition" : "En universellt unik identifierare.",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "BackboneElement"
      }]
    },
    {
      "id" : "getpersonsforprofileunrestricted.requestedPersonRecord.requestedPersonalIdentity.root",
      "path" : "getpersonsforprofileunrestricted.requestedPersonRecord.requestedPersonalIdentity.root",
      "short" : "root",
      "definition" : "root",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "getpersonsforprofileunrestricted.requestedPersonRecord.requestedPersonalIdentity.iiExtension",
      "path" : "getpersonsforprofileunrestricted.requestedPersonRecord.requestedPersonalIdentity.iiExtension",
      "short" : "iiExtension",
      "definition" : "iiExtension Heter extension i schemat.",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord",
      "path" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord",
      "short" : "personRecord",
      "definition" : "Grupp för personpost",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "BackboneElement"
      }]
    },
    {
      "id" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.personalIdentity",
      "path" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.personalIdentity",
      "short" : "personalIdentity",
      "definition" : "En universellt unik identifierare.",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "BackboneElement"
      }]
    },
    {
      "id" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.personalIdentity.root",
      "path" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.personalIdentity.root",
      "short" : "root",
      "definition" : "root",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.personalIdentity.iiExtension",
      "path" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.personalIdentity.iiExtension",
      "short" : "iiExtension",
      "definition" : "iiExtension Heter extension i schemat.",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.identityLevel",
      "path" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.identityLevel",
      "short" : "identityLevel",
      "definition" : "identityLevel",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.identityLevelDate",
      "path" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.identityLevelDate",
      "short" : "identityLevelDate",
      "definition" : "Kan beskriva ett datum med variabel noggrannhet.",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "BackboneElement"
      }]
    },
    {
      "id" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.identityLevelDate.format",
      "path" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.identityLevelDate.format",
      "short" : "format",
      "definition" : "format",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "code"
      }],
      "binding" : {
        "strength" : "required",
        "valueSet" : "https://fhir.inera.se/ig/strategicresourcemanagement-persons-person/ValueSet/SPP-datetypeformat-vs"
      }
    },
    {
      "id" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.identityLevelDate.partialDateValue",
      "path" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.identityLevelDate.partialDateValue",
      "short" : "partialDateValue",
      "definition" : "partialDateValue Heter value i schemat.",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.gender",
      "path" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.gender",
      "short" : "gender",
      "definition" : "gender",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.protectedPersonIndicator",
      "path" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.protectedPersonIndicator",
      "short" : "protectedPersonIndicator",
      "definition" : "protectedPersonIndicator",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "boolean"
      }]
    },
    {
      "id" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.testIndicator",
      "path" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.testIndicator",
      "short" : "testIndicator",
      "definition" : "testIndicator",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "boolean"
      }]
    },
    {
      "id" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.primaryIdentity",
      "path" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.primaryIdentity",
      "short" : "primaryIdentity",
      "definition" : "primaryIdentity",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "boolean"
      }]
    },
    {
      "id" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.personRecordVersion",
      "path" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.personRecordVersion",
      "short" : "personRecordVersion",
      "definition" : "personRecordVersion Heter version i schemat.",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.personRecordName",
      "path" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.personRecordName",
      "short" : "personRecordName",
      "definition" : "Namn Heter name i schemat.",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "BackboneElement"
      }]
    },
    {
      "id" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.personRecordName.givenNameIndicator",
      "path" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.personRecordName.givenNameIndicator",
      "short" : "givenNameIndicator",
      "definition" : "givenNameIndicator",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "integer"
      }]
    },
    {
      "id" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.personRecordName.givenName",
      "path" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.personRecordName.givenName",
      "short" : "givenName",
      "definition" : "givenName",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.personRecordName.middleName",
      "path" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.personRecordName.middleName",
      "short" : "middleName",
      "definition" : "middleName",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.personRecordName.surname",
      "path" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.personRecordName.surname",
      "short" : "surname",
      "definition" : "surname",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.personRecordName.notificationName",
      "path" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.personRecordName.notificationName",
      "short" : "notificationName",
      "definition" : "notificationName",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.linkedIdentity",
      "path" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.linkedIdentity",
      "short" : "linkedIdentity",
      "definition" : "Klass för att koppla ihop 2 identiteter. Ex en nationell reservidentitet till ett PNR",
      "min" : 0,
      "max" : "*",
      "type" : [{
        "code" : "BackboneElement"
      }]
    },
    {
      "id" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.linkedIdentity.referredPersonalIdentity",
      "path" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.linkedIdentity.referredPersonalIdentity",
      "short" : "referredPersonalIdentity",
      "definition" : "En universellt unik identifierare.",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "BackboneElement"
      }]
    },
    {
      "id" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.linkedIdentity.referredPersonalIdentity.root",
      "path" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.linkedIdentity.referredPersonalIdentity.root",
      "short" : "root",
      "definition" : "root",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.linkedIdentity.referredPersonalIdentity.iiExtension",
      "path" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.linkedIdentity.referredPersonalIdentity.iiExtension",
      "short" : "iiExtension",
      "definition" : "iiExtension Heter extension i schemat.",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.linkedIdentity.assuranceLevel",
      "path" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.linkedIdentity.assuranceLevel",
      "short" : "assuranceLevel",
      "definition" : "assuranceLevel",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.linkedIdentity.primaryIdentity",
      "path" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.linkedIdentity.primaryIdentity",
      "short" : "primaryIdentity",
      "definition" : "primaryIdentity",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "boolean"
      }]
    },
    {
      "id" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.referredPersonalIdentities",
      "path" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.referredPersonalIdentities",
      "short" : "referredPersonalIdentities",
      "definition" : "Klass för Hänvisningspersonnummer. För de personer som bytt personnummer anges tidigare personnummer/samordningsnummer som hänvisningspersonnummer. Det gamla personnumret/samordningsnumret utgör även det en egen personpost. I det fallet anges det nya personnumret som hänvisningspersonnummer. En person kan få nytt personnummer efter exempelvis ändring av en persons födelsetid eller vid beslut om ändrad könstillhörighet. Klassen håller ihop personidentiteter av typerna personnummer och samordningsnummer enligt Skatteverket till skillnad från klassen KoppladIdenitet som är Personuppgiftstjänstens egna klass för att kunna koppla ihop alla typer av personidentiteter (inkl. reservidentiteter).",
      "min" : 0,
      "max" : "*",
      "type" : [{
        "code" : "BackboneElement"
      }]
    },
    {
      "id" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.referredPersonalIdentities.referredPersonalIdentity",
      "path" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.referredPersonalIdentities.referredPersonalIdentity",
      "short" : "referredPersonalIdentity",
      "definition" : "En universellt unik identifierare.",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "BackboneElement"
      }]
    },
    {
      "id" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.referredPersonalIdentities.referredPersonalIdentity.root",
      "path" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.referredPersonalIdentities.referredPersonalIdentity.root",
      "short" : "root",
      "definition" : "root",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.referredPersonalIdentities.referredPersonalIdentity.iiExtension",
      "path" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.referredPersonalIdentities.referredPersonalIdentity.iiExtension",
      "short" : "iiExtension",
      "definition" : "iiExtension Heter extension i schemat.",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.referredPersonalIdentities.referredPersonalIdentityStatus",
      "path" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.referredPersonalIdentities.referredPersonalIdentityStatus",
      "short" : "referredPersonalIdentityStatus",
      "definition" : "referredPersonalIdentityStatus",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.birth",
      "path" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.birth",
      "short" : "birth",
      "definition" : "Uppgifter om födelse",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "BackboneElement"
      }]
    },
    {
      "id" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.birth.dateOfBirth",
      "path" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.birth.dateOfBirth",
      "short" : "dateOfBirth",
      "definition" : "Kan beskriva ett datum med variabel noggrannhet.",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "BackboneElement"
      }]
    },
    {
      "id" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.birth.dateOfBirth.format",
      "path" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.birth.dateOfBirth.format",
      "short" : "format",
      "definition" : "format",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "code"
      }],
      "binding" : {
        "strength" : "required",
        "valueSet" : "https://fhir.inera.se/ig/strategicresourcemanagement-persons-person/ValueSet/SPP-datetypeformat-vs"
      }
    },
    {
      "id" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.birth.dateOfBirth.partialDateValue",
      "path" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.birth.dateOfBirth.partialDateValue",
      "short" : "partialDateValue",
      "definition" : "partialDateValue Heter value i schemat.",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.birth.placeOfBirthSweden",
      "path" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.birth.placeOfBirthSweden",
      "short" : "placeOfBirthSweden",
      "definition" : "Uppgifter om hemort i Sverige",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "BackboneElement"
      }]
    },
    {
      "id" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.birth.placeOfBirthSweden.birthCountyCode",
      "path" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.birth.placeOfBirthSweden.birthCountyCode",
      "short" : "birthCountyCode",
      "definition" : "birthCountyCode",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.birth.placeOfBirthSweden.birthParish",
      "path" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.birth.placeOfBirthSweden.birthParish",
      "short" : "birthParish",
      "definition" : "birthParish",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.birth.birthAbroad",
      "path" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.birth.birthAbroad",
      "short" : "birthAbroad",
      "definition" : "Uppgifter om födelse i utlandet",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "BackboneElement"
      }]
    },
    {
      "id" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.birth.birthAbroad.placeOfBirthAbroad",
      "path" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.birth.birthAbroad.placeOfBirthAbroad",
      "short" : "placeOfBirthAbroad",
      "definition" : "placeOfBirthAbroad",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.birth.birthAbroad.countryOfBirth",
      "path" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.birth.birthAbroad.countryOfBirth",
      "short" : "countryOfBirth",
      "definition" : "countryOfBirth",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.populationRegistrationLocality",
      "path" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.populationRegistrationLocality",
      "short" : "populationRegistrationLocality",
      "definition" : "Uppgifter om folkbokföring",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "BackboneElement"
      }]
    },
    {
      "id" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.populationRegistrationLocality.populationRegistrationDate",
      "path" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.populationRegistrationLocality.populationRegistrationDate",
      "short" : "populationRegistrationDate",
      "definition" : "Kan beskriva ett datum med variabel noggrannhet.",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "BackboneElement"
      }]
    },
    {
      "id" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.populationRegistrationLocality.populationRegistrationDate.format",
      "path" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.populationRegistrationLocality.populationRegistrationDate.format",
      "short" : "format",
      "definition" : "format",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "code"
      }],
      "binding" : {
        "strength" : "required",
        "valueSet" : "https://fhir.inera.se/ig/strategicresourcemanagement-persons-person/ValueSet/SPP-datetypeformat-vs"
      }
    },
    {
      "id" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.populationRegistrationLocality.populationRegistrationDate.partialDateValue",
      "path" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.populationRegistrationLocality.populationRegistrationDate.partialDateValue",
      "short" : "partialDateValue",
      "definition" : "partialDateValue Heter value i schemat.",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.populationRegistrationLocality.countyCode",
      "path" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.populationRegistrationLocality.countyCode",
      "short" : "countyCode",
      "definition" : "countyCode",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.populationRegistrationLocality.municipalityCode",
      "path" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.populationRegistrationLocality.municipalityCode",
      "short" : "municipalityCode",
      "definition" : "municipalityCode",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.populationRegistrationLocality.parishCode",
      "path" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.populationRegistrationLocality.parishCode",
      "short" : "parishCode",
      "definition" : "parishCode",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.populationRegistrationLocality.propertyDesignation",
      "path" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.populationRegistrationLocality.propertyDesignation",
      "short" : "propertyDesignation",
      "definition" : "propertyDesignation",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.populationRegistrationLocality.fictitiousPropertyNumber",
      "path" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.populationRegistrationLocality.fictitiousPropertyNumber",
      "short" : "fictitiousPropertyNumber",
      "definition" : "fictitiousPropertyNumber",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "integer"
      }]
    },
    {
      "id" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.populationRegistrationLocality.populationRegistrationType",
      "path" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.populationRegistrationLocality.populationRegistrationType",
      "short" : "populationRegistrationType",
      "definition" : "populationRegistrationType",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.populationRegistrationLocality.localRegistrationTime",
      "path" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.populationRegistrationLocality.localRegistrationTime",
      "short" : "localRegistrationTime",
      "definition" : "localRegistrationTime",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "dateTime"
      }]
    },
    {
      "id" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.populationRegistrationLocality.localRegistrationEndTime",
      "path" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.populationRegistrationLocality.localRegistrationEndTime",
      "short" : "localRegistrationEndTime",
      "definition" : "localRegistrationEndTime",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "dateTime"
      }]
    },
    {
      "id" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.populationRegistrationRecord",
      "path" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.populationRegistrationRecord",
      "short" : "populationRegistrationRecord",
      "definition" : "Folkbokföringspost",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "BackboneElement"
      }]
    },
    {
      "id" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.populationRegistrationRecord.syncronizationTime",
      "path" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.populationRegistrationRecord.syncronizationTime",
      "short" : "syncronizationTime",
      "definition" : "syncronizationTime",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "dateTime"
      }]
    },
    {
      "id" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.populationRegistrationRecord.notificationCase",
      "path" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.populationRegistrationRecord.notificationCase",
      "short" : "notificationCase",
      "definition" : "Ärendeuppgifter",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "BackboneElement"
      }]
    },
    {
      "id" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.populationRegistrationRecord.notificationCase.recordId",
      "path" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.populationRegistrationRecord.notificationCase.recordId",
      "short" : "recordId",
      "definition" : "recordId",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.populationRegistrationRecord.notificationCase.notificationType",
      "path" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.populationRegistrationRecord.notificationCase.notificationType",
      "short" : "notificationType",
      "definition" : "notificationType",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.populationRegistrationRecord.notificationCase.modificationTime",
      "path" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.populationRegistrationRecord.notificationCase.modificationTime",
      "short" : "modificationTime",
      "definition" : "modificationTime",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "dateTime"
      }]
    },
    {
      "id" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.populationRegistrationRecord.notificationCase.totalRecord",
      "path" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.populationRegistrationRecord.notificationCase.totalRecord",
      "short" : "totalRecord",
      "definition" : "totalRecord",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "boolean"
      }]
    },
    {
      "id" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.populationRegistrationRecord.notificationCase.notificationDate",
      "path" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.populationRegistrationRecord.notificationCase.notificationDate",
      "short" : "notificationDate",
      "definition" : "Kan beskriva ett datum med variabel noggrannhet.",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "BackboneElement"
      }]
    },
    {
      "id" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.populationRegistrationRecord.notificationCase.notificationDate.format",
      "path" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.populationRegistrationRecord.notificationCase.notificationDate.format",
      "short" : "format",
      "definition" : "format",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "code"
      }],
      "binding" : {
        "strength" : "required",
        "valueSet" : "https://fhir.inera.se/ig/strategicresourcemanagement-persons-person/ValueSet/SPP-datetypeformat-vs"
      }
    },
    {
      "id" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.populationRegistrationRecord.notificationCase.notificationDate.partialDateValue",
      "path" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.populationRegistrationRecord.notificationCase.notificationDate.partialDateValue",
      "short" : "partialDateValue",
      "definition" : "partialDateValue Heter value i schemat.",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.populationRegistrationRecord.historicalRecords",
      "path" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.populationRegistrationRecord.historicalRecords",
      "short" : "historicalRecords",
      "definition" : "Grupp för historik",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "BackboneElement"
      }]
    },
    {
      "id" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.populationRegistrationRecord.historicalRecords.populationRegistrationLocality",
      "path" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.populationRegistrationRecord.historicalRecords.populationRegistrationLocality",
      "short" : "populationRegistrationLocality",
      "definition" : "Uppgifter om folkbokföring",
      "min" : 0,
      "max" : "*",
      "type" : [{
        "code" : "BackboneElement"
      }]
    },
    {
      "id" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.populationRegistrationRecord.historicalRecords.populationRegistrationLocality.populationRegistrationDate",
      "path" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.populationRegistrationRecord.historicalRecords.populationRegistrationLocality.populationRegistrationDate",
      "short" : "populationRegistrationDate",
      "definition" : "Kan beskriva ett datum med variabel noggrannhet.",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "BackboneElement"
      }]
    },
    {
      "id" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.populationRegistrationRecord.historicalRecords.populationRegistrationLocality.populationRegistrationDate.format",
      "path" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.populationRegistrationRecord.historicalRecords.populationRegistrationLocality.populationRegistrationDate.format",
      "short" : "format",
      "definition" : "format",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "code"
      }],
      "binding" : {
        "strength" : "required",
        "valueSet" : "https://fhir.inera.se/ig/strategicresourcemanagement-persons-person/ValueSet/SPP-datetypeformat-vs"
      }
    },
    {
      "id" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.populationRegistrationRecord.historicalRecords.populationRegistrationLocality.populationRegistrationDate.partialDateValue",
      "path" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.populationRegistrationRecord.historicalRecords.populationRegistrationLocality.populationRegistrationDate.partialDateValue",
      "short" : "partialDateValue",
      "definition" : "partialDateValue Heter value i schemat.",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.populationRegistrationRecord.historicalRecords.populationRegistrationLocality.countyCode",
      "path" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.populationRegistrationRecord.historicalRecords.populationRegistrationLocality.countyCode",
      "short" : "countyCode",
      "definition" : "countyCode",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.populationRegistrationRecord.historicalRecords.populationRegistrationLocality.municipalityCode",
      "path" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.populationRegistrationRecord.historicalRecords.populationRegistrationLocality.municipalityCode",
      "short" : "municipalityCode",
      "definition" : "municipalityCode",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.populationRegistrationRecord.historicalRecords.populationRegistrationLocality.parishCode",
      "path" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.populationRegistrationRecord.historicalRecords.populationRegistrationLocality.parishCode",
      "short" : "parishCode",
      "definition" : "parishCode",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.populationRegistrationRecord.historicalRecords.populationRegistrationLocality.propertyDesignation",
      "path" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.populationRegistrationRecord.historicalRecords.populationRegistrationLocality.propertyDesignation",
      "short" : "propertyDesignation",
      "definition" : "propertyDesignation",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.populationRegistrationRecord.historicalRecords.populationRegistrationLocality.fictitiousPropertyNumber",
      "path" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.populationRegistrationRecord.historicalRecords.populationRegistrationLocality.fictitiousPropertyNumber",
      "short" : "fictitiousPropertyNumber",
      "definition" : "fictitiousPropertyNumber",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "integer"
      }]
    },
    {
      "id" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.populationRegistrationRecord.historicalRecords.populationRegistrationLocality.populationRegistrationType",
      "path" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.populationRegistrationRecord.historicalRecords.populationRegistrationLocality.populationRegistrationType",
      "short" : "populationRegistrationType",
      "definition" : "populationRegistrationType",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.populationRegistrationRecord.historicalRecords.populationRegistrationLocality.localRegistrationTime",
      "path" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.populationRegistrationRecord.historicalRecords.populationRegistrationLocality.localRegistrationTime",
      "short" : "localRegistrationTime",
      "definition" : "localRegistrationTime",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "dateTime"
      }]
    },
    {
      "id" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.populationRegistrationRecord.historicalRecords.populationRegistrationLocality.localRegistrationEndTime",
      "path" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.populationRegistrationRecord.historicalRecords.populationRegistrationLocality.localRegistrationEndTime",
      "short" : "localRegistrationEndTime",
      "definition" : "localRegistrationEndTime",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "dateTime"
      }]
    },
    {
      "id" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.populationRegistrationRecord.historicalRecords.historicalAddress",
      "path" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.populationRegistrationRecord.historicalRecords.historicalAddress",
      "short" : "historicalAddress",
      "definition" : "Svensk adress",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "BackboneElement"
      }]
    },
    {
      "id" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.populationRegistrationRecord.historicalRecords.historicalAddress.careOf",
      "path" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.populationRegistrationRecord.historicalRecords.historicalAddress.careOf",
      "short" : "careOf",
      "definition" : "careOf",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.populationRegistrationRecord.historicalRecords.historicalAddress.postalAddress1",
      "path" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.populationRegistrationRecord.historicalRecords.historicalAddress.postalAddress1",
      "short" : "postalAddress1",
      "definition" : "postalAddress1",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.populationRegistrationRecord.historicalRecords.historicalAddress.postalAddress2",
      "path" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.populationRegistrationRecord.historicalRecords.historicalAddress.postalAddress2",
      "short" : "postalAddress2",
      "definition" : "postalAddress2",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.populationRegistrationRecord.historicalRecords.historicalAddress.postalCode",
      "path" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.populationRegistrationRecord.historicalRecords.historicalAddress.postalCode",
      "short" : "postalCode",
      "definition" : "postalCode",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "integer"
      }]
    },
    {
      "id" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.populationRegistrationRecord.historicalRecords.historicalAddress.city",
      "path" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.populationRegistrationRecord.historicalRecords.historicalAddress.city",
      "short" : "city",
      "definition" : "city",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.addressInformation",
      "path" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.addressInformation",
      "short" : "addressInformation",
      "definition" : "Grupp för adressuppgifter",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "BackboneElement"
      }]
    },
    {
      "id" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.addressInformation.residentialAddress",
      "path" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.addressInformation.residentialAddress",
      "short" : "residentialAddress",
      "definition" : "Svensk adress",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "BackboneElement"
      }]
    },
    {
      "id" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.addressInformation.residentialAddress.careOf",
      "path" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.addressInformation.residentialAddress.careOf",
      "short" : "careOf",
      "definition" : "careOf",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.addressInformation.residentialAddress.postalAddress1",
      "path" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.addressInformation.residentialAddress.postalAddress1",
      "short" : "postalAddress1",
      "definition" : "postalAddress1",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.addressInformation.residentialAddress.postalAddress2",
      "path" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.addressInformation.residentialAddress.postalAddress2",
      "short" : "postalAddress2",
      "definition" : "postalAddress2",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.addressInformation.residentialAddress.postalCode",
      "path" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.addressInformation.residentialAddress.postalCode",
      "short" : "postalCode",
      "definition" : "postalCode",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "integer"
      }]
    },
    {
      "id" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.addressInformation.residentialAddress.city",
      "path" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.addressInformation.residentialAddress.city",
      "short" : "city",
      "definition" : "city",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.addressInformation.nationalKeys",
      "path" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.addressInformation.nationalKeys",
      "short" : "nationalKeys",
      "definition" : "Riksnycklar",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "BackboneElement"
      }]
    },
    {
      "id" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.addressInformation.nationalKeys.propertyId",
      "path" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.addressInformation.nationalKeys.propertyId",
      "short" : "propertyId",
      "definition" : "propertyId",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.addressInformation.nationalKeys.addressPlaceId",
      "path" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.addressInformation.nationalKeys.addressPlaceId",
      "short" : "addressPlaceId",
      "definition" : "addressPlaceId",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.addressInformation.nationalKeys.apartmentId",
      "path" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.addressInformation.nationalKeys.apartmentId",
      "short" : "apartmentId",
      "definition" : "apartmentId",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.addressInformation.district",
      "path" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.addressInformation.district",
      "short" : "district",
      "definition" : "Grupp för Distriktskod",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "BackboneElement"
      }]
    },
    {
      "id" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.addressInformation.district.districtCode",
      "path" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.addressInformation.district.districtCode",
      "short" : "districtCode",
      "definition" : "districtCode",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.addressInformation.specialPostalAddress",
      "path" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.addressInformation.specialPostalAddress",
      "short" : "specialPostalAddress",
      "definition" : "Svensk adress",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "BackboneElement"
      }]
    },
    {
      "id" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.addressInformation.specialPostalAddress.careOf",
      "path" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.addressInformation.specialPostalAddress.careOf",
      "short" : "careOf",
      "definition" : "careOf",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.addressInformation.specialPostalAddress.postalAddress1",
      "path" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.addressInformation.specialPostalAddress.postalAddress1",
      "short" : "postalAddress1",
      "definition" : "postalAddress1",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.addressInformation.specialPostalAddress.postalAddress2",
      "path" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.addressInformation.specialPostalAddress.postalAddress2",
      "short" : "postalAddress2",
      "definition" : "postalAddress2",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.addressInformation.specialPostalAddress.postalCode",
      "path" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.addressInformation.specialPostalAddress.postalCode",
      "short" : "postalCode",
      "definition" : "postalCode",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "integer"
      }]
    },
    {
      "id" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.addressInformation.specialPostalAddress.city",
      "path" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.addressInformation.specialPostalAddress.city",
      "short" : "city",
      "definition" : "city",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.addressInformation.addressAbroad",
      "path" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.addressInformation.addressAbroad",
      "short" : "addressAbroad",
      "definition" : "Utlandsadress",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "BackboneElement"
      }]
    },
    {
      "id" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.addressInformation.addressAbroad.postalAddress1",
      "path" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.addressInformation.addressAbroad.postalAddress1",
      "short" : "postalAddress1",
      "definition" : "postalAddress1",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.addressInformation.addressAbroad.postalAddress2",
      "path" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.addressInformation.addressAbroad.postalAddress2",
      "short" : "postalAddress2",
      "definition" : "postalAddress2",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.addressInformation.addressAbroad.postalAddress3",
      "path" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.addressInformation.addressAbroad.postalAddress3",
      "short" : "postalAddress3",
      "definition" : "postalAddress3",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.addressInformation.addressAbroad.countryCode",
      "path" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.addressInformation.addressAbroad.countryCode",
      "short" : "countryCode",
      "definition" : "countryCode",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.addressInformation.addressAbroad.addressAbroadDate",
      "path" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.addressInformation.addressAbroad.addressAbroadDate",
      "short" : "addressAbroadDate",
      "definition" : "Kan beskriva ett datum med variabel noggrannhet.",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "BackboneElement"
      }]
    },
    {
      "id" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.addressInformation.addressAbroad.addressAbroadDate.format",
      "path" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.addressInformation.addressAbroad.addressAbroadDate.format",
      "short" : "format",
      "definition" : "format",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "code"
      }],
      "binding" : {
        "strength" : "required",
        "valueSet" : "https://fhir.inera.se/ig/strategicresourcemanagement-persons-person/ValueSet/SPP-datetypeformat-vs"
      }
    },
    {
      "id" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.addressInformation.addressAbroad.addressAbroadDate.partialDateValue",
      "path" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.addressInformation.addressAbroad.addressAbroadDate.partialDateValue",
      "short" : "partialDateValue",
      "definition" : "partialDateValue Heter value i schemat.",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.addressInformation.addressAbroad.votingDate",
      "path" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.addressInformation.addressAbroad.votingDate",
      "short" : "votingDate",
      "definition" : "Kan beskriva ett datum med variabel noggrannhet.",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "BackboneElement"
      }]
    },
    {
      "id" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.addressInformation.addressAbroad.votingDate.format",
      "path" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.addressInformation.addressAbroad.votingDate.format",
      "short" : "format",
      "definition" : "format",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "code"
      }],
      "binding" : {
        "strength" : "required",
        "valueSet" : "https://fhir.inera.se/ig/strategicresourcemanagement-persons-person/ValueSet/SPP-datetypeformat-vs"
      }
    },
    {
      "id" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.addressInformation.addressAbroad.votingDate.partialDateValue",
      "path" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.addressInformation.addressAbroad.votingDate.partialDateValue",
      "short" : "partialDateValue",
      "definition" : "partialDateValue Heter value i schemat.",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.addressInformation.givenAddress",
      "path" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.addressInformation.givenAddress",
      "short" : "givenAddress",
      "definition" : "Svensk adress",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "BackboneElement"
      }]
    },
    {
      "id" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.addressInformation.givenAddress.careOf",
      "path" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.addressInformation.givenAddress.careOf",
      "short" : "careOf",
      "definition" : "careOf",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.addressInformation.givenAddress.postalAddress1",
      "path" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.addressInformation.givenAddress.postalAddress1",
      "short" : "postalAddress1",
      "definition" : "postalAddress1",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.addressInformation.givenAddress.postalAddress2",
      "path" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.addressInformation.givenAddress.postalAddress2",
      "short" : "postalAddress2",
      "definition" : "postalAddress2",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.addressInformation.givenAddress.postalCode",
      "path" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.addressInformation.givenAddress.postalCode",
      "short" : "postalCode",
      "definition" : "postalCode",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "integer"
      }]
    },
    {
      "id" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.addressInformation.givenAddress.city",
      "path" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.addressInformation.givenAddress.city",
      "short" : "city",
      "definition" : "city",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.addressInformation.UUID",
      "path" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.addressInformation.UUID",
      "short" : "UUID",
      "definition" : "UUID för fastighet, aderess och lägenhet",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "BackboneElement"
      }]
    },
    {
      "id" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.addressInformation.UUID.propertyId",
      "path" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.addressInformation.UUID.propertyId",
      "short" : "propertyId",
      "definition" : "propertyId",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.addressInformation.UUID.addressPlaceId",
      "path" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.addressInformation.UUID.addressPlaceId",
      "short" : "addressPlaceId",
      "definition" : "addressPlaceId",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.addressInformation.UUID.apartmentId",
      "path" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.addressInformation.UUID.apartmentId",
      "short" : "apartmentId",
      "definition" : "apartmentId",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.contactInformation",
      "path" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.contactInformation",
      "short" : "contactInformation",
      "definition" : "Klass för patientens egna angivna kontakuppgifter",
      "min" : 0,
      "max" : "*",
      "type" : [{
        "code" : "BackboneElement"
      }]
    },
    {
      "id" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.contactInformation.contactType",
      "path" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.contactInformation.contactType",
      "short" : "contactType",
      "definition" : "contactType",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.contactInformation.use",
      "path" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.contactInformation.use",
      "short" : "use",
      "definition" : "use",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.contactInformation.contactInformationValue",
      "path" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.contactInformation.contactInformationValue",
      "short" : "contactInformationValue",
      "definition" : "contactInformationValue Heter value i schemat.",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.contactInformation.rank",
      "path" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.contactInformation.rank",
      "short" : "rank",
      "definition" : "rank",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "integer"
      }]
    },
    {
      "id" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.contactInformation.comment",
      "path" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.contactInformation.comment",
      "short" : "comment",
      "definition" : "comment",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.contactInformation.period",
      "path" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.contactInformation.period",
      "short" : "period",
      "definition" : "period",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "BackboneElement"
      }]
    },
    {
      "id" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.contactInformation.period.start",
      "path" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.contactInformation.period.start",
      "short" : "start",
      "definition" : "start",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "date"
      }]
    },
    {
      "id" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.contactInformation.period.end",
      "path" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.contactInformation.period.end",
      "short" : "end",
      "definition" : "end",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "date"
      }]
    },
    {
      "id" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.contactInformation.digitalNotification",
      "path" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.contactInformation.digitalNotification",
      "short" : "digitalNotification",
      "definition" : "digitalNotification",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "boolean"
      }]
    },
    {
      "id" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.contactPerson",
      "path" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.contactPerson",
      "short" : "contactPerson",
      "definition" : "contactPerson",
      "min" : 0,
      "max" : "*",
      "type" : [{
        "code" : "BackboneElement"
      }]
    },
    {
      "id" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.contactPerson.contactRelationshipType",
      "path" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.contactPerson.contactRelationshipType",
      "short" : "contactRelationshipType",
      "definition" : "contactRelationshipType",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.contactPerson.priorityOrder",
      "path" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.contactPerson.priorityOrder",
      "short" : "priorityOrder",
      "definition" : "priorityOrder",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "integer"
      }]
    },
    {
      "id" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.contactPerson.givenName",
      "path" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.contactPerson.givenName",
      "short" : "givenName",
      "definition" : "givenName",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.contactPerson.surName",
      "path" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.contactPerson.surName",
      "short" : "surName",
      "definition" : "surName",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.contactPerson.middleName",
      "path" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.contactPerson.middleName",
      "short" : "middleName",
      "definition" : "middleName",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.contactPerson.contactPersonAddress",
      "path" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.contactPerson.contactPersonAddress",
      "short" : "contactPersonAddress",
      "definition" : "Svensk adress",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "BackboneElement"
      }]
    },
    {
      "id" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.contactPerson.contactPersonAddress.careOf",
      "path" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.contactPerson.contactPersonAddress.careOf",
      "short" : "careOf",
      "definition" : "careOf",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.contactPerson.contactPersonAddress.postalAddress1",
      "path" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.contactPerson.contactPersonAddress.postalAddress1",
      "short" : "postalAddress1",
      "definition" : "postalAddress1",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.contactPerson.contactPersonAddress.postalAddress2",
      "path" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.contactPerson.contactPersonAddress.postalAddress2",
      "short" : "postalAddress2",
      "definition" : "postalAddress2",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.contactPerson.contactPersonAddress.postalCode",
      "path" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.contactPerson.contactPersonAddress.postalCode",
      "short" : "postalCode",
      "definition" : "postalCode",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "integer"
      }]
    },
    {
      "id" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.contactPerson.contactPersonAddress.city",
      "path" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.contactPerson.contactPersonAddress.city",
      "short" : "city",
      "definition" : "city",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.contactPerson.contactPersonContactInformation",
      "path" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.contactPerson.contactPersonContactInformation",
      "short" : "contactPersonContactInformation",
      "definition" : "Klass för patientens egna angivna kontakuppgifter",
      "min" : 0,
      "max" : "*",
      "type" : [{
        "code" : "BackboneElement"
      }]
    },
    {
      "id" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.contactPerson.contactPersonContactInformation.contactType",
      "path" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.contactPerson.contactPersonContactInformation.contactType",
      "short" : "contactType",
      "definition" : "contactType",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.contactPerson.contactPersonContactInformation.use",
      "path" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.contactPerson.contactPersonContactInformation.use",
      "short" : "use",
      "definition" : "use",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.contactPerson.contactPersonContactInformation.contactInformationValue",
      "path" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.contactPerson.contactPersonContactInformation.contactInformationValue",
      "short" : "contactInformationValue",
      "definition" : "contactInformationValue Heter value i schemat.",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.contactPerson.contactPersonContactInformation.rank",
      "path" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.contactPerson.contactPersonContactInformation.rank",
      "short" : "rank",
      "definition" : "rank",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "integer"
      }]
    },
    {
      "id" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.contactPerson.contactPersonContactInformation.comment",
      "path" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.contactPerson.contactPersonContactInformation.comment",
      "short" : "comment",
      "definition" : "comment",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.contactPerson.contactPersonContactInformation.period",
      "path" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.contactPerson.contactPersonContactInformation.period",
      "short" : "period",
      "definition" : "period",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "BackboneElement"
      }]
    },
    {
      "id" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.contactPerson.contactPersonContactInformation.period.start",
      "path" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.contactPerson.contactPersonContactInformation.period.start",
      "short" : "start",
      "definition" : "start",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "date"
      }]
    },
    {
      "id" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.contactPerson.contactPersonContactInformation.period.end",
      "path" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.contactPerson.contactPersonContactInformation.period.end",
      "short" : "end",
      "definition" : "end",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "date"
      }]
    },
    {
      "id" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.contactPerson.contactPersonContactInformation.digitalNotification",
      "path" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.contactPerson.contactPersonContactInformation.digitalNotification",
      "short" : "digitalNotification",
      "definition" : "digitalNotification",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "boolean"
      }]
    },
    {
      "id" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.confirmedIdentity",
      "path" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.confirmedIdentity",
      "short" : "confirmedIdentity",
      "definition" : "Klass för hur reservidentitetsuppgifter är styrkta.",
      "min" : 0,
      "max" : "*",
      "type" : [{
        "code" : "BackboneElement"
      }]
    },
    {
      "id" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.confirmedIdentity.typeOfIdentification",
      "path" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.confirmedIdentity.typeOfIdentification",
      "short" : "typeOfIdentification",
      "definition" : "typeOfIdentification",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.confirmedIdentity.identificationNumber",
      "path" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.confirmedIdentity.identificationNumber",
      "short" : "identificationNumber",
      "definition" : "identificationNumber",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.confirmedIdentity.issuersOfId",
      "path" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.confirmedIdentity.issuersOfId",
      "short" : "issuersOfId",
      "definition" : "issuersOfId",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.confirmedIdentity.validDatePeriod",
      "path" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.confirmedIdentity.validDatePeriod",
      "short" : "validDatePeriod",
      "definition" : "validDatePeriod",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "BackboneElement"
      }]
    },
    {
      "id" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.confirmedIdentity.validDatePeriod.start",
      "path" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.confirmedIdentity.validDatePeriod.start",
      "short" : "start",
      "definition" : "start",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "date"
      }]
    },
    {
      "id" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.confirmedIdentity.validDatePeriod.end",
      "path" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.confirmedIdentity.validDatePeriod.end",
      "short" : "end",
      "definition" : "end",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "date"
      }]
    },
    {
      "id" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.confirmedIdentity.attachmentId",
      "path" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.confirmedIdentity.attachmentId",
      "short" : "attachmentId",
      "definition" : "attachmentId",
      "min" : 0,
      "max" : "*",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.confirmedIdentity.countryCode",
      "path" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.confirmedIdentity.countryCode",
      "short" : "countryCode",
      "definition" : "countryCode",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.administrativeInformation",
      "path" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.administrativeInformation",
      "short" : "administrativeInformation",
      "definition" : "Klass för administrativa tilläggsuppgifter. Normalt tilläggsuppgifter kring en person med en reservidentitet som registreras i samband med uttag av reservidentitet (LRID/NRID).",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "BackboneElement"
      }]
    },
    {
      "id" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.administrativeInformation.categoryOfPerson",
      "path" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.administrativeInformation.categoryOfPerson",
      "short" : "categoryOfPerson",
      "definition" : "categoryOfPerson",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.administrativeInformation.accountCode",
      "path" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.administrativeInformation.accountCode",
      "short" : "accountCode",
      "definition" : "accountCode",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.administrativeInformation.comment",
      "path" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.administrativeInformation.comment",
      "short" : "comment",
      "definition" : "comment",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.deregistration",
      "path" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.deregistration",
      "short" : "deregistration",
      "definition" : "Uppgifter om avregistrering",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "BackboneElement"
      }]
    },
    {
      "id" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.deregistration.deregistrationReasonCode",
      "path" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.deregistration.deregistrationReasonCode",
      "short" : "deregistrationReasonCode",
      "definition" : "deregistrationReasonCode",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.deregistration.deregistrationDate",
      "path" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.deregistration.deregistrationDate",
      "short" : "deregistrationDate",
      "definition" : "Kan beskriva ett datum med variabel noggrannhet.",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "BackboneElement"
      }]
    },
    {
      "id" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.deregistration.deregistrationDate.format",
      "path" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.deregistration.deregistrationDate.format",
      "short" : "format",
      "definition" : "format",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "code"
      }],
      "binding" : {
        "strength" : "required",
        "valueSet" : "https://fhir.inera.se/ig/strategicresourcemanagement-persons-person/ValueSet/SPP-datetypeformat-vs"
      }
    },
    {
      "id" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.deregistration.deregistrationDate.partialDateValue",
      "path" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.deregistration.deregistrationDate.partialDateValue",
      "short" : "partialDateValue",
      "definition" : "partialDateValue Heter value i schemat.",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.deregistration.foundDeadAtDate",
      "path" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.deregistration.foundDeadAtDate",
      "short" : "foundDeadAtDate",
      "definition" : "Kan beskriva ett datum med variabel noggrannhet.",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "BackboneElement"
      }]
    },
    {
      "id" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.deregistration.foundDeadAtDate.format",
      "path" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.deregistration.foundDeadAtDate.format",
      "short" : "format",
      "definition" : "format",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "code"
      }],
      "binding" : {
        "strength" : "required",
        "valueSet" : "https://fhir.inera.se/ig/strategicresourcemanagement-persons-person/ValueSet/SPP-datetypeformat-vs"
      }
    },
    {
      "id" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.deregistration.foundDeadAtDate.partialDateValue",
      "path" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.deregistration.foundDeadAtDate.partialDateValue",
      "short" : "partialDateValue",
      "definition" : "partialDateValue Heter value i schemat.",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.maritalStatus",
      "path" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.maritalStatus",
      "short" : "maritalStatus",
      "definition" : "Civistånd",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "BackboneElement"
      }]
    },
    {
      "id" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.maritalStatus.maritalStatusCode",
      "path" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.maritalStatus.maritalStatusCode",
      "short" : "maritalStatusCode",
      "definition" : "maritalStatusCode",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.maritalStatus.maritalStatusDate",
      "path" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.maritalStatus.maritalStatusDate",
      "short" : "maritalStatusDate",
      "definition" : "Kan beskriva ett datum med variabel noggrannhet.",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "BackboneElement"
      }]
    },
    {
      "id" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.maritalStatus.maritalStatusDate.format",
      "path" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.maritalStatus.maritalStatusDate.format",
      "short" : "format",
      "definition" : "format",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "code"
      }],
      "binding" : {
        "strength" : "required",
        "valueSet" : "https://fhir.inera.se/ig/strategicresourcemanagement-persons-person/ValueSet/SPP-datetypeformat-vs"
      }
    },
    {
      "id" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.maritalStatus.maritalStatusDate.partialDateValue",
      "path" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.maritalStatus.maritalStatusDate.partialDateValue",
      "short" : "partialDateValue",
      "definition" : "partialDateValue Heter value i schemat.",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.immigration",
      "path" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.immigration",
      "short" : "immigration",
      "definition" : "Grupp för invandringsuppgifter",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "BackboneElement"
      }]
    },
    {
      "id" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.immigration.immigrationDate",
      "path" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.immigration.immigrationDate",
      "short" : "immigrationDate",
      "definition" : "Kan beskriva ett datum med variabel noggrannhet.",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "BackboneElement"
      }]
    },
    {
      "id" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.immigration.immigrationDate.format",
      "path" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.immigration.immigrationDate.format",
      "short" : "format",
      "definition" : "format",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "code"
      }],
      "binding" : {
        "strength" : "required",
        "valueSet" : "https://fhir.inera.se/ig/strategicresourcemanagement-persons-person/ValueSet/SPP-datetypeformat-vs"
      }
    },
    {
      "id" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.immigration.immigrationDate.partialDateValue",
      "path" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.immigration.immigrationDate.partialDateValue",
      "short" : "partialDateValue",
      "definition" : "partialDateValue Heter value i schemat.",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.immigration.rightOfResidence",
      "path" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.immigration.rightOfResidence",
      "short" : "rightOfResidence",
      "definition" : "rightOfResidence",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "boolean"
      }]
    },
    {
      "id" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.immigration.immigrationIdentity",
      "path" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.immigration.immigrationIdentity",
      "short" : "immigrationIdentity",
      "definition" : "Grupp för personnummer och vilket land det är knutet till. Motsvarar skatteverkets NordisktPnrDa, NordisktPnrFi, NordisktPnrFo, NordisktPnrIs och NordisktPnrNo",
      "min" : 0,
      "max" : "*",
      "type" : [{
        "code" : "BackboneElement"
      }]
    },
    {
      "id" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.immigration.immigrationIdentity.personalIdentityNumber",
      "path" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.immigration.immigrationIdentity.personalIdentityNumber",
      "short" : "personalIdentityNumber",
      "definition" : "personalIdentityNumber",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.immigration.immigrationIdentity.country",
      "path" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.immigration.immigrationIdentity.country",
      "short" : "country",
      "definition" : "country",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.citizenship",
      "path" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.citizenship",
      "short" : "citizenship",
      "definition" : "Grupp för medborgarskap",
      "min" : 0,
      "max" : "*",
      "type" : [{
        "code" : "BackboneElement"
      }]
    },
    {
      "id" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.citizenship.citizenshipCountryCode",
      "path" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.citizenship.citizenshipCountryCode",
      "short" : "citizenshipCountryCode",
      "definition" : "citizenshipCountryCode",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.citizenship.citizenshipDate",
      "path" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.citizenship.citizenshipDate",
      "short" : "citizenshipDate",
      "definition" : "Kan beskriva ett datum med variabel noggrannhet.",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "BackboneElement"
      }]
    },
    {
      "id" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.citizenship.citizenshipDate.format",
      "path" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.citizenship.citizenshipDate.format",
      "short" : "format",
      "definition" : "format",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "code"
      }],
      "binding" : {
        "strength" : "required",
        "valueSet" : "https://fhir.inera.se/ig/strategicresourcemanagement-persons-person/ValueSet/SPP-datetypeformat-vs"
      }
    },
    {
      "id" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.citizenship.citizenshipDate.partialDateValue",
      "path" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.citizenship.citizenshipDate.partialDateValue",
      "short" : "partialDateValue",
      "definition" : "partialDateValue Heter value i schemat.",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.citizenship.citizenshipStatus",
      "path" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.citizenship.citizenshipStatus",
      "short" : "citizenshipStatus",
      "definition" : "citizenshipStatus Heter status i schemat.",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.relationship",
      "path" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.relationship",
      "short" : "relationship",
      "definition" : "Grupp för relation",
      "min" : 0,
      "max" : "*",
      "type" : [{
        "code" : "BackboneElement"
      }]
    },
    {
      "id" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.relationship.relationshipId",
      "path" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.relationship.relationshipId",
      "short" : "relationshipId",
      "definition" : "Grupp för relationspersons identitet Antingen får man personnummer eller datum då personen föddes.",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "BackboneElement"
      }]
    },
    {
      "id" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.relationship.relationshipId.personalIdentity",
      "path" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.relationship.relationshipId.personalIdentity",
      "short" : "personalIdentity",
      "definition" : "En universellt unik identifierare.",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "BackboneElement"
      }]
    },
    {
      "id" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.relationship.relationshipId.personalIdentity.root",
      "path" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.relationship.relationshipId.personalIdentity.root",
      "short" : "root",
      "definition" : "root",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.relationship.relationshipId.personalIdentity.iiExtension",
      "path" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.relationship.relationshipId.personalIdentity.iiExtension",
      "short" : "iiExtension",
      "definition" : "iiExtension Heter extension i schemat.",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.relationship.relationshipId.dateOfBirth",
      "path" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.relationship.relationshipId.dateOfBirth",
      "short" : "dateOfBirth",
      "definition" : "Kan beskriva ett datum med variabel noggrannhet.",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "BackboneElement"
      }]
    },
    {
      "id" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.relationship.relationshipId.dateOfBirth.format",
      "path" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.relationship.relationshipId.dateOfBirth.format",
      "short" : "format",
      "definition" : "format",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "code"
      }],
      "binding" : {
        "strength" : "required",
        "valueSet" : "https://fhir.inera.se/ig/strategicresourcemanagement-persons-person/ValueSet/SPP-datetypeformat-vs"
      }
    },
    {
      "id" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.relationship.relationshipId.dateOfBirth.partialDateValue",
      "path" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.relationship.relationshipId.dateOfBirth.partialDateValue",
      "short" : "partialDateValue",
      "definition" : "partialDateValue Heter value i schemat.",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.relationship.relationshipType",
      "path" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.relationship.relationshipType",
      "short" : "relationshipType",
      "definition" : "relationshipType",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.relationship.relationshipFromDate",
      "path" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.relationship.relationshipFromDate",
      "short" : "relationshipFromDate",
      "definition" : "Kan beskriva ett datum med variabel noggrannhet.",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "BackboneElement"
      }]
    },
    {
      "id" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.relationship.relationshipFromDate.format",
      "path" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.relationship.relationshipFromDate.format",
      "short" : "format",
      "definition" : "format",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "code"
      }],
      "binding" : {
        "strength" : "required",
        "valueSet" : "https://fhir.inera.se/ig/strategicresourcemanagement-persons-person/ValueSet/SPP-datetypeformat-vs"
      }
    },
    {
      "id" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.relationship.relationshipFromDate.partialDateValue",
      "path" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.relationship.relationshipFromDate.partialDateValue",
      "short" : "partialDateValue",
      "definition" : "partialDateValue Heter value i schemat.",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.relationship.relationshipToDate",
      "path" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.relationship.relationshipToDate",
      "short" : "relationshipToDate",
      "definition" : "Kan beskriva ett datum med variabel noggrannhet.",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "BackboneElement"
      }]
    },
    {
      "id" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.relationship.relationshipToDate.format",
      "path" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.relationship.relationshipToDate.format",
      "short" : "format",
      "definition" : "format",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "code"
      }],
      "binding" : {
        "strength" : "required",
        "valueSet" : "https://fhir.inera.se/ig/strategicresourcemanagement-persons-person/ValueSet/SPP-datetypeformat-vs"
      }
    },
    {
      "id" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.relationship.relationshipToDate.partialDateValue",
      "path" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.relationship.relationshipToDate.partialDateValue",
      "short" : "partialDateValue",
      "definition" : "partialDateValue Heter value i schemat.",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.relationship.relationshipName",
      "path" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.relationship.relationshipName",
      "short" : "relationshipName",
      "definition" : "Namn Heter name i schemat.",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "BackboneElement"
      }]
    },
    {
      "id" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.relationship.relationshipName.givenNameIndicator",
      "path" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.relationship.relationshipName.givenNameIndicator",
      "short" : "givenNameIndicator",
      "definition" : "givenNameIndicator",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "integer"
      }]
    },
    {
      "id" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.relationship.relationshipName.givenName",
      "path" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.relationship.relationshipName.givenName",
      "short" : "givenName",
      "definition" : "givenName",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.relationship.relationshipName.middleName",
      "path" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.relationship.relationshipName.middleName",
      "short" : "middleName",
      "definition" : "middleName",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.relationship.relationshipName.surname",
      "path" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.relationship.relationshipName.surname",
      "short" : "surname",
      "definition" : "surname",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.relationship.relationshipName.notificationName",
      "path" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.relationship.relationshipName.notificationName",
      "short" : "notificationName",
      "definition" : "notificationName",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.relationship.deregistration",
      "path" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.relationship.deregistration",
      "short" : "deregistration",
      "definition" : "Uppgifter om avregistrering",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "BackboneElement"
      }]
    },
    {
      "id" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.relationship.deregistration.deregistrationReasonCode",
      "path" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.relationship.deregistration.deregistrationReasonCode",
      "short" : "deregistrationReasonCode",
      "definition" : "deregistrationReasonCode",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.relationship.deregistration.deregistrationDate",
      "path" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.relationship.deregistration.deregistrationDate",
      "short" : "deregistrationDate",
      "definition" : "Kan beskriva ett datum med variabel noggrannhet.",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "BackboneElement"
      }]
    },
    {
      "id" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.relationship.deregistration.deregistrationDate.format",
      "path" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.relationship.deregistration.deregistrationDate.format",
      "short" : "format",
      "definition" : "format",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "code"
      }],
      "binding" : {
        "strength" : "required",
        "valueSet" : "https://fhir.inera.se/ig/strategicresourcemanagement-persons-person/ValueSet/SPP-datetypeformat-vs"
      }
    },
    {
      "id" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.relationship.deregistration.deregistrationDate.partialDateValue",
      "path" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.relationship.deregistration.deregistrationDate.partialDateValue",
      "short" : "partialDateValue",
      "definition" : "partialDateValue Heter value i schemat.",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.relationship.deregistration.foundDeadAtDate",
      "path" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.relationship.deregistration.foundDeadAtDate",
      "short" : "foundDeadAtDate",
      "definition" : "Kan beskriva ett datum med variabel noggrannhet.",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "BackboneElement"
      }]
    },
    {
      "id" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.relationship.deregistration.foundDeadAtDate.format",
      "path" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.relationship.deregistration.foundDeadAtDate.format",
      "short" : "format",
      "definition" : "format",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "code"
      }],
      "binding" : {
        "strength" : "required",
        "valueSet" : "https://fhir.inera.se/ig/strategicresourcemanagement-persons-person/ValueSet/SPP-datetypeformat-vs"
      }
    },
    {
      "id" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.relationship.deregistration.foundDeadAtDate.partialDateValue",
      "path" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.relationship.deregistration.foundDeadAtDate.partialDateValue",
      "short" : "partialDateValue",
      "definition" : "partialDateValue Heter value i schemat.",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.relationship.relationshipStatus",
      "path" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.relationship.relationshipStatus",
      "short" : "relationshipStatus",
      "definition" : "relationshipStatus Heter status i schemat.",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.coOrdinationNumberData",
      "path" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.coOrdinationNumberData",
      "short" : "coOrdinationNumberData",
      "definition" : "Grupp för de personer som ej är folkbokförda men som har tilldelats ett samordningsnummer för identifiering av personen. Syftet med samordningsnummer är att myndigheter och andra samhällsfunktioner ska kunna identifiera personer även om de inte är folkbokförda i Sverige.",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "BackboneElement"
      }]
    },
    {
      "id" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.coOrdinationNumberData.allocationDate",
      "path" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.coOrdinationNumberData.allocationDate",
      "short" : "allocationDate",
      "definition" : "Kan beskriva ett datum med variabel noggrannhet.",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "BackboneElement"
      }]
    },
    {
      "id" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.coOrdinationNumberData.allocationDate.format",
      "path" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.coOrdinationNumberData.allocationDate.format",
      "short" : "format",
      "definition" : "format",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "code"
      }],
      "binding" : {
        "strength" : "required",
        "valueSet" : "https://fhir.inera.se/ig/strategicresourcemanagement-persons-person/ValueSet/SPP-datetypeformat-vs"
      }
    },
    {
      "id" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.coOrdinationNumberData.allocationDate.partialDateValue",
      "path" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.coOrdinationNumberData.allocationDate.partialDateValue",
      "short" : "partialDateValue",
      "definition" : "partialDateValue Heter value i schemat.",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.coOrdinationNumberData.preliminaryTransferDate",
      "path" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.coOrdinationNumberData.preliminaryTransferDate",
      "short" : "preliminaryTransferDate",
      "definition" : "Kan beskriva ett datum med variabel noggrannhet.",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "BackboneElement"
      }]
    },
    {
      "id" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.coOrdinationNumberData.preliminaryTransferDate.format",
      "path" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.coOrdinationNumberData.preliminaryTransferDate.format",
      "short" : "format",
      "definition" : "format",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "code"
      }],
      "binding" : {
        "strength" : "required",
        "valueSet" : "https://fhir.inera.se/ig/strategicresourcemanagement-persons-person/ValueSet/SPP-datetypeformat-vs"
      }
    },
    {
      "id" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.coOrdinationNumberData.preliminaryTransferDate.partialDateValue",
      "path" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.coOrdinationNumberData.preliminaryTransferDate.partialDateValue",
      "short" : "partialDateValue",
      "definition" : "partialDateValue Heter value i schemat.",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.coOrdinationNumberData.renewalDate",
      "path" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.coOrdinationNumberData.renewalDate",
      "short" : "renewalDate",
      "definition" : "Kan beskriva ett datum med variabel noggrannhet.",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "BackboneElement"
      }]
    },
    {
      "id" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.coOrdinationNumberData.renewalDate.format",
      "path" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.coOrdinationNumberData.renewalDate.format",
      "short" : "format",
      "definition" : "format",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "code"
      }],
      "binding" : {
        "strength" : "required",
        "valueSet" : "https://fhir.inera.se/ig/strategicresourcemanagement-persons-person/ValueSet/SPP-datetypeformat-vs"
      }
    },
    {
      "id" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.coOrdinationNumberData.renewalDate.partialDateValue",
      "path" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.coOrdinationNumberData.renewalDate.partialDateValue",
      "short" : "partialDateValue",
      "definition" : "partialDateValue Heter value i schemat.",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.coOrdinationNumberData.deceasedDate",
      "path" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.coOrdinationNumberData.deceasedDate",
      "short" : "deceasedDate",
      "definition" : "Kan beskriva ett datum med variabel noggrannhet.",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "BackboneElement"
      }]
    },
    {
      "id" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.coOrdinationNumberData.deceasedDate.format",
      "path" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.coOrdinationNumberData.deceasedDate.format",
      "short" : "format",
      "definition" : "format",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "code"
      }],
      "binding" : {
        "strength" : "required",
        "valueSet" : "https://fhir.inera.se/ig/strategicresourcemanagement-persons-person/ValueSet/SPP-datetypeformat-vs"
      }
    },
    {
      "id" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.coOrdinationNumberData.deceasedDate.partialDateValue",
      "path" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.coOrdinationNumberData.deceasedDate.partialDateValue",
      "short" : "partialDateValue",
      "definition" : "partialDateValue Heter value i schemat.",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.personalIdentityStatus",
      "path" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.personalIdentityStatus",
      "short" : "personalIdentityStatus",
      "definition" : "Klass som beskriver status för ett samordningsnummer. Status, datum och orsak ska vara obligatoriska uppgifter, när de finns, för aviseringar innehållande samordningsnummer.",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "BackboneElement"
      }]
    },
    {
      "id" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.personalIdentityStatus.identityStatus",
      "path" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.personalIdentityStatus.identityStatus",
      "short" : "identityStatus",
      "definition" : "identityStatus",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.personalIdentityStatus.identityStatusDate",
      "path" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.personalIdentityStatus.identityStatusDate",
      "short" : "identityStatusDate",
      "definition" : "Kan beskriva ett datum med variabel noggrannhet.",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "BackboneElement"
      }]
    },
    {
      "id" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.personalIdentityStatus.identityStatusDate.format",
      "path" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.personalIdentityStatus.identityStatusDate.format",
      "short" : "format",
      "definition" : "format",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "code"
      }],
      "binding" : {
        "strength" : "required",
        "valueSet" : "https://fhir.inera.se/ig/strategicresourcemanagement-persons-person/ValueSet/SPP-datetypeformat-vs"
      }
    },
    {
      "id" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.personalIdentityStatus.identityStatusDate.partialDateValue",
      "path" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.personalIdentityStatus.identityStatusDate.partialDateValue",
      "short" : "partialDateValue",
      "definition" : "partialDateValue Heter value i schemat.",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.personalIdentityStatus.identityStatusCause",
      "path" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.personalIdentityStatus.identityStatusCause",
      "short" : "identityStatusCause",
      "definition" : "identityStatusCause",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.updatePersonActor",
      "path" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.updatePersonActor",
      "short" : "updatePersonActor",
      "definition" : "Datatyp som identifierar en aktör.",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "BackboneElement"
      }]
    },
    {
      "id" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.updatePersonActor.actorId",
      "path" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.updatePersonActor.actorId",
      "short" : "actorId",
      "definition" : "En universellt unik identifierare. Heter id i schemat.",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "BackboneElement"
      }]
    },
    {
      "id" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.updatePersonActor.actorId.root",
      "path" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.updatePersonActor.actorId.root",
      "short" : "root",
      "definition" : "root",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.updatePersonActor.actorId.iiExtension",
      "path" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.updatePersonActor.actorId.iiExtension",
      "short" : "iiExtension",
      "definition" : "iiExtension Heter extension i schemat.",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.updatePersonActor.professional",
      "path" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.updatePersonActor.professional",
      "short" : "professional",
      "definition" : "Datatyp som identifierar en aktör inom en profession.",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "BackboneElement"
      }]
    },
    {
      "id" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.updatePersonActor.professional.organizationId",
      "path" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.updatePersonActor.professional.organizationId",
      "short" : "organizationId",
      "definition" : "En universellt unik identifierare.",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "BackboneElement"
      }]
    },
    {
      "id" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.updatePersonActor.professional.organizationId.root",
      "path" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.updatePersonActor.professional.organizationId.root",
      "short" : "root",
      "definition" : "root",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.updatePersonActor.professional.organizationId.iiExtension",
      "path" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.updatePersonActor.professional.organizationId.iiExtension",
      "short" : "iiExtension",
      "definition" : "iiExtension Heter extension i schemat.",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.updatePersonActor.updateTime",
      "path" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.updatePersonActor.updateTime",
      "short" : "updateTime",
      "definition" : "updateTime",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.updatePersonContactInformationActor",
      "path" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.updatePersonContactInformationActor",
      "short" : "updatePersonContactInformationActor",
      "definition" : "Datatyp som identifierar en aktör.",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "BackboneElement"
      }]
    },
    {
      "id" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.updatePersonContactInformationActor.actorId",
      "path" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.updatePersonContactInformationActor.actorId",
      "short" : "actorId",
      "definition" : "En universellt unik identifierare. Heter id i schemat.",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "BackboneElement"
      }]
    },
    {
      "id" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.updatePersonContactInformationActor.actorId.root",
      "path" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.updatePersonContactInformationActor.actorId.root",
      "short" : "root",
      "definition" : "root",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.updatePersonContactInformationActor.actorId.iiExtension",
      "path" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.updatePersonContactInformationActor.actorId.iiExtension",
      "short" : "iiExtension",
      "definition" : "iiExtension Heter extension i schemat.",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.updatePersonContactInformationActor.professional",
      "path" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.updatePersonContactInformationActor.professional",
      "short" : "professional",
      "definition" : "Datatyp som identifierar en aktör inom en profession.",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "BackboneElement"
      }]
    },
    {
      "id" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.updatePersonContactInformationActor.professional.organizationId",
      "path" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.updatePersonContactInformationActor.professional.organizationId",
      "short" : "organizationId",
      "definition" : "En universellt unik identifierare.",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "BackboneElement"
      }]
    },
    {
      "id" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.updatePersonContactInformationActor.professional.organizationId.root",
      "path" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.updatePersonContactInformationActor.professional.organizationId.root",
      "short" : "root",
      "definition" : "root",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.updatePersonContactInformationActor.professional.organizationId.iiExtension",
      "path" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.updatePersonContactInformationActor.professional.organizationId.iiExtension",
      "short" : "iiExtension",
      "definition" : "iiExtension Heter extension i schemat.",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.updatePersonContactInformationActor.updateTime",
      "path" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.updatePersonContactInformationActor.updateTime",
      "short" : "updateTime",
      "definition" : "updateTime",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.attachment",
      "path" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.attachment",
      "short" : "attachment",
      "definition" : "Datatyp som beskriver en multimediatyp. Data kan förekomma som inbäddat element eller hänvisas via en referens URL.",
      "min" : 0,
      "max" : "*",
      "type" : [{
        "code" : "BackboneElement"
      }]
    },
    {
      "id" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.attachment.multimediaId",
      "path" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.attachment.multimediaId",
      "short" : "multimediaId",
      "definition" : "multimediaId Heter id i schemat.",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.attachment.mediaType",
      "path" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.attachment.mediaType",
      "short" : "mediaType",
      "definition" : "mediaType",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.attachment.multimediaValue",
      "path" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.attachment.multimediaValue",
      "short" : "multimediaValue",
      "definition" : "multimediaValue Heter value i schemat.",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "base64Binary"
      }]
    },
    {
      "id" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.attachment.reference",
      "path" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.attachment.reference",
      "short" : "reference",
      "definition" : "reference",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "uri"
      }]
    },
    {
      "id" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.optoutPaperNotification",
      "path" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.optoutPaperNotification",
      "short" : "optoutPaperNotification",
      "definition" : "optoutPaperNotification",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "boolean"
      }]
    },
    {
      "id" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.protectedPopulationRecord",
      "path" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.protectedPopulationRecord",
      "short" : "protectedPopulationRecord",
      "definition" : "protectedPopulationRecord",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "boolean"
      }]
    }]
  }
}

```
