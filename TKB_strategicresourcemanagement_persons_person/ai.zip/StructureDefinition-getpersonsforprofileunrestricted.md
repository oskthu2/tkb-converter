# GetPersonsForProfileUnrestricted — Response - strategicresourcemanagement: persons: person v5.1.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **GetPersonsForProfileUnrestricted — Response**

## Logical Model: GetPersonsForProfileUnrestricted — Response 

| | |
| :--- | :--- |
| *Official URL*:https://fhir.inera.se/ig/strategicresourcemanagement-persons-person/StructureDefinition/getpersonsforprofileunrestricted | *Version*:5.0 |
| Active as of 2026-11-09 | *Computable Name*:GetPersonsForProfileUnrestricted |
| **Copyright/Legal**: Copyright 2024 Inera AB. Licensieras under Creative Commons Attribution 4.0. | |

 
Logisk modell för svaret i GetPersonsForProfileUnrestricted (urn:riv:strategicresourcemanagement:persons:person:GetPersonsForProfileUnrestrictedResponder:5, GetPersonsForProfileUnrestrictedResponseType). 

**Usages:**

* This Logical Model is not used by any profiles in this Specification

You can also check for [usages in the FHIR IG Statistics](https://packages2.fhir.org/xig/resource/inera.strategicresourcemanagement-persons-person|current/StructureDefinition/StructureDefinition-getpersonsforprofileunrestricted.json)

### Formal Views of Profile Content

 [Description of Profiles, Differentials, Snapshots and how the different presentations work](http://build.fhir.org/ig/FHIR/ig-guidance/readingIgs.html#structure-definitions). 

 

Other representations of profile: [CSV](StructureDefinition-getpersonsforprofileunrestricted.csv), [Excel](StructureDefinition-getpersonsforprofileunrestricted.xlsx) 



## Resource Content

```json
{
  "resourceType" : "StructureDefinition",
  "id" : "getpersonsforprofileunrestricted",
  "extension" : [{
    "url" : "http://hl7.org/fhir/StructureDefinition/structuredefinition-type-characteristics",
    "valueCode" : "can-be-target"
  }],
  "url" : "https://fhir.inera.se/ig/strategicresourcemanagement-persons-person/StructureDefinition/getpersonsforprofileunrestricted",
  "version" : "5.0",
  "name" : "GetPersonsForProfileUnrestricted",
  "title" : "GetPersonsForProfileUnrestricted — Response",
  "status" : "active",
  "date" : "2026-11-09T03:51:23+00:00",
  "contact" : [{
    "name" : "Inera Arkitektur",
    "telecom" : [{
      "system" : "url",
      "value" : "https://www.inera.se"
    }]
  }],
  "description" : "Logisk modell för svaret i GetPersonsForProfileUnrestricted\n(urn:riv:strategicresourcemanagement:persons:person:GetPersonsForProfileUnrestrictedResponder:5, GetPersonsForProfileUnrestrictedResponseType).",
  "copyright" : "Copyright 2024 Inera AB. Licensieras under Creative Commons Attribution 4.0.",
  "fhirVersion" : "4.0.1",
  "kind" : "logical",
  "abstract" : false,
  "type" : "https://fhir.inera.se/ig/strategicresourcemanagement-persons-person/StructureDefinition/getpersonsforprofileunrestricted",
  "baseDefinition" : "http://hl7.org/fhir/StructureDefinition/Base",
  "derivation" : "specialization",
  "differential" : {
    "element" : [{
      "id" : "getpersonsforprofileunrestricted",
      "path" : "getpersonsforprofileunrestricted",
      "short" : "GetPersonsForProfileUnrestricted — Response",
      "definition" : "Logisk modell för svaret i GetPersonsForProfileUnrestricted\n(urn:riv:strategicresourcemanagement:persons:person:GetPersonsForProfileUnrestrictedResponder:5, GetPersonsForProfileUnrestrictedResponseType)."
    },
    {
      "id" : "getpersonsforprofileunrestricted.requestedPersonRecord",
      "path" : "getpersonsforprofileunrestricted.requestedPersonRecord",
      "short" : "RequestedPersonRecordType",
      "definition" : "requestedPersonRecord",
      "comment" : "TKB-fält: `requestedPersonRecord` (`RequestedPersonRecordType`, kardinalitet 1..*).",
      "min" : 1,
      "max" : "*",
      "type" : [{
        "code" : "Base"
      }]
    },
    {
      "id" : "getpersonsforprofileunrestricted.requestedPersonRecord.requestedPersonalIdentity",
      "path" : "getpersonsforprofileunrestricted.requestedPersonRecord.requestedPersonalIdentity",
      "short" : "requestedPersonalIdentity",
      "definition" : "En universellt unik identifierare.",
      "comment" : "TKB-fält: `../requestedPersonalIdentity` (`IIType`, kardinalitet 1..1).",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "https://fhir.inera.se/ig/rivta-datatypes/StructureDefinition/IIType"
      }]
    },
    {
      "id" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord",
      "path" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord",
      "short" : "PersonRecordType",
      "definition" : "Grupp för personpost",
      "comment" : "TKB-fält: `../personRecord` (`PersonRecordType`, kardinalitet 0..1).",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "Base"
      }]
    },
    {
      "id" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.personalIdentity",
      "path" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.personalIdentity",
      "short" : "personalIdentity",
      "definition" : "En universellt unik identifierare.",
      "comment" : "TKB-fält: `../../personalIdentity` (`IIType`, kardinalitet 1..1).",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "https://fhir.inera.se/ig/rivta-datatypes/StructureDefinition/IIType"
      }]
    },
    {
      "id" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.identityLevel",
      "path" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.identityLevel",
      "short" : "identityLevel",
      "definition" : "identityLevel",
      "comment" : "TKB-fält: `../../identityLevel` (`string`, kardinalitet 0..1).",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.identityLevelDate",
      "path" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.identityLevelDate",
      "short" : "PartialDateType",
      "definition" : "Kan beskriva ett datum med variabel noggrannhet.",
      "comment" : "TKB-fält: `../../identityLevelDate` (`PartialDateType`, kardinalitet 0..1).",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "Base"
      }]
    },
    {
      "id" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.identityLevelDate.format",
      "path" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.identityLevelDate.format",
      "short" : "format",
      "definition" : "format Tillåtna värden: YYYY, YYYY-MM, YYYY-MM-DD.",
      "comment" : "TKB-fält: `../../../format` (`DateTypeFormatType`, kardinalitet 1..1).\n\n**Modellanteckning:** format Tillåtna värden: YYYY, YYYY-MM, YYYY-MM-DD.",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "code"
      }],
      "binding" : {
        "strength" : "required",
        "valueSet" : "https://fhir.inera.se/ig/strategicresourcemanagement-persons-person/ValueSet/SPP-datetypeformat-vs"
      }
    },
    {
      "id" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.identityLevelDate.value",
      "path" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.identityLevelDate.value",
      "short" : "value",
      "definition" : "value",
      "comment" : "TKB-fält: `../../../value` (`PartialDateValue`, kardinalitet 1..1).",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.gender",
      "path" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.gender",
      "short" : "gender",
      "definition" : "gender",
      "comment" : "TKB-fält: `../../gender` (`CodedValue`, kardinalitet 0..1).",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.protectedPersonIndicator",
      "path" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.protectedPersonIndicator",
      "short" : "protectedPersonIndicator",
      "definition" : "protectedPersonIndicator",
      "comment" : "TKB-fält: `../../protectedPersonIndicator` (`boolean`, kardinalitet 1..1).",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "boolean"
      }]
    },
    {
      "id" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.testIndicator",
      "path" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.testIndicator",
      "short" : "testIndicator",
      "definition" : "testIndicator",
      "comment" : "TKB-fält: `../../testIndicator` (`boolean`, kardinalitet 1..1).",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "boolean"
      }]
    },
    {
      "id" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.primaryIdentity",
      "path" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.primaryIdentity",
      "short" : "primaryIdentity",
      "definition" : "primaryIdentity",
      "comment" : "TKB-fält: `../../primaryIdentity` (`boolean`, kardinalitet 1..1).",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "boolean"
      }]
    },
    {
      "id" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.version",
      "path" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.version",
      "short" : "version",
      "definition" : "version",
      "comment" : "TKB-fält: `../../version` (`Timestamp`, kardinalitet 0..1).",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.name",
      "path" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.name",
      "short" : "NameType",
      "definition" : "Namn",
      "comment" : "TKB-fält: `../../name` (`NameType`, kardinalitet 0..1).",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "Base"
      }]
    },
    {
      "id" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.name.givenNameIndicator",
      "path" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.name.givenNameIndicator",
      "short" : "givenNameIndicator",
      "definition" : "givenNameIndicator",
      "comment" : "TKB-fält: `../../../givenNameIndicator` (`GivenNameIndicator`, kardinalitet 0..1).",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "integer"
      }]
    },
    {
      "id" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.name.givenName",
      "path" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.name.givenName",
      "short" : "givenName",
      "definition" : "givenName",
      "comment" : "TKB-fält: `../../../givenName` (`String80`, kardinalitet 0..1).",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.name.middleName",
      "path" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.name.middleName",
      "short" : "middleName",
      "definition" : "middleName",
      "comment" : "TKB-fält: `../../../middleName` (`String80`, kardinalitet 0..1).",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.name.surname",
      "path" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.name.surname",
      "short" : "surname",
      "definition" : "surname",
      "comment" : "TKB-fält: `../../../surname` (`String80`, kardinalitet 0..1).",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.name.notificationName",
      "path" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.name.notificationName",
      "short" : "notificationName",
      "definition" : "notificationName",
      "comment" : "TKB-fält: `../../../notificationName` (`String40`, kardinalitet 0..1).",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.linkedIdentity",
      "path" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.linkedIdentity",
      "short" : "LinkedIdentityType",
      "definition" : "Klass för att koppla ihop 2 identiteter. Ex en nationell reservidentitet till ett PNR",
      "comment" : "TKB-fält: `../../linkedIdentity` (`LinkedIdentityType`, kardinalitet 0..*).",
      "min" : 0,
      "max" : "*",
      "type" : [{
        "code" : "Base"
      }]
    },
    {
      "id" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.linkedIdentity.referredPersonalIdentity",
      "path" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.linkedIdentity.referredPersonalIdentity",
      "short" : "referredPersonalIdentity",
      "definition" : "En universellt unik identifierare.",
      "comment" : "TKB-fält: `../../../referredPersonalIdentity` (`IIType`, kardinalitet 1..1).",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "https://fhir.inera.se/ig/rivta-datatypes/StructureDefinition/IIType"
      }]
    },
    {
      "id" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.linkedIdentity.assuranceLevel",
      "path" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.linkedIdentity.assuranceLevel",
      "short" : "assuranceLevel",
      "definition" : "assuranceLevel",
      "comment" : "TKB-fält: `../../../assuranceLevel` (`CodedValue`, kardinalitet 1..1).",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.linkedIdentity.primaryIdentity",
      "path" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.linkedIdentity.primaryIdentity",
      "short" : "primaryIdentity",
      "definition" : "primaryIdentity",
      "comment" : "TKB-fält: `../../../primaryIdentity` (`boolean`, kardinalitet 1..1).",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "boolean"
      }]
    },
    {
      "id" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.referredPersonalIdentities",
      "path" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.referredPersonalIdentities",
      "short" : "ReferredPersonalIdentityType",
      "definition" : "Klass för Hänvisningspersonnummer. För de personer som bytt personnummer anges tidigare personnummer/samordningsnummer som hänvisningspersonnummer. Det gamla personnumret/samordningsnumret utgör även det en egen personpost. I det fallet anges det nya personnumret som hänvisningspersonnummer. En person kan få nytt personnummer efter exempelvis ändring av en persons födelsetid eller vid beslut om ändrad könstillhörighet. Klassen håller ihop personidentiteter av typerna personnummer och samordningsnummer enligt Skatteverket till skillnad från klassen KoppladIdenitet som är Personuppgiftstjänstens egna klass för att kunna koppla ihop alla typer av personidentiteter (inkl. reservidentiteter).",
      "comment" : "TKB-fält: `../../referredPersonalIdentities` (`ReferredPersonalIdentityType`, kardinalitet 0..*).",
      "min" : 0,
      "max" : "*",
      "type" : [{
        "code" : "Base"
      }]
    },
    {
      "id" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.referredPersonalIdentities.referredPersonalIdentity",
      "path" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.referredPersonalIdentities.referredPersonalIdentity",
      "short" : "referredPersonalIdentity",
      "definition" : "En universellt unik identifierare.",
      "comment" : "TKB-fält: `../../../referredPersonalIdentity` (`IIType`, kardinalitet 1..1).",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "https://fhir.inera.se/ig/rivta-datatypes/StructureDefinition/IIType"
      }]
    },
    {
      "id" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.referredPersonalIdentities.referredPersonalIdentityStatus",
      "path" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.referredPersonalIdentities.referredPersonalIdentityStatus",
      "short" : "referredPersonalIdentityStatus",
      "definition" : "referredPersonalIdentityStatus",
      "comment" : "TKB-fält: `../../../referredPersonalIdentityStatus` (`string`, kardinalitet 0..1).",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.birth",
      "path" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.birth",
      "short" : "BirthType",
      "definition" : "Uppgifter om födelse",
      "comment" : "TKB-fält: `../../birth` (`BirthType`, kardinalitet 0..1).",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "Base"
      }]
    },
    {
      "id" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.birth.dateOfBirth",
      "path" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.birth.dateOfBirth",
      "short" : "PartialDateType",
      "definition" : "Kan beskriva ett datum med variabel noggrannhet.",
      "comment" : "TKB-fält: `../../../dateOfBirth` (`PartialDateType`, kardinalitet 0..1).",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "Base"
      }]
    },
    {
      "id" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.birth.dateOfBirth.format",
      "path" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.birth.dateOfBirth.format",
      "short" : "format",
      "definition" : "format Tillåtna värden: YYYY, YYYY-MM, YYYY-MM-DD.",
      "comment" : "TKB-fält: `../../../../format` (`DateTypeFormatType`, kardinalitet 1..1).\n\n**Modellanteckning:** format Tillåtna värden: YYYY, YYYY-MM, YYYY-MM-DD.",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "code"
      }],
      "binding" : {
        "strength" : "required",
        "valueSet" : "https://fhir.inera.se/ig/strategicresourcemanagement-persons-person/ValueSet/SPP-datetypeformat-vs"
      }
    },
    {
      "id" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.birth.dateOfBirth.value",
      "path" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.birth.dateOfBirth.value",
      "short" : "value",
      "definition" : "value",
      "comment" : "TKB-fält: `../../../../value` (`PartialDateValue`, kardinalitet 1..1).",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.birth.placeOfBirthSweden",
      "path" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.birth.placeOfBirthSweden",
      "short" : "PlaceOfBirthSwedenType",
      "definition" : "Uppgifter om hemort i Sverige",
      "comment" : "TKB-fält: `../../../placeOfBirthSweden` (`PlaceOfBirthSwedenType`, kardinalitet 0..1).",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "Base"
      }]
    },
    {
      "id" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.birth.placeOfBirthSweden.birthCountyCode",
      "path" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.birth.placeOfBirthSweden.birthCountyCode",
      "short" : "birthCountyCode",
      "definition" : "birthCountyCode",
      "comment" : "TKB-fält: `../../../../birthCountyCode` (`String2`, kardinalitet 0..1).",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.birth.placeOfBirthSweden.birthParish",
      "path" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.birth.placeOfBirthSweden.birthParish",
      "short" : "birthParish",
      "definition" : "birthParish",
      "comment" : "TKB-fält: `../../../../birthParish` (`String40`, kardinalitet 0..1).",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.birth.birthAbroad",
      "path" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.birth.birthAbroad",
      "short" : "BirthAbroadType",
      "definition" : "Uppgifter om födelse i utlandet",
      "comment" : "TKB-fält: `../../../birthAbroad` (`BirthAbroadType`, kardinalitet 0..1).",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "Base"
      }]
    },
    {
      "id" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.birth.birthAbroad.placeOfBirthAbroad",
      "path" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.birth.birthAbroad.placeOfBirthAbroad",
      "short" : "placeOfBirthAbroad",
      "definition" : "placeOfBirthAbroad",
      "comment" : "TKB-fält: `../../../../placeOfBirthAbroad` (`String80`, kardinalitet 0..1).",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.birth.birthAbroad.countryOfBirth",
      "path" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.birth.birthAbroad.countryOfBirth",
      "short" : "countryOfBirth",
      "definition" : "countryOfBirth",
      "comment" : "TKB-fält: `../../../../countryOfBirth` (`String40`, kardinalitet 0..1).",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.populationRegistrationLocality",
      "path" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.populationRegistrationLocality",
      "short" : "PopulationRegistrationLocalityType",
      "definition" : "Uppgifter om folkbokföring",
      "comment" : "TKB-fält: `../../populationRegistrationLocality` (`PopulationRegistrationLocalityType`, kardinalitet 0..1).",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "Base"
      }]
    },
    {
      "id" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.populationRegistrationLocality.populationRegistrationDate",
      "path" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.populationRegistrationLocality.populationRegistrationDate",
      "short" : "PartialDateType",
      "definition" : "Kan beskriva ett datum med variabel noggrannhet.",
      "comment" : "TKB-fält: `../../../populationRegistrationDate` (`PartialDateType`, kardinalitet 0..1).",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "Base"
      }]
    },
    {
      "id" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.populationRegistrationLocality.populationRegistrationDate.format",
      "path" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.populationRegistrationLocality.populationRegistrationDate.format",
      "short" : "format",
      "definition" : "format Tillåtna värden: YYYY, YYYY-MM, YYYY-MM-DD.",
      "comment" : "TKB-fält: `../../../../format` (`DateTypeFormatType`, kardinalitet 1..1).\n\n**Modellanteckning:** format Tillåtna värden: YYYY, YYYY-MM, YYYY-MM-DD.",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "code"
      }],
      "binding" : {
        "strength" : "required",
        "valueSet" : "https://fhir.inera.se/ig/strategicresourcemanagement-persons-person/ValueSet/SPP-datetypeformat-vs"
      }
    },
    {
      "id" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.populationRegistrationLocality.populationRegistrationDate.value",
      "path" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.populationRegistrationLocality.populationRegistrationDate.value",
      "short" : "value",
      "definition" : "value",
      "comment" : "TKB-fält: `../../../../value` (`PartialDateValue`, kardinalitet 1..1).",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.populationRegistrationLocality.countyCode",
      "path" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.populationRegistrationLocality.countyCode",
      "short" : "countyCode",
      "definition" : "countyCode",
      "comment" : "TKB-fält: `../../../countyCode` (`String2`, kardinalitet 0..1).",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.populationRegistrationLocality.municipalityCode",
      "path" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.populationRegistrationLocality.municipalityCode",
      "short" : "municipalityCode",
      "definition" : "municipalityCode",
      "comment" : "TKB-fält: `../../../municipalityCode` (`String2`, kardinalitet 0..1).",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.populationRegistrationLocality.parishCode",
      "path" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.populationRegistrationLocality.parishCode",
      "short" : "parishCode",
      "definition" : "parishCode",
      "comment" : "TKB-fält: `../../../parishCode` (`String2`, kardinalitet 0..1).",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.populationRegistrationLocality.propertyDesignation",
      "path" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.populationRegistrationLocality.propertyDesignation",
      "short" : "propertyDesignation",
      "definition" : "propertyDesignation",
      "comment" : "TKB-fält: `../../../propertyDesignation` (`String40`, kardinalitet 0..1).",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.populationRegistrationLocality.fictitiousPropertyNumber",
      "path" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.populationRegistrationLocality.fictitiousPropertyNumber",
      "short" : "fictitiousPropertyNumber",
      "definition" : "fictitiousPropertyNumber",
      "comment" : "TKB-fält: `../../../fictitiousPropertyNumber` (`FictitiousPropertyNumber`, kardinalitet 0..1).",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "integer"
      }]
    },
    {
      "id" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.populationRegistrationLocality.populationRegistrationType",
      "path" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.populationRegistrationLocality.populationRegistrationType",
      "short" : "populationRegistrationType",
      "definition" : "populationRegistrationType",
      "comment" : "TKB-fält: `../../../populationRegistrationType` (`CodedValue`, kardinalitet 0..1).",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.populationRegistrationLocality.localRegistrationTime",
      "path" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.populationRegistrationLocality.localRegistrationTime",
      "short" : "localRegistrationTime",
      "definition" : "localRegistrationTime",
      "comment" : "TKB-fält: `../../../localRegistrationTime` (`dateTime`, kardinalitet 0..1).",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "dateTime"
      }]
    },
    {
      "id" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.populationRegistrationLocality.localRegistrationEndTime",
      "path" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.populationRegistrationLocality.localRegistrationEndTime",
      "short" : "localRegistrationEndTime",
      "definition" : "localRegistrationEndTime",
      "comment" : "TKB-fält: `../../../localRegistrationEndTime` (`dateTime`, kardinalitet 0..1).",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "dateTime"
      }]
    },
    {
      "id" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.populationRegistrationRecord",
      "path" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.populationRegistrationRecord",
      "short" : "PopulationRegistrationRecordType",
      "definition" : "Folkbokföringspost",
      "comment" : "TKB-fält: `../../populationRegistrationRecord` (`PopulationRegistrationRecordType`, kardinalitet 0..1).",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "Base"
      }]
    },
    {
      "id" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.populationRegistrationRecord.syncronizationTime",
      "path" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.populationRegistrationRecord.syncronizationTime",
      "short" : "syncronizationTime",
      "definition" : "syncronizationTime",
      "comment" : "TKB-fält: `../../../syncronizationTime` (`dateTime`, kardinalitet 0..1).",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "dateTime"
      }]
    },
    {
      "id" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.populationRegistrationRecord.notificationCase",
      "path" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.populationRegistrationRecord.notificationCase",
      "short" : "NotificationCaseType",
      "definition" : "Ärendeuppgifter",
      "comment" : "TKB-fält: `../../../notificationCase` (`NotificationCaseType`, kardinalitet 0..1).",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "Base"
      }]
    },
    {
      "id" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.populationRegistrationRecord.notificationCase.recordId",
      "path" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.populationRegistrationRecord.notificationCase.recordId",
      "short" : "recordId",
      "definition" : "recordId",
      "comment" : "TKB-fält: `../../../../recordId` (`RecordId`, kardinalitet 0..1).",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.populationRegistrationRecord.notificationCase.notificationType",
      "path" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.populationRegistrationRecord.notificationCase.notificationType",
      "short" : "notificationType",
      "definition" : "notificationType",
      "comment" : "TKB-fält: `../../../../notificationType` (`String40`, kardinalitet 0..1).",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.populationRegistrationRecord.notificationCase.modificationTime",
      "path" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.populationRegistrationRecord.notificationCase.modificationTime",
      "short" : "modificationTime",
      "definition" : "modificationTime",
      "comment" : "TKB-fält: `../../../../modificationTime` (`dateTime`, kardinalitet 0..1).",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "dateTime"
      }]
    },
    {
      "id" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.populationRegistrationRecord.notificationCase.totalRecord",
      "path" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.populationRegistrationRecord.notificationCase.totalRecord",
      "short" : "totalRecord",
      "definition" : "totalRecord",
      "comment" : "TKB-fält: `../../../../totalRecord` (`boolean`, kardinalitet 0..1).",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "boolean"
      }]
    },
    {
      "id" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.populationRegistrationRecord.notificationCase.notificationDate",
      "path" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.populationRegistrationRecord.notificationCase.notificationDate",
      "short" : "PartialDateType",
      "definition" : "Kan beskriva ett datum med variabel noggrannhet.",
      "comment" : "TKB-fält: `../../../../notificationDate` (`PartialDateType`, kardinalitet 0..1).",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "Base"
      }]
    },
    {
      "id" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.populationRegistrationRecord.notificationCase.notificationDate.format",
      "path" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.populationRegistrationRecord.notificationCase.notificationDate.format",
      "short" : "format",
      "definition" : "format Tillåtna värden: YYYY, YYYY-MM, YYYY-MM-DD.",
      "comment" : "TKB-fält: `../../../../../format` (`DateTypeFormatType`, kardinalitet 1..1).\n\n**Modellanteckning:** format Tillåtna värden: YYYY, YYYY-MM, YYYY-MM-DD.",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "code"
      }],
      "binding" : {
        "strength" : "required",
        "valueSet" : "https://fhir.inera.se/ig/strategicresourcemanagement-persons-person/ValueSet/SPP-datetypeformat-vs"
      }
    },
    {
      "id" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.populationRegistrationRecord.notificationCase.notificationDate.value",
      "path" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.populationRegistrationRecord.notificationCase.notificationDate.value",
      "short" : "value",
      "definition" : "value",
      "comment" : "TKB-fält: `../../../../../value` (`PartialDateValue`, kardinalitet 1..1).",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.populationRegistrationRecord.historicalRecords",
      "path" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.populationRegistrationRecord.historicalRecords",
      "short" : "HistoricalRecordsType",
      "definition" : "Grupp för historik",
      "comment" : "TKB-fält: `../../../historicalRecords` (`HistoricalRecordsType`, kardinalitet 0..1).",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "Base"
      }]
    },
    {
      "id" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.populationRegistrationRecord.historicalRecords.populationRegistrationLocality",
      "path" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.populationRegistrationRecord.historicalRecords.populationRegistrationLocality",
      "short" : "PopulationRegistrationLocalityType",
      "definition" : "Uppgifter om folkbokföring",
      "comment" : "TKB-fält: `../../../../populationRegistrationLocality` (`PopulationRegistrationLocalityType`, kardinalitet 0..*).",
      "min" : 0,
      "max" : "*",
      "type" : [{
        "code" : "Base"
      }]
    },
    {
      "id" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.populationRegistrationRecord.historicalRecords.populationRegistrationLocality.populationRegistrationDate",
      "path" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.populationRegistrationRecord.historicalRecords.populationRegistrationLocality.populationRegistrationDate",
      "short" : "PartialDateType",
      "definition" : "Kan beskriva ett datum med variabel noggrannhet.",
      "comment" : "TKB-fält: `../../../../../populationRegistrationDate` (`PartialDateType`, kardinalitet 0..1).",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "Base"
      }]
    },
    {
      "id" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.populationRegistrationRecord.historicalRecords.populationRegistrationLocality.populationRegistrationDate.format",
      "path" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.populationRegistrationRecord.historicalRecords.populationRegistrationLocality.populationRegistrationDate.format",
      "short" : "format",
      "definition" : "format Tillåtna värden: YYYY, YYYY-MM, YYYY-MM-DD.",
      "comment" : "TKB-fält: `../../../../../../format` (`DateTypeFormatType`, kardinalitet 1..1).\n\n**Modellanteckning:** format Tillåtna värden: YYYY, YYYY-MM, YYYY-MM-DD.",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "code"
      }],
      "binding" : {
        "strength" : "required",
        "valueSet" : "https://fhir.inera.se/ig/strategicresourcemanagement-persons-person/ValueSet/SPP-datetypeformat-vs"
      }
    },
    {
      "id" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.populationRegistrationRecord.historicalRecords.populationRegistrationLocality.populationRegistrationDate.value",
      "path" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.populationRegistrationRecord.historicalRecords.populationRegistrationLocality.populationRegistrationDate.value",
      "short" : "value",
      "definition" : "value",
      "comment" : "TKB-fält: `../../../../../../value` (`PartialDateValue`, kardinalitet 1..1).",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.populationRegistrationRecord.historicalRecords.populationRegistrationLocality.countyCode",
      "path" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.populationRegistrationRecord.historicalRecords.populationRegistrationLocality.countyCode",
      "short" : "countyCode",
      "definition" : "countyCode",
      "comment" : "TKB-fält: `../../../../../countyCode` (`String2`, kardinalitet 0..1).",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.populationRegistrationRecord.historicalRecords.populationRegistrationLocality.municipalityCode",
      "path" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.populationRegistrationRecord.historicalRecords.populationRegistrationLocality.municipalityCode",
      "short" : "municipalityCode",
      "definition" : "municipalityCode",
      "comment" : "TKB-fält: `../../../../../municipalityCode` (`String2`, kardinalitet 0..1).",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.populationRegistrationRecord.historicalRecords.populationRegistrationLocality.parishCode",
      "path" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.populationRegistrationRecord.historicalRecords.populationRegistrationLocality.parishCode",
      "short" : "parishCode",
      "definition" : "parishCode",
      "comment" : "TKB-fält: `../../../../../parishCode` (`String2`, kardinalitet 0..1).",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.populationRegistrationRecord.historicalRecords.populationRegistrationLocality.propertyDesignation",
      "path" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.populationRegistrationRecord.historicalRecords.populationRegistrationLocality.propertyDesignation",
      "short" : "propertyDesignation",
      "definition" : "propertyDesignation",
      "comment" : "TKB-fält: `../../../../../propertyDesignation` (`String40`, kardinalitet 0..1).",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.populationRegistrationRecord.historicalRecords.populationRegistrationLocality.fictitiousPropertyNumber",
      "path" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.populationRegistrationRecord.historicalRecords.populationRegistrationLocality.fictitiousPropertyNumber",
      "short" : "fictitiousPropertyNumber",
      "definition" : "fictitiousPropertyNumber",
      "comment" : "TKB-fält: `../../../../../fictitiousPropertyNumber` (`FictitiousPropertyNumber`, kardinalitet 0..1).",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "integer"
      }]
    },
    {
      "id" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.populationRegistrationRecord.historicalRecords.populationRegistrationLocality.populationRegistrationType",
      "path" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.populationRegistrationRecord.historicalRecords.populationRegistrationLocality.populationRegistrationType",
      "short" : "populationRegistrationType",
      "definition" : "populationRegistrationType",
      "comment" : "TKB-fält: `../../../../../populationRegistrationType` (`CodedValue`, kardinalitet 0..1).",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.populationRegistrationRecord.historicalRecords.populationRegistrationLocality.localRegistrationTime",
      "path" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.populationRegistrationRecord.historicalRecords.populationRegistrationLocality.localRegistrationTime",
      "short" : "localRegistrationTime",
      "definition" : "localRegistrationTime",
      "comment" : "TKB-fält: `../../../../../localRegistrationTime` (`dateTime`, kardinalitet 0..1).",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "dateTime"
      }]
    },
    {
      "id" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.populationRegistrationRecord.historicalRecords.populationRegistrationLocality.localRegistrationEndTime",
      "path" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.populationRegistrationRecord.historicalRecords.populationRegistrationLocality.localRegistrationEndTime",
      "short" : "localRegistrationEndTime",
      "definition" : "localRegistrationEndTime",
      "comment" : "TKB-fält: `../../../../../localRegistrationEndTime` (`dateTime`, kardinalitet 0..1).",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "dateTime"
      }]
    },
    {
      "id" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.populationRegistrationRecord.historicalRecords.historicalAddress",
      "path" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.populationRegistrationRecord.historicalRecords.historicalAddress",
      "short" : "ResidentialAddressType",
      "definition" : "Svensk adress",
      "comment" : "TKB-fält: `../../../../historicalAddress` (`ResidentialAddressType`, kardinalitet 0..1).",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "Base"
      }]
    },
    {
      "id" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.populationRegistrationRecord.historicalRecords.historicalAddress.careOf",
      "path" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.populationRegistrationRecord.historicalRecords.historicalAddress.careOf",
      "short" : "careOf",
      "definition" : "careOf",
      "comment" : "TKB-fält: `../../../../../careOf` (`String40`, kardinalitet 0..1).",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.populationRegistrationRecord.historicalRecords.historicalAddress.postalAddress1",
      "path" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.populationRegistrationRecord.historicalRecords.historicalAddress.postalAddress1",
      "short" : "postalAddress1",
      "definition" : "postalAddress1",
      "comment" : "TKB-fält: `../../../../../postalAddress1` (`String40`, kardinalitet 0..1).",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.populationRegistrationRecord.historicalRecords.historicalAddress.postalAddress2",
      "path" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.populationRegistrationRecord.historicalRecords.historicalAddress.postalAddress2",
      "short" : "postalAddress2",
      "definition" : "postalAddress2",
      "comment" : "TKB-fält: `../../../../../postalAddress2` (`String40`, kardinalitet 0..1).",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.populationRegistrationRecord.historicalRecords.historicalAddress.postalCode",
      "path" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.populationRegistrationRecord.historicalRecords.historicalAddress.postalCode",
      "short" : "postalCode",
      "definition" : "postalCode",
      "comment" : "TKB-fält: `../../../../../postalCode` (`PostalCode`, kardinalitet 0..1).",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "integer"
      }]
    },
    {
      "id" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.populationRegistrationRecord.historicalRecords.historicalAddress.city",
      "path" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.populationRegistrationRecord.historicalRecords.historicalAddress.city",
      "short" : "city",
      "definition" : "city",
      "comment" : "TKB-fält: `../../../../../city` (`String40`, kardinalitet 0..1).",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.addressInformation",
      "path" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.addressInformation",
      "short" : "AddressInformationType",
      "definition" : "Grupp för adressuppgifter",
      "comment" : "TKB-fält: `../../addressInformation` (`AddressInformationType`, kardinalitet 0..1).",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "Base"
      }]
    },
    {
      "id" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.addressInformation.residentialAddress",
      "path" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.addressInformation.residentialAddress",
      "short" : "ResidentialAddressType",
      "definition" : "Svensk adress",
      "comment" : "TKB-fält: `../../../residentialAddress` (`ResidentialAddressType`, kardinalitet 0..1).",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "Base"
      }]
    },
    {
      "id" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.addressInformation.residentialAddress.careOf",
      "path" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.addressInformation.residentialAddress.careOf",
      "short" : "careOf",
      "definition" : "careOf",
      "comment" : "TKB-fält: `../../../../careOf` (`String40`, kardinalitet 0..1).",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.addressInformation.residentialAddress.postalAddress1",
      "path" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.addressInformation.residentialAddress.postalAddress1",
      "short" : "postalAddress1",
      "definition" : "postalAddress1",
      "comment" : "TKB-fält: `../../../../postalAddress1` (`String40`, kardinalitet 0..1).",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.addressInformation.residentialAddress.postalAddress2",
      "path" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.addressInformation.residentialAddress.postalAddress2",
      "short" : "postalAddress2",
      "definition" : "postalAddress2",
      "comment" : "TKB-fält: `../../../../postalAddress2` (`String40`, kardinalitet 0..1).",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.addressInformation.residentialAddress.postalCode",
      "path" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.addressInformation.residentialAddress.postalCode",
      "short" : "postalCode",
      "definition" : "postalCode",
      "comment" : "TKB-fält: `../../../../postalCode` (`PostalCode`, kardinalitet 0..1).",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "integer"
      }]
    },
    {
      "id" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.addressInformation.residentialAddress.city",
      "path" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.addressInformation.residentialAddress.city",
      "short" : "city",
      "definition" : "city",
      "comment" : "TKB-fält: `../../../../city` (`String40`, kardinalitet 0..1).",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.addressInformation.nationalKeys",
      "path" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.addressInformation.nationalKeys",
      "short" : "NationalKeysType",
      "definition" : "Riksnycklar",
      "comment" : "TKB-fält: `../../../nationalKeys` (`NationalKeysType`, kardinalitet 0..1).",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "Base"
      }]
    },
    {
      "id" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.addressInformation.nationalKeys.propertyId",
      "path" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.addressInformation.nationalKeys.propertyId",
      "short" : "propertyId",
      "definition" : "propertyId",
      "comment" : "TKB-fält: `../../../../propertyId` (`PropertyId`, kardinalitet 0..1).",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.addressInformation.nationalKeys.addressPlaceId",
      "path" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.addressInformation.nationalKeys.addressPlaceId",
      "short" : "addressPlaceId",
      "definition" : "addressPlaceId",
      "comment" : "TKB-fält: `../../../../addressPlaceId` (`AddressPlaceId`, kardinalitet 0..1).",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.addressInformation.nationalKeys.apartmentId",
      "path" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.addressInformation.nationalKeys.apartmentId",
      "short" : "apartmentId",
      "definition" : "apartmentId",
      "comment" : "TKB-fält: `../../../../apartmentId` (`ApartmentId`, kardinalitet 0..1).",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.addressInformation.district",
      "path" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.addressInformation.district",
      "short" : "DistrictType",
      "definition" : "Grupp för Distriktskod",
      "comment" : "TKB-fält: `../../../district` (`DistrictType`, kardinalitet 0..1).",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "Base"
      }]
    },
    {
      "id" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.addressInformation.district.districtCode",
      "path" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.addressInformation.district.districtCode",
      "short" : "districtCode",
      "definition" : "districtCode",
      "comment" : "TKB-fält: `../../../../districtCode` (`DistrictCode`, kardinalitet 0..1).",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.addressInformation.specialPostalAddress",
      "path" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.addressInformation.specialPostalAddress",
      "short" : "ResidentialAddressType",
      "definition" : "Svensk adress",
      "comment" : "TKB-fält: `../../../specialPostalAddress` (`ResidentialAddressType`, kardinalitet 0..1).",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "Base"
      }]
    },
    {
      "id" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.addressInformation.specialPostalAddress.careOf",
      "path" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.addressInformation.specialPostalAddress.careOf",
      "short" : "careOf",
      "definition" : "careOf",
      "comment" : "TKB-fält: `../../../../careOf` (`String40`, kardinalitet 0..1).",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.addressInformation.specialPostalAddress.postalAddress1",
      "path" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.addressInformation.specialPostalAddress.postalAddress1",
      "short" : "postalAddress1",
      "definition" : "postalAddress1",
      "comment" : "TKB-fält: `../../../../postalAddress1` (`String40`, kardinalitet 0..1).",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.addressInformation.specialPostalAddress.postalAddress2",
      "path" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.addressInformation.specialPostalAddress.postalAddress2",
      "short" : "postalAddress2",
      "definition" : "postalAddress2",
      "comment" : "TKB-fält: `../../../../postalAddress2` (`String40`, kardinalitet 0..1).",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.addressInformation.specialPostalAddress.postalCode",
      "path" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.addressInformation.specialPostalAddress.postalCode",
      "short" : "postalCode",
      "definition" : "postalCode",
      "comment" : "TKB-fält: `../../../../postalCode` (`PostalCode`, kardinalitet 0..1).",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "integer"
      }]
    },
    {
      "id" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.addressInformation.specialPostalAddress.city",
      "path" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.addressInformation.specialPostalAddress.city",
      "short" : "city",
      "definition" : "city",
      "comment" : "TKB-fält: `../../../../city` (`String40`, kardinalitet 0..1).",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.addressInformation.addressAbroad",
      "path" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.addressInformation.addressAbroad",
      "short" : "AddressAbroadType",
      "definition" : "Utlandsadress",
      "comment" : "TKB-fält: `../../../addressAbroad` (`AddressAbroadType`, kardinalitet 0..1).",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "Base"
      }]
    },
    {
      "id" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.addressInformation.addressAbroad.postalAddress1",
      "path" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.addressInformation.addressAbroad.postalAddress1",
      "short" : "postalAddress1",
      "definition" : "postalAddress1",
      "comment" : "TKB-fält: `../../../../postalAddress1` (`String40`, kardinalitet 0..1).",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.addressInformation.addressAbroad.postalAddress2",
      "path" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.addressInformation.addressAbroad.postalAddress2",
      "short" : "postalAddress2",
      "definition" : "postalAddress2",
      "comment" : "TKB-fält: `../../../../postalAddress2` (`String40`, kardinalitet 0..1).",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.addressInformation.addressAbroad.postalAddress3",
      "path" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.addressInformation.addressAbroad.postalAddress3",
      "short" : "postalAddress3",
      "definition" : "postalAddress3",
      "comment" : "TKB-fält: `../../../../postalAddress3` (`String40`, kardinalitet 0..1).",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.addressInformation.addressAbroad.countryCode",
      "path" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.addressInformation.addressAbroad.countryCode",
      "short" : "countryCode",
      "definition" : "countryCode",
      "comment" : "TKB-fält: `../../../../countryCode` (`String40`, kardinalitet 0..1).",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.addressInformation.addressAbroad.addressAbroadDate",
      "path" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.addressInformation.addressAbroad.addressAbroadDate",
      "short" : "PartialDateType",
      "definition" : "Kan beskriva ett datum med variabel noggrannhet.",
      "comment" : "TKB-fält: `../../../../addressAbroadDate` (`PartialDateType`, kardinalitet 0..1).",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "Base"
      }]
    },
    {
      "id" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.addressInformation.addressAbroad.addressAbroadDate.format",
      "path" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.addressInformation.addressAbroad.addressAbroadDate.format",
      "short" : "format",
      "definition" : "format Tillåtna värden: YYYY, YYYY-MM, YYYY-MM-DD.",
      "comment" : "TKB-fält: `../../../../../format` (`DateTypeFormatType`, kardinalitet 1..1).\n\n**Modellanteckning:** format Tillåtna värden: YYYY, YYYY-MM, YYYY-MM-DD.",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "code"
      }],
      "binding" : {
        "strength" : "required",
        "valueSet" : "https://fhir.inera.se/ig/strategicresourcemanagement-persons-person/ValueSet/SPP-datetypeformat-vs"
      }
    },
    {
      "id" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.addressInformation.addressAbroad.addressAbroadDate.value",
      "path" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.addressInformation.addressAbroad.addressAbroadDate.value",
      "short" : "value",
      "definition" : "value",
      "comment" : "TKB-fält: `../../../../../value` (`PartialDateValue`, kardinalitet 1..1).",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.addressInformation.addressAbroad.votingDate",
      "path" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.addressInformation.addressAbroad.votingDate",
      "short" : "PartialDateType",
      "definition" : "Kan beskriva ett datum med variabel noggrannhet.",
      "comment" : "TKB-fält: `../../../../votingDate` (`PartialDateType`, kardinalitet 0..1).",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "Base"
      }]
    },
    {
      "id" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.addressInformation.addressAbroad.votingDate.format",
      "path" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.addressInformation.addressAbroad.votingDate.format",
      "short" : "format",
      "definition" : "format Tillåtna värden: YYYY, YYYY-MM, YYYY-MM-DD.",
      "comment" : "TKB-fält: `../../../../../format` (`DateTypeFormatType`, kardinalitet 1..1).\n\n**Modellanteckning:** format Tillåtna värden: YYYY, YYYY-MM, YYYY-MM-DD.",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "code"
      }],
      "binding" : {
        "strength" : "required",
        "valueSet" : "https://fhir.inera.se/ig/strategicresourcemanagement-persons-person/ValueSet/SPP-datetypeformat-vs"
      }
    },
    {
      "id" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.addressInformation.addressAbroad.votingDate.value",
      "path" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.addressInformation.addressAbroad.votingDate.value",
      "short" : "value",
      "definition" : "value",
      "comment" : "TKB-fält: `../../../../../value` (`PartialDateValue`, kardinalitet 1..1).",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.addressInformation.givenAddress",
      "path" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.addressInformation.givenAddress",
      "short" : "ResidentialAddressType",
      "definition" : "Svensk adress",
      "comment" : "TKB-fält: `../../../givenAddress` (`ResidentialAddressType`, kardinalitet 0..1).",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "Base"
      }]
    },
    {
      "id" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.addressInformation.givenAddress.careOf",
      "path" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.addressInformation.givenAddress.careOf",
      "short" : "careOf",
      "definition" : "careOf",
      "comment" : "TKB-fält: `../../../../careOf` (`String40`, kardinalitet 0..1).",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.addressInformation.givenAddress.postalAddress1",
      "path" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.addressInformation.givenAddress.postalAddress1",
      "short" : "postalAddress1",
      "definition" : "postalAddress1",
      "comment" : "TKB-fält: `../../../../postalAddress1` (`String40`, kardinalitet 0..1).",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.addressInformation.givenAddress.postalAddress2",
      "path" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.addressInformation.givenAddress.postalAddress2",
      "short" : "postalAddress2",
      "definition" : "postalAddress2",
      "comment" : "TKB-fält: `../../../../postalAddress2` (`String40`, kardinalitet 0..1).",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.addressInformation.givenAddress.postalCode",
      "path" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.addressInformation.givenAddress.postalCode",
      "short" : "postalCode",
      "definition" : "postalCode",
      "comment" : "TKB-fält: `../../../../postalCode` (`PostalCode`, kardinalitet 0..1).",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "integer"
      }]
    },
    {
      "id" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.addressInformation.givenAddress.city",
      "path" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.addressInformation.givenAddress.city",
      "short" : "city",
      "definition" : "city",
      "comment" : "TKB-fält: `../../../../city` (`String40`, kardinalitet 0..1).",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.addressInformation.UUID",
      "path" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.addressInformation.UUID",
      "short" : "UUIDType",
      "definition" : "UUID för fastighet, aderess och lägenhet",
      "comment" : "TKB-fält: `../../../UUID` (`UUIDType`, kardinalitet 0..1).",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "Base"
      }]
    },
    {
      "id" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.addressInformation.UUID.propertyId",
      "path" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.addressInformation.UUID.propertyId",
      "short" : "propertyId",
      "definition" : "propertyId",
      "comment" : "TKB-fält: `../../../../propertyId` (`string`, kardinalitet 0..1).",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.addressInformation.UUID.addressPlaceId",
      "path" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.addressInformation.UUID.addressPlaceId",
      "short" : "addressPlaceId",
      "definition" : "addressPlaceId",
      "comment" : "TKB-fält: `../../../../addressPlaceId` (`string`, kardinalitet 0..1).",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.addressInformation.UUID.apartmentId",
      "path" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.addressInformation.UUID.apartmentId",
      "short" : "apartmentId",
      "definition" : "apartmentId",
      "comment" : "TKB-fält: `../../../../apartmentId` (`string`, kardinalitet 0..1).",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.contactInformation",
      "path" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.contactInformation",
      "short" : "ContactInformationType",
      "definition" : "Klass för patientens egna angivna kontakuppgifter",
      "comment" : "TKB-fält: `../../contactInformation` (`ContactInformationType`, kardinalitet 0..*).",
      "min" : 0,
      "max" : "*",
      "type" : [{
        "code" : "Base"
      }]
    },
    {
      "id" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.contactInformation.contactType",
      "path" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.contactInformation.contactType",
      "short" : "contactType",
      "definition" : "contactType",
      "comment" : "TKB-fält: `../../../contactType` (`CodedValue`, kardinalitet 1..1).",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.contactInformation.use",
      "path" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.contactInformation.use",
      "short" : "use",
      "definition" : "use",
      "comment" : "TKB-fält: `../../../use` (`CodedValue`, kardinalitet 0..1).",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.contactInformation.value",
      "path" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.contactInformation.value",
      "short" : "value",
      "definition" : "value",
      "comment" : "TKB-fält: `../../../value` (`string`, kardinalitet 0..1).",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.contactInformation.rank",
      "path" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.contactInformation.rank",
      "short" : "rank",
      "definition" : "rank",
      "comment" : "TKB-fält: `../../../rank` (`int`, kardinalitet 0..1).",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "integer"
      }]
    },
    {
      "id" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.contactInformation.comment",
      "path" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.contactInformation.comment",
      "short" : "comment",
      "definition" : "comment",
      "comment" : "TKB-fält: `../../../comment` (`string`, kardinalitet 0..1).",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.contactInformation.period",
      "path" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.contactInformation.period",
      "short" : "DatePeriodType",
      "definition" : "period",
      "comment" : "TKB-fält: `../../../period` (`DatePeriodType`, kardinalitet 0..1).",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "Base"
      }]
    },
    {
      "id" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.contactInformation.period.start",
      "path" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.contactInformation.period.start",
      "short" : "start",
      "definition" : "start",
      "comment" : "TKB-fält: `../../../../start` (`date`, kardinalitet 0..1).",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "date"
      }]
    },
    {
      "id" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.contactInformation.period.end",
      "path" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.contactInformation.period.end",
      "short" : "end",
      "definition" : "end",
      "comment" : "TKB-fält: `../../../../end` (`date`, kardinalitet 0..1).",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "date"
      }]
    },
    {
      "id" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.contactInformation.digitalNotification",
      "path" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.contactInformation.digitalNotification",
      "short" : "digitalNotification",
      "definition" : "digitalNotification",
      "comment" : "TKB-fält: `../../../digitalNotification` (`boolean`, kardinalitet 0..1).",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "boolean"
      }]
    },
    {
      "id" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.contactPerson",
      "path" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.contactPerson",
      "short" : "ContactPersonType",
      "definition" : "contactPerson",
      "comment" : "TKB-fält: `../../contactPerson` (`ContactPersonType`, kardinalitet 0..*).",
      "min" : 0,
      "max" : "*",
      "type" : [{
        "code" : "Base"
      }]
    },
    {
      "id" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.contactPerson.contactRelationshipType",
      "path" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.contactPerson.contactRelationshipType",
      "short" : "contactRelationshipType",
      "definition" : "contactRelationshipType",
      "comment" : "TKB-fält: `../../../contactRelationshipType` (`CodedValue`, kardinalitet 1..1).",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.contactPerson.priorityOrder",
      "path" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.contactPerson.priorityOrder",
      "short" : "priorityOrder",
      "definition" : "priorityOrder",
      "comment" : "TKB-fält: `../../../priorityOrder` (`int`, kardinalitet 0..1).",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "integer"
      }]
    },
    {
      "id" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.contactPerson.givenName",
      "path" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.contactPerson.givenName",
      "short" : "givenName",
      "definition" : "givenName",
      "comment" : "TKB-fält: `../../../givenName` (`String80`, kardinalitet 0..1).",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.contactPerson.surName",
      "path" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.contactPerson.surName",
      "short" : "surName",
      "definition" : "surName",
      "comment" : "TKB-fält: `../../../surName` (`String80`, kardinalitet 0..1).",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.contactPerson.middleName",
      "path" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.contactPerson.middleName",
      "short" : "middleName",
      "definition" : "middleName",
      "comment" : "TKB-fält: `../../../middleName` (`String80`, kardinalitet 0..1).",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.contactPerson.contactPersonAddress",
      "path" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.contactPerson.contactPersonAddress",
      "short" : "ResidentialAddressType",
      "definition" : "Svensk adress",
      "comment" : "TKB-fält: `../../../contactPersonAddress` (`ResidentialAddressType`, kardinalitet 0..1).",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "Base"
      }]
    },
    {
      "id" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.contactPerson.contactPersonAddress.careOf",
      "path" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.contactPerson.contactPersonAddress.careOf",
      "short" : "careOf",
      "definition" : "careOf",
      "comment" : "TKB-fält: `../../../../careOf` (`String40`, kardinalitet 0..1).",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.contactPerson.contactPersonAddress.postalAddress1",
      "path" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.contactPerson.contactPersonAddress.postalAddress1",
      "short" : "postalAddress1",
      "definition" : "postalAddress1",
      "comment" : "TKB-fält: `../../../../postalAddress1` (`String40`, kardinalitet 0..1).",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.contactPerson.contactPersonAddress.postalAddress2",
      "path" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.contactPerson.contactPersonAddress.postalAddress2",
      "short" : "postalAddress2",
      "definition" : "postalAddress2",
      "comment" : "TKB-fält: `../../../../postalAddress2` (`String40`, kardinalitet 0..1).",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.contactPerson.contactPersonAddress.postalCode",
      "path" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.contactPerson.contactPersonAddress.postalCode",
      "short" : "postalCode",
      "definition" : "postalCode",
      "comment" : "TKB-fält: `../../../../postalCode` (`PostalCode`, kardinalitet 0..1).",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "integer"
      }]
    },
    {
      "id" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.contactPerson.contactPersonAddress.city",
      "path" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.contactPerson.contactPersonAddress.city",
      "short" : "city",
      "definition" : "city",
      "comment" : "TKB-fält: `../../../../city` (`String40`, kardinalitet 0..1).",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.contactPerson.contactPersonContactInformation",
      "path" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.contactPerson.contactPersonContactInformation",
      "short" : "ContactInformationType",
      "definition" : "Klass för patientens egna angivna kontakuppgifter",
      "comment" : "TKB-fält: `../../../contactPersonContactInformation` (`ContactInformationType`, kardinalitet 0..*).",
      "min" : 0,
      "max" : "*",
      "type" : [{
        "code" : "Base"
      }]
    },
    {
      "id" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.contactPerson.contactPersonContactInformation.contactType",
      "path" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.contactPerson.contactPersonContactInformation.contactType",
      "short" : "contactType",
      "definition" : "contactType",
      "comment" : "TKB-fält: `../../../../contactType` (`CodedValue`, kardinalitet 1..1).",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.contactPerson.contactPersonContactInformation.use",
      "path" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.contactPerson.contactPersonContactInformation.use",
      "short" : "use",
      "definition" : "use",
      "comment" : "TKB-fält: `../../../../use` (`CodedValue`, kardinalitet 0..1).",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.contactPerson.contactPersonContactInformation.value",
      "path" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.contactPerson.contactPersonContactInformation.value",
      "short" : "value",
      "definition" : "value",
      "comment" : "TKB-fält: `../../../../value` (`string`, kardinalitet 0..1).",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.contactPerson.contactPersonContactInformation.rank",
      "path" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.contactPerson.contactPersonContactInformation.rank",
      "short" : "rank",
      "definition" : "rank",
      "comment" : "TKB-fält: `../../../../rank` (`int`, kardinalitet 0..1).",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "integer"
      }]
    },
    {
      "id" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.contactPerson.contactPersonContactInformation.comment",
      "path" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.contactPerson.contactPersonContactInformation.comment",
      "short" : "comment",
      "definition" : "comment",
      "comment" : "TKB-fält: `../../../../comment` (`string`, kardinalitet 0..1).",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.contactPerson.contactPersonContactInformation.period",
      "path" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.contactPerson.contactPersonContactInformation.period",
      "short" : "DatePeriodType",
      "definition" : "period",
      "comment" : "TKB-fält: `../../../../period` (`DatePeriodType`, kardinalitet 0..1).",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "Base"
      }]
    },
    {
      "id" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.contactPerson.contactPersonContactInformation.period.start",
      "path" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.contactPerson.contactPersonContactInformation.period.start",
      "short" : "start",
      "definition" : "start",
      "comment" : "TKB-fält: `../../../../../start` (`date`, kardinalitet 0..1).",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "date"
      }]
    },
    {
      "id" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.contactPerson.contactPersonContactInformation.period.end",
      "path" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.contactPerson.contactPersonContactInformation.period.end",
      "short" : "end",
      "definition" : "end",
      "comment" : "TKB-fält: `../../../../../end` (`date`, kardinalitet 0..1).",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "date"
      }]
    },
    {
      "id" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.contactPerson.contactPersonContactInformation.digitalNotification",
      "path" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.contactPerson.contactPersonContactInformation.digitalNotification",
      "short" : "digitalNotification",
      "definition" : "digitalNotification",
      "comment" : "TKB-fält: `../../../../digitalNotification` (`boolean`, kardinalitet 0..1).",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "boolean"
      }]
    },
    {
      "id" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.confirmedIdentity",
      "path" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.confirmedIdentity",
      "short" : "ConfirmedIdentityType",
      "definition" : "Klass för hur reservidentitetsuppgifter är styrkta.",
      "comment" : "TKB-fält: `../../confirmedIdentity` (`ConfirmedIdentityType`, kardinalitet 0..*).",
      "min" : 0,
      "max" : "*",
      "type" : [{
        "code" : "Base"
      }]
    },
    {
      "id" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.confirmedIdentity.typeOfIdentification",
      "path" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.confirmedIdentity.typeOfIdentification",
      "short" : "typeOfIdentification",
      "definition" : "typeOfIdentification",
      "comment" : "TKB-fält: `../../../typeOfIdentification` (`CodedValue`, kardinalitet 0..1).",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.confirmedIdentity.identificationNumber",
      "path" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.confirmedIdentity.identificationNumber",
      "short" : "identificationNumber",
      "definition" : "identificationNumber",
      "comment" : "TKB-fält: `../../../identificationNumber` (`string`, kardinalitet 0..1).",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.confirmedIdentity.issuersOfId",
      "path" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.confirmedIdentity.issuersOfId",
      "short" : "issuersOfId",
      "definition" : "issuersOfId",
      "comment" : "TKB-fält: `../../../issuersOfId` (`string`, kardinalitet 0..1).",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.confirmedIdentity.validDatePeriod",
      "path" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.confirmedIdentity.validDatePeriod",
      "short" : "DatePeriodType",
      "definition" : "validDatePeriod",
      "comment" : "TKB-fält: `../../../validDatePeriod` (`DatePeriodType`, kardinalitet 0..1).",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "Base"
      }]
    },
    {
      "id" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.confirmedIdentity.validDatePeriod.start",
      "path" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.confirmedIdentity.validDatePeriod.start",
      "short" : "start",
      "definition" : "start",
      "comment" : "TKB-fält: `../../../../start` (`date`, kardinalitet 0..1).",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "date"
      }]
    },
    {
      "id" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.confirmedIdentity.validDatePeriod.end",
      "path" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.confirmedIdentity.validDatePeriod.end",
      "short" : "end",
      "definition" : "end",
      "comment" : "TKB-fält: `../../../../end` (`date`, kardinalitet 0..1).",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "date"
      }]
    },
    {
      "id" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.confirmedIdentity.attachmentId",
      "path" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.confirmedIdentity.attachmentId",
      "short" : "attachmentId",
      "definition" : "attachmentId",
      "comment" : "TKB-fält: `../../../attachmentId` (`string`, kardinalitet 0..*).",
      "min" : 0,
      "max" : "*",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.confirmedIdentity.countryCode",
      "path" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.confirmedIdentity.countryCode",
      "short" : "countryCode",
      "definition" : "countryCode",
      "comment" : "TKB-fält: `../../../countryCode` (`CountryCode`, kardinalitet 0..1).",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.administrativeInformation",
      "path" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.administrativeInformation",
      "short" : "AdministrativeInformationType",
      "definition" : "Klass för administrativa tilläggsuppgifter. Normalt tilläggsuppgifter kring en person med en reservidentitet som registreras i samband med uttag av reservidentitet (LRID/NRID).",
      "comment" : "TKB-fält: `../../administrativeInformation` (`AdministrativeInformationType`, kardinalitet 0..1).",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "Base"
      }]
    },
    {
      "id" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.administrativeInformation.categoryOfPerson",
      "path" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.administrativeInformation.categoryOfPerson",
      "short" : "categoryOfPerson",
      "definition" : "categoryOfPerson",
      "comment" : "TKB-fält: `../../../categoryOfPerson` (`CodedValue`, kardinalitet 0..1).",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.administrativeInformation.accountCode",
      "path" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.administrativeInformation.accountCode",
      "short" : "accountCode",
      "definition" : "accountCode",
      "comment" : "TKB-fält: `../../../accountCode` (`CodedValue`, kardinalitet 0..1).",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.administrativeInformation.comment",
      "path" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.administrativeInformation.comment",
      "short" : "comment",
      "definition" : "comment",
      "comment" : "TKB-fält: `../../../comment` (`string`, kardinalitet 0..1).",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.deregistration",
      "path" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.deregistration",
      "short" : "DeregistrationType",
      "definition" : "Uppgifter om avregistrering",
      "comment" : "TKB-fält: `../../deregistration` (`DeregistrationType`, kardinalitet 0..1).",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "Base"
      }]
    },
    {
      "id" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.deregistration.deregistrationReasonCode",
      "path" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.deregistration.deregistrationReasonCode",
      "short" : "deregistrationReasonCode",
      "definition" : "deregistrationReasonCode",
      "comment" : "TKB-fält: `../../../deregistrationReasonCode` (`CodedValue`, kardinalitet 0..1).",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.deregistration.deregistrationDate",
      "path" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.deregistration.deregistrationDate",
      "short" : "PartialDateType",
      "definition" : "Kan beskriva ett datum med variabel noggrannhet.",
      "comment" : "TKB-fält: `../../../deregistrationDate` (`PartialDateType`, kardinalitet 0..1).",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "Base"
      }]
    },
    {
      "id" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.deregistration.deregistrationDate.format",
      "path" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.deregistration.deregistrationDate.format",
      "short" : "format",
      "definition" : "format Tillåtna värden: YYYY, YYYY-MM, YYYY-MM-DD.",
      "comment" : "TKB-fält: `../../../../format` (`DateTypeFormatType`, kardinalitet 1..1).\n\n**Modellanteckning:** format Tillåtna värden: YYYY, YYYY-MM, YYYY-MM-DD.",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "code"
      }],
      "binding" : {
        "strength" : "required",
        "valueSet" : "https://fhir.inera.se/ig/strategicresourcemanagement-persons-person/ValueSet/SPP-datetypeformat-vs"
      }
    },
    {
      "id" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.deregistration.deregistrationDate.value",
      "path" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.deregistration.deregistrationDate.value",
      "short" : "value",
      "definition" : "value",
      "comment" : "TKB-fält: `../../../../value` (`PartialDateValue`, kardinalitet 1..1).",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.deregistration.foundDeadAtDate",
      "path" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.deregistration.foundDeadAtDate",
      "short" : "PartialDateType",
      "definition" : "Kan beskriva ett datum med variabel noggrannhet.",
      "comment" : "TKB-fält: `../../../foundDeadAtDate` (`PartialDateType`, kardinalitet 0..1).",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "Base"
      }]
    },
    {
      "id" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.deregistration.foundDeadAtDate.format",
      "path" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.deregistration.foundDeadAtDate.format",
      "short" : "format",
      "definition" : "format Tillåtna värden: YYYY, YYYY-MM, YYYY-MM-DD.",
      "comment" : "TKB-fält: `../../../../format` (`DateTypeFormatType`, kardinalitet 1..1).\n\n**Modellanteckning:** format Tillåtna värden: YYYY, YYYY-MM, YYYY-MM-DD.",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "code"
      }],
      "binding" : {
        "strength" : "required",
        "valueSet" : "https://fhir.inera.se/ig/strategicresourcemanagement-persons-person/ValueSet/SPP-datetypeformat-vs"
      }
    },
    {
      "id" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.deregistration.foundDeadAtDate.value",
      "path" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.deregistration.foundDeadAtDate.value",
      "short" : "value",
      "definition" : "value",
      "comment" : "TKB-fält: `../../../../value` (`PartialDateValue`, kardinalitet 1..1).",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.maritalStatus",
      "path" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.maritalStatus",
      "short" : "MaritalStatusType",
      "definition" : "Civistånd",
      "comment" : "TKB-fält: `../../maritalStatus` (`MaritalStatusType`, kardinalitet 0..1).",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "Base"
      }]
    },
    {
      "id" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.maritalStatus.maritalStatusCode",
      "path" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.maritalStatus.maritalStatusCode",
      "short" : "maritalStatusCode",
      "definition" : "maritalStatusCode",
      "comment" : "TKB-fält: `../../../maritalStatusCode` (`CodedValue`, kardinalitet 0..1).",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.maritalStatus.maritalStatusDate",
      "path" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.maritalStatus.maritalStatusDate",
      "short" : "PartialDateType",
      "definition" : "Kan beskriva ett datum med variabel noggrannhet.",
      "comment" : "TKB-fält: `../../../maritalStatusDate` (`PartialDateType`, kardinalitet 0..1).",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "Base"
      }]
    },
    {
      "id" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.maritalStatus.maritalStatusDate.format",
      "path" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.maritalStatus.maritalStatusDate.format",
      "short" : "format",
      "definition" : "format Tillåtna värden: YYYY, YYYY-MM, YYYY-MM-DD.",
      "comment" : "TKB-fält: `../../../../format` (`DateTypeFormatType`, kardinalitet 1..1).\n\n**Modellanteckning:** format Tillåtna värden: YYYY, YYYY-MM, YYYY-MM-DD.",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "code"
      }],
      "binding" : {
        "strength" : "required",
        "valueSet" : "https://fhir.inera.se/ig/strategicresourcemanagement-persons-person/ValueSet/SPP-datetypeformat-vs"
      }
    },
    {
      "id" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.maritalStatus.maritalStatusDate.value",
      "path" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.maritalStatus.maritalStatusDate.value",
      "short" : "value",
      "definition" : "value",
      "comment" : "TKB-fält: `../../../../value` (`PartialDateValue`, kardinalitet 1..1).",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.immigration",
      "path" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.immigration",
      "short" : "ImmigrationType",
      "definition" : "Grupp för invandringsuppgifter",
      "comment" : "TKB-fält: `../../immigration` (`ImmigrationType`, kardinalitet 0..1).",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "Base"
      }]
    },
    {
      "id" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.immigration.immigrationDate",
      "path" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.immigration.immigrationDate",
      "short" : "PartialDateType",
      "definition" : "Kan beskriva ett datum med variabel noggrannhet.",
      "comment" : "TKB-fält: `../../../immigrationDate` (`PartialDateType`, kardinalitet 0..1).",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "Base"
      }]
    },
    {
      "id" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.immigration.immigrationDate.format",
      "path" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.immigration.immigrationDate.format",
      "short" : "format",
      "definition" : "format Tillåtna värden: YYYY, YYYY-MM, YYYY-MM-DD.",
      "comment" : "TKB-fält: `../../../../format` (`DateTypeFormatType`, kardinalitet 1..1).\n\n**Modellanteckning:** format Tillåtna värden: YYYY, YYYY-MM, YYYY-MM-DD.",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "code"
      }],
      "binding" : {
        "strength" : "required",
        "valueSet" : "https://fhir.inera.se/ig/strategicresourcemanagement-persons-person/ValueSet/SPP-datetypeformat-vs"
      }
    },
    {
      "id" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.immigration.immigrationDate.value",
      "path" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.immigration.immigrationDate.value",
      "short" : "value",
      "definition" : "value",
      "comment" : "TKB-fält: `../../../../value` (`PartialDateValue`, kardinalitet 1..1).",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.immigration.rightOfResidence",
      "path" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.immigration.rightOfResidence",
      "short" : "rightOfResidence",
      "definition" : "rightOfResidence",
      "comment" : "TKB-fält: `../../../rightOfResidence` (`boolean`, kardinalitet 0..1).",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "boolean"
      }]
    },
    {
      "id" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.immigration.immigrationIdentity",
      "path" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.immigration.immigrationIdentity",
      "short" : "ImmigrationIdentityType",
      "definition" : "Grupp för personnummer och vilket land det är knutet till. Motsvarar skatteverkets NordisktPnrDa, NordisktPnrFi, NordisktPnrFo, NordisktPnrIs och NordisktPnrNo",
      "comment" : "TKB-fält: `../../../immigrationIdentity` (`ImmigrationIdentityType`, kardinalitet 0..*).",
      "min" : 0,
      "max" : "*",
      "type" : [{
        "code" : "Base"
      }]
    },
    {
      "id" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.immigration.immigrationIdentity.personalIdentityNumber",
      "path" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.immigration.immigrationIdentity.personalIdentityNumber",
      "short" : "personalIdentityNumber",
      "definition" : "personalIdentityNumber",
      "comment" : "TKB-fält: `../../../../personalIdentityNumber` (`PersonalIdentityNumber`, kardinalitet 1..1).",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.immigration.immigrationIdentity.country",
      "path" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.immigration.immigrationIdentity.country",
      "short" : "country",
      "definition" : "country",
      "comment" : "TKB-fält: `../../../../country` (`CountryCode`, kardinalitet 1..1).",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.citizenship",
      "path" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.citizenship",
      "short" : "CitizenshipType",
      "definition" : "Grupp för medborgarskap",
      "comment" : "TKB-fält: `../../citizenship` (`CitizenshipType`, kardinalitet 0..*).",
      "min" : 0,
      "max" : "*",
      "type" : [{
        "code" : "Base"
      }]
    },
    {
      "id" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.citizenship.citizenshipCountryCode",
      "path" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.citizenship.citizenshipCountryCode",
      "short" : "citizenshipCountryCode",
      "definition" : "citizenshipCountryCode",
      "comment" : "TKB-fält: `../../../citizenshipCountryCode` (`CountryCode`, kardinalitet 0..1).",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.citizenship.citizenshipDate",
      "path" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.citizenship.citizenshipDate",
      "short" : "PartialDateType",
      "definition" : "Kan beskriva ett datum med variabel noggrannhet.",
      "comment" : "TKB-fält: `../../../citizenshipDate` (`PartialDateType`, kardinalitet 0..1).",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "Base"
      }]
    },
    {
      "id" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.citizenship.citizenshipDate.format",
      "path" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.citizenship.citizenshipDate.format",
      "short" : "format",
      "definition" : "format Tillåtna värden: YYYY, YYYY-MM, YYYY-MM-DD.",
      "comment" : "TKB-fält: `../../../../format` (`DateTypeFormatType`, kardinalitet 1..1).\n\n**Modellanteckning:** format Tillåtna värden: YYYY, YYYY-MM, YYYY-MM-DD.",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "code"
      }],
      "binding" : {
        "strength" : "required",
        "valueSet" : "https://fhir.inera.se/ig/strategicresourcemanagement-persons-person/ValueSet/SPP-datetypeformat-vs"
      }
    },
    {
      "id" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.citizenship.citizenshipDate.value",
      "path" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.citizenship.citizenshipDate.value",
      "short" : "value",
      "definition" : "value",
      "comment" : "TKB-fält: `../../../../value` (`PartialDateValue`, kardinalitet 1..1).",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.citizenship.status",
      "path" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.citizenship.status",
      "short" : "status",
      "definition" : "status",
      "comment" : "TKB-fält: `../../../status` (`CodedValue`, kardinalitet 0..1).",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.relationship",
      "path" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.relationship",
      "short" : "RelationshipType",
      "definition" : "Grupp för relation",
      "comment" : "TKB-fält: `../../relationship` (`RelationshipType`, kardinalitet 0..*).",
      "min" : 0,
      "max" : "*",
      "type" : [{
        "code" : "Base"
      }]
    },
    {
      "id" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.relationship.relationshipId",
      "path" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.relationship.relationshipId",
      "short" : "RelationshipIdType",
      "definition" : "Grupp för relationspersons identitet Antingen får man personnummer eller datum då personen föddes.",
      "comment" : "TKB-fält: `../../../relationshipId` (`RelationshipIdType`, kardinalitet 1..1).",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "Base"
      }]
    },
    {
      "id" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.relationship.relationshipId.personalIdentity",
      "path" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.relationship.relationshipId.personalIdentity",
      "short" : "personalIdentity",
      "definition" : "En universellt unik identifierare.",
      "comment" : "TKB-fält: `../../../../personalIdentity` (`IIType`, kardinalitet 0..1).",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "https://fhir.inera.se/ig/rivta-datatypes/StructureDefinition/IIType"
      }]
    },
    {
      "id" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.relationship.relationshipId.dateOfBirth",
      "path" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.relationship.relationshipId.dateOfBirth",
      "short" : "PartialDateType",
      "definition" : "Kan beskriva ett datum med variabel noggrannhet.",
      "comment" : "TKB-fält: `../../../../dateOfBirth` (`PartialDateType`, kardinalitet 0..1).",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "Base"
      }]
    },
    {
      "id" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.relationship.relationshipId.dateOfBirth.format",
      "path" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.relationship.relationshipId.dateOfBirth.format",
      "short" : "format",
      "definition" : "format Tillåtna värden: YYYY, YYYY-MM, YYYY-MM-DD.",
      "comment" : "TKB-fält: `../../../../../format` (`DateTypeFormatType`, kardinalitet 1..1).\n\n**Modellanteckning:** format Tillåtna värden: YYYY, YYYY-MM, YYYY-MM-DD.",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "code"
      }],
      "binding" : {
        "strength" : "required",
        "valueSet" : "https://fhir.inera.se/ig/strategicresourcemanagement-persons-person/ValueSet/SPP-datetypeformat-vs"
      }
    },
    {
      "id" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.relationship.relationshipId.dateOfBirth.value",
      "path" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.relationship.relationshipId.dateOfBirth.value",
      "short" : "value",
      "definition" : "value",
      "comment" : "TKB-fält: `../../../../../value` (`PartialDateValue`, kardinalitet 1..1).",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.relationship.relationshipType",
      "path" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.relationship.relationshipType",
      "short" : "relationshipType",
      "definition" : "relationshipType",
      "comment" : "TKB-fält: `../../../relationshipType` (`CodedValue`, kardinalitet 1..1).",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.relationship.relationshipFromDate",
      "path" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.relationship.relationshipFromDate",
      "short" : "PartialDateType",
      "definition" : "Kan beskriva ett datum med variabel noggrannhet.",
      "comment" : "TKB-fält: `../../../relationshipFromDate` (`PartialDateType`, kardinalitet 0..1).",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "Base"
      }]
    },
    {
      "id" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.relationship.relationshipFromDate.format",
      "path" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.relationship.relationshipFromDate.format",
      "short" : "format",
      "definition" : "format Tillåtna värden: YYYY, YYYY-MM, YYYY-MM-DD.",
      "comment" : "TKB-fält: `../../../../format` (`DateTypeFormatType`, kardinalitet 1..1).\n\n**Modellanteckning:** format Tillåtna värden: YYYY, YYYY-MM, YYYY-MM-DD.",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "code"
      }],
      "binding" : {
        "strength" : "required",
        "valueSet" : "https://fhir.inera.se/ig/strategicresourcemanagement-persons-person/ValueSet/SPP-datetypeformat-vs"
      }
    },
    {
      "id" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.relationship.relationshipFromDate.value",
      "path" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.relationship.relationshipFromDate.value",
      "short" : "value",
      "definition" : "value",
      "comment" : "TKB-fält: `../../../../value` (`PartialDateValue`, kardinalitet 1..1).",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.relationship.relationshipToDate",
      "path" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.relationship.relationshipToDate",
      "short" : "PartialDateType",
      "definition" : "Kan beskriva ett datum med variabel noggrannhet.",
      "comment" : "TKB-fält: `../../../relationshipToDate` (`PartialDateType`, kardinalitet 0..1).",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "Base"
      }]
    },
    {
      "id" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.relationship.relationshipToDate.format",
      "path" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.relationship.relationshipToDate.format",
      "short" : "format",
      "definition" : "format Tillåtna värden: YYYY, YYYY-MM, YYYY-MM-DD.",
      "comment" : "TKB-fält: `../../../../format` (`DateTypeFormatType`, kardinalitet 1..1).\n\n**Modellanteckning:** format Tillåtna värden: YYYY, YYYY-MM, YYYY-MM-DD.",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "code"
      }],
      "binding" : {
        "strength" : "required",
        "valueSet" : "https://fhir.inera.se/ig/strategicresourcemanagement-persons-person/ValueSet/SPP-datetypeformat-vs"
      }
    },
    {
      "id" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.relationship.relationshipToDate.value",
      "path" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.relationship.relationshipToDate.value",
      "short" : "value",
      "definition" : "value",
      "comment" : "TKB-fält: `../../../../value` (`PartialDateValue`, kardinalitet 1..1).",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.relationship.name",
      "path" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.relationship.name",
      "short" : "NameType",
      "definition" : "Namn",
      "comment" : "TKB-fält: `../../../name` (`NameType`, kardinalitet 0..1).",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "Base"
      }]
    },
    {
      "id" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.relationship.name.givenNameIndicator",
      "path" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.relationship.name.givenNameIndicator",
      "short" : "givenNameIndicator",
      "definition" : "givenNameIndicator",
      "comment" : "TKB-fält: `../../../../givenNameIndicator` (`GivenNameIndicator`, kardinalitet 0..1).",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "integer"
      }]
    },
    {
      "id" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.relationship.name.givenName",
      "path" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.relationship.name.givenName",
      "short" : "givenName",
      "definition" : "givenName",
      "comment" : "TKB-fält: `../../../../givenName` (`String80`, kardinalitet 0..1).",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.relationship.name.middleName",
      "path" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.relationship.name.middleName",
      "short" : "middleName",
      "definition" : "middleName",
      "comment" : "TKB-fält: `../../../../middleName` (`String80`, kardinalitet 0..1).",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.relationship.name.surname",
      "path" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.relationship.name.surname",
      "short" : "surname",
      "definition" : "surname",
      "comment" : "TKB-fält: `../../../../surname` (`String80`, kardinalitet 0..1).",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.relationship.name.notificationName",
      "path" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.relationship.name.notificationName",
      "short" : "notificationName",
      "definition" : "notificationName",
      "comment" : "TKB-fält: `../../../../notificationName` (`String40`, kardinalitet 0..1).",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.relationship.deregistration",
      "path" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.relationship.deregistration",
      "short" : "DeregistrationType",
      "definition" : "Uppgifter om avregistrering",
      "comment" : "TKB-fält: `../../../deregistration` (`DeregistrationType`, kardinalitet 0..1).",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "Base"
      }]
    },
    {
      "id" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.relationship.deregistration.deregistrationReasonCode",
      "path" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.relationship.deregistration.deregistrationReasonCode",
      "short" : "deregistrationReasonCode",
      "definition" : "deregistrationReasonCode",
      "comment" : "TKB-fält: `../../../../deregistrationReasonCode` (`CodedValue`, kardinalitet 0..1).",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.relationship.deregistration.deregistrationDate",
      "path" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.relationship.deregistration.deregistrationDate",
      "short" : "PartialDateType",
      "definition" : "Kan beskriva ett datum med variabel noggrannhet.",
      "comment" : "TKB-fält: `../../../../deregistrationDate` (`PartialDateType`, kardinalitet 0..1).",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "Base"
      }]
    },
    {
      "id" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.relationship.deregistration.deregistrationDate.format",
      "path" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.relationship.deregistration.deregistrationDate.format",
      "short" : "format",
      "definition" : "format Tillåtna värden: YYYY, YYYY-MM, YYYY-MM-DD.",
      "comment" : "TKB-fält: `../../../../../format` (`DateTypeFormatType`, kardinalitet 1..1).\n\n**Modellanteckning:** format Tillåtna värden: YYYY, YYYY-MM, YYYY-MM-DD.",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "code"
      }],
      "binding" : {
        "strength" : "required",
        "valueSet" : "https://fhir.inera.se/ig/strategicresourcemanagement-persons-person/ValueSet/SPP-datetypeformat-vs"
      }
    },
    {
      "id" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.relationship.deregistration.deregistrationDate.value",
      "path" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.relationship.deregistration.deregistrationDate.value",
      "short" : "value",
      "definition" : "value",
      "comment" : "TKB-fält: `../../../../../value` (`PartialDateValue`, kardinalitet 1..1).",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.relationship.deregistration.foundDeadAtDate",
      "path" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.relationship.deregistration.foundDeadAtDate",
      "short" : "PartialDateType",
      "definition" : "Kan beskriva ett datum med variabel noggrannhet.",
      "comment" : "TKB-fält: `../../../../foundDeadAtDate` (`PartialDateType`, kardinalitet 0..1).",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "Base"
      }]
    },
    {
      "id" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.relationship.deregistration.foundDeadAtDate.format",
      "path" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.relationship.deregistration.foundDeadAtDate.format",
      "short" : "format",
      "definition" : "format Tillåtna värden: YYYY, YYYY-MM, YYYY-MM-DD.",
      "comment" : "TKB-fält: `../../../../../format` (`DateTypeFormatType`, kardinalitet 1..1).\n\n**Modellanteckning:** format Tillåtna värden: YYYY, YYYY-MM, YYYY-MM-DD.",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "code"
      }],
      "binding" : {
        "strength" : "required",
        "valueSet" : "https://fhir.inera.se/ig/strategicresourcemanagement-persons-person/ValueSet/SPP-datetypeformat-vs"
      }
    },
    {
      "id" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.relationship.deregistration.foundDeadAtDate.value",
      "path" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.relationship.deregistration.foundDeadAtDate.value",
      "short" : "value",
      "definition" : "value",
      "comment" : "TKB-fält: `../../../../../value` (`PartialDateValue`, kardinalitet 1..1).",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.relationship.status",
      "path" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.relationship.status",
      "short" : "status",
      "definition" : "status",
      "comment" : "TKB-fält: `../../../status` (`CodedValue`, kardinalitet 0..1).",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.coOrdinationNumberData",
      "path" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.coOrdinationNumberData",
      "short" : "CoOrdinationNumberDataType",
      "definition" : "Grupp för de personer som ej är folkbokförda men som har tilldelats ett samordningsnummer för identifiering av personen. Syftet med samordningsnummer är att myndigheter och andra samhällsfunktioner ska kunna identifiera personer även om de inte är folkbokförda i Sverige.",
      "comment" : "TKB-fält: `../../coOrdinationNumberData` (`CoOrdinationNumberDataType`, kardinalitet 0..1).",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "Base"
      }]
    },
    {
      "id" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.coOrdinationNumberData.allocationDate",
      "path" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.coOrdinationNumberData.allocationDate",
      "short" : "PartialDateType",
      "definition" : "Kan beskriva ett datum med variabel noggrannhet.",
      "comment" : "TKB-fält: `../../../allocationDate` (`PartialDateType`, kardinalitet 0..1).",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "Base"
      }]
    },
    {
      "id" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.coOrdinationNumberData.allocationDate.format",
      "path" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.coOrdinationNumberData.allocationDate.format",
      "short" : "format",
      "definition" : "format Tillåtna värden: YYYY, YYYY-MM, YYYY-MM-DD.",
      "comment" : "TKB-fält: `../../../../format` (`DateTypeFormatType`, kardinalitet 1..1).\n\n**Modellanteckning:** format Tillåtna värden: YYYY, YYYY-MM, YYYY-MM-DD.",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "code"
      }],
      "binding" : {
        "strength" : "required",
        "valueSet" : "https://fhir.inera.se/ig/strategicresourcemanagement-persons-person/ValueSet/SPP-datetypeformat-vs"
      }
    },
    {
      "id" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.coOrdinationNumberData.allocationDate.value",
      "path" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.coOrdinationNumberData.allocationDate.value",
      "short" : "value",
      "definition" : "value",
      "comment" : "TKB-fält: `../../../../value` (`PartialDateValue`, kardinalitet 1..1).",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.coOrdinationNumberData.preliminaryTransferDate",
      "path" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.coOrdinationNumberData.preliminaryTransferDate",
      "short" : "PartialDateType",
      "definition" : "Kan beskriva ett datum med variabel noggrannhet.",
      "comment" : "TKB-fält: `../../../preliminaryTransferDate` (`PartialDateType`, kardinalitet 0..1).",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "Base"
      }]
    },
    {
      "id" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.coOrdinationNumberData.preliminaryTransferDate.format",
      "path" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.coOrdinationNumberData.preliminaryTransferDate.format",
      "short" : "format",
      "definition" : "format Tillåtna värden: YYYY, YYYY-MM, YYYY-MM-DD.",
      "comment" : "TKB-fält: `../../../../format` (`DateTypeFormatType`, kardinalitet 1..1).\n\n**Modellanteckning:** format Tillåtna värden: YYYY, YYYY-MM, YYYY-MM-DD.",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "code"
      }],
      "binding" : {
        "strength" : "required",
        "valueSet" : "https://fhir.inera.se/ig/strategicresourcemanagement-persons-person/ValueSet/SPP-datetypeformat-vs"
      }
    },
    {
      "id" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.coOrdinationNumberData.preliminaryTransferDate.value",
      "path" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.coOrdinationNumberData.preliminaryTransferDate.value",
      "short" : "value",
      "definition" : "value",
      "comment" : "TKB-fält: `../../../../value` (`PartialDateValue`, kardinalitet 1..1).",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.coOrdinationNumberData.renewalDate",
      "path" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.coOrdinationNumberData.renewalDate",
      "short" : "PartialDateType",
      "definition" : "Kan beskriva ett datum med variabel noggrannhet.",
      "comment" : "TKB-fält: `../../../renewalDate` (`PartialDateType`, kardinalitet 0..1).",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "Base"
      }]
    },
    {
      "id" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.coOrdinationNumberData.renewalDate.format",
      "path" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.coOrdinationNumberData.renewalDate.format",
      "short" : "format",
      "definition" : "format Tillåtna värden: YYYY, YYYY-MM, YYYY-MM-DD.",
      "comment" : "TKB-fält: `../../../../format` (`DateTypeFormatType`, kardinalitet 1..1).\n\n**Modellanteckning:** format Tillåtna värden: YYYY, YYYY-MM, YYYY-MM-DD.",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "code"
      }],
      "binding" : {
        "strength" : "required",
        "valueSet" : "https://fhir.inera.se/ig/strategicresourcemanagement-persons-person/ValueSet/SPP-datetypeformat-vs"
      }
    },
    {
      "id" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.coOrdinationNumberData.renewalDate.value",
      "path" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.coOrdinationNumberData.renewalDate.value",
      "short" : "value",
      "definition" : "value",
      "comment" : "TKB-fält: `../../../../value` (`PartialDateValue`, kardinalitet 1..1).",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.coOrdinationNumberData.deceasedDate",
      "path" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.coOrdinationNumberData.deceasedDate",
      "short" : "PartialDateType",
      "definition" : "Kan beskriva ett datum med variabel noggrannhet.",
      "comment" : "TKB-fält: `../../../deceasedDate` (`PartialDateType`, kardinalitet 0..1).",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "Base"
      }]
    },
    {
      "id" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.coOrdinationNumberData.deceasedDate.format",
      "path" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.coOrdinationNumberData.deceasedDate.format",
      "short" : "format",
      "definition" : "format Tillåtna värden: YYYY, YYYY-MM, YYYY-MM-DD.",
      "comment" : "TKB-fält: `../../../../format` (`DateTypeFormatType`, kardinalitet 1..1).\n\n**Modellanteckning:** format Tillåtna värden: YYYY, YYYY-MM, YYYY-MM-DD.",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "code"
      }],
      "binding" : {
        "strength" : "required",
        "valueSet" : "https://fhir.inera.se/ig/strategicresourcemanagement-persons-person/ValueSet/SPP-datetypeformat-vs"
      }
    },
    {
      "id" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.coOrdinationNumberData.deceasedDate.value",
      "path" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.coOrdinationNumberData.deceasedDate.value",
      "short" : "value",
      "definition" : "value",
      "comment" : "TKB-fält: `../../../../value` (`PartialDateValue`, kardinalitet 1..1).",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.personalIdentityStatus",
      "path" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.personalIdentityStatus",
      "short" : "PersonalIdentityStatusType",
      "definition" : "Klass som beskriver status för ett samordningsnummer. Status, datum och orsak ska vara obligatoriska uppgifter, när de finns, för aviseringar innehållande samordningsnummer.",
      "comment" : "TKB-fält: `../../personalIdentityStatus` (`PersonalIdentityStatusType`, kardinalitet 0..1).",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "Base"
      }]
    },
    {
      "id" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.personalIdentityStatus.identityStatus",
      "path" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.personalIdentityStatus.identityStatus",
      "short" : "identityStatus",
      "definition" : "identityStatus",
      "comment" : "TKB-fält: `../../../identityStatus` (`string`, kardinalitet 0..1).",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.personalIdentityStatus.identityStatusDate",
      "path" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.personalIdentityStatus.identityStatusDate",
      "short" : "PartialDateType",
      "definition" : "Kan beskriva ett datum med variabel noggrannhet.",
      "comment" : "TKB-fält: `../../../identityStatusDate` (`PartialDateType`, kardinalitet 0..1).",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "Base"
      }]
    },
    {
      "id" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.personalIdentityStatus.identityStatusDate.format",
      "path" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.personalIdentityStatus.identityStatusDate.format",
      "short" : "format",
      "definition" : "format Tillåtna värden: YYYY, YYYY-MM, YYYY-MM-DD.",
      "comment" : "TKB-fält: `../../../../format` (`DateTypeFormatType`, kardinalitet 1..1).\n\n**Modellanteckning:** format Tillåtna värden: YYYY, YYYY-MM, YYYY-MM-DD.",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "code"
      }],
      "binding" : {
        "strength" : "required",
        "valueSet" : "https://fhir.inera.se/ig/strategicresourcemanagement-persons-person/ValueSet/SPP-datetypeformat-vs"
      }
    },
    {
      "id" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.personalIdentityStatus.identityStatusDate.value",
      "path" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.personalIdentityStatus.identityStatusDate.value",
      "short" : "value",
      "definition" : "value",
      "comment" : "TKB-fält: `../../../../value` (`PartialDateValue`, kardinalitet 1..1).",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.personalIdentityStatus.identityStatusCause",
      "path" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.personalIdentityStatus.identityStatusCause",
      "short" : "identityStatusCause",
      "definition" : "identityStatusCause",
      "comment" : "TKB-fält: `../../../identityStatusCause` (`string`, kardinalitet 0..1).",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.updatePersonActor",
      "path" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.updatePersonActor",
      "short" : "ActorType",
      "definition" : "Datatyp som identifierar en aktör.",
      "comment" : "TKB-fält: `../../updatePersonActor` (`ActorType`, kardinalitet 0..1).",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "Base"
      }]
    },
    {
      "id" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.updatePersonActor.id",
      "path" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.updatePersonActor.id",
      "short" : "id",
      "definition" : "En universellt unik identifierare.",
      "comment" : "TKB-fält: `../../../id` (`IIType`, kardinalitet 1..1).",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "https://fhir.inera.se/ig/rivta-datatypes/StructureDefinition/IIType"
      }]
    },
    {
      "id" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.updatePersonActor.professional",
      "path" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.updatePersonActor.professional",
      "short" : "ProfessionalType",
      "definition" : "Datatyp som identifierar en aktör inom en profession.",
      "comment" : "TKB-fält: `../../../professional` (`ProfessionalType`, kardinalitet 0..1).",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "Base"
      }]
    },
    {
      "id" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.updatePersonActor.professional.organizationId",
      "path" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.updatePersonActor.professional.organizationId",
      "short" : "organizationId",
      "definition" : "En universellt unik identifierare.",
      "comment" : "TKB-fält: `../../../../organizationId` (`IIType`, kardinalitet 1..1).",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "https://fhir.inera.se/ig/rivta-datatypes/StructureDefinition/IIType"
      }]
    },
    {
      "id" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.updatePersonActor.updateTime",
      "path" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.updatePersonActor.updateTime",
      "short" : "updateTime",
      "definition" : "updateTime",
      "comment" : "TKB-fält: `../../../updateTime` (`Timestamp`, kardinalitet 0..1).",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.updatePersonContactInformationActor",
      "path" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.updatePersonContactInformationActor",
      "short" : "ActorType",
      "definition" : "Datatyp som identifierar en aktör.",
      "comment" : "TKB-fält: `../../updatePersonContactInformationActor` (`ActorType`, kardinalitet 0..1).",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "Base"
      }]
    },
    {
      "id" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.updatePersonContactInformationActor.id",
      "path" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.updatePersonContactInformationActor.id",
      "short" : "id",
      "definition" : "En universellt unik identifierare.",
      "comment" : "TKB-fält: `../../../id` (`IIType`, kardinalitet 1..1).",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "https://fhir.inera.se/ig/rivta-datatypes/StructureDefinition/IIType"
      }]
    },
    {
      "id" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.updatePersonContactInformationActor.professional",
      "path" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.updatePersonContactInformationActor.professional",
      "short" : "ProfessionalType",
      "definition" : "Datatyp som identifierar en aktör inom en profession.",
      "comment" : "TKB-fält: `../../../professional` (`ProfessionalType`, kardinalitet 0..1).",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "Base"
      }]
    },
    {
      "id" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.updatePersonContactInformationActor.professional.organizationId",
      "path" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.updatePersonContactInformationActor.professional.organizationId",
      "short" : "organizationId",
      "definition" : "En universellt unik identifierare.",
      "comment" : "TKB-fält: `../../../../organizationId` (`IIType`, kardinalitet 1..1).",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "https://fhir.inera.se/ig/rivta-datatypes/StructureDefinition/IIType"
      }]
    },
    {
      "id" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.updatePersonContactInformationActor.updateTime",
      "path" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.updatePersonContactInformationActor.updateTime",
      "short" : "updateTime",
      "definition" : "updateTime",
      "comment" : "TKB-fält: `../../../updateTime` (`Timestamp`, kardinalitet 0..1).",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.attachment",
      "path" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.attachment",
      "short" : "MultimediaType",
      "definition" : "Datatyp som beskriver en multimediatyp. Data kan förekomma som inbäddat element eller hänvisas via en referens URL.",
      "comment" : "TKB-fält: `../../attachment` (`MultimediaType`, kardinalitet 0..*).",
      "min" : 0,
      "max" : "*",
      "type" : [{
        "code" : "Base"
      }]
    },
    {
      "id" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.attachment.id",
      "path" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.attachment.id",
      "short" : "id",
      "definition" : "id",
      "comment" : "TKB-fält: `../../../id` (`string`, kardinalitet 0..1).",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.attachment.mediaType",
      "path" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.attachment.mediaType",
      "short" : "mediaType",
      "definition" : "mediaType",
      "comment" : "TKB-fält: `../../../mediaType` (`CodedValue`, kardinalitet 1..1).",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.attachment.value",
      "path" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.attachment.value",
      "short" : "value",
      "definition" : "value",
      "comment" : "TKB-fält: `../../../value` (`base64Binary`, kardinalitet 0..1).",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "base64Binary"
      }]
    },
    {
      "id" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.attachment.reference",
      "path" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.attachment.reference",
      "short" : "reference",
      "definition" : "reference",
      "comment" : "TKB-fält: `../../../reference` (`anyURI`, kardinalitet 0..1).",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "uri"
      }]
    },
    {
      "id" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.optoutPaperNotification",
      "path" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.optoutPaperNotification",
      "short" : "optoutPaperNotification",
      "definition" : "optoutPaperNotification",
      "comment" : "TKB-fält: `../../optoutPaperNotification` (`boolean`, kardinalitet 0..1).",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "boolean"
      }]
    },
    {
      "id" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.protectedPopulationRecord",
      "path" : "getpersonsforprofileunrestricted.requestedPersonRecord.personRecord.protectedPopulationRecord",
      "short" : "protectedPopulationRecord",
      "definition" : "protectedPopulationRecord",
      "comment" : "TKB-fält: `../../protectedPopulationRecord` (`boolean`, kardinalitet 0..1).",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "boolean"
      }]
    }]
  }
}

```
