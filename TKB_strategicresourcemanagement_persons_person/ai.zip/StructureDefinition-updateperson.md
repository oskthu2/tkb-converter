# UpdatePerson — Response - strategicresourcemanagement: persons: person v5.1.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **UpdatePerson — Response**

## Logical Model: UpdatePerson — Response 

| | |
| :--- | :--- |
| *Official URL*:https://fhir.inera.se/ig/strategicresourcemanagement-persons-person/StructureDefinition/updateperson | *Version*:5.0 |
| Active as of 2026-11-09 | *Computable Name*:UpdatePerson |
| **Copyright/Legal**: Copyright 2024 Inera AB. Licensieras under Creative Commons Attribution 4.0. | |

 
Logisk modell för svaret i UpdatePerson (urn:riv:strategicresourcemanagement:persons:person:UpdatePersonResponder:5, UpdatePersonResponseType). 

**Usages:**

* This Logical Model is not used by any profiles in this Specification

You can also check for [usages in the FHIR IG Statistics](https://packages2.fhir.org/xig/resource/inera.strategicresourcemanagement-persons-person|current/StructureDefinition/StructureDefinition-updateperson.json)

### Formal Views of Profile Content

 [Description of Profiles, Differentials, Snapshots and how the different presentations work](http://build.fhir.org/ig/FHIR/ig-guidance/readingIgs.html#structure-definitions). 

 

Other representations of profile: [CSV](StructureDefinition-updateperson.csv), [Excel](StructureDefinition-updateperson.xlsx) 



## Resource Content

```json
{
  "resourceType" : "StructureDefinition",
  "id" : "updateperson",
  "extension" : [{
    "url" : "http://hl7.org/fhir/StructureDefinition/structuredefinition-type-characteristics",
    "valueCode" : "can-be-target"
  }],
  "url" : "https://fhir.inera.se/ig/strategicresourcemanagement-persons-person/StructureDefinition/updateperson",
  "version" : "5.0",
  "name" : "UpdatePerson",
  "title" : "UpdatePerson — Response",
  "status" : "active",
  "date" : "2026-11-09T03:51:23+00:00",
  "contact" : [{
    "name" : "Inera Arkitektur",
    "telecom" : [{
      "system" : "url",
      "value" : "https://www.inera.se"
    }]
  }],
  "description" : "Logisk modell för svaret i UpdatePerson\n(urn:riv:strategicresourcemanagement:persons:person:UpdatePersonResponder:5, UpdatePersonResponseType).",
  "copyright" : "Copyright 2024 Inera AB. Licensieras under Creative Commons Attribution 4.0.",
  "fhirVersion" : "4.0.1",
  "kind" : "logical",
  "abstract" : false,
  "type" : "https://fhir.inera.se/ig/strategicresourcemanagement-persons-person/StructureDefinition/updateperson",
  "baseDefinition" : "http://hl7.org/fhir/StructureDefinition/Base",
  "derivation" : "specialization",
  "differential" : {
    "element" : [{
      "id" : "updateperson",
      "path" : "updateperson",
      "short" : "UpdatePerson — Response",
      "definition" : "Logisk modell för svaret i UpdatePerson\n(urn:riv:strategicresourcemanagement:persons:person:UpdatePersonResponder:5, UpdatePersonResponseType)."
    },
    {
      "id" : "updateperson.updatePersonResult",
      "path" : "updateperson.updatePersonResult",
      "short" : "UpdatePersonResultType",
      "definition" : "UpdatePersonResult med status för om tjänsten utfördes, samt eventuellt uppdaterad/skapad personpost. För felkoder, se datatyp resultType",
      "comment" : "TKB-fält: `updatePersonResult` (`urn:riv:strategicresourcemanagement:persons:person:5:UpdatePersonResultType`, kardinalitet 1..1).",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "Base"
      }]
    },
    {
      "id" : "updateperson.updatePersonResult.result",
      "path" : "updateperson.updatePersonResult.result",
      "short" : "ResultType",
      "definition" : "Datatyp som returneras som ett generellt svar från alla förändrande tjänster, t.ex. skapa, radera, etc. En tjänstekonsument skall alltid kontrollera att resultatkoden inte innehåller fel för att på så sätt veta om anropet lyckades. Alla svarskoder förutom OK betyder att åtgärden inte genomfördes.",
      "comment" : "TKB-fält: `../result` (`ResultType`, kardinalitet 1..1).",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "Base"
      }]
    },
    {
      "id" : "updateperson.updatePersonResult.result.resultCode",
      "path" : "updateperson.updatePersonResult.result.resultCode",
      "short" : "resultCode",
      "definition" : "resultCode Tillåtna värden: OK, ERROR.",
      "comment" : "TKB-fält: `../../resultCode` (`ResultCodeType`, kardinalitet 1..1).\n\n**Modellanteckning:** resultCode Tillåtna värden: OK, ERROR.",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "code"
      }],
      "binding" : {
        "strength" : "required",
        "valueSet" : "https://fhir.inera.se/ig/strategicresourcemanagement-persons-person/ValueSet/SPP-resultcode-vs"
      }
    },
    {
      "id" : "updateperson.updatePersonResult.result.resultText",
      "path" : "updateperson.updatePersonResult.result.resultText",
      "short" : "resultText",
      "definition" : "resultText",
      "comment" : "TKB-fält: `../../resultText` (`string`, kardinalitet 0..1).",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "updateperson.updatePersonResult.personRecord",
      "path" : "updateperson.updatePersonResult.personRecord",
      "short" : "PersonRecordType",
      "definition" : "Grupp för personpost",
      "comment" : "TKB-fält: `../personRecord` (`PersonRecordType`, kardinalitet 0..1).",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "Base"
      }]
    },
    {
      "id" : "updateperson.updatePersonResult.personRecord.personalIdentity",
      "path" : "updateperson.updatePersonResult.personRecord.personalIdentity",
      "short" : "personalIdentity",
      "definition" : "En universellt unik identifierare.",
      "comment" : "TKB-fält: `../../personalIdentity` (`IIType`, kardinalitet 1..1).",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "https://fhir.inera.se/ig/rivta-datatypes/StructureDefinition/IIType"
      }]
    },
    {
      "id" : "updateperson.updatePersonResult.personRecord.identityLevel",
      "path" : "updateperson.updatePersonResult.personRecord.identityLevel",
      "short" : "identityLevel",
      "definition" : "identityLevel",
      "comment" : "TKB-fält: `../../identityLevel` (`string`, kardinalitet 0..1).",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "updateperson.updatePersonResult.personRecord.identityLevelDate",
      "path" : "updateperson.updatePersonResult.personRecord.identityLevelDate",
      "short" : "PartialDateType",
      "definition" : "Kan beskriva ett datum med variabel noggrannhet.",
      "comment" : "TKB-fält: `../../identityLevelDate` (`PartialDateType`, kardinalitet 0..1).",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "Base"
      }]
    },
    {
      "id" : "updateperson.updatePersonResult.personRecord.identityLevelDate.format",
      "path" : "updateperson.updatePersonResult.personRecord.identityLevelDate.format",
      "short" : "format",
      "definition" : "format Tillåtna värden: YYYY, YYYY-MM, YYYY-MM-DD.",
      "comment" : "TKB-fält: `../../../format` (`DateTypeFormatType`, kardinalitet 1..1).\n\n**Modellanteckning:** format Tillåtna värden: YYYY, YYYY-MM, YYYY-MM-DD.",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "code"
      }],
      "binding" : {
        "strength" : "required",
        "valueSet" : "https://fhir.inera.se/ig/strategicresourcemanagement-persons-person/ValueSet/SPP-datetypeformat-vs"
      }
    },
    {
      "id" : "updateperson.updatePersonResult.personRecord.identityLevelDate.value",
      "path" : "updateperson.updatePersonResult.personRecord.identityLevelDate.value",
      "short" : "value",
      "definition" : "value",
      "comment" : "TKB-fält: `../../../value` (`PartialDateValue`, kardinalitet 1..1).",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "updateperson.updatePersonResult.personRecord.gender",
      "path" : "updateperson.updatePersonResult.personRecord.gender",
      "short" : "gender",
      "definition" : "gender",
      "comment" : "TKB-fält: `../../gender` (`CodedValue`, kardinalitet 0..1).",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "updateperson.updatePersonResult.personRecord.protectedPersonIndicator",
      "path" : "updateperson.updatePersonResult.personRecord.protectedPersonIndicator",
      "short" : "protectedPersonIndicator",
      "definition" : "protectedPersonIndicator",
      "comment" : "TKB-fält: `../../protectedPersonIndicator` (`boolean`, kardinalitet 1..1).",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "boolean"
      }]
    },
    {
      "id" : "updateperson.updatePersonResult.personRecord.testIndicator",
      "path" : "updateperson.updatePersonResult.personRecord.testIndicator",
      "short" : "testIndicator",
      "definition" : "testIndicator",
      "comment" : "TKB-fält: `../../testIndicator` (`boolean`, kardinalitet 1..1).",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "boolean"
      }]
    },
    {
      "id" : "updateperson.updatePersonResult.personRecord.primaryIdentity",
      "path" : "updateperson.updatePersonResult.personRecord.primaryIdentity",
      "short" : "primaryIdentity",
      "definition" : "primaryIdentity",
      "comment" : "TKB-fält: `../../primaryIdentity` (`boolean`, kardinalitet 1..1).",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "boolean"
      }]
    },
    {
      "id" : "updateperson.updatePersonResult.personRecord.version",
      "path" : "updateperson.updatePersonResult.personRecord.version",
      "short" : "version",
      "definition" : "version",
      "comment" : "TKB-fält: `../../version` (`Timestamp`, kardinalitet 0..1).",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "updateperson.updatePersonResult.personRecord.name",
      "path" : "updateperson.updatePersonResult.personRecord.name",
      "short" : "NameType",
      "definition" : "Namn",
      "comment" : "TKB-fält: `../../name` (`NameType`, kardinalitet 0..1).",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "Base"
      }]
    },
    {
      "id" : "updateperson.updatePersonResult.personRecord.name.givenNameIndicator",
      "path" : "updateperson.updatePersonResult.personRecord.name.givenNameIndicator",
      "short" : "givenNameIndicator",
      "definition" : "givenNameIndicator",
      "comment" : "TKB-fält: `../../../givenNameIndicator` (`GivenNameIndicator`, kardinalitet 0..1).",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "integer"
      }]
    },
    {
      "id" : "updateperson.updatePersonResult.personRecord.name.givenName",
      "path" : "updateperson.updatePersonResult.personRecord.name.givenName",
      "short" : "givenName",
      "definition" : "givenName",
      "comment" : "TKB-fält: `../../../givenName` (`String80`, kardinalitet 0..1).",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "updateperson.updatePersonResult.personRecord.name.middleName",
      "path" : "updateperson.updatePersonResult.personRecord.name.middleName",
      "short" : "middleName",
      "definition" : "middleName",
      "comment" : "TKB-fält: `../../../middleName` (`String80`, kardinalitet 0..1).",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "updateperson.updatePersonResult.personRecord.name.surname",
      "path" : "updateperson.updatePersonResult.personRecord.name.surname",
      "short" : "surname",
      "definition" : "surname",
      "comment" : "TKB-fält: `../../../surname` (`String80`, kardinalitet 0..1).",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "updateperson.updatePersonResult.personRecord.name.notificationName",
      "path" : "updateperson.updatePersonResult.personRecord.name.notificationName",
      "short" : "notificationName",
      "definition" : "notificationName",
      "comment" : "TKB-fält: `../../../notificationName` (`String40`, kardinalitet 0..1).",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "updateperson.updatePersonResult.personRecord.linkedIdentity",
      "path" : "updateperson.updatePersonResult.personRecord.linkedIdentity",
      "short" : "LinkedIdentityType",
      "definition" : "Klass för att koppla ihop 2 identiteter. Ex en nationell reservidentitet till ett PNR",
      "comment" : "TKB-fält: `../../linkedIdentity` (`LinkedIdentityType`, kardinalitet 0..*).",
      "min" : 0,
      "max" : "*",
      "type" : [{
        "code" : "Base"
      }]
    },
    {
      "id" : "updateperson.updatePersonResult.personRecord.linkedIdentity.referredPersonalIdentity",
      "path" : "updateperson.updatePersonResult.personRecord.linkedIdentity.referredPersonalIdentity",
      "short" : "referredPersonalIdentity",
      "definition" : "En universellt unik identifierare.",
      "comment" : "TKB-fält: `../../../referredPersonalIdentity` (`IIType`, kardinalitet 1..1).",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "https://fhir.inera.se/ig/rivta-datatypes/StructureDefinition/IIType"
      }]
    },
    {
      "id" : "updateperson.updatePersonResult.personRecord.linkedIdentity.assuranceLevel",
      "path" : "updateperson.updatePersonResult.personRecord.linkedIdentity.assuranceLevel",
      "short" : "assuranceLevel",
      "definition" : "assuranceLevel",
      "comment" : "TKB-fält: `../../../assuranceLevel` (`CodedValue`, kardinalitet 1..1).",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "updateperson.updatePersonResult.personRecord.linkedIdentity.primaryIdentity",
      "path" : "updateperson.updatePersonResult.personRecord.linkedIdentity.primaryIdentity",
      "short" : "primaryIdentity",
      "definition" : "primaryIdentity",
      "comment" : "TKB-fält: `../../../primaryIdentity` (`boolean`, kardinalitet 1..1).",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "boolean"
      }]
    },
    {
      "id" : "updateperson.updatePersonResult.personRecord.referredPersonalIdentities",
      "path" : "updateperson.updatePersonResult.personRecord.referredPersonalIdentities",
      "short" : "ReferredPersonalIdentityType",
      "definition" : "Klass för Hänvisningspersonnummer. För de personer som bytt personnummer anges tidigare personnummer/samordningsnummer som hänvisningspersonnummer. Det gamla personnumret/samordningsnumret utgör även det en egen personpost. I det fallet anges det nya personnumret som hänvisningspersonnummer. En person kan få nytt personnummer efter exempelvis ändring av en persons födelsetid eller vid beslut om ändrad könstillhörighet. Klassen håller ihop personidentiteter av typerna personnummer och samordningsnummer enligt Skatteverket till skillnad från klassen KoppladIdenitet som är Personuppgiftstjänstens egna klass för att kunna koppla ihop alla typer av personidentiteter (inkl. reservidentiteter).",
      "comment" : "TKB-fält: `../../referredPersonalIdentities` (`ReferredPersonalIdentityType`, kardinalitet 0..*).",
      "min" : 0,
      "max" : "*",
      "type" : [{
        "code" : "Base"
      }]
    },
    {
      "id" : "updateperson.updatePersonResult.personRecord.referredPersonalIdentities.referredPersonalIdentity",
      "path" : "updateperson.updatePersonResult.personRecord.referredPersonalIdentities.referredPersonalIdentity",
      "short" : "referredPersonalIdentity",
      "definition" : "En universellt unik identifierare.",
      "comment" : "TKB-fält: `../../../referredPersonalIdentity` (`IIType`, kardinalitet 1..1).",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "https://fhir.inera.se/ig/rivta-datatypes/StructureDefinition/IIType"
      }]
    },
    {
      "id" : "updateperson.updatePersonResult.personRecord.referredPersonalIdentities.referredPersonalIdentityStatus",
      "path" : "updateperson.updatePersonResult.personRecord.referredPersonalIdentities.referredPersonalIdentityStatus",
      "short" : "referredPersonalIdentityStatus",
      "definition" : "referredPersonalIdentityStatus",
      "comment" : "TKB-fält: `../../../referredPersonalIdentityStatus` (`string`, kardinalitet 0..1).",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "updateperson.updatePersonResult.personRecord.birth",
      "path" : "updateperson.updatePersonResult.personRecord.birth",
      "short" : "BirthType",
      "definition" : "Uppgifter om födelse",
      "comment" : "TKB-fält: `../../birth` (`BirthType`, kardinalitet 0..1).",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "Base"
      }]
    },
    {
      "id" : "updateperson.updatePersonResult.personRecord.birth.dateOfBirth",
      "path" : "updateperson.updatePersonResult.personRecord.birth.dateOfBirth",
      "short" : "PartialDateType",
      "definition" : "Kan beskriva ett datum med variabel noggrannhet.",
      "comment" : "TKB-fält: `../../../dateOfBirth` (`PartialDateType`, kardinalitet 0..1).",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "Base"
      }]
    },
    {
      "id" : "updateperson.updatePersonResult.personRecord.birth.dateOfBirth.format",
      "path" : "updateperson.updatePersonResult.personRecord.birth.dateOfBirth.format",
      "short" : "format",
      "definition" : "format Tillåtna värden: YYYY, YYYY-MM, YYYY-MM-DD.",
      "comment" : "TKB-fält: `../../../../format` (`DateTypeFormatType`, kardinalitet 1..1).\n\n**Modellanteckning:** format Tillåtna värden: YYYY, YYYY-MM, YYYY-MM-DD.",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "code"
      }],
      "binding" : {
        "strength" : "required",
        "valueSet" : "https://fhir.inera.se/ig/strategicresourcemanagement-persons-person/ValueSet/SPP-datetypeformat-vs"
      }
    },
    {
      "id" : "updateperson.updatePersonResult.personRecord.birth.dateOfBirth.value",
      "path" : "updateperson.updatePersonResult.personRecord.birth.dateOfBirth.value",
      "short" : "value",
      "definition" : "value",
      "comment" : "TKB-fält: `../../../../value` (`PartialDateValue`, kardinalitet 1..1).",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "updateperson.updatePersonResult.personRecord.birth.placeOfBirthSweden",
      "path" : "updateperson.updatePersonResult.personRecord.birth.placeOfBirthSweden",
      "short" : "PlaceOfBirthSwedenType",
      "definition" : "Uppgifter om hemort i Sverige",
      "comment" : "TKB-fält: `../../../placeOfBirthSweden` (`PlaceOfBirthSwedenType`, kardinalitet 0..1).",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "Base"
      }]
    },
    {
      "id" : "updateperson.updatePersonResult.personRecord.birth.placeOfBirthSweden.birthCountyCode",
      "path" : "updateperson.updatePersonResult.personRecord.birth.placeOfBirthSweden.birthCountyCode",
      "short" : "birthCountyCode",
      "definition" : "birthCountyCode",
      "comment" : "TKB-fält: `../../../../birthCountyCode` (`String2`, kardinalitet 0..1).",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "updateperson.updatePersonResult.personRecord.birth.placeOfBirthSweden.birthParish",
      "path" : "updateperson.updatePersonResult.personRecord.birth.placeOfBirthSweden.birthParish",
      "short" : "birthParish",
      "definition" : "birthParish",
      "comment" : "TKB-fält: `../../../../birthParish` (`String40`, kardinalitet 0..1).",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "updateperson.updatePersonResult.personRecord.birth.birthAbroad",
      "path" : "updateperson.updatePersonResult.personRecord.birth.birthAbroad",
      "short" : "BirthAbroadType",
      "definition" : "Uppgifter om födelse i utlandet",
      "comment" : "TKB-fält: `../../../birthAbroad` (`BirthAbroadType`, kardinalitet 0..1).",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "Base"
      }]
    },
    {
      "id" : "updateperson.updatePersonResult.personRecord.birth.birthAbroad.placeOfBirthAbroad",
      "path" : "updateperson.updatePersonResult.personRecord.birth.birthAbroad.placeOfBirthAbroad",
      "short" : "placeOfBirthAbroad",
      "definition" : "placeOfBirthAbroad",
      "comment" : "TKB-fält: `../../../../placeOfBirthAbroad` (`String80`, kardinalitet 0..1).",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "updateperson.updatePersonResult.personRecord.birth.birthAbroad.countryOfBirth",
      "path" : "updateperson.updatePersonResult.personRecord.birth.birthAbroad.countryOfBirth",
      "short" : "countryOfBirth",
      "definition" : "countryOfBirth",
      "comment" : "TKB-fält: `../../../../countryOfBirth` (`String40`, kardinalitet 0..1).",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "updateperson.updatePersonResult.personRecord.populationRegistrationLocality",
      "path" : "updateperson.updatePersonResult.personRecord.populationRegistrationLocality",
      "short" : "PopulationRegistrationLocalityType",
      "definition" : "Uppgifter om folkbokföring",
      "comment" : "TKB-fält: `../../populationRegistrationLocality` (`PopulationRegistrationLocalityType`, kardinalitet 0..1).",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "Base"
      }]
    },
    {
      "id" : "updateperson.updatePersonResult.personRecord.populationRegistrationLocality.populationRegistrationDate",
      "path" : "updateperson.updatePersonResult.personRecord.populationRegistrationLocality.populationRegistrationDate",
      "short" : "PartialDateType",
      "definition" : "Kan beskriva ett datum med variabel noggrannhet.",
      "comment" : "TKB-fält: `../../../populationRegistrationDate` (`PartialDateType`, kardinalitet 0..1).",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "Base"
      }]
    },
    {
      "id" : "updateperson.updatePersonResult.personRecord.populationRegistrationLocality.populationRegistrationDate.format",
      "path" : "updateperson.updatePersonResult.personRecord.populationRegistrationLocality.populationRegistrationDate.format",
      "short" : "format",
      "definition" : "format Tillåtna värden: YYYY, YYYY-MM, YYYY-MM-DD.",
      "comment" : "TKB-fält: `../../../../format` (`DateTypeFormatType`, kardinalitet 1..1).\n\n**Modellanteckning:** format Tillåtna värden: YYYY, YYYY-MM, YYYY-MM-DD.",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "code"
      }],
      "binding" : {
        "strength" : "required",
        "valueSet" : "https://fhir.inera.se/ig/strategicresourcemanagement-persons-person/ValueSet/SPP-datetypeformat-vs"
      }
    },
    {
      "id" : "updateperson.updatePersonResult.personRecord.populationRegistrationLocality.populationRegistrationDate.value",
      "path" : "updateperson.updatePersonResult.personRecord.populationRegistrationLocality.populationRegistrationDate.value",
      "short" : "value",
      "definition" : "value",
      "comment" : "TKB-fält: `../../../../value` (`PartialDateValue`, kardinalitet 1..1).",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "updateperson.updatePersonResult.personRecord.populationRegistrationLocality.countyCode",
      "path" : "updateperson.updatePersonResult.personRecord.populationRegistrationLocality.countyCode",
      "short" : "countyCode",
      "definition" : "countyCode",
      "comment" : "TKB-fält: `../../../countyCode` (`String2`, kardinalitet 0..1).",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "updateperson.updatePersonResult.personRecord.populationRegistrationLocality.municipalityCode",
      "path" : "updateperson.updatePersonResult.personRecord.populationRegistrationLocality.municipalityCode",
      "short" : "municipalityCode",
      "definition" : "municipalityCode",
      "comment" : "TKB-fält: `../../../municipalityCode` (`String2`, kardinalitet 0..1).",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "updateperson.updatePersonResult.personRecord.populationRegistrationLocality.parishCode",
      "path" : "updateperson.updatePersonResult.personRecord.populationRegistrationLocality.parishCode",
      "short" : "parishCode",
      "definition" : "parishCode",
      "comment" : "TKB-fält: `../../../parishCode` (`String2`, kardinalitet 0..1).",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "updateperson.updatePersonResult.personRecord.populationRegistrationLocality.propertyDesignation",
      "path" : "updateperson.updatePersonResult.personRecord.populationRegistrationLocality.propertyDesignation",
      "short" : "propertyDesignation",
      "definition" : "propertyDesignation",
      "comment" : "TKB-fält: `../../../propertyDesignation` (`String40`, kardinalitet 0..1).",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "updateperson.updatePersonResult.personRecord.populationRegistrationLocality.fictitiousPropertyNumber",
      "path" : "updateperson.updatePersonResult.personRecord.populationRegistrationLocality.fictitiousPropertyNumber",
      "short" : "fictitiousPropertyNumber",
      "definition" : "fictitiousPropertyNumber",
      "comment" : "TKB-fält: `../../../fictitiousPropertyNumber` (`FictitiousPropertyNumber`, kardinalitet 0..1).",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "integer"
      }]
    },
    {
      "id" : "updateperson.updatePersonResult.personRecord.populationRegistrationLocality.populationRegistrationType",
      "path" : "updateperson.updatePersonResult.personRecord.populationRegistrationLocality.populationRegistrationType",
      "short" : "populationRegistrationType",
      "definition" : "populationRegistrationType",
      "comment" : "TKB-fält: `../../../populationRegistrationType` (`CodedValue`, kardinalitet 0..1).",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "updateperson.updatePersonResult.personRecord.populationRegistrationLocality.localRegistrationTime",
      "path" : "updateperson.updatePersonResult.personRecord.populationRegistrationLocality.localRegistrationTime",
      "short" : "localRegistrationTime",
      "definition" : "localRegistrationTime",
      "comment" : "TKB-fält: `../../../localRegistrationTime` (`dateTime`, kardinalitet 0..1).",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "dateTime"
      }]
    },
    {
      "id" : "updateperson.updatePersonResult.personRecord.populationRegistrationLocality.localRegistrationEndTime",
      "path" : "updateperson.updatePersonResult.personRecord.populationRegistrationLocality.localRegistrationEndTime",
      "short" : "localRegistrationEndTime",
      "definition" : "localRegistrationEndTime",
      "comment" : "TKB-fält: `../../../localRegistrationEndTime` (`dateTime`, kardinalitet 0..1).",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "dateTime"
      }]
    },
    {
      "id" : "updateperson.updatePersonResult.personRecord.populationRegistrationRecord",
      "path" : "updateperson.updatePersonResult.personRecord.populationRegistrationRecord",
      "short" : "PopulationRegistrationRecordType",
      "definition" : "Folkbokföringspost",
      "comment" : "TKB-fält: `../../populationRegistrationRecord` (`PopulationRegistrationRecordType`, kardinalitet 0..1).",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "Base"
      }]
    },
    {
      "id" : "updateperson.updatePersonResult.personRecord.populationRegistrationRecord.syncronizationTime",
      "path" : "updateperson.updatePersonResult.personRecord.populationRegistrationRecord.syncronizationTime",
      "short" : "syncronizationTime",
      "definition" : "syncronizationTime",
      "comment" : "TKB-fält: `../../../syncronizationTime` (`dateTime`, kardinalitet 0..1).",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "dateTime"
      }]
    },
    {
      "id" : "updateperson.updatePersonResult.personRecord.populationRegistrationRecord.notificationCase",
      "path" : "updateperson.updatePersonResult.personRecord.populationRegistrationRecord.notificationCase",
      "short" : "NotificationCaseType",
      "definition" : "Ärendeuppgifter",
      "comment" : "TKB-fält: `../../../notificationCase` (`NotificationCaseType`, kardinalitet 0..1).",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "Base"
      }]
    },
    {
      "id" : "updateperson.updatePersonResult.personRecord.populationRegistrationRecord.notificationCase.recordId",
      "path" : "updateperson.updatePersonResult.personRecord.populationRegistrationRecord.notificationCase.recordId",
      "short" : "recordId",
      "definition" : "recordId",
      "comment" : "TKB-fält: `../../../../recordId` (`RecordId`, kardinalitet 0..1).",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "updateperson.updatePersonResult.personRecord.populationRegistrationRecord.notificationCase.notificationType",
      "path" : "updateperson.updatePersonResult.personRecord.populationRegistrationRecord.notificationCase.notificationType",
      "short" : "notificationType",
      "definition" : "notificationType",
      "comment" : "TKB-fält: `../../../../notificationType` (`String40`, kardinalitet 0..1).",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "updateperson.updatePersonResult.personRecord.populationRegistrationRecord.notificationCase.modificationTime",
      "path" : "updateperson.updatePersonResult.personRecord.populationRegistrationRecord.notificationCase.modificationTime",
      "short" : "modificationTime",
      "definition" : "modificationTime",
      "comment" : "TKB-fält: `../../../../modificationTime` (`dateTime`, kardinalitet 0..1).",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "dateTime"
      }]
    },
    {
      "id" : "updateperson.updatePersonResult.personRecord.populationRegistrationRecord.notificationCase.totalRecord",
      "path" : "updateperson.updatePersonResult.personRecord.populationRegistrationRecord.notificationCase.totalRecord",
      "short" : "totalRecord",
      "definition" : "totalRecord",
      "comment" : "TKB-fält: `../../../../totalRecord` (`boolean`, kardinalitet 0..1).",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "boolean"
      }]
    },
    {
      "id" : "updateperson.updatePersonResult.personRecord.populationRegistrationRecord.notificationCase.notificationDate",
      "path" : "updateperson.updatePersonResult.personRecord.populationRegistrationRecord.notificationCase.notificationDate",
      "short" : "PartialDateType",
      "definition" : "Kan beskriva ett datum med variabel noggrannhet.",
      "comment" : "TKB-fält: `../../../../notificationDate` (`PartialDateType`, kardinalitet 0..1).",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "Base"
      }]
    },
    {
      "id" : "updateperson.updatePersonResult.personRecord.populationRegistrationRecord.notificationCase.notificationDate.format",
      "path" : "updateperson.updatePersonResult.personRecord.populationRegistrationRecord.notificationCase.notificationDate.format",
      "short" : "format",
      "definition" : "format Tillåtna värden: YYYY, YYYY-MM, YYYY-MM-DD.",
      "comment" : "TKB-fält: `../../../../../format` (`DateTypeFormatType`, kardinalitet 1..1).\n\n**Modellanteckning:** format Tillåtna värden: YYYY, YYYY-MM, YYYY-MM-DD.",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "code"
      }],
      "binding" : {
        "strength" : "required",
        "valueSet" : "https://fhir.inera.se/ig/strategicresourcemanagement-persons-person/ValueSet/SPP-datetypeformat-vs"
      }
    },
    {
      "id" : "updateperson.updatePersonResult.personRecord.populationRegistrationRecord.notificationCase.notificationDate.value",
      "path" : "updateperson.updatePersonResult.personRecord.populationRegistrationRecord.notificationCase.notificationDate.value",
      "short" : "value",
      "definition" : "value",
      "comment" : "TKB-fält: `../../../../../value` (`PartialDateValue`, kardinalitet 1..1).",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "updateperson.updatePersonResult.personRecord.populationRegistrationRecord.historicalRecords",
      "path" : "updateperson.updatePersonResult.personRecord.populationRegistrationRecord.historicalRecords",
      "short" : "HistoricalRecordsType",
      "definition" : "Grupp för historik",
      "comment" : "TKB-fält: `../../../historicalRecords` (`HistoricalRecordsType`, kardinalitet 0..1).",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "Base"
      }]
    },
    {
      "id" : "updateperson.updatePersonResult.personRecord.populationRegistrationRecord.historicalRecords.populationRegistrationLocality",
      "path" : "updateperson.updatePersonResult.personRecord.populationRegistrationRecord.historicalRecords.populationRegistrationLocality",
      "short" : "PopulationRegistrationLocalityType",
      "definition" : "Uppgifter om folkbokföring",
      "comment" : "TKB-fält: `../../../../populationRegistrationLocality` (`PopulationRegistrationLocalityType`, kardinalitet 0..*).",
      "min" : 0,
      "max" : "*",
      "type" : [{
        "code" : "Base"
      }]
    },
    {
      "id" : "updateperson.updatePersonResult.personRecord.populationRegistrationRecord.historicalRecords.populationRegistrationLocality.populationRegistrationDate",
      "path" : "updateperson.updatePersonResult.personRecord.populationRegistrationRecord.historicalRecords.populationRegistrationLocality.populationRegistrationDate",
      "short" : "PartialDateType",
      "definition" : "Kan beskriva ett datum med variabel noggrannhet.",
      "comment" : "TKB-fält: `../../../../../populationRegistrationDate` (`PartialDateType`, kardinalitet 0..1).",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "Base"
      }]
    },
    {
      "id" : "updateperson.updatePersonResult.personRecord.populationRegistrationRecord.historicalRecords.populationRegistrationLocality.populationRegistrationDate.format",
      "path" : "updateperson.updatePersonResult.personRecord.populationRegistrationRecord.historicalRecords.populationRegistrationLocality.populationRegistrationDate.format",
      "short" : "format",
      "definition" : "format Tillåtna värden: YYYY, YYYY-MM, YYYY-MM-DD.",
      "comment" : "TKB-fält: `../../../../../../format` (`DateTypeFormatType`, kardinalitet 1..1).\n\n**Modellanteckning:** format Tillåtna värden: YYYY, YYYY-MM, YYYY-MM-DD.",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "code"
      }],
      "binding" : {
        "strength" : "required",
        "valueSet" : "https://fhir.inera.se/ig/strategicresourcemanagement-persons-person/ValueSet/SPP-datetypeformat-vs"
      }
    },
    {
      "id" : "updateperson.updatePersonResult.personRecord.populationRegistrationRecord.historicalRecords.populationRegistrationLocality.populationRegistrationDate.value",
      "path" : "updateperson.updatePersonResult.personRecord.populationRegistrationRecord.historicalRecords.populationRegistrationLocality.populationRegistrationDate.value",
      "short" : "value",
      "definition" : "value",
      "comment" : "TKB-fält: `../../../../../../value` (`PartialDateValue`, kardinalitet 1..1).",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "updateperson.updatePersonResult.personRecord.populationRegistrationRecord.historicalRecords.populationRegistrationLocality.countyCode",
      "path" : "updateperson.updatePersonResult.personRecord.populationRegistrationRecord.historicalRecords.populationRegistrationLocality.countyCode",
      "short" : "countyCode",
      "definition" : "countyCode",
      "comment" : "TKB-fält: `../../../../../countyCode` (`String2`, kardinalitet 0..1).",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "updateperson.updatePersonResult.personRecord.populationRegistrationRecord.historicalRecords.populationRegistrationLocality.municipalityCode",
      "path" : "updateperson.updatePersonResult.personRecord.populationRegistrationRecord.historicalRecords.populationRegistrationLocality.municipalityCode",
      "short" : "municipalityCode",
      "definition" : "municipalityCode",
      "comment" : "TKB-fält: `../../../../../municipalityCode` (`String2`, kardinalitet 0..1).",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "updateperson.updatePersonResult.personRecord.populationRegistrationRecord.historicalRecords.populationRegistrationLocality.parishCode",
      "path" : "updateperson.updatePersonResult.personRecord.populationRegistrationRecord.historicalRecords.populationRegistrationLocality.parishCode",
      "short" : "parishCode",
      "definition" : "parishCode",
      "comment" : "TKB-fält: `../../../../../parishCode` (`String2`, kardinalitet 0..1).",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "updateperson.updatePersonResult.personRecord.populationRegistrationRecord.historicalRecords.populationRegistrationLocality.propertyDesignation",
      "path" : "updateperson.updatePersonResult.personRecord.populationRegistrationRecord.historicalRecords.populationRegistrationLocality.propertyDesignation",
      "short" : "propertyDesignation",
      "definition" : "propertyDesignation",
      "comment" : "TKB-fält: `../../../../../propertyDesignation` (`String40`, kardinalitet 0..1).",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "updateperson.updatePersonResult.personRecord.populationRegistrationRecord.historicalRecords.populationRegistrationLocality.fictitiousPropertyNumber",
      "path" : "updateperson.updatePersonResult.personRecord.populationRegistrationRecord.historicalRecords.populationRegistrationLocality.fictitiousPropertyNumber",
      "short" : "fictitiousPropertyNumber",
      "definition" : "fictitiousPropertyNumber",
      "comment" : "TKB-fält: `../../../../../fictitiousPropertyNumber` (`FictitiousPropertyNumber`, kardinalitet 0..1).",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "integer"
      }]
    },
    {
      "id" : "updateperson.updatePersonResult.personRecord.populationRegistrationRecord.historicalRecords.populationRegistrationLocality.populationRegistrationType",
      "path" : "updateperson.updatePersonResult.personRecord.populationRegistrationRecord.historicalRecords.populationRegistrationLocality.populationRegistrationType",
      "short" : "populationRegistrationType",
      "definition" : "populationRegistrationType",
      "comment" : "TKB-fält: `../../../../../populationRegistrationType` (`CodedValue`, kardinalitet 0..1).",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "updateperson.updatePersonResult.personRecord.populationRegistrationRecord.historicalRecords.populationRegistrationLocality.localRegistrationTime",
      "path" : "updateperson.updatePersonResult.personRecord.populationRegistrationRecord.historicalRecords.populationRegistrationLocality.localRegistrationTime",
      "short" : "localRegistrationTime",
      "definition" : "localRegistrationTime",
      "comment" : "TKB-fält: `../../../../../localRegistrationTime` (`dateTime`, kardinalitet 0..1).",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "dateTime"
      }]
    },
    {
      "id" : "updateperson.updatePersonResult.personRecord.populationRegistrationRecord.historicalRecords.populationRegistrationLocality.localRegistrationEndTime",
      "path" : "updateperson.updatePersonResult.personRecord.populationRegistrationRecord.historicalRecords.populationRegistrationLocality.localRegistrationEndTime",
      "short" : "localRegistrationEndTime",
      "definition" : "localRegistrationEndTime",
      "comment" : "TKB-fält: `../../../../../localRegistrationEndTime` (`dateTime`, kardinalitet 0..1).",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "dateTime"
      }]
    },
    {
      "id" : "updateperson.updatePersonResult.personRecord.populationRegistrationRecord.historicalRecords.historicalAddress",
      "path" : "updateperson.updatePersonResult.personRecord.populationRegistrationRecord.historicalRecords.historicalAddress",
      "short" : "ResidentialAddressType",
      "definition" : "Svensk adress",
      "comment" : "TKB-fält: `../../../../historicalAddress` (`ResidentialAddressType`, kardinalitet 0..1).",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "Base"
      }]
    },
    {
      "id" : "updateperson.updatePersonResult.personRecord.populationRegistrationRecord.historicalRecords.historicalAddress.careOf",
      "path" : "updateperson.updatePersonResult.personRecord.populationRegistrationRecord.historicalRecords.historicalAddress.careOf",
      "short" : "careOf",
      "definition" : "careOf",
      "comment" : "TKB-fält: `../../../../../careOf` (`String40`, kardinalitet 0..1).",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "updateperson.updatePersonResult.personRecord.populationRegistrationRecord.historicalRecords.historicalAddress.postalAddress1",
      "path" : "updateperson.updatePersonResult.personRecord.populationRegistrationRecord.historicalRecords.historicalAddress.postalAddress1",
      "short" : "postalAddress1",
      "definition" : "postalAddress1",
      "comment" : "TKB-fält: `../../../../../postalAddress1` (`String40`, kardinalitet 0..1).",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "updateperson.updatePersonResult.personRecord.populationRegistrationRecord.historicalRecords.historicalAddress.postalAddress2",
      "path" : "updateperson.updatePersonResult.personRecord.populationRegistrationRecord.historicalRecords.historicalAddress.postalAddress2",
      "short" : "postalAddress2",
      "definition" : "postalAddress2",
      "comment" : "TKB-fält: `../../../../../postalAddress2` (`String40`, kardinalitet 0..1).",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "updateperson.updatePersonResult.personRecord.populationRegistrationRecord.historicalRecords.historicalAddress.postalCode",
      "path" : "updateperson.updatePersonResult.personRecord.populationRegistrationRecord.historicalRecords.historicalAddress.postalCode",
      "short" : "postalCode",
      "definition" : "postalCode",
      "comment" : "TKB-fält: `../../../../../postalCode` (`PostalCode`, kardinalitet 0..1).",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "integer"
      }]
    },
    {
      "id" : "updateperson.updatePersonResult.personRecord.populationRegistrationRecord.historicalRecords.historicalAddress.city",
      "path" : "updateperson.updatePersonResult.personRecord.populationRegistrationRecord.historicalRecords.historicalAddress.city",
      "short" : "city",
      "definition" : "city",
      "comment" : "TKB-fält: `../../../../../city` (`String40`, kardinalitet 0..1).",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "updateperson.updatePersonResult.personRecord.addressInformation",
      "path" : "updateperson.updatePersonResult.personRecord.addressInformation",
      "short" : "AddressInformationType",
      "definition" : "Grupp för adressuppgifter",
      "comment" : "TKB-fält: `../../addressInformation` (`AddressInformationType`, kardinalitet 0..1).",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "Base"
      }]
    },
    {
      "id" : "updateperson.updatePersonResult.personRecord.addressInformation.residentialAddress",
      "path" : "updateperson.updatePersonResult.personRecord.addressInformation.residentialAddress",
      "short" : "ResidentialAddressType",
      "definition" : "Svensk adress",
      "comment" : "TKB-fält: `../../../residentialAddress` (`ResidentialAddressType`, kardinalitet 0..1).",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "Base"
      }]
    },
    {
      "id" : "updateperson.updatePersonResult.personRecord.addressInformation.residentialAddress.careOf",
      "path" : "updateperson.updatePersonResult.personRecord.addressInformation.residentialAddress.careOf",
      "short" : "careOf",
      "definition" : "careOf",
      "comment" : "TKB-fält: `../../../../careOf` (`String40`, kardinalitet 0..1).",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "updateperson.updatePersonResult.personRecord.addressInformation.residentialAddress.postalAddress1",
      "path" : "updateperson.updatePersonResult.personRecord.addressInformation.residentialAddress.postalAddress1",
      "short" : "postalAddress1",
      "definition" : "postalAddress1",
      "comment" : "TKB-fält: `../../../../postalAddress1` (`String40`, kardinalitet 0..1).",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "updateperson.updatePersonResult.personRecord.addressInformation.residentialAddress.postalAddress2",
      "path" : "updateperson.updatePersonResult.personRecord.addressInformation.residentialAddress.postalAddress2",
      "short" : "postalAddress2",
      "definition" : "postalAddress2",
      "comment" : "TKB-fält: `../../../../postalAddress2` (`String40`, kardinalitet 0..1).",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "updateperson.updatePersonResult.personRecord.addressInformation.residentialAddress.postalCode",
      "path" : "updateperson.updatePersonResult.personRecord.addressInformation.residentialAddress.postalCode",
      "short" : "postalCode",
      "definition" : "postalCode",
      "comment" : "TKB-fält: `../../../../postalCode` (`PostalCode`, kardinalitet 0..1).",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "integer"
      }]
    },
    {
      "id" : "updateperson.updatePersonResult.personRecord.addressInformation.residentialAddress.city",
      "path" : "updateperson.updatePersonResult.personRecord.addressInformation.residentialAddress.city",
      "short" : "city",
      "definition" : "city",
      "comment" : "TKB-fält: `../../../../city` (`String40`, kardinalitet 0..1).",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "updateperson.updatePersonResult.personRecord.addressInformation.nationalKeys",
      "path" : "updateperson.updatePersonResult.personRecord.addressInformation.nationalKeys",
      "short" : "NationalKeysType",
      "definition" : "Riksnycklar",
      "comment" : "TKB-fält: `../../../nationalKeys` (`NationalKeysType`, kardinalitet 0..1).",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "Base"
      }]
    },
    {
      "id" : "updateperson.updatePersonResult.personRecord.addressInformation.nationalKeys.propertyId",
      "path" : "updateperson.updatePersonResult.personRecord.addressInformation.nationalKeys.propertyId",
      "short" : "propertyId",
      "definition" : "propertyId",
      "comment" : "TKB-fält: `../../../../propertyId` (`PropertyId`, kardinalitet 0..1).",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "updateperson.updatePersonResult.personRecord.addressInformation.nationalKeys.addressPlaceId",
      "path" : "updateperson.updatePersonResult.personRecord.addressInformation.nationalKeys.addressPlaceId",
      "short" : "addressPlaceId",
      "definition" : "addressPlaceId",
      "comment" : "TKB-fält: `../../../../addressPlaceId` (`AddressPlaceId`, kardinalitet 0..1).",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "updateperson.updatePersonResult.personRecord.addressInformation.nationalKeys.apartmentId",
      "path" : "updateperson.updatePersonResult.personRecord.addressInformation.nationalKeys.apartmentId",
      "short" : "apartmentId",
      "definition" : "apartmentId",
      "comment" : "TKB-fält: `../../../../apartmentId` (`ApartmentId`, kardinalitet 0..1).",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "updateperson.updatePersonResult.personRecord.addressInformation.district",
      "path" : "updateperson.updatePersonResult.personRecord.addressInformation.district",
      "short" : "DistrictType",
      "definition" : "Grupp för Distriktskod",
      "comment" : "TKB-fält: `../../../district` (`DistrictType`, kardinalitet 0..1).",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "Base"
      }]
    },
    {
      "id" : "updateperson.updatePersonResult.personRecord.addressInformation.district.districtCode",
      "path" : "updateperson.updatePersonResult.personRecord.addressInformation.district.districtCode",
      "short" : "districtCode",
      "definition" : "districtCode",
      "comment" : "TKB-fält: `../../../../districtCode` (`DistrictCode`, kardinalitet 0..1).",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "updateperson.updatePersonResult.personRecord.addressInformation.specialPostalAddress",
      "path" : "updateperson.updatePersonResult.personRecord.addressInformation.specialPostalAddress",
      "short" : "ResidentialAddressType",
      "definition" : "Svensk adress",
      "comment" : "TKB-fält: `../../../specialPostalAddress` (`ResidentialAddressType`, kardinalitet 0..1).",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "Base"
      }]
    },
    {
      "id" : "updateperson.updatePersonResult.personRecord.addressInformation.specialPostalAddress.careOf",
      "path" : "updateperson.updatePersonResult.personRecord.addressInformation.specialPostalAddress.careOf",
      "short" : "careOf",
      "definition" : "careOf",
      "comment" : "TKB-fält: `../../../../careOf` (`String40`, kardinalitet 0..1).",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "updateperson.updatePersonResult.personRecord.addressInformation.specialPostalAddress.postalAddress1",
      "path" : "updateperson.updatePersonResult.personRecord.addressInformation.specialPostalAddress.postalAddress1",
      "short" : "postalAddress1",
      "definition" : "postalAddress1",
      "comment" : "TKB-fält: `../../../../postalAddress1` (`String40`, kardinalitet 0..1).",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "updateperson.updatePersonResult.personRecord.addressInformation.specialPostalAddress.postalAddress2",
      "path" : "updateperson.updatePersonResult.personRecord.addressInformation.specialPostalAddress.postalAddress2",
      "short" : "postalAddress2",
      "definition" : "postalAddress2",
      "comment" : "TKB-fält: `../../../../postalAddress2` (`String40`, kardinalitet 0..1).",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "updateperson.updatePersonResult.personRecord.addressInformation.specialPostalAddress.postalCode",
      "path" : "updateperson.updatePersonResult.personRecord.addressInformation.specialPostalAddress.postalCode",
      "short" : "postalCode",
      "definition" : "postalCode",
      "comment" : "TKB-fält: `../../../../postalCode` (`PostalCode`, kardinalitet 0..1).",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "integer"
      }]
    },
    {
      "id" : "updateperson.updatePersonResult.personRecord.addressInformation.specialPostalAddress.city",
      "path" : "updateperson.updatePersonResult.personRecord.addressInformation.specialPostalAddress.city",
      "short" : "city",
      "definition" : "city",
      "comment" : "TKB-fält: `../../../../city` (`String40`, kardinalitet 0..1).",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "updateperson.updatePersonResult.personRecord.addressInformation.addressAbroad",
      "path" : "updateperson.updatePersonResult.personRecord.addressInformation.addressAbroad",
      "short" : "AddressAbroadType",
      "definition" : "Utlandsadress",
      "comment" : "TKB-fält: `../../../addressAbroad` (`AddressAbroadType`, kardinalitet 0..1).",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "Base"
      }]
    },
    {
      "id" : "updateperson.updatePersonResult.personRecord.addressInformation.addressAbroad.postalAddress1",
      "path" : "updateperson.updatePersonResult.personRecord.addressInformation.addressAbroad.postalAddress1",
      "short" : "postalAddress1",
      "definition" : "postalAddress1",
      "comment" : "TKB-fält: `../../../../postalAddress1` (`String40`, kardinalitet 0..1).",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "updateperson.updatePersonResult.personRecord.addressInformation.addressAbroad.postalAddress2",
      "path" : "updateperson.updatePersonResult.personRecord.addressInformation.addressAbroad.postalAddress2",
      "short" : "postalAddress2",
      "definition" : "postalAddress2",
      "comment" : "TKB-fält: `../../../../postalAddress2` (`String40`, kardinalitet 0..1).",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "updateperson.updatePersonResult.personRecord.addressInformation.addressAbroad.postalAddress3",
      "path" : "updateperson.updatePersonResult.personRecord.addressInformation.addressAbroad.postalAddress3",
      "short" : "postalAddress3",
      "definition" : "postalAddress3",
      "comment" : "TKB-fält: `../../../../postalAddress3` (`String40`, kardinalitet 0..1).",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "updateperson.updatePersonResult.personRecord.addressInformation.addressAbroad.countryCode",
      "path" : "updateperson.updatePersonResult.personRecord.addressInformation.addressAbroad.countryCode",
      "short" : "countryCode",
      "definition" : "countryCode",
      "comment" : "TKB-fält: `../../../../countryCode` (`String40`, kardinalitet 0..1).",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "updateperson.updatePersonResult.personRecord.addressInformation.addressAbroad.addressAbroadDate",
      "path" : "updateperson.updatePersonResult.personRecord.addressInformation.addressAbroad.addressAbroadDate",
      "short" : "PartialDateType",
      "definition" : "Kan beskriva ett datum med variabel noggrannhet.",
      "comment" : "TKB-fält: `../../../../addressAbroadDate` (`PartialDateType`, kardinalitet 0..1).",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "Base"
      }]
    },
    {
      "id" : "updateperson.updatePersonResult.personRecord.addressInformation.addressAbroad.addressAbroadDate.format",
      "path" : "updateperson.updatePersonResult.personRecord.addressInformation.addressAbroad.addressAbroadDate.format",
      "short" : "format",
      "definition" : "format Tillåtna värden: YYYY, YYYY-MM, YYYY-MM-DD.",
      "comment" : "TKB-fält: `../../../../../format` (`DateTypeFormatType`, kardinalitet 1..1).\n\n**Modellanteckning:** format Tillåtna värden: YYYY, YYYY-MM, YYYY-MM-DD.",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "code"
      }],
      "binding" : {
        "strength" : "required",
        "valueSet" : "https://fhir.inera.se/ig/strategicresourcemanagement-persons-person/ValueSet/SPP-datetypeformat-vs"
      }
    },
    {
      "id" : "updateperson.updatePersonResult.personRecord.addressInformation.addressAbroad.addressAbroadDate.value",
      "path" : "updateperson.updatePersonResult.personRecord.addressInformation.addressAbroad.addressAbroadDate.value",
      "short" : "value",
      "definition" : "value",
      "comment" : "TKB-fält: `../../../../../value` (`PartialDateValue`, kardinalitet 1..1).",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "updateperson.updatePersonResult.personRecord.addressInformation.addressAbroad.votingDate",
      "path" : "updateperson.updatePersonResult.personRecord.addressInformation.addressAbroad.votingDate",
      "short" : "PartialDateType",
      "definition" : "Kan beskriva ett datum med variabel noggrannhet.",
      "comment" : "TKB-fält: `../../../../votingDate` (`PartialDateType`, kardinalitet 0..1).",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "Base"
      }]
    },
    {
      "id" : "updateperson.updatePersonResult.personRecord.addressInformation.addressAbroad.votingDate.format",
      "path" : "updateperson.updatePersonResult.personRecord.addressInformation.addressAbroad.votingDate.format",
      "short" : "format",
      "definition" : "format Tillåtna värden: YYYY, YYYY-MM, YYYY-MM-DD.",
      "comment" : "TKB-fält: `../../../../../format` (`DateTypeFormatType`, kardinalitet 1..1).\n\n**Modellanteckning:** format Tillåtna värden: YYYY, YYYY-MM, YYYY-MM-DD.",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "code"
      }],
      "binding" : {
        "strength" : "required",
        "valueSet" : "https://fhir.inera.se/ig/strategicresourcemanagement-persons-person/ValueSet/SPP-datetypeformat-vs"
      }
    },
    {
      "id" : "updateperson.updatePersonResult.personRecord.addressInformation.addressAbroad.votingDate.value",
      "path" : "updateperson.updatePersonResult.personRecord.addressInformation.addressAbroad.votingDate.value",
      "short" : "value",
      "definition" : "value",
      "comment" : "TKB-fält: `../../../../../value` (`PartialDateValue`, kardinalitet 1..1).",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "updateperson.updatePersonResult.personRecord.addressInformation.givenAddress",
      "path" : "updateperson.updatePersonResult.personRecord.addressInformation.givenAddress",
      "short" : "ResidentialAddressType",
      "definition" : "Svensk adress",
      "comment" : "TKB-fält: `../../../givenAddress` (`ResidentialAddressType`, kardinalitet 0..1).",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "Base"
      }]
    },
    {
      "id" : "updateperson.updatePersonResult.personRecord.addressInformation.givenAddress.careOf",
      "path" : "updateperson.updatePersonResult.personRecord.addressInformation.givenAddress.careOf",
      "short" : "careOf",
      "definition" : "careOf",
      "comment" : "TKB-fält: `../../../../careOf` (`String40`, kardinalitet 0..1).",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "updateperson.updatePersonResult.personRecord.addressInformation.givenAddress.postalAddress1",
      "path" : "updateperson.updatePersonResult.personRecord.addressInformation.givenAddress.postalAddress1",
      "short" : "postalAddress1",
      "definition" : "postalAddress1",
      "comment" : "TKB-fält: `../../../../postalAddress1` (`String40`, kardinalitet 0..1).",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "updateperson.updatePersonResult.personRecord.addressInformation.givenAddress.postalAddress2",
      "path" : "updateperson.updatePersonResult.personRecord.addressInformation.givenAddress.postalAddress2",
      "short" : "postalAddress2",
      "definition" : "postalAddress2",
      "comment" : "TKB-fält: `../../../../postalAddress2` (`String40`, kardinalitet 0..1).",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "updateperson.updatePersonResult.personRecord.addressInformation.givenAddress.postalCode",
      "path" : "updateperson.updatePersonResult.personRecord.addressInformation.givenAddress.postalCode",
      "short" : "postalCode",
      "definition" : "postalCode",
      "comment" : "TKB-fält: `../../../../postalCode` (`PostalCode`, kardinalitet 0..1).",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "integer"
      }]
    },
    {
      "id" : "updateperson.updatePersonResult.personRecord.addressInformation.givenAddress.city",
      "path" : "updateperson.updatePersonResult.personRecord.addressInformation.givenAddress.city",
      "short" : "city",
      "definition" : "city",
      "comment" : "TKB-fält: `../../../../city` (`String40`, kardinalitet 0..1).",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "updateperson.updatePersonResult.personRecord.addressInformation.UUID",
      "path" : "updateperson.updatePersonResult.personRecord.addressInformation.UUID",
      "short" : "UUIDType",
      "definition" : "UUID för fastighet, aderess och lägenhet",
      "comment" : "TKB-fält: `../../../UUID` (`UUIDType`, kardinalitet 0..1).",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "Base"
      }]
    },
    {
      "id" : "updateperson.updatePersonResult.personRecord.addressInformation.UUID.propertyId",
      "path" : "updateperson.updatePersonResult.personRecord.addressInformation.UUID.propertyId",
      "short" : "propertyId",
      "definition" : "propertyId",
      "comment" : "TKB-fält: `../../../../propertyId` (`string`, kardinalitet 0..1).",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "updateperson.updatePersonResult.personRecord.addressInformation.UUID.addressPlaceId",
      "path" : "updateperson.updatePersonResult.personRecord.addressInformation.UUID.addressPlaceId",
      "short" : "addressPlaceId",
      "definition" : "addressPlaceId",
      "comment" : "TKB-fält: `../../../../addressPlaceId` (`string`, kardinalitet 0..1).",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "updateperson.updatePersonResult.personRecord.addressInformation.UUID.apartmentId",
      "path" : "updateperson.updatePersonResult.personRecord.addressInformation.UUID.apartmentId",
      "short" : "apartmentId",
      "definition" : "apartmentId",
      "comment" : "TKB-fält: `../../../../apartmentId` (`string`, kardinalitet 0..1).",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "updateperson.updatePersonResult.personRecord.contactInformation",
      "path" : "updateperson.updatePersonResult.personRecord.contactInformation",
      "short" : "ContactInformationType",
      "definition" : "Klass för patientens egna angivna kontakuppgifter",
      "comment" : "TKB-fält: `../../contactInformation` (`ContactInformationType`, kardinalitet 0..*).",
      "min" : 0,
      "max" : "*",
      "type" : [{
        "code" : "Base"
      }]
    },
    {
      "id" : "updateperson.updatePersonResult.personRecord.contactInformation.contactType",
      "path" : "updateperson.updatePersonResult.personRecord.contactInformation.contactType",
      "short" : "contactType",
      "definition" : "contactType",
      "comment" : "TKB-fält: `../../../contactType` (`CodedValue`, kardinalitet 1..1).",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "updateperson.updatePersonResult.personRecord.contactInformation.use",
      "path" : "updateperson.updatePersonResult.personRecord.contactInformation.use",
      "short" : "use",
      "definition" : "use",
      "comment" : "TKB-fält: `../../../use` (`CodedValue`, kardinalitet 0..1).",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "updateperson.updatePersonResult.personRecord.contactInformation.value",
      "path" : "updateperson.updatePersonResult.personRecord.contactInformation.value",
      "short" : "value",
      "definition" : "value",
      "comment" : "TKB-fält: `../../../value` (`string`, kardinalitet 0..1).",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "updateperson.updatePersonResult.personRecord.contactInformation.rank",
      "path" : "updateperson.updatePersonResult.personRecord.contactInformation.rank",
      "short" : "rank",
      "definition" : "rank",
      "comment" : "TKB-fält: `../../../rank` (`int`, kardinalitet 0..1).",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "integer"
      }]
    },
    {
      "id" : "updateperson.updatePersonResult.personRecord.contactInformation.comment",
      "path" : "updateperson.updatePersonResult.personRecord.contactInformation.comment",
      "short" : "comment",
      "definition" : "comment",
      "comment" : "TKB-fält: `../../../comment` (`string`, kardinalitet 0..1).",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "updateperson.updatePersonResult.personRecord.contactInformation.period",
      "path" : "updateperson.updatePersonResult.personRecord.contactInformation.period",
      "short" : "DatePeriodType",
      "definition" : "period",
      "comment" : "TKB-fält: `../../../period` (`DatePeriodType`, kardinalitet 0..1).",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "Base"
      }]
    },
    {
      "id" : "updateperson.updatePersonResult.personRecord.contactInformation.period.start",
      "path" : "updateperson.updatePersonResult.personRecord.contactInformation.period.start",
      "short" : "start",
      "definition" : "start",
      "comment" : "TKB-fält: `../../../../start` (`date`, kardinalitet 0..1).",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "date"
      }]
    },
    {
      "id" : "updateperson.updatePersonResult.personRecord.contactInformation.period.end",
      "path" : "updateperson.updatePersonResult.personRecord.contactInformation.period.end",
      "short" : "end",
      "definition" : "end",
      "comment" : "TKB-fält: `../../../../end` (`date`, kardinalitet 0..1).",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "date"
      }]
    },
    {
      "id" : "updateperson.updatePersonResult.personRecord.contactInformation.digitalNotification",
      "path" : "updateperson.updatePersonResult.personRecord.contactInformation.digitalNotification",
      "short" : "digitalNotification",
      "definition" : "digitalNotification",
      "comment" : "TKB-fält: `../../../digitalNotification` (`boolean`, kardinalitet 0..1).",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "boolean"
      }]
    },
    {
      "id" : "updateperson.updatePersonResult.personRecord.contactPerson",
      "path" : "updateperson.updatePersonResult.personRecord.contactPerson",
      "short" : "ContactPersonType",
      "definition" : "contactPerson",
      "comment" : "TKB-fält: `../../contactPerson` (`ContactPersonType`, kardinalitet 0..*).",
      "min" : 0,
      "max" : "*",
      "type" : [{
        "code" : "Base"
      }]
    },
    {
      "id" : "updateperson.updatePersonResult.personRecord.contactPerson.contactRelationshipType",
      "path" : "updateperson.updatePersonResult.personRecord.contactPerson.contactRelationshipType",
      "short" : "contactRelationshipType",
      "definition" : "contactRelationshipType",
      "comment" : "TKB-fält: `../../../contactRelationshipType` (`CodedValue`, kardinalitet 1..1).",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "updateperson.updatePersonResult.personRecord.contactPerson.priorityOrder",
      "path" : "updateperson.updatePersonResult.personRecord.contactPerson.priorityOrder",
      "short" : "priorityOrder",
      "definition" : "priorityOrder",
      "comment" : "TKB-fält: `../../../priorityOrder` (`int`, kardinalitet 0..1).",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "integer"
      }]
    },
    {
      "id" : "updateperson.updatePersonResult.personRecord.contactPerson.givenName",
      "path" : "updateperson.updatePersonResult.personRecord.contactPerson.givenName",
      "short" : "givenName",
      "definition" : "givenName",
      "comment" : "TKB-fält: `../../../givenName` (`String80`, kardinalitet 0..1).",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "updateperson.updatePersonResult.personRecord.contactPerson.surName",
      "path" : "updateperson.updatePersonResult.personRecord.contactPerson.surName",
      "short" : "surName",
      "definition" : "surName",
      "comment" : "TKB-fält: `../../../surName` (`String80`, kardinalitet 0..1).",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "updateperson.updatePersonResult.personRecord.contactPerson.middleName",
      "path" : "updateperson.updatePersonResult.personRecord.contactPerson.middleName",
      "short" : "middleName",
      "definition" : "middleName",
      "comment" : "TKB-fält: `../../../middleName` (`String80`, kardinalitet 0..1).",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "updateperson.updatePersonResult.personRecord.contactPerson.contactPersonAddress",
      "path" : "updateperson.updatePersonResult.personRecord.contactPerson.contactPersonAddress",
      "short" : "ResidentialAddressType",
      "definition" : "Svensk adress",
      "comment" : "TKB-fält: `../../../contactPersonAddress` (`ResidentialAddressType`, kardinalitet 0..1).",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "Base"
      }]
    },
    {
      "id" : "updateperson.updatePersonResult.personRecord.contactPerson.contactPersonAddress.careOf",
      "path" : "updateperson.updatePersonResult.personRecord.contactPerson.contactPersonAddress.careOf",
      "short" : "careOf",
      "definition" : "careOf",
      "comment" : "TKB-fält: `../../../../careOf` (`String40`, kardinalitet 0..1).",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "updateperson.updatePersonResult.personRecord.contactPerson.contactPersonAddress.postalAddress1",
      "path" : "updateperson.updatePersonResult.personRecord.contactPerson.contactPersonAddress.postalAddress1",
      "short" : "postalAddress1",
      "definition" : "postalAddress1",
      "comment" : "TKB-fält: `../../../../postalAddress1` (`String40`, kardinalitet 0..1).",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "updateperson.updatePersonResult.personRecord.contactPerson.contactPersonAddress.postalAddress2",
      "path" : "updateperson.updatePersonResult.personRecord.contactPerson.contactPersonAddress.postalAddress2",
      "short" : "postalAddress2",
      "definition" : "postalAddress2",
      "comment" : "TKB-fält: `../../../../postalAddress2` (`String40`, kardinalitet 0..1).",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "updateperson.updatePersonResult.personRecord.contactPerson.contactPersonAddress.postalCode",
      "path" : "updateperson.updatePersonResult.personRecord.contactPerson.contactPersonAddress.postalCode",
      "short" : "postalCode",
      "definition" : "postalCode",
      "comment" : "TKB-fält: `../../../../postalCode` (`PostalCode`, kardinalitet 0..1).",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "integer"
      }]
    },
    {
      "id" : "updateperson.updatePersonResult.personRecord.contactPerson.contactPersonAddress.city",
      "path" : "updateperson.updatePersonResult.personRecord.contactPerson.contactPersonAddress.city",
      "short" : "city",
      "definition" : "city",
      "comment" : "TKB-fält: `../../../../city` (`String40`, kardinalitet 0..1).",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "updateperson.updatePersonResult.personRecord.contactPerson.contactPersonContactInformation",
      "path" : "updateperson.updatePersonResult.personRecord.contactPerson.contactPersonContactInformation",
      "short" : "ContactInformationType",
      "definition" : "Klass för patientens egna angivna kontakuppgifter",
      "comment" : "TKB-fält: `../../../contactPersonContactInformation` (`ContactInformationType`, kardinalitet 0..*).",
      "min" : 0,
      "max" : "*",
      "type" : [{
        "code" : "Base"
      }]
    },
    {
      "id" : "updateperson.updatePersonResult.personRecord.contactPerson.contactPersonContactInformation.contactType",
      "path" : "updateperson.updatePersonResult.personRecord.contactPerson.contactPersonContactInformation.contactType",
      "short" : "contactType",
      "definition" : "contactType",
      "comment" : "TKB-fält: `../../../../contactType` (`CodedValue`, kardinalitet 1..1).",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "updateperson.updatePersonResult.personRecord.contactPerson.contactPersonContactInformation.use",
      "path" : "updateperson.updatePersonResult.personRecord.contactPerson.contactPersonContactInformation.use",
      "short" : "use",
      "definition" : "use",
      "comment" : "TKB-fält: `../../../../use` (`CodedValue`, kardinalitet 0..1).",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "updateperson.updatePersonResult.personRecord.contactPerson.contactPersonContactInformation.value",
      "path" : "updateperson.updatePersonResult.personRecord.contactPerson.contactPersonContactInformation.value",
      "short" : "value",
      "definition" : "value",
      "comment" : "TKB-fält: `../../../../value` (`string`, kardinalitet 0..1).",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "updateperson.updatePersonResult.personRecord.contactPerson.contactPersonContactInformation.rank",
      "path" : "updateperson.updatePersonResult.personRecord.contactPerson.contactPersonContactInformation.rank",
      "short" : "rank",
      "definition" : "rank",
      "comment" : "TKB-fält: `../../../../rank` (`int`, kardinalitet 0..1).",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "integer"
      }]
    },
    {
      "id" : "updateperson.updatePersonResult.personRecord.contactPerson.contactPersonContactInformation.comment",
      "path" : "updateperson.updatePersonResult.personRecord.contactPerson.contactPersonContactInformation.comment",
      "short" : "comment",
      "definition" : "comment",
      "comment" : "TKB-fält: `../../../../comment` (`string`, kardinalitet 0..1).",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "updateperson.updatePersonResult.personRecord.contactPerson.contactPersonContactInformation.period",
      "path" : "updateperson.updatePersonResult.personRecord.contactPerson.contactPersonContactInformation.period",
      "short" : "DatePeriodType",
      "definition" : "period",
      "comment" : "TKB-fält: `../../../../period` (`DatePeriodType`, kardinalitet 0..1).",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "Base"
      }]
    },
    {
      "id" : "updateperson.updatePersonResult.personRecord.contactPerson.contactPersonContactInformation.period.start",
      "path" : "updateperson.updatePersonResult.personRecord.contactPerson.contactPersonContactInformation.period.start",
      "short" : "start",
      "definition" : "start",
      "comment" : "TKB-fält: `../../../../../start` (`date`, kardinalitet 0..1).",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "date"
      }]
    },
    {
      "id" : "updateperson.updatePersonResult.personRecord.contactPerson.contactPersonContactInformation.period.end",
      "path" : "updateperson.updatePersonResult.personRecord.contactPerson.contactPersonContactInformation.period.end",
      "short" : "end",
      "definition" : "end",
      "comment" : "TKB-fält: `../../../../../end` (`date`, kardinalitet 0..1).",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "date"
      }]
    },
    {
      "id" : "updateperson.updatePersonResult.personRecord.contactPerson.contactPersonContactInformation.digitalNotification",
      "path" : "updateperson.updatePersonResult.personRecord.contactPerson.contactPersonContactInformation.digitalNotification",
      "short" : "digitalNotification",
      "definition" : "digitalNotification",
      "comment" : "TKB-fält: `../../../../digitalNotification` (`boolean`, kardinalitet 0..1).",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "boolean"
      }]
    },
    {
      "id" : "updateperson.updatePersonResult.personRecord.confirmedIdentity",
      "path" : "updateperson.updatePersonResult.personRecord.confirmedIdentity",
      "short" : "ConfirmedIdentityType",
      "definition" : "Klass för hur reservidentitetsuppgifter är styrkta.",
      "comment" : "TKB-fält: `../../confirmedIdentity` (`ConfirmedIdentityType`, kardinalitet 0..*).",
      "min" : 0,
      "max" : "*",
      "type" : [{
        "code" : "Base"
      }]
    },
    {
      "id" : "updateperson.updatePersonResult.personRecord.confirmedIdentity.typeOfIdentification",
      "path" : "updateperson.updatePersonResult.personRecord.confirmedIdentity.typeOfIdentification",
      "short" : "typeOfIdentification",
      "definition" : "typeOfIdentification",
      "comment" : "TKB-fält: `../../../typeOfIdentification` (`CodedValue`, kardinalitet 0..1).",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "updateperson.updatePersonResult.personRecord.confirmedIdentity.identificationNumber",
      "path" : "updateperson.updatePersonResult.personRecord.confirmedIdentity.identificationNumber",
      "short" : "identificationNumber",
      "definition" : "identificationNumber",
      "comment" : "TKB-fält: `../../../identificationNumber` (`string`, kardinalitet 0..1).",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "updateperson.updatePersonResult.personRecord.confirmedIdentity.issuersOfId",
      "path" : "updateperson.updatePersonResult.personRecord.confirmedIdentity.issuersOfId",
      "short" : "issuersOfId",
      "definition" : "issuersOfId",
      "comment" : "TKB-fält: `../../../issuersOfId` (`string`, kardinalitet 0..1).",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "updateperson.updatePersonResult.personRecord.confirmedIdentity.validDatePeriod",
      "path" : "updateperson.updatePersonResult.personRecord.confirmedIdentity.validDatePeriod",
      "short" : "DatePeriodType",
      "definition" : "validDatePeriod",
      "comment" : "TKB-fält: `../../../validDatePeriod` (`DatePeriodType`, kardinalitet 0..1).",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "Base"
      }]
    },
    {
      "id" : "updateperson.updatePersonResult.personRecord.confirmedIdentity.validDatePeriod.start",
      "path" : "updateperson.updatePersonResult.personRecord.confirmedIdentity.validDatePeriod.start",
      "short" : "start",
      "definition" : "start",
      "comment" : "TKB-fält: `../../../../start` (`date`, kardinalitet 0..1).",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "date"
      }]
    },
    {
      "id" : "updateperson.updatePersonResult.personRecord.confirmedIdentity.validDatePeriod.end",
      "path" : "updateperson.updatePersonResult.personRecord.confirmedIdentity.validDatePeriod.end",
      "short" : "end",
      "definition" : "end",
      "comment" : "TKB-fält: `../../../../end` (`date`, kardinalitet 0..1).",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "date"
      }]
    },
    {
      "id" : "updateperson.updatePersonResult.personRecord.confirmedIdentity.attachmentId",
      "path" : "updateperson.updatePersonResult.personRecord.confirmedIdentity.attachmentId",
      "short" : "attachmentId",
      "definition" : "attachmentId",
      "comment" : "TKB-fält: `../../../attachmentId` (`string`, kardinalitet 0..*).",
      "min" : 0,
      "max" : "*",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "updateperson.updatePersonResult.personRecord.confirmedIdentity.countryCode",
      "path" : "updateperson.updatePersonResult.personRecord.confirmedIdentity.countryCode",
      "short" : "countryCode",
      "definition" : "countryCode",
      "comment" : "TKB-fält: `../../../countryCode` (`CountryCode`, kardinalitet 0..1).",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "updateperson.updatePersonResult.personRecord.administrativeInformation",
      "path" : "updateperson.updatePersonResult.personRecord.administrativeInformation",
      "short" : "AdministrativeInformationType",
      "definition" : "Klass för administrativa tilläggsuppgifter. Normalt tilläggsuppgifter kring en person med en reservidentitet som registreras i samband med uttag av reservidentitet (LRID/NRID).",
      "comment" : "TKB-fält: `../../administrativeInformation` (`AdministrativeInformationType`, kardinalitet 0..1).",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "Base"
      }]
    },
    {
      "id" : "updateperson.updatePersonResult.personRecord.administrativeInformation.categoryOfPerson",
      "path" : "updateperson.updatePersonResult.personRecord.administrativeInformation.categoryOfPerson",
      "short" : "categoryOfPerson",
      "definition" : "categoryOfPerson",
      "comment" : "TKB-fält: `../../../categoryOfPerson` (`CodedValue`, kardinalitet 0..1).",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "updateperson.updatePersonResult.personRecord.administrativeInformation.accountCode",
      "path" : "updateperson.updatePersonResult.personRecord.administrativeInformation.accountCode",
      "short" : "accountCode",
      "definition" : "accountCode",
      "comment" : "TKB-fält: `../../../accountCode` (`CodedValue`, kardinalitet 0..1).",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "updateperson.updatePersonResult.personRecord.administrativeInformation.comment",
      "path" : "updateperson.updatePersonResult.personRecord.administrativeInformation.comment",
      "short" : "comment",
      "definition" : "comment",
      "comment" : "TKB-fält: `../../../comment` (`string`, kardinalitet 0..1).",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "updateperson.updatePersonResult.personRecord.deregistration",
      "path" : "updateperson.updatePersonResult.personRecord.deregistration",
      "short" : "DeregistrationType",
      "definition" : "Uppgifter om avregistrering",
      "comment" : "TKB-fält: `../../deregistration` (`DeregistrationType`, kardinalitet 0..1).",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "Base"
      }]
    },
    {
      "id" : "updateperson.updatePersonResult.personRecord.deregistration.deregistrationReasonCode",
      "path" : "updateperson.updatePersonResult.personRecord.deregistration.deregistrationReasonCode",
      "short" : "deregistrationReasonCode",
      "definition" : "deregistrationReasonCode",
      "comment" : "TKB-fält: `../../../deregistrationReasonCode` (`CodedValue`, kardinalitet 0..1).",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "updateperson.updatePersonResult.personRecord.deregistration.deregistrationDate",
      "path" : "updateperson.updatePersonResult.personRecord.deregistration.deregistrationDate",
      "short" : "PartialDateType",
      "definition" : "Kan beskriva ett datum med variabel noggrannhet.",
      "comment" : "TKB-fält: `../../../deregistrationDate` (`PartialDateType`, kardinalitet 0..1).",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "Base"
      }]
    },
    {
      "id" : "updateperson.updatePersonResult.personRecord.deregistration.deregistrationDate.format",
      "path" : "updateperson.updatePersonResult.personRecord.deregistration.deregistrationDate.format",
      "short" : "format",
      "definition" : "format Tillåtna värden: YYYY, YYYY-MM, YYYY-MM-DD.",
      "comment" : "TKB-fält: `../../../../format` (`DateTypeFormatType`, kardinalitet 1..1).\n\n**Modellanteckning:** format Tillåtna värden: YYYY, YYYY-MM, YYYY-MM-DD.",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "code"
      }],
      "binding" : {
        "strength" : "required",
        "valueSet" : "https://fhir.inera.se/ig/strategicresourcemanagement-persons-person/ValueSet/SPP-datetypeformat-vs"
      }
    },
    {
      "id" : "updateperson.updatePersonResult.personRecord.deregistration.deregistrationDate.value",
      "path" : "updateperson.updatePersonResult.personRecord.deregistration.deregistrationDate.value",
      "short" : "value",
      "definition" : "value",
      "comment" : "TKB-fält: `../../../../value` (`PartialDateValue`, kardinalitet 1..1).",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "updateperson.updatePersonResult.personRecord.deregistration.foundDeadAtDate",
      "path" : "updateperson.updatePersonResult.personRecord.deregistration.foundDeadAtDate",
      "short" : "PartialDateType",
      "definition" : "Kan beskriva ett datum med variabel noggrannhet.",
      "comment" : "TKB-fält: `../../../foundDeadAtDate` (`PartialDateType`, kardinalitet 0..1).",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "Base"
      }]
    },
    {
      "id" : "updateperson.updatePersonResult.personRecord.deregistration.foundDeadAtDate.format",
      "path" : "updateperson.updatePersonResult.personRecord.deregistration.foundDeadAtDate.format",
      "short" : "format",
      "definition" : "format Tillåtna värden: YYYY, YYYY-MM, YYYY-MM-DD.",
      "comment" : "TKB-fält: `../../../../format` (`DateTypeFormatType`, kardinalitet 1..1).\n\n**Modellanteckning:** format Tillåtna värden: YYYY, YYYY-MM, YYYY-MM-DD.",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "code"
      }],
      "binding" : {
        "strength" : "required",
        "valueSet" : "https://fhir.inera.se/ig/strategicresourcemanagement-persons-person/ValueSet/SPP-datetypeformat-vs"
      }
    },
    {
      "id" : "updateperson.updatePersonResult.personRecord.deregistration.foundDeadAtDate.value",
      "path" : "updateperson.updatePersonResult.personRecord.deregistration.foundDeadAtDate.value",
      "short" : "value",
      "definition" : "value",
      "comment" : "TKB-fält: `../../../../value` (`PartialDateValue`, kardinalitet 1..1).",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "updateperson.updatePersonResult.personRecord.maritalStatus",
      "path" : "updateperson.updatePersonResult.personRecord.maritalStatus",
      "short" : "MaritalStatusType",
      "definition" : "Civistånd",
      "comment" : "TKB-fält: `../../maritalStatus` (`MaritalStatusType`, kardinalitet 0..1).",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "Base"
      }]
    },
    {
      "id" : "updateperson.updatePersonResult.personRecord.maritalStatus.maritalStatusCode",
      "path" : "updateperson.updatePersonResult.personRecord.maritalStatus.maritalStatusCode",
      "short" : "maritalStatusCode",
      "definition" : "maritalStatusCode",
      "comment" : "TKB-fält: `../../../maritalStatusCode` (`CodedValue`, kardinalitet 0..1).",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "updateperson.updatePersonResult.personRecord.maritalStatus.maritalStatusDate",
      "path" : "updateperson.updatePersonResult.personRecord.maritalStatus.maritalStatusDate",
      "short" : "PartialDateType",
      "definition" : "Kan beskriva ett datum med variabel noggrannhet.",
      "comment" : "TKB-fält: `../../../maritalStatusDate` (`PartialDateType`, kardinalitet 0..1).",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "Base"
      }]
    },
    {
      "id" : "updateperson.updatePersonResult.personRecord.maritalStatus.maritalStatusDate.format",
      "path" : "updateperson.updatePersonResult.personRecord.maritalStatus.maritalStatusDate.format",
      "short" : "format",
      "definition" : "format Tillåtna värden: YYYY, YYYY-MM, YYYY-MM-DD.",
      "comment" : "TKB-fält: `../../../../format` (`DateTypeFormatType`, kardinalitet 1..1).\n\n**Modellanteckning:** format Tillåtna värden: YYYY, YYYY-MM, YYYY-MM-DD.",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "code"
      }],
      "binding" : {
        "strength" : "required",
        "valueSet" : "https://fhir.inera.se/ig/strategicresourcemanagement-persons-person/ValueSet/SPP-datetypeformat-vs"
      }
    },
    {
      "id" : "updateperson.updatePersonResult.personRecord.maritalStatus.maritalStatusDate.value",
      "path" : "updateperson.updatePersonResult.personRecord.maritalStatus.maritalStatusDate.value",
      "short" : "value",
      "definition" : "value",
      "comment" : "TKB-fält: `../../../../value` (`PartialDateValue`, kardinalitet 1..1).",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "updateperson.updatePersonResult.personRecord.immigration",
      "path" : "updateperson.updatePersonResult.personRecord.immigration",
      "short" : "ImmigrationType",
      "definition" : "Grupp för invandringsuppgifter",
      "comment" : "TKB-fält: `../../immigration` (`ImmigrationType`, kardinalitet 0..1).",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "Base"
      }]
    },
    {
      "id" : "updateperson.updatePersonResult.personRecord.immigration.immigrationDate",
      "path" : "updateperson.updatePersonResult.personRecord.immigration.immigrationDate",
      "short" : "PartialDateType",
      "definition" : "Kan beskriva ett datum med variabel noggrannhet.",
      "comment" : "TKB-fält: `../../../immigrationDate` (`PartialDateType`, kardinalitet 0..1).",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "Base"
      }]
    },
    {
      "id" : "updateperson.updatePersonResult.personRecord.immigration.immigrationDate.format",
      "path" : "updateperson.updatePersonResult.personRecord.immigration.immigrationDate.format",
      "short" : "format",
      "definition" : "format Tillåtna värden: YYYY, YYYY-MM, YYYY-MM-DD.",
      "comment" : "TKB-fält: `../../../../format` (`DateTypeFormatType`, kardinalitet 1..1).\n\n**Modellanteckning:** format Tillåtna värden: YYYY, YYYY-MM, YYYY-MM-DD.",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "code"
      }],
      "binding" : {
        "strength" : "required",
        "valueSet" : "https://fhir.inera.se/ig/strategicresourcemanagement-persons-person/ValueSet/SPP-datetypeformat-vs"
      }
    },
    {
      "id" : "updateperson.updatePersonResult.personRecord.immigration.immigrationDate.value",
      "path" : "updateperson.updatePersonResult.personRecord.immigration.immigrationDate.value",
      "short" : "value",
      "definition" : "value",
      "comment" : "TKB-fält: `../../../../value` (`PartialDateValue`, kardinalitet 1..1).",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "updateperson.updatePersonResult.personRecord.immigration.rightOfResidence",
      "path" : "updateperson.updatePersonResult.personRecord.immigration.rightOfResidence",
      "short" : "rightOfResidence",
      "definition" : "rightOfResidence",
      "comment" : "TKB-fält: `../../../rightOfResidence` (`boolean`, kardinalitet 0..1).",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "boolean"
      }]
    },
    {
      "id" : "updateperson.updatePersonResult.personRecord.immigration.immigrationIdentity",
      "path" : "updateperson.updatePersonResult.personRecord.immigration.immigrationIdentity",
      "short" : "ImmigrationIdentityType",
      "definition" : "Grupp för personnummer och vilket land det är knutet till. Motsvarar skatteverkets NordisktPnrDa, NordisktPnrFi, NordisktPnrFo, NordisktPnrIs och NordisktPnrNo",
      "comment" : "TKB-fält: `../../../immigrationIdentity` (`ImmigrationIdentityType`, kardinalitet 0..*).",
      "min" : 0,
      "max" : "*",
      "type" : [{
        "code" : "Base"
      }]
    },
    {
      "id" : "updateperson.updatePersonResult.personRecord.immigration.immigrationIdentity.personalIdentityNumber",
      "path" : "updateperson.updatePersonResult.personRecord.immigration.immigrationIdentity.personalIdentityNumber",
      "short" : "personalIdentityNumber",
      "definition" : "personalIdentityNumber",
      "comment" : "TKB-fält: `../../../../personalIdentityNumber` (`PersonalIdentityNumber`, kardinalitet 1..1).",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "updateperson.updatePersonResult.personRecord.immigration.immigrationIdentity.country",
      "path" : "updateperson.updatePersonResult.personRecord.immigration.immigrationIdentity.country",
      "short" : "country",
      "definition" : "country",
      "comment" : "TKB-fält: `../../../../country` (`CountryCode`, kardinalitet 1..1).",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "updateperson.updatePersonResult.personRecord.citizenship",
      "path" : "updateperson.updatePersonResult.personRecord.citizenship",
      "short" : "CitizenshipType",
      "definition" : "Grupp för medborgarskap",
      "comment" : "TKB-fält: `../../citizenship` (`CitizenshipType`, kardinalitet 0..*).",
      "min" : 0,
      "max" : "*",
      "type" : [{
        "code" : "Base"
      }]
    },
    {
      "id" : "updateperson.updatePersonResult.personRecord.citizenship.citizenshipCountryCode",
      "path" : "updateperson.updatePersonResult.personRecord.citizenship.citizenshipCountryCode",
      "short" : "citizenshipCountryCode",
      "definition" : "citizenshipCountryCode",
      "comment" : "TKB-fält: `../../../citizenshipCountryCode` (`CountryCode`, kardinalitet 0..1).",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "updateperson.updatePersonResult.personRecord.citizenship.citizenshipDate",
      "path" : "updateperson.updatePersonResult.personRecord.citizenship.citizenshipDate",
      "short" : "PartialDateType",
      "definition" : "Kan beskriva ett datum med variabel noggrannhet.",
      "comment" : "TKB-fält: `../../../citizenshipDate` (`PartialDateType`, kardinalitet 0..1).",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "Base"
      }]
    },
    {
      "id" : "updateperson.updatePersonResult.personRecord.citizenship.citizenshipDate.format",
      "path" : "updateperson.updatePersonResult.personRecord.citizenship.citizenshipDate.format",
      "short" : "format",
      "definition" : "format Tillåtna värden: YYYY, YYYY-MM, YYYY-MM-DD.",
      "comment" : "TKB-fält: `../../../../format` (`DateTypeFormatType`, kardinalitet 1..1).\n\n**Modellanteckning:** format Tillåtna värden: YYYY, YYYY-MM, YYYY-MM-DD.",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "code"
      }],
      "binding" : {
        "strength" : "required",
        "valueSet" : "https://fhir.inera.se/ig/strategicresourcemanagement-persons-person/ValueSet/SPP-datetypeformat-vs"
      }
    },
    {
      "id" : "updateperson.updatePersonResult.personRecord.citizenship.citizenshipDate.value",
      "path" : "updateperson.updatePersonResult.personRecord.citizenship.citizenshipDate.value",
      "short" : "value",
      "definition" : "value",
      "comment" : "TKB-fält: `../../../../value` (`PartialDateValue`, kardinalitet 1..1).",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "updateperson.updatePersonResult.personRecord.citizenship.status",
      "path" : "updateperson.updatePersonResult.personRecord.citizenship.status",
      "short" : "status",
      "definition" : "status",
      "comment" : "TKB-fält: `../../../status` (`CodedValue`, kardinalitet 0..1).",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "updateperson.updatePersonResult.personRecord.relationship",
      "path" : "updateperson.updatePersonResult.personRecord.relationship",
      "short" : "RelationshipType",
      "definition" : "Grupp för relation",
      "comment" : "TKB-fält: `../../relationship` (`RelationshipType`, kardinalitet 0..*).",
      "min" : 0,
      "max" : "*",
      "type" : [{
        "code" : "Base"
      }]
    },
    {
      "id" : "updateperson.updatePersonResult.personRecord.relationship.relationshipId",
      "path" : "updateperson.updatePersonResult.personRecord.relationship.relationshipId",
      "short" : "RelationshipIdType",
      "definition" : "Grupp för relationspersons identitet Antingen får man personnummer eller datum då personen föddes.",
      "comment" : "TKB-fält: `../../../relationshipId` (`RelationshipIdType`, kardinalitet 1..1).",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "Base"
      }]
    },
    {
      "id" : "updateperson.updatePersonResult.personRecord.relationship.relationshipId.personalIdentity",
      "path" : "updateperson.updatePersonResult.personRecord.relationship.relationshipId.personalIdentity",
      "short" : "personalIdentity",
      "definition" : "En universellt unik identifierare.",
      "comment" : "TKB-fält: `../../../../personalIdentity` (`IIType`, kardinalitet 0..1).",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "https://fhir.inera.se/ig/rivta-datatypes/StructureDefinition/IIType"
      }]
    },
    {
      "id" : "updateperson.updatePersonResult.personRecord.relationship.relationshipId.dateOfBirth",
      "path" : "updateperson.updatePersonResult.personRecord.relationship.relationshipId.dateOfBirth",
      "short" : "PartialDateType",
      "definition" : "Kan beskriva ett datum med variabel noggrannhet.",
      "comment" : "TKB-fält: `../../../../dateOfBirth` (`PartialDateType`, kardinalitet 0..1).",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "Base"
      }]
    },
    {
      "id" : "updateperson.updatePersonResult.personRecord.relationship.relationshipId.dateOfBirth.format",
      "path" : "updateperson.updatePersonResult.personRecord.relationship.relationshipId.dateOfBirth.format",
      "short" : "format",
      "definition" : "format Tillåtna värden: YYYY, YYYY-MM, YYYY-MM-DD.",
      "comment" : "TKB-fält: `../../../../../format` (`DateTypeFormatType`, kardinalitet 1..1).\n\n**Modellanteckning:** format Tillåtna värden: YYYY, YYYY-MM, YYYY-MM-DD.",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "code"
      }],
      "binding" : {
        "strength" : "required",
        "valueSet" : "https://fhir.inera.se/ig/strategicresourcemanagement-persons-person/ValueSet/SPP-datetypeformat-vs"
      }
    },
    {
      "id" : "updateperson.updatePersonResult.personRecord.relationship.relationshipId.dateOfBirth.value",
      "path" : "updateperson.updatePersonResult.personRecord.relationship.relationshipId.dateOfBirth.value",
      "short" : "value",
      "definition" : "value",
      "comment" : "TKB-fält: `../../../../../value` (`PartialDateValue`, kardinalitet 1..1).",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "updateperson.updatePersonResult.personRecord.relationship.relationshipType",
      "path" : "updateperson.updatePersonResult.personRecord.relationship.relationshipType",
      "short" : "relationshipType",
      "definition" : "relationshipType",
      "comment" : "TKB-fält: `../../../relationshipType` (`CodedValue`, kardinalitet 1..1).",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "updateperson.updatePersonResult.personRecord.relationship.relationshipFromDate",
      "path" : "updateperson.updatePersonResult.personRecord.relationship.relationshipFromDate",
      "short" : "PartialDateType",
      "definition" : "Kan beskriva ett datum med variabel noggrannhet.",
      "comment" : "TKB-fält: `../../../relationshipFromDate` (`PartialDateType`, kardinalitet 0..1).",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "Base"
      }]
    },
    {
      "id" : "updateperson.updatePersonResult.personRecord.relationship.relationshipFromDate.format",
      "path" : "updateperson.updatePersonResult.personRecord.relationship.relationshipFromDate.format",
      "short" : "format",
      "definition" : "format Tillåtna värden: YYYY, YYYY-MM, YYYY-MM-DD.",
      "comment" : "TKB-fält: `../../../../format` (`DateTypeFormatType`, kardinalitet 1..1).\n\n**Modellanteckning:** format Tillåtna värden: YYYY, YYYY-MM, YYYY-MM-DD.",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "code"
      }],
      "binding" : {
        "strength" : "required",
        "valueSet" : "https://fhir.inera.se/ig/strategicresourcemanagement-persons-person/ValueSet/SPP-datetypeformat-vs"
      }
    },
    {
      "id" : "updateperson.updatePersonResult.personRecord.relationship.relationshipFromDate.value",
      "path" : "updateperson.updatePersonResult.personRecord.relationship.relationshipFromDate.value",
      "short" : "value",
      "definition" : "value",
      "comment" : "TKB-fält: `../../../../value` (`PartialDateValue`, kardinalitet 1..1).",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "updateperson.updatePersonResult.personRecord.relationship.relationshipToDate",
      "path" : "updateperson.updatePersonResult.personRecord.relationship.relationshipToDate",
      "short" : "PartialDateType",
      "definition" : "Kan beskriva ett datum med variabel noggrannhet.",
      "comment" : "TKB-fält: `../../../relationshipToDate` (`PartialDateType`, kardinalitet 0..1).",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "Base"
      }]
    },
    {
      "id" : "updateperson.updatePersonResult.personRecord.relationship.relationshipToDate.format",
      "path" : "updateperson.updatePersonResult.personRecord.relationship.relationshipToDate.format",
      "short" : "format",
      "definition" : "format Tillåtna värden: YYYY, YYYY-MM, YYYY-MM-DD.",
      "comment" : "TKB-fält: `../../../../format` (`DateTypeFormatType`, kardinalitet 1..1).\n\n**Modellanteckning:** format Tillåtna värden: YYYY, YYYY-MM, YYYY-MM-DD.",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "code"
      }],
      "binding" : {
        "strength" : "required",
        "valueSet" : "https://fhir.inera.se/ig/strategicresourcemanagement-persons-person/ValueSet/SPP-datetypeformat-vs"
      }
    },
    {
      "id" : "updateperson.updatePersonResult.personRecord.relationship.relationshipToDate.value",
      "path" : "updateperson.updatePersonResult.personRecord.relationship.relationshipToDate.value",
      "short" : "value",
      "definition" : "value",
      "comment" : "TKB-fält: `../../../../value` (`PartialDateValue`, kardinalitet 1..1).",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "updateperson.updatePersonResult.personRecord.relationship.name",
      "path" : "updateperson.updatePersonResult.personRecord.relationship.name",
      "short" : "NameType",
      "definition" : "Namn",
      "comment" : "TKB-fält: `../../../name` (`NameType`, kardinalitet 0..1).",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "Base"
      }]
    },
    {
      "id" : "updateperson.updatePersonResult.personRecord.relationship.name.givenNameIndicator",
      "path" : "updateperson.updatePersonResult.personRecord.relationship.name.givenNameIndicator",
      "short" : "givenNameIndicator",
      "definition" : "givenNameIndicator",
      "comment" : "TKB-fält: `../../../../givenNameIndicator` (`GivenNameIndicator`, kardinalitet 0..1).",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "integer"
      }]
    },
    {
      "id" : "updateperson.updatePersonResult.personRecord.relationship.name.givenName",
      "path" : "updateperson.updatePersonResult.personRecord.relationship.name.givenName",
      "short" : "givenName",
      "definition" : "givenName",
      "comment" : "TKB-fält: `../../../../givenName` (`String80`, kardinalitet 0..1).",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "updateperson.updatePersonResult.personRecord.relationship.name.middleName",
      "path" : "updateperson.updatePersonResult.personRecord.relationship.name.middleName",
      "short" : "middleName",
      "definition" : "middleName",
      "comment" : "TKB-fält: `../../../../middleName` (`String80`, kardinalitet 0..1).",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "updateperson.updatePersonResult.personRecord.relationship.name.surname",
      "path" : "updateperson.updatePersonResult.personRecord.relationship.name.surname",
      "short" : "surname",
      "definition" : "surname",
      "comment" : "TKB-fält: `../../../../surname` (`String80`, kardinalitet 0..1).",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "updateperson.updatePersonResult.personRecord.relationship.name.notificationName",
      "path" : "updateperson.updatePersonResult.personRecord.relationship.name.notificationName",
      "short" : "notificationName",
      "definition" : "notificationName",
      "comment" : "TKB-fält: `../../../../notificationName` (`String40`, kardinalitet 0..1).",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "updateperson.updatePersonResult.personRecord.relationship.deregistration",
      "path" : "updateperson.updatePersonResult.personRecord.relationship.deregistration",
      "short" : "DeregistrationType",
      "definition" : "Uppgifter om avregistrering",
      "comment" : "TKB-fält: `../../../deregistration` (`DeregistrationType`, kardinalitet 0..1).",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "Base"
      }]
    },
    {
      "id" : "updateperson.updatePersonResult.personRecord.relationship.deregistration.deregistrationReasonCode",
      "path" : "updateperson.updatePersonResult.personRecord.relationship.deregistration.deregistrationReasonCode",
      "short" : "deregistrationReasonCode",
      "definition" : "deregistrationReasonCode",
      "comment" : "TKB-fält: `../../../../deregistrationReasonCode` (`CodedValue`, kardinalitet 0..1).",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "updateperson.updatePersonResult.personRecord.relationship.deregistration.deregistrationDate",
      "path" : "updateperson.updatePersonResult.personRecord.relationship.deregistration.deregistrationDate",
      "short" : "PartialDateType",
      "definition" : "Kan beskriva ett datum med variabel noggrannhet.",
      "comment" : "TKB-fält: `../../../../deregistrationDate` (`PartialDateType`, kardinalitet 0..1).",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "Base"
      }]
    },
    {
      "id" : "updateperson.updatePersonResult.personRecord.relationship.deregistration.deregistrationDate.format",
      "path" : "updateperson.updatePersonResult.personRecord.relationship.deregistration.deregistrationDate.format",
      "short" : "format",
      "definition" : "format Tillåtna värden: YYYY, YYYY-MM, YYYY-MM-DD.",
      "comment" : "TKB-fält: `../../../../../format` (`DateTypeFormatType`, kardinalitet 1..1).\n\n**Modellanteckning:** format Tillåtna värden: YYYY, YYYY-MM, YYYY-MM-DD.",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "code"
      }],
      "binding" : {
        "strength" : "required",
        "valueSet" : "https://fhir.inera.se/ig/strategicresourcemanagement-persons-person/ValueSet/SPP-datetypeformat-vs"
      }
    },
    {
      "id" : "updateperson.updatePersonResult.personRecord.relationship.deregistration.deregistrationDate.value",
      "path" : "updateperson.updatePersonResult.personRecord.relationship.deregistration.deregistrationDate.value",
      "short" : "value",
      "definition" : "value",
      "comment" : "TKB-fält: `../../../../../value` (`PartialDateValue`, kardinalitet 1..1).",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "updateperson.updatePersonResult.personRecord.relationship.deregistration.foundDeadAtDate",
      "path" : "updateperson.updatePersonResult.personRecord.relationship.deregistration.foundDeadAtDate",
      "short" : "PartialDateType",
      "definition" : "Kan beskriva ett datum med variabel noggrannhet.",
      "comment" : "TKB-fält: `../../../../foundDeadAtDate` (`PartialDateType`, kardinalitet 0..1).",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "Base"
      }]
    },
    {
      "id" : "updateperson.updatePersonResult.personRecord.relationship.deregistration.foundDeadAtDate.format",
      "path" : "updateperson.updatePersonResult.personRecord.relationship.deregistration.foundDeadAtDate.format",
      "short" : "format",
      "definition" : "format Tillåtna värden: YYYY, YYYY-MM, YYYY-MM-DD.",
      "comment" : "TKB-fält: `../../../../../format` (`DateTypeFormatType`, kardinalitet 1..1).\n\n**Modellanteckning:** format Tillåtna värden: YYYY, YYYY-MM, YYYY-MM-DD.",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "code"
      }],
      "binding" : {
        "strength" : "required",
        "valueSet" : "https://fhir.inera.se/ig/strategicresourcemanagement-persons-person/ValueSet/SPP-datetypeformat-vs"
      }
    },
    {
      "id" : "updateperson.updatePersonResult.personRecord.relationship.deregistration.foundDeadAtDate.value",
      "path" : "updateperson.updatePersonResult.personRecord.relationship.deregistration.foundDeadAtDate.value",
      "short" : "value",
      "definition" : "value",
      "comment" : "TKB-fält: `../../../../../value` (`PartialDateValue`, kardinalitet 1..1).",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "updateperson.updatePersonResult.personRecord.relationship.status",
      "path" : "updateperson.updatePersonResult.personRecord.relationship.status",
      "short" : "status",
      "definition" : "status",
      "comment" : "TKB-fält: `../../../status` (`CodedValue`, kardinalitet 0..1).",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "updateperson.updatePersonResult.personRecord.coOrdinationNumberData",
      "path" : "updateperson.updatePersonResult.personRecord.coOrdinationNumberData",
      "short" : "CoOrdinationNumberDataType",
      "definition" : "Grupp för de personer som ej är folkbokförda men som har tilldelats ett samordningsnummer för identifiering av personen. Syftet med samordningsnummer är att myndigheter och andra samhällsfunktioner ska kunna identifiera personer även om de inte är folkbokförda i Sverige.",
      "comment" : "TKB-fält: `../../coOrdinationNumberData` (`CoOrdinationNumberDataType`, kardinalitet 0..1).",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "Base"
      }]
    },
    {
      "id" : "updateperson.updatePersonResult.personRecord.coOrdinationNumberData.allocationDate",
      "path" : "updateperson.updatePersonResult.personRecord.coOrdinationNumberData.allocationDate",
      "short" : "PartialDateType",
      "definition" : "Kan beskriva ett datum med variabel noggrannhet.",
      "comment" : "TKB-fält: `../../../allocationDate` (`PartialDateType`, kardinalitet 0..1).",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "Base"
      }]
    },
    {
      "id" : "updateperson.updatePersonResult.personRecord.coOrdinationNumberData.allocationDate.format",
      "path" : "updateperson.updatePersonResult.personRecord.coOrdinationNumberData.allocationDate.format",
      "short" : "format",
      "definition" : "format Tillåtna värden: YYYY, YYYY-MM, YYYY-MM-DD.",
      "comment" : "TKB-fält: `../../../../format` (`DateTypeFormatType`, kardinalitet 1..1).\n\n**Modellanteckning:** format Tillåtna värden: YYYY, YYYY-MM, YYYY-MM-DD.",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "code"
      }],
      "binding" : {
        "strength" : "required",
        "valueSet" : "https://fhir.inera.se/ig/strategicresourcemanagement-persons-person/ValueSet/SPP-datetypeformat-vs"
      }
    },
    {
      "id" : "updateperson.updatePersonResult.personRecord.coOrdinationNumberData.allocationDate.value",
      "path" : "updateperson.updatePersonResult.personRecord.coOrdinationNumberData.allocationDate.value",
      "short" : "value",
      "definition" : "value",
      "comment" : "TKB-fält: `../../../../value` (`PartialDateValue`, kardinalitet 1..1).",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "updateperson.updatePersonResult.personRecord.coOrdinationNumberData.preliminaryTransferDate",
      "path" : "updateperson.updatePersonResult.personRecord.coOrdinationNumberData.preliminaryTransferDate",
      "short" : "PartialDateType",
      "definition" : "Kan beskriva ett datum med variabel noggrannhet.",
      "comment" : "TKB-fält: `../../../preliminaryTransferDate` (`PartialDateType`, kardinalitet 0..1).",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "Base"
      }]
    },
    {
      "id" : "updateperson.updatePersonResult.personRecord.coOrdinationNumberData.preliminaryTransferDate.format",
      "path" : "updateperson.updatePersonResult.personRecord.coOrdinationNumberData.preliminaryTransferDate.format",
      "short" : "format",
      "definition" : "format Tillåtna värden: YYYY, YYYY-MM, YYYY-MM-DD.",
      "comment" : "TKB-fält: `../../../../format` (`DateTypeFormatType`, kardinalitet 1..1).\n\n**Modellanteckning:** format Tillåtna värden: YYYY, YYYY-MM, YYYY-MM-DD.",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "code"
      }],
      "binding" : {
        "strength" : "required",
        "valueSet" : "https://fhir.inera.se/ig/strategicresourcemanagement-persons-person/ValueSet/SPP-datetypeformat-vs"
      }
    },
    {
      "id" : "updateperson.updatePersonResult.personRecord.coOrdinationNumberData.preliminaryTransferDate.value",
      "path" : "updateperson.updatePersonResult.personRecord.coOrdinationNumberData.preliminaryTransferDate.value",
      "short" : "value",
      "definition" : "value",
      "comment" : "TKB-fält: `../../../../value` (`PartialDateValue`, kardinalitet 1..1).",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "updateperson.updatePersonResult.personRecord.coOrdinationNumberData.renewalDate",
      "path" : "updateperson.updatePersonResult.personRecord.coOrdinationNumberData.renewalDate",
      "short" : "PartialDateType",
      "definition" : "Kan beskriva ett datum med variabel noggrannhet.",
      "comment" : "TKB-fält: `../../../renewalDate` (`PartialDateType`, kardinalitet 0..1).",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "Base"
      }]
    },
    {
      "id" : "updateperson.updatePersonResult.personRecord.coOrdinationNumberData.renewalDate.format",
      "path" : "updateperson.updatePersonResult.personRecord.coOrdinationNumberData.renewalDate.format",
      "short" : "format",
      "definition" : "format Tillåtna värden: YYYY, YYYY-MM, YYYY-MM-DD.",
      "comment" : "TKB-fält: `../../../../format` (`DateTypeFormatType`, kardinalitet 1..1).\n\n**Modellanteckning:** format Tillåtna värden: YYYY, YYYY-MM, YYYY-MM-DD.",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "code"
      }],
      "binding" : {
        "strength" : "required",
        "valueSet" : "https://fhir.inera.se/ig/strategicresourcemanagement-persons-person/ValueSet/SPP-datetypeformat-vs"
      }
    },
    {
      "id" : "updateperson.updatePersonResult.personRecord.coOrdinationNumberData.renewalDate.value",
      "path" : "updateperson.updatePersonResult.personRecord.coOrdinationNumberData.renewalDate.value",
      "short" : "value",
      "definition" : "value",
      "comment" : "TKB-fält: `../../../../value` (`PartialDateValue`, kardinalitet 1..1).",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "updateperson.updatePersonResult.personRecord.coOrdinationNumberData.deceasedDate",
      "path" : "updateperson.updatePersonResult.personRecord.coOrdinationNumberData.deceasedDate",
      "short" : "PartialDateType",
      "definition" : "Kan beskriva ett datum med variabel noggrannhet.",
      "comment" : "TKB-fält: `../../../deceasedDate` (`PartialDateType`, kardinalitet 0..1).",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "Base"
      }]
    },
    {
      "id" : "updateperson.updatePersonResult.personRecord.coOrdinationNumberData.deceasedDate.format",
      "path" : "updateperson.updatePersonResult.personRecord.coOrdinationNumberData.deceasedDate.format",
      "short" : "format",
      "definition" : "format Tillåtna värden: YYYY, YYYY-MM, YYYY-MM-DD.",
      "comment" : "TKB-fält: `../../../../format` (`DateTypeFormatType`, kardinalitet 1..1).\n\n**Modellanteckning:** format Tillåtna värden: YYYY, YYYY-MM, YYYY-MM-DD.",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "code"
      }],
      "binding" : {
        "strength" : "required",
        "valueSet" : "https://fhir.inera.se/ig/strategicresourcemanagement-persons-person/ValueSet/SPP-datetypeformat-vs"
      }
    },
    {
      "id" : "updateperson.updatePersonResult.personRecord.coOrdinationNumberData.deceasedDate.value",
      "path" : "updateperson.updatePersonResult.personRecord.coOrdinationNumberData.deceasedDate.value",
      "short" : "value",
      "definition" : "value",
      "comment" : "TKB-fält: `../../../../value` (`PartialDateValue`, kardinalitet 1..1).",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "updateperson.updatePersonResult.personRecord.personalIdentityStatus",
      "path" : "updateperson.updatePersonResult.personRecord.personalIdentityStatus",
      "short" : "PersonalIdentityStatusType",
      "definition" : "Klass som beskriver status för ett samordningsnummer. Status, datum och orsak ska vara obligatoriska uppgifter, när de finns, för aviseringar innehållande samordningsnummer.",
      "comment" : "TKB-fält: `../../personalIdentityStatus` (`PersonalIdentityStatusType`, kardinalitet 0..1).",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "Base"
      }]
    },
    {
      "id" : "updateperson.updatePersonResult.personRecord.personalIdentityStatus.identityStatus",
      "path" : "updateperson.updatePersonResult.personRecord.personalIdentityStatus.identityStatus",
      "short" : "identityStatus",
      "definition" : "identityStatus",
      "comment" : "TKB-fält: `../../../identityStatus` (`string`, kardinalitet 0..1).",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "updateperson.updatePersonResult.personRecord.personalIdentityStatus.identityStatusDate",
      "path" : "updateperson.updatePersonResult.personRecord.personalIdentityStatus.identityStatusDate",
      "short" : "PartialDateType",
      "definition" : "Kan beskriva ett datum med variabel noggrannhet.",
      "comment" : "TKB-fält: `../../../identityStatusDate` (`PartialDateType`, kardinalitet 0..1).",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "Base"
      }]
    },
    {
      "id" : "updateperson.updatePersonResult.personRecord.personalIdentityStatus.identityStatusDate.format",
      "path" : "updateperson.updatePersonResult.personRecord.personalIdentityStatus.identityStatusDate.format",
      "short" : "format",
      "definition" : "format Tillåtna värden: YYYY, YYYY-MM, YYYY-MM-DD.",
      "comment" : "TKB-fält: `../../../../format` (`DateTypeFormatType`, kardinalitet 1..1).\n\n**Modellanteckning:** format Tillåtna värden: YYYY, YYYY-MM, YYYY-MM-DD.",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "code"
      }],
      "binding" : {
        "strength" : "required",
        "valueSet" : "https://fhir.inera.se/ig/strategicresourcemanagement-persons-person/ValueSet/SPP-datetypeformat-vs"
      }
    },
    {
      "id" : "updateperson.updatePersonResult.personRecord.personalIdentityStatus.identityStatusDate.value",
      "path" : "updateperson.updatePersonResult.personRecord.personalIdentityStatus.identityStatusDate.value",
      "short" : "value",
      "definition" : "value",
      "comment" : "TKB-fält: `../../../../value` (`PartialDateValue`, kardinalitet 1..1).",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "updateperson.updatePersonResult.personRecord.personalIdentityStatus.identityStatusCause",
      "path" : "updateperson.updatePersonResult.personRecord.personalIdentityStatus.identityStatusCause",
      "short" : "identityStatusCause",
      "definition" : "identityStatusCause",
      "comment" : "TKB-fält: `../../../identityStatusCause` (`string`, kardinalitet 0..1).",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "updateperson.updatePersonResult.personRecord.updatePersonActor",
      "path" : "updateperson.updatePersonResult.personRecord.updatePersonActor",
      "short" : "ActorType",
      "definition" : "Datatyp som identifierar en aktör.",
      "comment" : "TKB-fält: `../../updatePersonActor` (`ActorType`, kardinalitet 0..1).",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "Base"
      }]
    },
    {
      "id" : "updateperson.updatePersonResult.personRecord.updatePersonActor.id",
      "path" : "updateperson.updatePersonResult.personRecord.updatePersonActor.id",
      "short" : "id",
      "definition" : "En universellt unik identifierare.",
      "comment" : "TKB-fält: `../../../id` (`IIType`, kardinalitet 1..1).",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "https://fhir.inera.se/ig/rivta-datatypes/StructureDefinition/IIType"
      }]
    },
    {
      "id" : "updateperson.updatePersonResult.personRecord.updatePersonActor.professional",
      "path" : "updateperson.updatePersonResult.personRecord.updatePersonActor.professional",
      "short" : "ProfessionalType",
      "definition" : "Datatyp som identifierar en aktör inom en profession.",
      "comment" : "TKB-fält: `../../../professional` (`ProfessionalType`, kardinalitet 0..1).",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "Base"
      }]
    },
    {
      "id" : "updateperson.updatePersonResult.personRecord.updatePersonActor.professional.organizationId",
      "path" : "updateperson.updatePersonResult.personRecord.updatePersonActor.professional.organizationId",
      "short" : "organizationId",
      "definition" : "En universellt unik identifierare.",
      "comment" : "TKB-fält: `../../../../organizationId` (`IIType`, kardinalitet 1..1).",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "https://fhir.inera.se/ig/rivta-datatypes/StructureDefinition/IIType"
      }]
    },
    {
      "id" : "updateperson.updatePersonResult.personRecord.updatePersonActor.updateTime",
      "path" : "updateperson.updatePersonResult.personRecord.updatePersonActor.updateTime",
      "short" : "updateTime",
      "definition" : "updateTime",
      "comment" : "TKB-fält: `../../../updateTime` (`Timestamp`, kardinalitet 0..1).",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "updateperson.updatePersonResult.personRecord.updatePersonContactInformationActor",
      "path" : "updateperson.updatePersonResult.personRecord.updatePersonContactInformationActor",
      "short" : "ActorType",
      "definition" : "Datatyp som identifierar en aktör.",
      "comment" : "TKB-fält: `../../updatePersonContactInformationActor` (`ActorType`, kardinalitet 0..1).",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "Base"
      }]
    },
    {
      "id" : "updateperson.updatePersonResult.personRecord.updatePersonContactInformationActor.id",
      "path" : "updateperson.updatePersonResult.personRecord.updatePersonContactInformationActor.id",
      "short" : "id",
      "definition" : "En universellt unik identifierare.",
      "comment" : "TKB-fält: `../../../id` (`IIType`, kardinalitet 1..1).",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "https://fhir.inera.se/ig/rivta-datatypes/StructureDefinition/IIType"
      }]
    },
    {
      "id" : "updateperson.updatePersonResult.personRecord.updatePersonContactInformationActor.professional",
      "path" : "updateperson.updatePersonResult.personRecord.updatePersonContactInformationActor.professional",
      "short" : "ProfessionalType",
      "definition" : "Datatyp som identifierar en aktör inom en profession.",
      "comment" : "TKB-fält: `../../../professional` (`ProfessionalType`, kardinalitet 0..1).",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "Base"
      }]
    },
    {
      "id" : "updateperson.updatePersonResult.personRecord.updatePersonContactInformationActor.professional.organizationId",
      "path" : "updateperson.updatePersonResult.personRecord.updatePersonContactInformationActor.professional.organizationId",
      "short" : "organizationId",
      "definition" : "En universellt unik identifierare.",
      "comment" : "TKB-fält: `../../../../organizationId` (`IIType`, kardinalitet 1..1).",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "https://fhir.inera.se/ig/rivta-datatypes/StructureDefinition/IIType"
      }]
    },
    {
      "id" : "updateperson.updatePersonResult.personRecord.updatePersonContactInformationActor.updateTime",
      "path" : "updateperson.updatePersonResult.personRecord.updatePersonContactInformationActor.updateTime",
      "short" : "updateTime",
      "definition" : "updateTime",
      "comment" : "TKB-fält: `../../../updateTime` (`Timestamp`, kardinalitet 0..1).",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "updateperson.updatePersonResult.personRecord.attachment",
      "path" : "updateperson.updatePersonResult.personRecord.attachment",
      "short" : "MultimediaType",
      "definition" : "Datatyp som beskriver en multimediatyp. Data kan förekomma som inbäddat element eller hänvisas via en referens URL.",
      "comment" : "TKB-fält: `../../attachment` (`MultimediaType`, kardinalitet 0..*).",
      "min" : 0,
      "max" : "*",
      "type" : [{
        "code" : "Base"
      }]
    },
    {
      "id" : "updateperson.updatePersonResult.personRecord.attachment.id",
      "path" : "updateperson.updatePersonResult.personRecord.attachment.id",
      "short" : "id",
      "definition" : "id",
      "comment" : "TKB-fält: `../../../id` (`string`, kardinalitet 0..1).",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "updateperson.updatePersonResult.personRecord.attachment.mediaType",
      "path" : "updateperson.updatePersonResult.personRecord.attachment.mediaType",
      "short" : "mediaType",
      "definition" : "mediaType",
      "comment" : "TKB-fält: `../../../mediaType` (`CodedValue`, kardinalitet 1..1).",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "updateperson.updatePersonResult.personRecord.attachment.value",
      "path" : "updateperson.updatePersonResult.personRecord.attachment.value",
      "short" : "value",
      "definition" : "value",
      "comment" : "TKB-fält: `../../../value` (`base64Binary`, kardinalitet 0..1).",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "base64Binary"
      }]
    },
    {
      "id" : "updateperson.updatePersonResult.personRecord.attachment.reference",
      "path" : "updateperson.updatePersonResult.personRecord.attachment.reference",
      "short" : "reference",
      "definition" : "reference",
      "comment" : "TKB-fält: `../../../reference` (`anyURI`, kardinalitet 0..1).",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "uri"
      }]
    },
    {
      "id" : "updateperson.updatePersonResult.personRecord.optoutPaperNotification",
      "path" : "updateperson.updatePersonResult.personRecord.optoutPaperNotification",
      "short" : "optoutPaperNotification",
      "definition" : "optoutPaperNotification",
      "comment" : "TKB-fält: `../../optoutPaperNotification` (`boolean`, kardinalitet 0..1).",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "boolean"
      }]
    },
    {
      "id" : "updateperson.updatePersonResult.personRecord.protectedPopulationRecord",
      "path" : "updateperson.updatePersonResult.personRecord.protectedPopulationRecord",
      "short" : "protectedPopulationRecord",
      "definition" : "protectedPopulationRecord",
      "comment" : "TKB-fält: `../../protectedPopulationRecord` (`boolean`, kardinalitet 0..1).",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "boolean"
      }]
    }]
  }
}

```
