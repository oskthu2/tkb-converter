# Hem - strategicresourcemanagement: persons: person v5.1.0

* [**Table of Contents**](toc.md)
* **Hem**

## Hem

| | |
| :--- | :--- |
| *Official URL*:https://fhir.inera.se/ig/strategicresourcemanagement-persons-person/ImplementationGuide/inera.strategicresourcemanagement-persons-person | *Version*:5.1.0 |
| Active as of 2026-10-08 | *Computable Name*:strategicresourcemanagementpersonsperson |
| **Copyright/Legal**: Copyright 2024 Inera AB. Licensieras under Creative Commons Attribution 4.0. | |

# strategicresourcemanagement: persons: person

**TKB-version:** 5.1 · **IG-version:** 5.1.0 · **Källa:** Bitbucket-tagg `5.1` 

## Översikt

FHIR Implementation Guide för tjänstedomänen **strategicresourcemanagement: persons: person** (Personuppgiftstjänsten, PU-tjänsten) version 5.1. Genererad från Ineras Tjänstekontraktsbeskrivning (TKB), version 5.1 (2024-11-28), och domänens WSDL- och XSD-filer (tagg 5.1).

Personuppgiftstjänsten tillhandahåller personuppgifter ur Skatteverkets folkbokföring (Navet) och hanterar reservidentiteter och personers kontaktuppgifter. Kontrakten med suffixet **Unrestricted** returnerar även uppgifter för personer med skyddade personuppgifter. Utöver RIV-TA-kontrakten beskriver TKB:n REST-tjänsten [GetPersonsByFile](7-tjanstekontrakt.md#getpersonsbyfile).

Domänen innehåller följande tjänstekontrakt:

| | | |
| :--- | :--- | :--- |
| [GetPersonsForProfile](7-tjanstekontrakt.md#getpersonsforprofile) | 5.0 | Tjänst för att hämta uppgifter för 1..* personidentiteter. |
| [GetPersonsForProfileUnrestricted](7-tjanstekontrakt.md#getpersonsforprofileunrestricted) | 5.0 | Tjänst för att hämta uppgifter för 1..* personidentiteter. |
| [SearchPersonsForProfile](7-tjanstekontrakt.md#searchpersonsforprofile) | 5.0 | Tjänst för att söka uppgifter för 0..* personidentiteter utifrån sökparametrar definierad enligt en bestämd syntax. |
| [SearchPersonsForProfileUnrestricted](7-tjanstekontrakt.md#searchpersonsforprofileunrestricted) | 5.0 | Tjänst för att söka uppgifter för 0..* personidentiteter utifrån sökparametrar definierad enligt en bestämd syntax. |
| [SearchPersonsForProfileByOrder](7-tjanstekontrakt.md#searchpersonsforprofilebyorder) | 5.0 | Tjänst för att asynkront söka uppgifter för 0..* personidentiteter utifrån sökparametrar definierad enligt en bestämd syntax. Denna tjänst tillskillnad från SearchPersonsForProfile returnerar endast ett orderId som sedan ska användas tillsammans med tjänsten GetFilesForOrderId för att få tillgång till resultatet av sökningen. Se sekvensschemat i kapitel 3.1.10. |
| [SearchPersonsForProfileByOrderUnrestricted](7-tjanstekontrakt.md#searchpersonsforprofilebyorderunrestricted) | 5.0 | Tjänst för att asynkront söka uppgifter för 0..* personidentiteter utifrån sökparametrar definierad enligt en bestämd syntax. |
| [GetFilesForOrderId](7-tjanstekontrakt.md#getfilesfororderid) | 4.0 | Tjänst för få en adress (URL) utifrån ett givet OrderId, där man kan hämta begärda data. Till exempel personposter utifrån en tidigare begärd sökning med tjänsten SearchPersonsForProfileByOrder eller förändrade personposter. |
| [GetPersonContactInformation](7-tjanstekontrakt.md#getpersoncontactinformation) | 4.0 | Tjänst för att hämta information om kontaktinformation, exempelvis mailadress eller mobilnummer till personen. Kontaktinformationen kan ha skapats antingen via någon tjänst där personen själv har matat in uppgifterna (t.ex via 1177) eller av t.ex en vårdaktör via vårdaktörens tjänst. Kontaktuppgifterna består dels av vilka kontaktvägar (telefon, mail etc) som personen själv i fråga kan nås på, dels av kontaktpersoner och kontaktuppgifter till dem. Kontaktpersoner kan t.ex vara anhöriga som vårdens aktörer kan ha behov av att kontakta kring personens vård. |
| [GetPersonContactInformationUnrestricted](7-tjanstekontrakt.md#getpersoncontactinformationunrestricted) | 4.0 | Tjänst för att hämta information om kontaktinformation, exempelvis mailadress eller mobilnummer till personen. |
| [UpdatePersonContactInformation](7-tjanstekontrakt.md#updatepersoncontactinformation) | 4.0 | Tjänst för att skapa/uppdatera kontaktinformation. Antingen via någon tjänst där personen själv har matat in uppgifterna (t.ex via 1177) eller där en vårdaktör uppger personen kontaktuppgifter via vårdaktörens journalsystem/eTjänst. Kontaktuppgifterna består dels av vilka kontaktvägar som personen själv i fråga kan nås på (exempelvis telefon, email), dels av kontaktpersoner samt kontaktuppgifter till dem. Kontaktpersoner kan t.ex vara anhöriga som vårdens aktörer kan ha behov av att kontakta kring personens vård. En konsument av denna tjänst kan således dels vara en tjänst såsom Journalen, dels ett vårdsystem. |
| [UpdatePersonContactInformationUnrestricted](7-tjanstekontrakt.md#updatepersoncontactinformationunrestricted) | 4.0 | Tjänst för att skapa/uppdatera kontaktinformation. Antingen via någon tjänst där personen själv har matat in uppgifterna (t.ex via 1177) eller där en vårdaktör uppger personen kontaktuppgifter via vårdaktörens journalsystem/eTjänst. |
| [UpdatePerson](7-tjanstekontrakt.md#updateperson) | 5.0 | Tjänst för att ta ut en ny reservidentitet (NRID), uppdatera en befintlig reservidentitet, eller lägga till en lokal reservidentitet (LRID). Om tjänsten anropas utan identitet så erhålls en ny identitet (NRID) i svaret baserad på de uppgifter som har angivets på personen, ex födelsedatum, kön. |
| [LinkPersonIdentity](7-tjanstekontrakt.md#linkpersonidentity) | 4.0 | Tjänst för att koppla en persons identitet till dess huvudidentitet. T.ex en reservidentitet (LRID/NRID) till ett personnummer. Dvs kunna ange att en person som har 2 identiteter är densamma person. Genom denna koppling kan t.ex NPÖ för en person som är journalförd på 2 olika identiteter, t.ex en reservidentitet och sitt ordinarie personnummer, visa upp journalerna för bägge identiteterna. |
| [UnlinkPersonIdentity](7-tjanstekontrakt.md#unlinkpersonidentity) | 4.0 | Tjänst för att koppla isär en tidigare koppling mellan 2 identiteter. T.ex en koppling mellan en reservidentitet (LRID/NRID) och ett personnummer (PNR). Skälet till isärkopplingen är normalt en felaktig tidigare genomförd koppling. |

## Innehåll

* [1 Inledning](1-inledning.md)
* [2 Versionsinformation](2-versionsinformation.md)
* [3 Tjänstedomänens arkitektur](3-tjanstedomanens-arkitektur.md)
* [4 Tjänstedomänens krav och regler](4-tjanstedomanens-krav-och-regler.md)
* [5 Tjänstedomänens meddelandemodeller](5-tjanstedomanens-meddelandemodeller.md)
* [6 Gemensamma informationskomponenter](6-gemensamma-informationskomponenter.md)
* [7 Tjänstekontrakt](7-tjanstekontrakt.md)
* [8 Aktuella profiler](8-aktuella-profiler.md)
* [Artefakter](artifacts.md)

