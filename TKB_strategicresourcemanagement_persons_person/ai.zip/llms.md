# inera.strategicresourcemanagement-persons-person#5.1.0: strategicresourcemanagement: persons: person

## Pages

* [Hem](index.md)
* [7 Tjänstekontrakt](7-tjanstekontrakt.md)
* [5 Tjänstedomänens meddelandemodeller](5-tjanstedomanens-meddelandemodeller.md)
* [Artifacts Summary](artifacts.md)
* [6 Gemensamma informationskomponenter](6-gemensamma-informationskomponenter.md)
* [3 Tjänstedomänens arkitektur](3-tjanstedomanens-arkitektur.md)
* [8 Aktuella profiler](8-aktuella-profiler.md)
* [4 Tjänstedomänens krav och regler](4-tjanstedomanens-krav-och-regler.md)
* [2 Versionsinformation](2-versionsinformation.md)
* [1 Inledning](1-inledning.md)

## Resources

### CodeSystems

* [DateTypeFormat](CodeSystem-SPP-datetypeformat-cs.md)
* [LookupProfile](CodeSystem-SPP-lookupprofile-cs.md)
* [ResultCode](CodeSystem-SPP-resultcode-cs.md)

### ValueSets

* [DateTypeFormat](ValueSet-SPP-datetypeformat-vs.md)
* [LookupProfile](ValueSet-SPP-lookupprofile-vs.md)
* [ResultCode](ValueSet-SPP-resultcode-vs.md)

### Logicals

* [GetFilesForOrderId — Request](StructureDefinition-getfilesfororderid-request.md)
* [GetFilesForOrderId — Response](StructureDefinition-getfilesfororderid.md)
* [GetPersonContactInformation — Request](StructureDefinition-getpersoncontactinformation-request.md)
* [GetPersonContactInformation — Response](StructureDefinition-getpersoncontactinformation.md)
* [GetPersonContactInformationUnrestricted — Request](StructureDefinition-getpersoncontactinformationunrestricted-request.md)
* [GetPersonContactInformationUnrestricted — Response](StructureDefinition-getpersoncontactinformationunrestricted.md)
* [GetPersonsForProfile — Request](StructureDefinition-getpersonsforprofile-request.md)
* [GetPersonsForProfile — Response](StructureDefinition-getpersonsforprofile.md)
* [GetPersonsForProfileUnrestricted — Request](StructureDefinition-getpersonsforprofileunrestricted-request.md)
* [GetPersonsForProfileUnrestricted — Response](StructureDefinition-getpersonsforprofileunrestricted.md)
* [LinkPersonIdentity — Request](StructureDefinition-linkpersonidentity-request.md)
* [LinkPersonIdentity — Response](StructureDefinition-linkpersonidentity.md)
* [SearchPersonsForProfile — Request](StructureDefinition-searchpersonsforprofile-request.md)
* [SearchPersonsForProfile — Response](StructureDefinition-searchpersonsforprofile.md)
* [SearchPersonsForProfileByOrder — Request](StructureDefinition-searchpersonsforprofilebyorder-request.md)
* [SearchPersonsForProfileByOrder — Response](StructureDefinition-searchpersonsforprofilebyorder.md)
* [SearchPersonsForProfileByOrderUnrestricted — Request](StructureDefinition-searchpersonsforprofilebyorderunrestricted-request.md)
* [SearchPersonsForProfileByOrderUnrestricted — Response](StructureDefinition-searchpersonsforprofilebyorderunrestricted.md)
* [SearchPersonsForProfileUnrestricted — Request](StructureDefinition-searchpersonsforprofileunrestricted-request.md)
* [SearchPersonsForProfileUnrestricted — Response](StructureDefinition-searchpersonsforprofileunrestricted.md)
* [UnlinkPersonIdentity — Request](StructureDefinition-unlinkpersonidentity-request.md)
* [UnlinkPersonIdentity — Response](StructureDefinition-unlinkpersonidentity.md)
* [UpdatePerson — Request](StructureDefinition-updateperson-request.md)
* [UpdatePerson — Response](StructureDefinition-updateperson.md)
* [UpdatePersonContactInformation — Request](StructureDefinition-updatepersoncontactinformation-request.md)
* [UpdatePersonContactInformation — Response](StructureDefinition-updatepersoncontactinformation.md)
* [UpdatePersonContactInformationUnrestricted — Request](StructureDefinition-updatepersoncontactinformationunrestricted-request.md)
* [UpdatePersonContactInformationUnrestricted — Response](StructureDefinition-updatepersoncontactinformationunrestricted.md)

### ImplementationGuides

* [strategicresourcemanagement: persons: person](index.md)
