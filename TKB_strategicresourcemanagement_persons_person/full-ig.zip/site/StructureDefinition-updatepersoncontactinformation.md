# UpdatePersonContactInformation — Response - strategicresourcemanagement: persons: person v5.1.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **UpdatePersonContactInformation — Response**

## Logical Model: UpdatePersonContactInformation — Response 

| | |
| :--- | :--- |
| *Official URL*:https://fhir.inera.se/ig/strategicresourcemanagement-persons-person/StructureDefinition/updatepersoncontactinformation | *Version*:4.0 |
| Active as of 2026-10-08 | *Computable Name*:UpdatePersonContactInformation |
| **Copyright/Legal**: Copyright 2024 Inera AB. Licensieras under Creative Commons Attribution 4.0. | |

 
Logisk modell för svaret i UpdatePersonContactInformation (urn:riv:strategicresourcemanagement:persons:person:UpdatePersonContactInformationResponder:4, UpdatePersonContactInformationResponseType). 

**Usages:**

* This Logical Model is not used by any profiles in this Specification

You can also check for [usages in the FHIR IG Statistics](https://packages2.fhir.org/xig/resource/inera.strategicresourcemanagement-persons-person|current/StructureDefinition/StructureDefinition-updatepersoncontactinformation.json)

### Formal Views of Profile Content

 [Description of Profiles, Differentials, Snapshots and how the different presentations work](http://build.fhir.org/ig/FHIR/ig-guidance/readingIgs.html#structure-definitions). 

 

Other representations of profile: [CSV](StructureDefinition-updatepersoncontactinformation.csv), [Excel](StructureDefinition-updatepersoncontactinformation.xlsx) 



## Resource Content

```json
{
  "resourceType" : "StructureDefinition",
  "id" : "updatepersoncontactinformation",
  "extension" : [{
    "url" : "http://hl7.org/fhir/StructureDefinition/structuredefinition-type-characteristics",
    "valueCode" : "can-be-target"
  }],
  "url" : "https://fhir.inera.se/ig/strategicresourcemanagement-persons-person/StructureDefinition/updatepersoncontactinformation",
  "version" : "4.0",
  "name" : "UpdatePersonContactInformation",
  "title" : "UpdatePersonContactInformation — Response",
  "status" : "active",
  "date" : "2026-10-08T18:52:53+00:00",
  "contact" : [{
    "name" : "Inera Arkitektur",
    "telecom" : [{
      "system" : "url",
      "value" : "https://www.inera.se"
    }]
  }],
  "description" : "Logisk modell för svaret i UpdatePersonContactInformation\n(urn:riv:strategicresourcemanagement:persons:person:UpdatePersonContactInformationResponder:4, UpdatePersonContactInformationResponseType).",
  "copyright" : "Copyright 2024 Inera AB. Licensieras under Creative Commons Attribution 4.0.",
  "fhirVersion" : "4.0.1",
  "kind" : "logical",
  "abstract" : false,
  "type" : "https://fhir.inera.se/ig/strategicresourcemanagement-persons-person/StructureDefinition/updatepersoncontactinformation",
  "baseDefinition" : "http://hl7.org/fhir/StructureDefinition/Base",
  "derivation" : "specialization",
  "differential" : {
    "element" : [{
      "id" : "updatepersoncontactinformation",
      "path" : "updatepersoncontactinformation",
      "short" : "UpdatePersonContactInformation — Response",
      "definition" : "Logisk modell för svaret i UpdatePersonContactInformation\n(urn:riv:strategicresourcemanagement:persons:person:UpdatePersonContactInformationResponder:4, UpdatePersonContactInformationResponseType)."
    },
    {
      "id" : "updatepersoncontactinformation.updatePersonContactInformationResult",
      "path" : "updatepersoncontactinformation.updatePersonContactInformationResult",
      "short" : "updatePersonContactInformationResult",
      "definition" : "updatePersonContactInformationResult",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "BackboneElement"
      }]
    },
    {
      "id" : "updatepersoncontactinformation.updatePersonContactInformationResult.result",
      "path" : "updatepersoncontactinformation.updatePersonContactInformationResult.result",
      "short" : "result",
      "definition" : "Datatyp som returneras som ett generellt svar från alla förändrande tjänster, t.ex. skapa, radera, etc. En tjänstekonsument skall alltid kontrollera att resultatkoden inte innehåller fel för att på så sätt veta om anropet lyckades. Alla svarskoder förutom OK betyder att åtgärden inte genomfördes.",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "BackboneElement"
      }]
    },
    {
      "id" : "updatepersoncontactinformation.updatePersonContactInformationResult.result.resultCode",
      "path" : "updatepersoncontactinformation.updatePersonContactInformationResult.result.resultCode",
      "short" : "resultCode",
      "definition" : "resultCode",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "code"
      }],
      "binding" : {
        "strength" : "required",
        "valueSet" : "https://fhir.inera.se/ig/strategicresourcemanagement-persons-person/ValueSet/SPP-resultcode-vs"
      }
    },
    {
      "id" : "updatepersoncontactinformation.updatePersonContactInformationResult.result.resultText",
      "path" : "updatepersoncontactinformation.updatePersonContactInformationResult.result.resultText",
      "short" : "resultText",
      "definition" : "resultText",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "updatepersoncontactinformation.updatePersonContactInformationResult.contactInformationRecord",
      "path" : "updatepersoncontactinformation.updatePersonContactInformationResult.contactInformationRecord",
      "short" : "contactInformationRecord",
      "definition" : "Uppgifter om personens kontaktuppgifter och kontaktpersoner",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "BackboneElement"
      }]
    },
    {
      "id" : "updatepersoncontactinformation.updatePersonContactInformationResult.contactInformationRecord.contactInformationRecordVersion",
      "path" : "updatepersoncontactinformation.updatePersonContactInformationResult.contactInformationRecord.contactInformationRecordVersion",
      "short" : "contactInformationRecordVersion",
      "definition" : "contactInformationRecordVersion Heter version i schemat.",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "updatepersoncontactinformation.updatePersonContactInformationResult.contactInformationRecord.personId",
      "path" : "updatepersoncontactinformation.updatePersonContactInformationResult.contactInformationRecord.personId",
      "short" : "personId",
      "definition" : "En universellt unik identifierare.",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "BackboneElement"
      }]
    },
    {
      "id" : "updatepersoncontactinformation.updatePersonContactInformationResult.contactInformationRecord.personId.root",
      "path" : "updatepersoncontactinformation.updatePersonContactInformationResult.contactInformationRecord.personId.root",
      "short" : "root",
      "definition" : "root",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "updatepersoncontactinformation.updatePersonContactInformationResult.contactInformationRecord.personId.iiExtension",
      "path" : "updatepersoncontactinformation.updatePersonContactInformationResult.contactInformationRecord.personId.iiExtension",
      "short" : "iiExtension",
      "definition" : "iiExtension Heter extension i schemat.",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "updatepersoncontactinformation.updatePersonContactInformationResult.contactInformationRecord.contactInformation",
      "path" : "updatepersoncontactinformation.updatePersonContactInformationResult.contactInformationRecord.contactInformation",
      "short" : "contactInformation",
      "definition" : "Klass för patientens egna angivna kontakuppgifter",
      "min" : 0,
      "max" : "*",
      "type" : [{
        "code" : "BackboneElement"
      }]
    },
    {
      "id" : "updatepersoncontactinformation.updatePersonContactInformationResult.contactInformationRecord.contactInformation.contactType",
      "path" : "updatepersoncontactinformation.updatePersonContactInformationResult.contactInformationRecord.contactInformation.contactType",
      "short" : "contactType",
      "definition" : "contactType",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "updatepersoncontactinformation.updatePersonContactInformationResult.contactInformationRecord.contactInformation.use",
      "path" : "updatepersoncontactinformation.updatePersonContactInformationResult.contactInformationRecord.contactInformation.use",
      "short" : "use",
      "definition" : "use",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "updatepersoncontactinformation.updatePersonContactInformationResult.contactInformationRecord.contactInformation.contactInformationValue",
      "path" : "updatepersoncontactinformation.updatePersonContactInformationResult.contactInformationRecord.contactInformation.contactInformationValue",
      "short" : "contactInformationValue",
      "definition" : "contactInformationValue Heter value i schemat.",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "updatepersoncontactinformation.updatePersonContactInformationResult.contactInformationRecord.contactInformation.rank",
      "path" : "updatepersoncontactinformation.updatePersonContactInformationResult.contactInformationRecord.contactInformation.rank",
      "short" : "rank",
      "definition" : "rank",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "integer"
      }]
    },
    {
      "id" : "updatepersoncontactinformation.updatePersonContactInformationResult.contactInformationRecord.contactInformation.comment",
      "path" : "updatepersoncontactinformation.updatePersonContactInformationResult.contactInformationRecord.contactInformation.comment",
      "short" : "comment",
      "definition" : "comment",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "updatepersoncontactinformation.updatePersonContactInformationResult.contactInformationRecord.contactInformation.period",
      "path" : "updatepersoncontactinformation.updatePersonContactInformationResult.contactInformationRecord.contactInformation.period",
      "short" : "period",
      "definition" : "period",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "BackboneElement"
      }]
    },
    {
      "id" : "updatepersoncontactinformation.updatePersonContactInformationResult.contactInformationRecord.contactInformation.period.start",
      "path" : "updatepersoncontactinformation.updatePersonContactInformationResult.contactInformationRecord.contactInformation.period.start",
      "short" : "start",
      "definition" : "start",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "date"
      }]
    },
    {
      "id" : "updatepersoncontactinformation.updatePersonContactInformationResult.contactInformationRecord.contactInformation.period.end",
      "path" : "updatepersoncontactinformation.updatePersonContactInformationResult.contactInformationRecord.contactInformation.period.end",
      "short" : "end",
      "definition" : "end",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "date"
      }]
    },
    {
      "id" : "updatepersoncontactinformation.updatePersonContactInformationResult.contactInformationRecord.contactInformation.digitalNotification",
      "path" : "updatepersoncontactinformation.updatePersonContactInformationResult.contactInformationRecord.contactInformation.digitalNotification",
      "short" : "digitalNotification",
      "definition" : "digitalNotification",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "boolean"
      }]
    },
    {
      "id" : "updatepersoncontactinformation.updatePersonContactInformationResult.contactInformationRecord.contactPerson",
      "path" : "updatepersoncontactinformation.updatePersonContactInformationResult.contactInformationRecord.contactPerson",
      "short" : "contactPerson",
      "definition" : "contactPerson",
      "min" : 0,
      "max" : "*",
      "type" : [{
        "code" : "BackboneElement"
      }]
    },
    {
      "id" : "updatepersoncontactinformation.updatePersonContactInformationResult.contactInformationRecord.contactPerson.contactRelationshipType",
      "path" : "updatepersoncontactinformation.updatePersonContactInformationResult.contactInformationRecord.contactPerson.contactRelationshipType",
      "short" : "contactRelationshipType",
      "definition" : "contactRelationshipType",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "updatepersoncontactinformation.updatePersonContactInformationResult.contactInformationRecord.contactPerson.priorityOrder",
      "path" : "updatepersoncontactinformation.updatePersonContactInformationResult.contactInformationRecord.contactPerson.priorityOrder",
      "short" : "priorityOrder",
      "definition" : "priorityOrder",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "integer"
      }]
    },
    {
      "id" : "updatepersoncontactinformation.updatePersonContactInformationResult.contactInformationRecord.contactPerson.givenName",
      "path" : "updatepersoncontactinformation.updatePersonContactInformationResult.contactInformationRecord.contactPerson.givenName",
      "short" : "givenName",
      "definition" : "givenName",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "updatepersoncontactinformation.updatePersonContactInformationResult.contactInformationRecord.contactPerson.surName",
      "path" : "updatepersoncontactinformation.updatePersonContactInformationResult.contactInformationRecord.contactPerson.surName",
      "short" : "surName",
      "definition" : "surName",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "updatepersoncontactinformation.updatePersonContactInformationResult.contactInformationRecord.contactPerson.middleName",
      "path" : "updatepersoncontactinformation.updatePersonContactInformationResult.contactInformationRecord.contactPerson.middleName",
      "short" : "middleName",
      "definition" : "middleName",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "updatepersoncontactinformation.updatePersonContactInformationResult.contactInformationRecord.contactPerson.contactPersonAddress",
      "path" : "updatepersoncontactinformation.updatePersonContactInformationResult.contactInformationRecord.contactPerson.contactPersonAddress",
      "short" : "contactPersonAddress",
      "definition" : "Svensk adress",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "BackboneElement"
      }]
    },
    {
      "id" : "updatepersoncontactinformation.updatePersonContactInformationResult.contactInformationRecord.contactPerson.contactPersonAddress.careOf",
      "path" : "updatepersoncontactinformation.updatePersonContactInformationResult.contactInformationRecord.contactPerson.contactPersonAddress.careOf",
      "short" : "careOf",
      "definition" : "careOf",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "updatepersoncontactinformation.updatePersonContactInformationResult.contactInformationRecord.contactPerson.contactPersonAddress.postalAddress1",
      "path" : "updatepersoncontactinformation.updatePersonContactInformationResult.contactInformationRecord.contactPerson.contactPersonAddress.postalAddress1",
      "short" : "postalAddress1",
      "definition" : "postalAddress1",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "updatepersoncontactinformation.updatePersonContactInformationResult.contactInformationRecord.contactPerson.contactPersonAddress.postalAddress2",
      "path" : "updatepersoncontactinformation.updatePersonContactInformationResult.contactInformationRecord.contactPerson.contactPersonAddress.postalAddress2",
      "short" : "postalAddress2",
      "definition" : "postalAddress2",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "updatepersoncontactinformation.updatePersonContactInformationResult.contactInformationRecord.contactPerson.contactPersonAddress.postalCode",
      "path" : "updatepersoncontactinformation.updatePersonContactInformationResult.contactInformationRecord.contactPerson.contactPersonAddress.postalCode",
      "short" : "postalCode",
      "definition" : "postalCode",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "integer"
      }]
    },
    {
      "id" : "updatepersoncontactinformation.updatePersonContactInformationResult.contactInformationRecord.contactPerson.contactPersonAddress.city",
      "path" : "updatepersoncontactinformation.updatePersonContactInformationResult.contactInformationRecord.contactPerson.contactPersonAddress.city",
      "short" : "city",
      "definition" : "city",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "updatepersoncontactinformation.updatePersonContactInformationResult.contactInformationRecord.contactPerson.contactPersonContactInformation",
      "path" : "updatepersoncontactinformation.updatePersonContactInformationResult.contactInformationRecord.contactPerson.contactPersonContactInformation",
      "short" : "contactPersonContactInformation",
      "definition" : "Klass för patientens egna angivna kontakuppgifter",
      "min" : 0,
      "max" : "*",
      "type" : [{
        "code" : "BackboneElement"
      }]
    },
    {
      "id" : "updatepersoncontactinformation.updatePersonContactInformationResult.contactInformationRecord.contactPerson.contactPersonContactInformation.contactType",
      "path" : "updatepersoncontactinformation.updatePersonContactInformationResult.contactInformationRecord.contactPerson.contactPersonContactInformation.contactType",
      "short" : "contactType",
      "definition" : "contactType",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "updatepersoncontactinformation.updatePersonContactInformationResult.contactInformationRecord.contactPerson.contactPersonContactInformation.use",
      "path" : "updatepersoncontactinformation.updatePersonContactInformationResult.contactInformationRecord.contactPerson.contactPersonContactInformation.use",
      "short" : "use",
      "definition" : "use",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "updatepersoncontactinformation.updatePersonContactInformationResult.contactInformationRecord.contactPerson.contactPersonContactInformation.contactInformationValue",
      "path" : "updatepersoncontactinformation.updatePersonContactInformationResult.contactInformationRecord.contactPerson.contactPersonContactInformation.contactInformationValue",
      "short" : "contactInformationValue",
      "definition" : "contactInformationValue Heter value i schemat.",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "updatepersoncontactinformation.updatePersonContactInformationResult.contactInformationRecord.contactPerson.contactPersonContactInformation.rank",
      "path" : "updatepersoncontactinformation.updatePersonContactInformationResult.contactInformationRecord.contactPerson.contactPersonContactInformation.rank",
      "short" : "rank",
      "definition" : "rank",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "integer"
      }]
    },
    {
      "id" : "updatepersoncontactinformation.updatePersonContactInformationResult.contactInformationRecord.contactPerson.contactPersonContactInformation.comment",
      "path" : "updatepersoncontactinformation.updatePersonContactInformationResult.contactInformationRecord.contactPerson.contactPersonContactInformation.comment",
      "short" : "comment",
      "definition" : "comment",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "updatepersoncontactinformation.updatePersonContactInformationResult.contactInformationRecord.contactPerson.contactPersonContactInformation.period",
      "path" : "updatepersoncontactinformation.updatePersonContactInformationResult.contactInformationRecord.contactPerson.contactPersonContactInformation.period",
      "short" : "period",
      "definition" : "period",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "BackboneElement"
      }]
    },
    {
      "id" : "updatepersoncontactinformation.updatePersonContactInformationResult.contactInformationRecord.contactPerson.contactPersonContactInformation.period.start",
      "path" : "updatepersoncontactinformation.updatePersonContactInformationResult.contactInformationRecord.contactPerson.contactPersonContactInformation.period.start",
      "short" : "start",
      "definition" : "start",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "date"
      }]
    },
    {
      "id" : "updatepersoncontactinformation.updatePersonContactInformationResult.contactInformationRecord.contactPerson.contactPersonContactInformation.period.end",
      "path" : "updatepersoncontactinformation.updatePersonContactInformationResult.contactInformationRecord.contactPerson.contactPersonContactInformation.period.end",
      "short" : "end",
      "definition" : "end",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "date"
      }]
    },
    {
      "id" : "updatepersoncontactinformation.updatePersonContactInformationResult.contactInformationRecord.contactPerson.contactPersonContactInformation.digitalNotification",
      "path" : "updatepersoncontactinformation.updatePersonContactInformationResult.contactInformationRecord.contactPerson.contactPersonContactInformation.digitalNotification",
      "short" : "digitalNotification",
      "definition" : "digitalNotification",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "boolean"
      }]
    },
    {
      "id" : "updatepersoncontactinformation.updatePersonContactInformationResult.contactInformationRecord.protectedPersonIndicator",
      "path" : "updatepersoncontactinformation.updatePersonContactInformationResult.contactInformationRecord.protectedPersonIndicator",
      "short" : "protectedPersonIndicator",
      "definition" : "protectedPersonIndicator",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "boolean"
      }]
    },
    {
      "id" : "updatepersoncontactinformation.updatePersonContactInformationResult.contactInformationRecord.protectedPopulationRecord",
      "path" : "updatepersoncontactinformation.updatePersonContactInformationResult.contactInformationRecord.protectedPopulationRecord",
      "short" : "protectedPopulationRecord",
      "definition" : "protectedPopulationRecord",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "boolean"
      }]
    },
    {
      "id" : "updatepersoncontactinformation.updatePersonContactInformationResult.contactInformationRecord.optoutPaperNotification",
      "path" : "updatepersoncontactinformation.updatePersonContactInformationResult.contactInformationRecord.optoutPaperNotification",
      "short" : "optoutPaperNotification",
      "definition" : "optoutPaperNotification",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "boolean"
      }]
    },
    {
      "id" : "updatepersoncontactinformation.updatePersonContactInformationResult.contactInformationRecord.updatePersonContactInformationActor",
      "path" : "updatepersoncontactinformation.updatePersonContactInformationResult.contactInformationRecord.updatePersonContactInformationActor",
      "short" : "updatePersonContactInformationActor",
      "definition" : "Datatyp som identifierar en aktör.",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "BackboneElement"
      }]
    },
    {
      "id" : "updatepersoncontactinformation.updatePersonContactInformationResult.contactInformationRecord.updatePersonContactInformationActor.actorId",
      "path" : "updatepersoncontactinformation.updatePersonContactInformationResult.contactInformationRecord.updatePersonContactInformationActor.actorId",
      "short" : "actorId",
      "definition" : "En universellt unik identifierare. Heter id i schemat.",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "BackboneElement"
      }]
    },
    {
      "id" : "updatepersoncontactinformation.updatePersonContactInformationResult.contactInformationRecord.updatePersonContactInformationActor.actorId.root",
      "path" : "updatepersoncontactinformation.updatePersonContactInformationResult.contactInformationRecord.updatePersonContactInformationActor.actorId.root",
      "short" : "root",
      "definition" : "root",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "updatepersoncontactinformation.updatePersonContactInformationResult.contactInformationRecord.updatePersonContactInformationActor.actorId.iiExtension",
      "path" : "updatepersoncontactinformation.updatePersonContactInformationResult.contactInformationRecord.updatePersonContactInformationActor.actorId.iiExtension",
      "short" : "iiExtension",
      "definition" : "iiExtension Heter extension i schemat.",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "updatepersoncontactinformation.updatePersonContactInformationResult.contactInformationRecord.updatePersonContactInformationActor.professional",
      "path" : "updatepersoncontactinformation.updatePersonContactInformationResult.contactInformationRecord.updatePersonContactInformationActor.professional",
      "short" : "professional",
      "definition" : "Datatyp som identifierar en aktör inom en profession.",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "BackboneElement"
      }]
    },
    {
      "id" : "updatepersoncontactinformation.updatePersonContactInformationResult.contactInformationRecord.updatePersonContactInformationActor.professional.organizationId",
      "path" : "updatepersoncontactinformation.updatePersonContactInformationResult.contactInformationRecord.updatePersonContactInformationActor.professional.organizationId",
      "short" : "organizationId",
      "definition" : "En universellt unik identifierare.",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "BackboneElement"
      }]
    },
    {
      "id" : "updatepersoncontactinformation.updatePersonContactInformationResult.contactInformationRecord.updatePersonContactInformationActor.professional.organizationId.root",
      "path" : "updatepersoncontactinformation.updatePersonContactInformationResult.contactInformationRecord.updatePersonContactInformationActor.professional.organizationId.root",
      "short" : "root",
      "definition" : "root",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "updatepersoncontactinformation.updatePersonContactInformationResult.contactInformationRecord.updatePersonContactInformationActor.professional.organizationId.iiExtension",
      "path" : "updatepersoncontactinformation.updatePersonContactInformationResult.contactInformationRecord.updatePersonContactInformationActor.professional.organizationId.iiExtension",
      "short" : "iiExtension",
      "definition" : "iiExtension Heter extension i schemat.",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "updatepersoncontactinformation.updatePersonContactInformationResult.contactInformationRecord.updatePersonContactInformationActor.updateTime",
      "path" : "updatepersoncontactinformation.updatePersonContactInformationResult.contactInformationRecord.updatePersonContactInformationActor.updateTime",
      "short" : "updateTime",
      "definition" : "updateTime",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    }]
  }
}

```
