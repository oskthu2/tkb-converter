# Hem - infrastructure: supportservices: forminteraction v2.0.0

* [**Table of Contents**](toc.md)
* **Hem**

## Hem

| | |
| :--- | :--- |
| *Official URL*:https://fhir.inera.se/ig/infrastructure-supportservices-forminteraction/ImplementationGuide/inera.infrastructure-supportservices-forminteraction | *Version*:2.0.0 |
| Draft as of 2026-09-17 | *Computable Name*:infrastructuresupportservicesforminteraction |
| **Copyright/Legal**: Copyright 2024 Inera AB. Licensieras under Creative Commons Attribution 4.0. | |

# infrastructure: supportservices: forminteraction

## Översikt

FHIR Implementation Guide för tjänstedomänen **infrastructure: supportservices: forminteraction** version 2.0.0. Genererad från Ineras Tjänstekontraktsbeskrivning (TKB) `TKB_infrastructure_eservicesupply_forminteraction.docx`.

Domänen innehåller tjänstekontrakt för att stödja formulärinteraktion mellan patient (e-tjänst i form av en tjänstekonsument) och verksamhetssystem (formulärmotor i form av en tjänsteproducent). Formulärtjänsten möjliggör hantering av formulärinformation mellan olika aktörer.

Domänen innehåller följande tjänstekontrakt:

| | | |
| :--- | :--- | :--- |
| [GetFormTemplates](7-tjanstekontrakt.md#getformtemplates) | 2.0 | Hämta lista med formulärmallar |
| [CreateForm](7-tjanstekontrakt.md#createform) | 2.0 | Skapa ett formulär |
| [GetForms](7-tjanstekontrakt.md#getforms) | 2.0 | Hämta lista med formulär |
| [GetForm](7-tjanstekontrakt.md#getform) | 2.0 | Hämta ett specifikt formulär |
| [GetFormQuestionPage](7-tjanstekontrakt.md#getformquestionpage) | 2.0 | Hämta en frågesida i ett formulär |
| [SaveFormPage](7-tjanstekontrakt.md#saveformpage) | 2.0 | Spara en frågesida i ett formulär |
| [SaveForm](7-tjanstekontrakt.md#saveform) | 2.0 | Avsluta och spara ett formulär |
| [CancelForm](7-tjanstekontrakt.md#cancelform) | 2.0 | Avbryta ett formulär |
| [CreateFormRequest](7-tjanstekontrakt.md#createformrequest) | 2.0 | Skapa en formulärbegäran |
| [GetFormTemplate](7-tjanstekontrakt.md#getformtemplate) | 2.0 | Hämta en specifik formulärmall |
| [SaveFormTemplate](7-tjanstekontrakt.md#saveformtemplate) | 2.0 | Spara en formulärmall |

## Innehåll

* [1 Inledning](1-inledning.md)
* [2 Versionsinformation](2-versionsinformation.md)
* [3 Tjänstedomänens arkitektur](3-tjanstedomanens-arkitektur.md)
* [4 Tjänstedomänens krav och regler](4-tjanstedomanens-krav-och-regler.md)
* [5 Tjänstedomänens meddelandemodeller](5-tjanstedomanens-meddelandemodeller.md)
* [6 Tjänster sammanställning](6-tjanster-sammanstallning.md)
* [7 Tjänstekontrakt](7-tjanstekontrakt.md)
* [Artefakter](artifacts.md)

