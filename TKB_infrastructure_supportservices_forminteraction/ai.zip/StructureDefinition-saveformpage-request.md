# SaveFormPage — Request - infrastructure: supportservices: forminteraction v2.0.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **SaveFormPage — Request**

## Logical Model: SaveFormPage — Request 

| | |
| :--- | :--- |
| *Official URL*:https://fhir.inera.se/ig/infrastructure-supportservices-forminteraction/StructureDefinition/saveformpage-request | *Version*:2.0.0 |
| Draft as of 2026-09-17 | *Computable Name*:SaveFormPageRequest |
| **Copyright/Legal**: Copyright 2024 Inera AB. Licensieras under Creative Commons Attribution 4.0. | |

 
Logisk modell för requestparametrar i SaveFormPage (RIV-TA urn:riv:infrastructure:supportservices:forminteraction:SaveFormPage:2). Sparar invånarens besvarade frågor på en sida under pågående formulärsession. Om temporarySave anges: spara utan validering, returnera samma sida. 

**Usages:**

* This Logical Model is not used by any profiles in this Specification

You can also check for [usages in the FHIR IG Statistics](https://packages2.fhir.org/xig/resource/inera.infrastructure-supportservices-forminteraction|current/StructureDefinition/StructureDefinition-saveformpage-request.json)

### Formal Views of Profile Content

 [Description of Profiles, Differentials, Snapshots and how the different presentations work](http://build.fhir.org/ig/FHIR/ig-guidance/readingIgs.html#structure-definitions). 

 

Other representations of profile: [CSV](StructureDefinition-saveformpage-request.csv), [Excel](StructureDefinition-saveformpage-request.xlsx) 



## Resource Content

```json
{
  "resourceType" : "StructureDefinition",
  "id" : "saveformpage-request",
  "extension" : [{
    "url" : "http://hl7.org/fhir/StructureDefinition/structuredefinition-type-characteristics",
    "valueCode" : "can-be-target"
  }],
  "url" : "https://fhir.inera.se/ig/infrastructure-supportservices-forminteraction/StructureDefinition/saveformpage-request",
  "version" : "2.0.0",
  "name" : "SaveFormPageRequest",
  "title" : "SaveFormPage — Request",
  "status" : "draft",
  "date" : "2026-09-17T11:15:42+00:00",
  "contact" : [{
    "name" : "Inera Arkitektur",
    "telecom" : [{
      "system" : "url",
      "value" : "https://www.inera.se"
    }]
  }],
  "description" : "Logisk modell för requestparametrar i SaveFormPage\n(RIV-TA urn:riv:infrastructure:supportservices:forminteraction:SaveFormPage:2).\nSparar invånarens besvarade frågor på en sida under pågående formulärsession.\nOm temporarySave anges: spara utan validering, returnera samma sida.",
  "copyright" : "Copyright 2024 Inera AB. Licensieras under Creative Commons Attribution 4.0.",
  "fhirVersion" : "4.0.1",
  "kind" : "logical",
  "abstract" : false,
  "type" : "https://fhir.inera.se/ig/infrastructure-supportservices-forminteraction/StructureDefinition/saveformpage-request",
  "baseDefinition" : "http://hl7.org/fhir/StructureDefinition/Base",
  "derivation" : "specialization",
  "differential" : {
    "element" : [{
      "id" : "saveformpage-request",
      "path" : "saveformpage-request",
      "short" : "SaveFormPage — Request",
      "definition" : "Logisk modell för requestparametrar i SaveFormPage\n(RIV-TA urn:riv:infrastructure:supportservices:forminteraction:SaveFormPage:2).\nSparar invånarens besvarade frågor på en sida under pågående formulärsession.\nOm temporarySave anges: spara utan validering, returnera samma sida."
    },
    {
      "id" : "saveformpage-request.formId",
      "path" : "saveformpage-request.formId",
      "short" : "Formulärets unika ID (GUID)",
      "definition" : "Formulärets unika ID (GUID)",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "saveformpage-request.subjectOfCare",
      "path" : "saveformpage-request.subjectOfCare",
      "short" : "Invånarens personnummer (yyyymmddnnnn)",
      "definition" : "Invånarens personnummer (yyyymmddnnnn)",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "saveformpage-request.pageAnswer",
      "path" : "saveformpage-request.pageAnswer",
      "short" : "Sida med besvarade frågor att spara",
      "definition" : "Innehåller sidans nummer och alla svar som invånaren har lämnat.",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "BackboneElement"
      }]
    },
    {
      "id" : "saveformpage-request.pageAnswer.pageNumber",
      "path" : "saveformpage-request.pageAnswer.pageNumber",
      "short" : "Sidans nummer",
      "definition" : "Sidans nummer",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "integer"
      }]
    },
    {
      "id" : "saveformpage-request.pageAnswer.questionBlock",
      "path" : "saveformpage-request.pageAnswer.questionBlock",
      "short" : "Frågegrupperingar med svar",
      "definition" : "Frågegrupperingar med svar",
      "min" : 1,
      "max" : "*",
      "type" : [{
        "code" : "BackboneElement"
      }]
    },
    {
      "id" : "saveformpage-request.pageAnswer.questionBlock.question",
      "path" : "saveformpage-request.pageAnswer.questionBlock.question",
      "short" : "Frågor med svar",
      "definition" : "Frågor med svar",
      "min" : 1,
      "max" : "*",
      "type" : [{
        "code" : "BackboneElement"
      }]
    },
    {
      "id" : "saveformpage-request.pageAnswer.questionBlock.question.questionId",
      "path" : "saveformpage-request.pageAnswer.questionBlock.question.questionId",
      "short" : "Frågans ID",
      "definition" : "Frågans ID",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "saveformpage-request.pageAnswer.questionBlock.question.answer",
      "path" : "saveformpage-request.pageAnswer.questionBlock.question.answer",
      "short" : "Invånarens svar",
      "definition" : "Invånarens svar",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "BackboneElement"
      }]
    },
    {
      "id" : "saveformpage-request.pageAnswer.questionBlock.question.answer.answerText",
      "path" : "saveformpage-request.pageAnswer.questionBlock.question.answer.answerText",
      "short" : "Svarstext",
      "definition" : "Svarstext",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "saveformpage-request.pageAnswer.questionBlock.question.answer.answeredAlternativeId",
      "path" : "saveformpage-request.pageAnswer.questionBlock.question.answer.answeredAlternativeId",
      "short" : "ID för valt svarsalternativ",
      "definition" : "ID för valt svarsalternativ",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "saveformpage-request.temporarySave",
      "path" : "saveformpage-request.temporarySave",
      "short" : "Om true: temporärspara utan validering och returnera samma sida",
      "definition" : "Om true: temporärspara utan validering och returnera samma sida",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "boolean"
      }]
    }]
  }
}

```
