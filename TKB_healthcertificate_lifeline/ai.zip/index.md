# Hem - healthcertificate: lifeline v1.0.0-snapshot

* [**Table of Contents**](toc.md)
* **Hem**

## Hem

| | |
| :--- | :--- |
| *Official URL*:https://fhir.inera.se/ig/healthcertificate-lifeline/ImplementationGuide/inera.healthcertificate-lifeline | *Version*:1.0.0-snapshot |
| Draft as of 2026-11-06 | *Computable Name*:healthcertificatelifeline |
| **Copyright/Legal**: Copyright 2024 Inera AB. Licensieras under Creative Commons Attribution 4.0. | |

# healthcertificate: lifeline

**TKB-version:** 1.0 · **IG-version:** 1.0.0-snapshot · **Källa:** Bitbucket-commit `6281e725997f` (ingen tagg) 

## Översikt

* Typ: Förvaltare
  * Extern tjänstedomän: VGR
* Typ: Källkod
  * Extern tjänstedomän: [Bitbucket](https://bitbucket.org/rivta-domains/riv.healthcertificate.lifeline/src)
* Typ: Ärenden
  * Extern tjänstedomän: [Bitbucket issues](https://bitbucket.org/rivta-domains/riv.healthcertificate.lifeline/issues)
* Typ: Underlag för denna IG
  * Extern tjänstedomän: Version 1.0 ·[commit 6281e725997f](https://bitbucket.org/rivta-domains/riv.healthcertificate.lifeline/src/6281e725997f2111bb73ea7154765936fb82e36d)·[zip](https://bitbucket.org/rivta-domains/riv.healthcertificate.lifeline/get/6281e725997f.zip)
* Typ: RIV-TA-portalen
  * Extern tjänstedomän: [Alla tjänstedomäner](https://oskthu2.github.io/tkb-converter/rivta-portal/tjanstedomaner.html)·[Alla tjänstekontrakt](https://oskthu2.github.io/tkb-converter/rivta-portal/tjanstekontrakt.html)

FHIR Implementation Guide för tjänstedomänen **healthcertificate: lifeline** (Elektronisk Födelseanmälan, eFA) version 1.0. Genererad från Ineras Tjänstekontraktsbeskrivning (TKB), utgåva PA1 (2012-04-13), och domänens WSDL- och XSD-filer.

Tjänstedomänen gör det möjligt för förlossningsjournalsystem att göra en elektronisk födelseanmälan till Skatteverket och få barnets personnummer i retur.

Domänen innehåller följande tjänstekontrakt:

| | | |
| :--- | :--- | :--- |
| [BirthRegistration](7-tjanstekontrakt.md#birthregistration) | 1.0 | Elektronisk födelseanmälan till Skatteverket |

**Om källan:** TKB:n är ett utkast (utgåva PA1) i det äldre Word-formatet (.doc). Källan saknar versionstaggar; IG:n bygger på senaste commit på `master` (2012-04-18).

### Versioner och granskningar

| | | | |
| :--- | :--- | :--- | :--- |
| trunk |  |  | [källkod](https://bitbucket.org/rivta-domains/riv.healthcertificate.lifeline/src/master) |

*Zip-arkiven hämtas från taggarna på Bitbucket. Granskningsprotokollen publicerades på rivta.se och länkas inte härifrån.*

*Källa: ögonblicksbild av DOMDB från 2021-08-24, via RIV-TA-portalen.*

## Innehåll

* [1 Inledning](1-inledning.md)
* [2 Generella regler](2-generella-regler.md)
* [7 Tjänstekontrakt](7-tjanstekontrakt.md)
* [8 Datatyper](8-datatyper.md)
* [Artefakter](artifacts.md)

