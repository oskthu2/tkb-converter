# Hem - healthcertificate: lifeline v1.0.0

* [**Table of Contents**](toc.md)
* **Hem**

## Hem

| | |
| :--- | :--- |
| *Official URL*:https://fhir.inera.se/ig/healthcertificate-lifeline/ImplementationGuide/inera.healthcertificate-lifeline | *Version*:1.0.0 |
| Draft as of 2026-09-26 | *Computable Name*:healthcertificatelifeline |
| **Copyright/Legal**: Copyright 2024 Inera AB. Licensieras under Creative Commons Attribution 4.0. | |

# healthcertificate: lifeline

## Översikt

FHIR Implementation Guide för tjänstedomänen **healthcertificate: lifeline** (Elektronisk Födelseanmälan, eFA) version 1.0. Genererad från Ineras Tjänstekontraktsbeskrivning (TKB), utgåva PA1 (2012-04-13), och domänens WSDL- och XSD-filer.

Tjänstedomänen gör det möjligt för förlossningsjournalsystem att göra en elektronisk födelseanmälan till Skatteverket och få barnets personnummer i retur.

Domänen innehåller följande tjänstekontrakt:

| | | |
| :--- | :--- | :--- |
| [BirthRegistration](7-tjanstekontrakt.md#birthregistration) | 1.0 | Elektronisk födelseanmälan till Skatteverket |

**Om källan:** TKB:n är ett utkast (utgåva PA1) i det äldre Word-formatet (.doc). Källan saknar versionstaggar; IG:n bygger på senaste commit på `master` (2012-04-18).

## Innehåll

* [1 Inledning](1-inledning.md)
* [2 Generella regler](2-generella-regler.md)
* [7 Tjänstekontrakt](7-tjanstekontrakt.md)
* [8 Datatyper](8-datatyper.md)
* [Artefakter](artifacts.md)

