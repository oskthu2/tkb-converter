# Barnets kön - healthcertificate: lifeline v1.0.0-snapshot

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Barnets kön**

## ValueSet: Barnets kön 

| | |
| :--- | :--- |
| *Official URL*:https://fhir.inera.se/ig/healthcertificate-lifeline/ValueSet/lifeline-kon-vs | *Version*:1.0.0-snapshot |
| Active as of 2026-10-12 | *Computable Name*:KonVS |
| **Copyright/Legal**: Copyright 2024 Inera AB. Licensieras under Creative Commons Attribution 4.0. | |

 
Alla koder i KonCS. 

 **References** 

* [BirthRegistration — Request](StructureDefinition-birthregistration-request.md)

### Logical Definition (CLD)

 

### Expansion

-------

 Explanation of the columns that may appear on this page: 

| | |
| :--- | :--- |
| Level | A few code lists that FHIR defines are hierarchical - each code is assigned a level. In this scheme, some codes are under other codes, and imply that the code they are under also applies |
| System | The source of the definition of the code (when the value set draws in codes defined elsewhere) |
| Code | The code (used as the code in the resource instance) |
| Display | The display (used in the*display*element of a[Coding](http://hl7.org/fhir/R4/datatypes.html#Coding)). If there is no display, implementers should not simply display the code, but map the concept into their application |
| Definition | An explanation of the meaning of the concept |
| Comments | Additional notes about how to use the code |



## Resource Content

```json
{
  "resourceType" : "ValueSet",
  "id" : "lifeline-kon-vs",
  "url" : "https://fhir.inera.se/ig/healthcertificate-lifeline/ValueSet/lifeline-kon-vs",
  "version" : "1.0.0-snapshot",
  "name" : "KonVS",
  "title" : "Barnets kön",
  "status" : "active",
  "date" : "2026-10-12T12:26:38+00:00",
  "contact" : [{
    "name" : "Inera Arkitektur",
    "telecom" : [{
      "system" : "url",
      "value" : "https://www.inera.se"
    }]
  }],
  "description" : "Alla koder i KonCS.",
  "copyright" : "Copyright 2024 Inera AB. Licensieras under Creative Commons Attribution 4.0.",
  "compose" : {
    "include" : [{
      "system" : "https://fhir.inera.se/CodeSystem/lifeline-kon-cs"
    }]
  }
}

```
