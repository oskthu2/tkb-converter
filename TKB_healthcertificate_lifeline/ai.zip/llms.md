# inera.healthcertificate-lifeline#1.0.0: healthcertificate: lifeline

## Pages

* [Hem](index.md)
* [2 Generella regler](2-generella-regler.md)
* [7 Tjänstekontrakt](7-tjanstekontrakt.md)
* [8 Datatyper](8-datatyper.md)
* [Artifacts Summary](artifacts.md)
* [1 Inledning](1-inledning.md)

## Resources

### CodeSystems

* [Anmälan mottagen](CodeSystem-lifeline-anmalanmottagen-cs.md)
* [Anmälningstyp](CodeSystem-lifeline-anmalningstyp-cs.md)
* [Feltyp](CodeSystem-lifeline-erroridenum-cs.md)
* [Barnets kön](CodeSystem-lifeline-kon-cs.md)
* [Levande vid födelsen](CodeSystem-lifeline-levande-cs.md)
* [Resultatkod](CodeSystem-lifeline-resultcodeenum-cs.md)

### ValueSets

* [Anmälan mottagen](ValueSet-lifeline-anmalanmottagen-vs.md)
* [Anmälningstyp](ValueSet-lifeline-anmalningstyp-vs.md)
* [Feltyp](ValueSet-lifeline-erroridenum-vs.md)
* [Barnets kön](ValueSet-lifeline-kon-vs.md)
* [Levande vid födelsen](ValueSet-lifeline-levande-vs.md)
* [Resultatkod](ValueSet-lifeline-resultcodeenum-vs.md)

### Logicals

* [BirthRegistration — Request](StructureDefinition-birthregistration-request.md)
* [BirthRegistration — Response](StructureDefinition-birthregistration.md)

### ImplementationGuides

* [healthcertificate: lifeline](index.md)
