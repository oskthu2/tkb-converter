# GetOfferingCatalogues — Response - supportprocess: serviceprovisioning: healthcareoffering v3.0.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **GetOfferingCatalogues — Response**

## Logical Model: GetOfferingCatalogues — Response 

| | |
| :--- | :--- |
| *Official URL*:https://fhir.inera.se/ig/supportprocess-serviceprovisioning-healthcareoffering/StructureDefinition/getofferingcatalogues | *Version*:2.0 |
| Active as of 2026-10-08 | *Computable Name*:GetOfferingCatalogues |
| **Copyright/Legal**: Copyright 2024 Inera AB. Licensieras under Creative Commons Attribution 4.0. | |

 
Logisk modell för svaret i GetOfferingCatalogues (urn:riv:supportprocess:serviceprovisioning:healthcareoffering:GetOfferingCataloguesResponder:2, GetOfferingCataloguesResponseType). 

**Usages:**

* This Logical Model is not used by any profiles in this Specification

You can also check for [usages in the FHIR IG Statistics](https://packages2.fhir.org/xig/resource/inera.supportprocess-serviceprovisioning-healthcareoffering|current/StructureDefinition/StructureDefinition-getofferingcatalogues.json)

### Formal Views of Profile Content

 [Description of Profiles, Differentials, Snapshots and how the different presentations work](http://build.fhir.org/ig/FHIR/ig-guidance/readingIgs.html#structure-definitions). 

 

Other representations of profile: [CSV](StructureDefinition-getofferingcatalogues.csv), [Excel](StructureDefinition-getofferingcatalogues.xlsx) 



## Resource Content

```json
{
  "resourceType" : "StructureDefinition",
  "id" : "getofferingcatalogues",
  "extension" : [{
    "url" : "http://hl7.org/fhir/StructureDefinition/structuredefinition-type-characteristics",
    "valueCode" : "can-be-target"
  }],
  "url" : "https://fhir.inera.se/ig/supportprocess-serviceprovisioning-healthcareoffering/StructureDefinition/getofferingcatalogues",
  "version" : "2.0",
  "name" : "GetOfferingCatalogues",
  "title" : "GetOfferingCatalogues — Response",
  "status" : "active",
  "date" : "2026-10-08T18:58:01+00:00",
  "contact" : [{
    "name" : "Inera Arkitektur",
    "telecom" : [{
      "system" : "url",
      "value" : "https://www.inera.se"
    }]
  }],
  "description" : "Logisk modell för svaret i GetOfferingCatalogues\n(urn:riv:supportprocess:serviceprovisioning:healthcareoffering:GetOfferingCataloguesResponder:2, GetOfferingCataloguesResponseType).",
  "copyright" : "Copyright 2024 Inera AB. Licensieras under Creative Commons Attribution 4.0.",
  "fhirVersion" : "4.0.1",
  "kind" : "logical",
  "abstract" : false,
  "type" : "https://fhir.inera.se/ig/supportprocess-serviceprovisioning-healthcareoffering/StructureDefinition/getofferingcatalogues",
  "baseDefinition" : "http://hl7.org/fhir/StructureDefinition/Base",
  "derivation" : "specialization",
  "differential" : {
    "element" : [{
      "id" : "getofferingcatalogues",
      "path" : "getofferingcatalogues",
      "short" : "GetOfferingCatalogues — Response",
      "definition" : "Logisk modell för svaret i GetOfferingCatalogues\n(urn:riv:supportprocess:serviceprovisioning:healthcareoffering:GetOfferingCataloguesResponder:2, GetOfferingCataloguesResponseType)."
    },
    {
      "id" : "getofferingcatalogues.offeringCatalogue",
      "path" : "getofferingcatalogues.offeringCatalogue",
      "short" : "offeringCatalogue",
      "definition" : "offeringCatalogue",
      "min" : 0,
      "max" : "*",
      "type" : [{
        "code" : "BackboneElement"
      }]
    },
    {
      "id" : "getofferingcatalogues.offeringCatalogue.providingOrganization",
      "path" : "getofferingcatalogues.offeringCatalogue.providingOrganization",
      "short" : "providingOrganization",
      "definition" : "providingOrganization",
      "min" : 1,
      "max" : "*",
      "type" : [{
        "code" : "BackboneElement"
      }]
    },
    {
      "id" : "getofferingcatalogues.offeringCatalogue.providingOrganization.providingOrganizationId",
      "path" : "getofferingcatalogues.offeringCatalogue.providingOrganization.providingOrganizationId",
      "short" : "providingOrganizationId",
      "definition" : "providingOrganizationId Heter id i schemat.",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "BackboneElement"
      }]
    },
    {
      "id" : "getofferingcatalogues.offeringCatalogue.providingOrganization.providingOrganizationId.root",
      "path" : "getofferingcatalogues.offeringCatalogue.providingOrganization.providingOrganizationId.root",
      "short" : "root",
      "definition" : "root",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "getofferingcatalogues.offeringCatalogue.providingOrganization.providingOrganizationId.iiExtension",
      "path" : "getofferingcatalogues.offeringCatalogue.providingOrganization.providingOrganizationId.iiExtension",
      "short" : "iiExtension",
      "definition" : "iiExtension Heter extension i schemat.",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "getofferingcatalogues.offeringCatalogue.providingOrganization.providingOrganizationName",
      "path" : "getofferingcatalogues.offeringCatalogue.providingOrganization.providingOrganizationName",
      "short" : "providingOrganizationName",
      "definition" : "providingOrganizationName Heter name i schemat.",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "getofferingcatalogues.offeringCatalogue.providingOrganization.management",
      "path" : "getofferingcatalogues.offeringCatalogue.providingOrganization.management",
      "short" : "management",
      "definition" : "management",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "BackboneElement"
      }]
    },
    {
      "id" : "getofferingcatalogues.offeringCatalogue.providingOrganization.management.cvCode",
      "path" : "getofferingcatalogues.offeringCatalogue.providingOrganization.management.cvCode",
      "short" : "cvCode",
      "definition" : "cvCode Heter code i schemat.",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "getofferingcatalogues.offeringCatalogue.providingOrganization.management.codeSystem",
      "path" : "getofferingcatalogues.offeringCatalogue.providingOrganization.management.codeSystem",
      "short" : "codeSystem",
      "definition" : "codeSystem",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "getofferingcatalogues.offeringCatalogue.providingOrganization.management.codeSystemName",
      "path" : "getofferingcatalogues.offeringCatalogue.providingOrganization.management.codeSystemName",
      "short" : "codeSystemName",
      "definition" : "codeSystemName",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "getofferingcatalogues.offeringCatalogue.providingOrganization.management.codeSystemVersion",
      "path" : "getofferingcatalogues.offeringCatalogue.providingOrganization.management.codeSystemVersion",
      "short" : "codeSystemVersion",
      "definition" : "codeSystemVersion",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "getofferingcatalogues.offeringCatalogue.providingOrganization.management.displayName",
      "path" : "getofferingcatalogues.offeringCatalogue.providingOrganization.management.displayName",
      "short" : "displayName",
      "definition" : "displayName",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "getofferingcatalogues.offeringCatalogue.providingOrganization.management.originalText",
      "path" : "getofferingcatalogues.offeringCatalogue.providingOrganization.management.originalText",
      "short" : "originalText",
      "definition" : "originalText",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "getofferingcatalogues.offeringCatalogue.providingOrganization.publicProvider",
      "path" : "getofferingcatalogues.offeringCatalogue.providingOrganization.publicProvider",
      "short" : "publicProvider",
      "definition" : "publicProvider",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "boolean"
      }]
    },
    {
      "id" : "getofferingcatalogues.offeringCatalogue.providingOrganization.description",
      "path" : "getofferingcatalogues.offeringCatalogue.providingOrganization.description",
      "short" : "description",
      "definition" : "description",
      "min" : 0,
      "max" : "*",
      "type" : [{
        "code" : "BackboneElement"
      }]
    },
    {
      "id" : "getofferingcatalogues.offeringCatalogue.providingOrganization.description.descriptionText",
      "path" : "getofferingcatalogues.offeringCatalogue.providingOrganization.description.descriptionText",
      "short" : "descriptionText",
      "definition" : "descriptionText Heter text i schemat.",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "getofferingcatalogues.offeringCatalogue.providingOrganization.description.descriptionLanguage",
      "path" : "getofferingcatalogues.offeringCatalogue.providingOrganization.description.descriptionLanguage",
      "short" : "descriptionLanguage",
      "definition" : "descriptionLanguage Heter language i schemat.",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "BackboneElement"
      }]
    },
    {
      "id" : "getofferingcatalogues.offeringCatalogue.providingOrganization.description.descriptionLanguage.cvCode",
      "path" : "getofferingcatalogues.offeringCatalogue.providingOrganization.description.descriptionLanguage.cvCode",
      "short" : "cvCode",
      "definition" : "cvCode Heter code i schemat.",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "getofferingcatalogues.offeringCatalogue.providingOrganization.description.descriptionLanguage.codeSystem",
      "path" : "getofferingcatalogues.offeringCatalogue.providingOrganization.description.descriptionLanguage.codeSystem",
      "short" : "codeSystem",
      "definition" : "codeSystem",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "getofferingcatalogues.offeringCatalogue.providingOrganization.description.descriptionLanguage.codeSystemName",
      "path" : "getofferingcatalogues.offeringCatalogue.providingOrganization.description.descriptionLanguage.codeSystemName",
      "short" : "codeSystemName",
      "definition" : "codeSystemName",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "getofferingcatalogues.offeringCatalogue.providingOrganization.description.descriptionLanguage.codeSystemVersion",
      "path" : "getofferingcatalogues.offeringCatalogue.providingOrganization.description.descriptionLanguage.codeSystemVersion",
      "short" : "codeSystemVersion",
      "definition" : "codeSystemVersion",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "getofferingcatalogues.offeringCatalogue.providingOrganization.description.descriptionLanguage.displayName",
      "path" : "getofferingcatalogues.offeringCatalogue.providingOrganization.description.descriptionLanguage.displayName",
      "short" : "displayName",
      "definition" : "displayName",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "getofferingcatalogues.offeringCatalogue.providingOrganization.description.descriptionLanguage.originalText",
      "path" : "getofferingcatalogues.offeringCatalogue.providingOrganization.description.descriptionLanguage.originalText",
      "short" : "originalText",
      "definition" : "originalText",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "getofferingcatalogues.offeringCatalogue.providingOrganization.description.role",
      "path" : "getofferingcatalogues.offeringCatalogue.providingOrganization.description.role",
      "short" : "role",
      "definition" : "role",
      "min" : 0,
      "max" : "*",
      "type" : [{
        "code" : "BackboneElement"
      }]
    },
    {
      "id" : "getofferingcatalogues.offeringCatalogue.providingOrganization.description.role.cvCode",
      "path" : "getofferingcatalogues.offeringCatalogue.providingOrganization.description.role.cvCode",
      "short" : "cvCode",
      "definition" : "cvCode Heter code i schemat.",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "getofferingcatalogues.offeringCatalogue.providingOrganization.description.role.codeSystem",
      "path" : "getofferingcatalogues.offeringCatalogue.providingOrganization.description.role.codeSystem",
      "short" : "codeSystem",
      "definition" : "codeSystem",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "getofferingcatalogues.offeringCatalogue.providingOrganization.description.role.codeSystemName",
      "path" : "getofferingcatalogues.offeringCatalogue.providingOrganization.description.role.codeSystemName",
      "short" : "codeSystemName",
      "definition" : "codeSystemName",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "getofferingcatalogues.offeringCatalogue.providingOrganization.description.role.codeSystemVersion",
      "path" : "getofferingcatalogues.offeringCatalogue.providingOrganization.description.role.codeSystemVersion",
      "short" : "codeSystemVersion",
      "definition" : "codeSystemVersion",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "getofferingcatalogues.offeringCatalogue.providingOrganization.description.role.displayName",
      "path" : "getofferingcatalogues.offeringCatalogue.providingOrganization.description.role.displayName",
      "short" : "displayName",
      "definition" : "displayName",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "getofferingcatalogues.offeringCatalogue.providingOrganization.description.role.originalText",
      "path" : "getofferingcatalogues.offeringCatalogue.providingOrganization.description.role.originalText",
      "short" : "originalText",
      "definition" : "originalText",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "getofferingcatalogues.offeringCatalogue.interaction",
      "path" : "getofferingcatalogues.offeringCatalogue.interaction",
      "short" : "interaction",
      "definition" : "interaction",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "BackboneElement"
      }]
    },
    {
      "id" : "getofferingcatalogues.offeringCatalogue.interaction.logicalAddress",
      "path" : "getofferingcatalogues.offeringCatalogue.interaction.logicalAddress",
      "short" : "logicalAddress",
      "definition" : "logicalAddress",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "getofferingcatalogues.offeringCatalogue.interaction.interactionName",
      "path" : "getofferingcatalogues.offeringCatalogue.interaction.interactionName",
      "short" : "interactionName",
      "definition" : "interactionName Heter name i schemat.",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "uri"
      }]
    },
    {
      "id" : "getofferingcatalogues.offeringCatalogue.interaction.majorVersion",
      "path" : "getofferingcatalogues.offeringCatalogue.interaction.majorVersion",
      "short" : "majorVersion",
      "definition" : "majorVersion",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "integer"
      }]
    },
    {
      "id" : "getofferingcatalogues.offeringCatalogue.interaction.minorVersion",
      "path" : "getofferingcatalogues.offeringCatalogue.interaction.minorVersion",
      "short" : "minorVersion",
      "definition" : "minorVersion",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "integer"
      }]
    },
    {
      "id" : "getofferingcatalogues.offeringCatalogue.interaction.rivtaVersion",
      "path" : "getofferingcatalogues.offeringCatalogue.interaction.rivtaVersion",
      "short" : "rivtaVersion",
      "definition" : "rivtaVersion",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "code"
      }],
      "binding" : {
        "strength" : "required",
        "valueSet" : "https://fhir.inera.se/ig/supportprocess-serviceprovisioning-healthcareoffering/ValueSet/healthcareoffering-rivtaversion-vs"
      }
    }]
  }
}

```
