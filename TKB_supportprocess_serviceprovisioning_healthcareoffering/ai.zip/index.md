# Hem - supportprocess: serviceprovisioning: healthcareoffering v3.0.0

* [**Table of Contents**](toc.md)
* **Hem**

## Hem

| | |
| :--- | :--- |
| *Official URL*:https://fhir.inera.se/ig/supportprocess-serviceprovisioning-healthcareoffering/ImplementationGuide/inera.supportprocess-serviceprovisioning-healthcareoffering | *Version*:3.0.0 |
| Active as of 2026-11-06 | *Computable Name*:supportprocessserviceprovisioninghealthcareoffering |
| **Copyright/Legal**: Copyright 2024 Inera AB. Licensieras under Creative Commons Attribution 4.0. | |

# supportprocess: serviceprovisioning: healthcareoffering

**TKB-version:** 3.0 · **IG-version:** 3.0.0 · **Källa:** Bitbucket-tagg `3.0` 

## Översikt

* Beskrivning: Svenskt kortnamn
  * Syftet med denna tjänstedomän är att göra det möjligt för både vårdprofession och invånare att söka efter vårdtjänster, samt var dessa utförs. Tjänstekontrakten inom denna domän gör det möjligt att söka efter vem som kan utföra en viss typ av vårdtjänst, var vårdtjänsten utförs och ge detaljerad information om utföraren är lämplig att utföra vårdtjänsten.: vårdochomsorgsutbud
* Beskrivning: Svenskt namn
  * Syftet med denna tjänstedomän är att göra det möjligt för både vårdprofession och invånare att söka efter vårdtjänster, samt var dessa utförs. Tjänstekontrakten inom denna domän gör det möjligt att söka efter vem som kan utföra en viss typ av vårdtjänst, var vårdtjänsten utförs och ge detaljerad information om utföraren är lämplig att utföra vårdtjänsten.: operativt processtöd:tillgängliggöra tjänst:vårdochomsorgsutbud
* Beskrivning: Typ
  * Syftet med denna tjänstedomän är att göra det möjligt för både vårdprofession och invånare att söka efter vårdtjänster, samt var dessa utförs. Tjänstekontrakten inom denna domän gör det möjligt att söka efter vem som kan utföra en viss typ av vårdtjänst, var vårdtjänsten utförs och ge detaljerad information om utföraren är lämplig att utföra vårdtjänsten.: Nationell tjänstedomän
* Beskrivning: Källkod
  * Syftet med denna tjänstedomän är att göra det möjligt för både vårdprofession och invånare att söka efter vårdtjänster, samt var dessa utförs. Tjänstekontrakten inom denna domän gör det möjligt att söka efter vem som kan utföra en viss typ av vårdtjänst, var vårdtjänsten utförs och ge detaljerad information om utföraren är lämplig att utföra vårdtjänsten.: [Bitbucket](https://bitbucket.org/rivta-domains/riv.supportprocess.serviceprovisioning.healthcareoffering/src)
* Beskrivning: Ärenden
  * Syftet med denna tjänstedomän är att göra det möjligt för både vårdprofession och invånare att söka efter vårdtjänster, samt var dessa utförs. Tjänstekontrakten inom denna domän gör det möjligt att söka efter vem som kan utföra en viss typ av vårdtjänst, var vårdtjänsten utförs och ge detaljerad information om utföraren är lämplig att utföra vårdtjänsten.: [Bitbucket issues](https://bitbucket.org/rivta-domains/riv.supportprocess.serviceprovisioning.healthcareoffering/issues)
* Beskrivning: Underlag för denna IG
  * Syftet med denna tjänstedomän är att göra det möjligt för både vårdprofession och invånare att söka efter vårdtjänster, samt var dessa utförs. Tjänstekontrakten inom denna domän gör det möjligt att söka efter vem som kan utföra en viss typ av vårdtjänst, var vårdtjänsten utförs och ge detaljerad information om utföraren är lämplig att utföra vårdtjänsten.: Version 3.0 ·[tagg 3.0](https://bitbucket.org/rivta-domains/riv.supportprocess.serviceprovisioning.healthcareoffering/src/3.0)·[zip](https://bitbucket.org/rivta-domains/riv.supportprocess.serviceprovisioning.healthcareoffering/get/3.0.zip)
* Beskrivning: RIV-TA-portalen
  * Syftet med denna tjänstedomän är att göra det möjligt för både vårdprofession och invånare att söka efter vårdtjänster, samt var dessa utförs. Tjänstekontrakten inom denna domän gör det möjligt att söka efter vem som kan utföra en viss typ av vårdtjänst, var vårdtjänsten utförs och ge detaljerad information om utföraren är lämplig att utföra vårdtjänsten.: [Alla tjänstedomäner](https://oskthu2.github.io/tkb-converter/rivta-portal/tjanstedomaner.html)·[Alla tjänstekontrakt](https://oskthu2.github.io/tkb-converter/rivta-portal/tjanstekontrakt.html)

FHIR Implementation Guide för tjänstedomänen **supportprocess: serviceprovisioning: healthcareoffering** (Vård- och omsorgsutbud) version 3.0. Genererad från Ineras Tjänstekontraktsbeskrivning (TKB), version 3.0 (2023-04-25), och domänens WSDL- och XSD-filer (tagg 3.0).

Tjänstedomänen gör det möjligt att hämta utbudskataloger och de vård- och omsorgstjänster som katalogansvariga organisationer erbjuder, till exempel för att hitta rätt mottagare av en remiss.

Domänen innehåller följande tjänstekontrakt:

| | | |
| :--- | :--- | :--- |
| [GetOfferingCatalogues](7-tjanstekontrakt.md#getofferingcatalogues) | 2.0 | Hämtar information om utbudskataloger, vilken adress de tillhandahålls på och vilka katalogansvariga organisationer som tillhandahåller utbud i respektive katalog. |
| [GetCareServiceOfferings](7-tjanstekontrakt.md#getcareserviceofferings) | 3.0 | GetCareServiceOfferings hämtar de vård- och omsorgstjänster som ingår i det utbud som erbjuds av en katalogansvarig organisation och som är tillgängliga baserat på användarens filterparametrar. |

### Versioner och granskningar

| | | | |
| :--- | :--- | :--- | :--- |
| 1.0.1 | IS, AB, TKB | Arkitektur & Regelverk: Teknik: GodkändArkitektur & Regelverk: Informatik: GodkändArkitektur & Regelverk: Säkerhet: Godkänd | [zip](https://bitbucket.org/rivta-domains/riv.supportprocess.serviceprovisioning.healthcareoffering/get/1.0.1.zip)·[källkod](https://bitbucket.org/rivta-domains/riv.supportprocess.serviceprovisioning.healthcareoffering/src/1.0.1) |
| trunk | TKB, AB, IS |  | [källkod](https://bitbucket.org/rivta-domains/riv.supportprocess.serviceprovisioning.healthcareoffering/src/master) |

*Zip-arkiven hämtas från taggarna på Bitbucket. Granskningsprotokollen publicerades på rivta.se och länkas inte härifrån.*

*Källa: ögonblicksbild av DOMDB från 2021-08-24, via RIV-TA-portalen.*

## Innehåll

* [1 Inledning](1-inledning.md)
* [2 Versionsinformation](2-versionsinformation.md)
* [3 Tjänstedomänens arkitektur](3-tjanstedomanens-arkitektur.md)
* [4 Tjänstedomänens krav och regler](4-tjanstedomanens-krav-och-regler.md)
* [5 Tjänstedomänens meddelandemodeller](5-tjanstedomanens-meddelandemodeller.md)
* [6 Gemensamma informationskomponenter](6-gemensamma-informationskomponenter.md)
* [7 Tjänstekontrakt](7-tjanstekontrakt.md)
* [Artefakter](artifacts.md)

