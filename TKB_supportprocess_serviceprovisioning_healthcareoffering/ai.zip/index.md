# Hem - supportprocess: serviceprovisioning: healthcareoffering v3.0.0

* [**Table of Contents**](toc.md)
* **Hem**

## Hem

| | |
| :--- | :--- |
| *Official URL*:https://fhir.inera.se/ig/supportprocess-serviceprovisioning-healthcareoffering/ImplementationGuide/inera.supportprocess-serviceprovisioning-healthcareoffering | *Version*:3.0.0 |
| Active as of 2026-10-08 | *Computable Name*:supportprocessserviceprovisioninghealthcareoffering |
| **Copyright/Legal**: Copyright 2024 Inera AB. Licensieras under Creative Commons Attribution 4.0. | |

# supportprocess: serviceprovisioning: healthcareoffering

**TKB-version:** 3.0 · **IG-version:** 3.0.0 · **Källa:** Bitbucket-tagg `3.0` 

## Översikt

FHIR Implementation Guide för tjänstedomänen **supportprocess: serviceprovisioning: healthcareoffering** (Vård- och omsorgsutbud) version 3.0. Genererad från Ineras Tjänstekontraktsbeskrivning (TKB), version 3.0 (2023-04-25), och domänens WSDL- och XSD-filer (tagg 3.0).

Tjänstedomänen gör det möjligt att hämta utbudskataloger och de vård- och omsorgstjänster som katalogansvariga organisationer erbjuder, till exempel för att hitta rätt mottagare av en remiss.

Domänen innehåller följande tjänstekontrakt:

| | | |
| :--- | :--- | :--- |
| [GetOfferingCatalogues](7-tjanstekontrakt.md#getofferingcatalogues) | 2.0 | Hämtar information om utbudskataloger, vilken adress de tillhandahålls på och vilka katalogansvariga organisationer som tillhandahåller utbud i respektive katalog. |
| [GetCareServiceOfferings](7-tjanstekontrakt.md#getcareserviceofferings) | 3.0 | GetCareServiceOfferings hämtar de vård- och omsorgstjänster som ingår i det utbud som erbjuds av en katalogansvarig organisation och som är tillgängliga baserat på användarens filterparametrar. |

## Innehåll

* [1 Inledning](1-inledning.md)
* [2 Versionsinformation](2-versionsinformation.md)
* [3 Tjänstedomänens arkitektur](3-tjanstedomanens-arkitektur.md)
* [4 Tjänstedomänens krav och regler](4-tjanstedomanens-krav-och-regler.md)
* [5 Tjänstedomänens meddelandemodeller](5-tjanstedomanens-meddelandemodeller.md)
* [6 Gemensamma informationskomponenter](6-gemensamma-informationskomponenter.md)
* [7 Tjänstekontrakt](7-tjanstekontrakt.md)
* [Artefakter](artifacts.md)

