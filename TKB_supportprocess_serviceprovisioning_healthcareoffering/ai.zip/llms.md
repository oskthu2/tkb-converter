# inera.supportprocess-serviceprovisioning-healthcareoffering#3.0.0: supportprocess: serviceprovisioning: healthcareoffering

## Pages

* [Hem](index.md)
* [7 Tjänstekontrakt](7-tjanstekontrakt.md)
* [5 Tjänstedomänens meddelandemodeller](5-tjanstedomanens-meddelandemodeller.md)
* [Artifacts Summary](artifacts.md)
* [6 Gemensamma informationskomponenter](6-gemensamma-informationskomponenter.md)
* [3 Tjänstedomänens arkitektur](3-tjanstedomanens-arkitektur.md)
* [4 Tjänstedomänens krav och regler](4-tjanstedomanens-krav-och-regler.md)
* [2 Versionsinformation](2-versionsinformation.md)
* [1 Inledning](1-inledning.md)

## Resources

### CodeSystems

* [Status för vård- och omsorgstjänst (CareServiceStatus)](CodeSystem-healthcareoffering-careservicestatus-cs.md)
* [RIV-TA-version (RIVTAVersion)](CodeSystem-healthcareoffering-rivtaversion-cs.md)
* [Typ av plats (TypeOfPlace)](CodeSystem-healthcareoffering-typeofplace-cs.md)

### ValueSets

* [Status för vård- och omsorgstjänst (CareServiceStatus)](ValueSet-healthcareoffering-careservicestatus-vs.md)
* [RIV-TA-version (RIVTAVersion)](ValueSet-healthcareoffering-rivtaversion-vs.md)
* [Typ av plats (TypeOfPlace)](ValueSet-healthcareoffering-typeofplace-vs.md)

### Logicals

* [GetCareServiceOfferings — Request](StructureDefinition-getcareserviceofferings-request.md)
* [GetCareServiceOfferings — Response](StructureDefinition-getcareserviceofferings.md)
* [GetOfferingCatalogues — Request](StructureDefinition-getofferingcatalogues-request.md)
* [GetOfferingCatalogues — Response](StructureDefinition-getofferingcatalogues.md)

### ImplementationGuides

* [supportprocess: serviceprovisioning: healthcareoffering](index.md)
