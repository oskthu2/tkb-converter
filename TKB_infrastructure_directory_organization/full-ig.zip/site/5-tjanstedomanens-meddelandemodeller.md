# 5 Tjänstedomänens meddelandemodeller - infrastructure: directory: organization v5.0.0

* [**Table of Contents**](toc.md)
* **5 Tjänstedomänens meddelandemodeller**

## 5 Tjänstedomänens meddelandemodeller

## Tjänstedomänens meddelandemodeller

### V-MIM

För tjänstedomänen utnyttjas befintliga strukturer inom HSA för förvaltning och vidareutveckling av informations- och meddelandemodeller, se även AB-2.4 [R2]. Två gånger per år införs genomarbetade och beslutade ändringar i informationsmodellen enligt särskild process. Nuvarande informationsmodell som också inkluderar mappning mot Nationell Informationsstruktur 2017:1 beskrivs i Informationsspecifikation för Katalogtjänst HSA [R5].

### Formatregler

#### RIV-specifikation

Formatregler för tjänstedomänen specificeras i Informationsspecifikation för Katalogtjänst HSA [R5], se även AB-2.6 [R1]. Ytterligare detaljer finns i även schemabeskrivningen för respektive tjänstekontrakt, se avsnitt 6.

