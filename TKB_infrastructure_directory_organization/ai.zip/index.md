# Hem - infrastructure: directory: organization v5

* [**Table of Contents**](toc.md)
* **Hem**

## Hem

| | |
| :--- | :--- |
| *Official URL*:https://fhir.inera.se/ig/infrastructure-directory-organization/ImplementationGuide/inera.infrastructure-directory-organization | *Version*:5 |
| Draft as of 2026-09-14 | *Computable Name*:InfrastructureDirectoryOrganization |
| **Copyright/Legal**: Copyright 2024 Inera AB. Licensieras under Creative Commons Attribution 4.0. | |

# infrastructure: directory: organization

## Översikt

FHIR Implementation Guide för tjänstedomänen **infrastructure: directory: organization** version 5.0. Genererad från Ineras Tjänstekontraktsbeskrivning (TKB).

Domänen innehåller följande tjänstekontrakt:

| | | |
| :--- | :--- | :--- |
| [GetHealthCareUnit](7-tjanstekontrakt.md#gethealthcareunit) | 2.0 | Söker ut vilken vårdenhet den angivna enheten eller funktionen är kopplad till. |
| [GetHealthCareUnitList](7-tjanstekontrakt.md#gethealthcareunitlist) | 2.0 | Söker fram och listar en angiven vårdgivares alla vårdenheter, definierade enligt PDL. |
| [GetHealthCareUnitMembers](7-tjanstekontrakt.md#gethealthcareunitmembers) | 2.1 | Söker fram alla kopplade enheter för den angivna vårdenheten. |
| [GetUnit](7-tjanstekontrakt.md#getunit) | 5.0 | Returnerar information om den angivna enheten (organisation, enhet eller funktion). |
| [GetHealthCareProvider](7-tjanstekontrakt.md#gethealthcareprovider) | 1.0 | Söker ut och returnerar information om en vårdgivare. |

## Innehåll

* [1 Inledning](1-inledning.md)
* [2 Versionsinformation](2-versionsinformation.md)
* [3 Tjänstedomänens arkitektur](3-tjanstedomanens-arkitektur.md)
* [4 Tjänstedomänens krav och regler](4-tjanstedomanens-krav-och-regler.md)
* [5 Tjänstedomänens meddelandemodeller](5-tjanstedomanens-meddelandemodeller.md)
* [6 Gemensamma informationskomponenter](6-gemensamma-informationskomponenter.md)
* [7 Tjänstekontrakt](7-tjanstekontrakt.md)
* [Artefakter](artifacts.md)

