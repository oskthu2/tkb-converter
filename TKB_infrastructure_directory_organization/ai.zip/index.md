# Hem - infrastructure: directory: organization v5.0.0

* [**Table of Contents**](toc.md)
* **Hem**

## Hem

| | |
| :--- | :--- |
| *Official URL*:https://fhir.inera.se/ig/infrastructure-directory-organization/ImplementationGuide/inera.infrastructure-directory-organization | *Version*:5.0.0 |
| Active as of 2026-10-12 | *Computable Name*:InfrastructureDirectoryOrganization |
| **Copyright/Legal**: Copyright 2024 Inera AB. Licensieras under Creative Commons Attribution 4.0. | |

# infrastructure: directory: organization

**TKB-version:** 5.0 · **IG-version:** 5.0.0 · **Källa:** Bitbucket-commit `6a2e36035369`, efter taggen `5.0` 

## Översikt

* Beskrivning: Svenskt kortnamn
  * Tjänstedomänens ändamål är att förse övriga tjänster med kvalitetssäkrade och aktuella organisations-, enhets- och funktionsuppgifter. Användningsområden utgörs främst av * Publika vårdsökningar efter kontaktinformation till enheter verksamma inom vård och omsorg * Hämtning av information om vårdgivare och vårdenheter kopplade till Patientdatalagen, PDL: organisation
* Beskrivning: Svenskt namn
  * Tjänstedomänens ändamål är att förse övriga tjänster med kvalitetssäkrade och aktuella organisations-, enhets- och funktionsuppgifter. Användningsområden utgörs främst av * Publika vårdsökningar efter kontaktinformation till enheter verksamma inom vård och omsorg * Hämtning av information om vårdgivare och vårdenheter kopplade till Patientdatalagen, PDL: infrastruktur:katalogtjänster:organisation
* Beskrivning: Typ
  * Tjänstedomänens ändamål är att förse övriga tjänster med kvalitetssäkrade och aktuella organisations-, enhets- och funktionsuppgifter. Användningsområden utgörs främst av * Publika vårdsökningar efter kontaktinformation till enheter verksamma inom vård och omsorg * Hämtning av information om vårdgivare och vårdenheter kopplade till Patientdatalagen, PDL: Nationell tjänstedomän
* Beskrivning: Källkod
  * Tjänstedomänens ändamål är att förse övriga tjänster med kvalitetssäkrade och aktuella organisations-, enhets- och funktionsuppgifter. Användningsområden utgörs främst av * Publika vårdsökningar efter kontaktinformation till enheter verksamma inom vård och omsorg * Hämtning av information om vårdgivare och vårdenheter kopplade till Patientdatalagen, PDL: [Bitbucket](https://bitbucket.org/rivta-domains/riv.infrastructure.directory.organization/src)
* Beskrivning: Ärenden
  * Tjänstedomänens ändamål är att förse övriga tjänster med kvalitetssäkrade och aktuella organisations-, enhets- och funktionsuppgifter. Användningsområden utgörs främst av * Publika vårdsökningar efter kontaktinformation till enheter verksamma inom vård och omsorg * Hämtning av information om vårdgivare och vårdenheter kopplade till Patientdatalagen, PDL: [Bitbucket issues](https://bitbucket.org/rivta-domains/riv.infrastructure.directory.organization/issues)
* Beskrivning: Underlag för denna IG
  * Tjänstedomänens ändamål är att förse övriga tjänster med kvalitetssäkrade och aktuella organisations-, enhets- och funktionsuppgifter. Användningsområden utgörs främst av * Publika vårdsökningar efter kontaktinformation till enheter verksamma inom vård och omsorg * Hämtning av information om vårdgivare och vårdenheter kopplade till Patientdatalagen, PDL: Version 5.0 ·[tagg 5.0](https://bitbucket.org/rivta-domains/riv.infrastructure.directory.organization/src/5.0)
* Beskrivning: RIV-TA-portalen
  * Tjänstedomänens ändamål är att förse övriga tjänster med kvalitetssäkrade och aktuella organisations-, enhets- och funktionsuppgifter. Användningsområden utgörs främst av * Publika vårdsökningar efter kontaktinformation till enheter verksamma inom vård och omsorg * Hämtning av information om vårdgivare och vårdenheter kopplade till Patientdatalagen, PDL: [Alla tjänstedomäner](https://oskthu2.github.io/tkb-converter/rivta-portal/tjanstedomaner.html)·[Alla tjänstekontrakt](https://oskthu2.github.io/tkb-converter/rivta-portal/tjanstekontrakt.html)

FHIR Implementation Guide för tjänstedomänen **infrastructure: directory: organization** version 5.0. Genererad från Ineras Tjänstekontraktsbeskrivning (TKB).

Domänen innehåller följande tjänstekontrakt:

| | | |
| :--- | :--- | :--- |
| [GetHealthCareUnit](7-tjanstekontrakt.md#gethealthcareunit) | 2.0 | Söker ut vilken vårdenhet den angivna enheten eller funktionen är kopplad till. |
| [GetHealthCareUnitList](7-tjanstekontrakt.md#gethealthcareunitlist) | 2.0 | Söker fram och listar en angiven vårdgivares alla vårdenheter, definierade enligt PDL. |
| [GetHealthCareUnitMembers](7-tjanstekontrakt.md#gethealthcareunitmembers) | 2.1 | Söker fram alla kopplade enheter för den angivna vårdenheten. |
| [GetUnit](7-tjanstekontrakt.md#getunit) | 5.0 | Returnerar information om den angivna enheten (organisation, enhet eller funktion). |
| [GetHealthCareProvider](7-tjanstekontrakt.md#gethealthcareprovider) | 1.0 | Söker ut och returnerar information om en vårdgivare. |

### Versioner och granskningar

| | | | |
| :--- | :--- | :--- | :--- |
| 3.1 | TKB, AB | [Arkitektur & Regelverk: Teknik: Godkänd](http://rivta.se/downloads//infrastructure_directory_organization/3.1/T-granskning%20-%20%20infrastructure_directory_organization_3.1.docx)[Arkitektur & Regelverk: Säkerhet: Godkänd](http://rivta.se/downloads//infrastructure_directory_organization/3.1/VIS_granskning%20-%20%20infrastructure_directory_organization_3.1.docx)[Arkitektur & Regelverk: Informatik: Godkänd](http://rivta.se/downloads//infrastructure_directory_organization/3.1/VIS_granskning%20-%20%20infrastructure_directory_organization_3.1.docx) | [zip](http://rivta.se/downloads//infrastructure_directory_organization/3.1/ServiceContracts_infrastructure_directory_organization_3.1.zip)·[källkod](https://bitbucket.org/rivta-domains/riv.infrastructure.directory.organization/src/3.1) |
| 2.4 | AB, TKB | [Arkitektur & Regelverk: Teknik: Godkänd](http://rivta.se/downloads//infrastructure_directory_organization/2.4/T-granskning%20infrastructure_directory_organization_2.4.docx) | [zip](http://rivta.se/downloads//infrastructure_directory_organization/2.4/ServiceContracts_infrastructure_directory_organization_2.4.zip)·[källkod](https://bitbucket.org/rivta-domains/riv.infrastructure.directory.organization/src/2.4) |
| trunk | TKB, AB |  | [källkod](https://bitbucket.org/rivta-domains/riv.infrastructure.directory.organization/src/master) |

*Källa: ögonblicksbild av DOMDB från 2021-08-24, via RIV-TA-portalen.*

## Innehåll

* [1 Inledning](1-inledning.md)
* [2 Versionsinformation](2-versionsinformation.md)
* [3 Tjänstedomänens arkitektur](3-tjanstedomanens-arkitektur.md)
* [4 Tjänstedomänens krav och regler](4-tjanstedomanens-krav-och-regler.md)
* [5 Tjänstedomänens meddelandemodeller](5-tjanstedomanens-meddelandemodeller.md)
* [6 Gemensamma informationskomponenter](6-gemensamma-informationskomponenter.md)
* [7 Tjänstekontrakt](7-tjanstekontrakt.md)
* [Artefakter](artifacts.md)

