# inera.infrastructure-directory-organization#5: infrastructure: directory: organization

## Pages

* [Hem](index.md)
* [7 Tjänstekontrakt](7-tjanstekontrakt.md)
* [Tjänstedomänens meddelandemodeller](5-tjanstedomanens-meddelandemodeller.md)
* [Artifacts Summary](artifacts.md)
* [6 Gemensamma informationskomponenter](6-gemensamma-informationskomponenter.md)
* [3 Tjänstedomänens arkitektur](3-tjanstedomanens-arkitektur.md)
* [4 Tjänstedomänens krav och regler](4-tjanstedomanens-krav-och-regler.md)
* [2 Versionsinformation](2-versionsinformation.md)
* [1 Inledning](1-inledning.md)

## Resources

### Logicals

* [GetHealthCareProvider — Request](StructureDefinition-gethealthcareprovider-request.md)
* [GetHealthCareProvider](StructureDefinition-gethealthcareprovider.md)
* [GetHealthCareUnit — Request](StructureDefinition-gethealthcareunit-request.md)
* [GetHealthCareUnit](StructureDefinition-gethealthcareunit.md)
* [GetHealthCareUnitList — Request](StructureDefinition-gethealthcareunitlist-request.md)
* [GetHealthCareUnitList](StructureDefinition-gethealthcareunitlist.md)
* [GetHealthCareUnitMembers — Request](StructureDefinition-gethealthcareunitmembers-request.md)
* [GetHealthCareUnitMembers](StructureDefinition-gethealthcareunitmembers.md)
* [GetUnit — Request](StructureDefinition-getunit-request.md)
* [GetUnit](StructureDefinition-getunit.md)

### ImplementationGuides

* [infrastructure: directory: organization](index.md)
