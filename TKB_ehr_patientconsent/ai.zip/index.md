# Hem - ehr: patientconsent — Samtyckeshantering v1.0.1-snapshot

* [**Table of Contents**](toc.md)
* **Hem**

## Hem

| | |
| :--- | :--- |
| *Official URL*:https://fhir.inera.se/ig/ehr-patientconsent/ImplementationGuide/inera.ehr-patientconsent | *Version*:1.0.1-snapshot |
| Draft as of 2026-10-12 | *Computable Name*:ehrpatientconsent |
| **Copyright/Legal**: Copyright 2024 Inera AB. Licensieras under Creative Commons Attribution 4.0. | |

# ehr: patientconsent — Samtyckeshantering

**TKB-version:** 1.0.1 · **IG-version:** 1.0.1-snapshot · **Källa:** Bitbucket-commit `d3d8cd596c49` (ingen tagg) 

## Översikt

* Beskrivning: Svenskt kortnamn
  * OBSERVERA: Denna domän utvecklas inte längre, för nyutveckling, support och buggrättningar hänvisas till den nya domänen: samtyckestjänst - informationsecurity:authorization:consent För att vårdpersonalen ska få åtkomst till patientens information hos andra vårdgivare krävs patientens samtycke. Samtyckeshantering registrerar och lagrar information om patientens samtycke, och innehåller uppgifter om vilken tidsperiod samtycket ska gälla, och för vilken vårdpersonal/vårdenhet som samtycket ska gälla.Tjänstekontrakten för Samtyckeshantering gör det möjligt för vårdpersonal att genom sina vårdsystem på ett flexibelt sätt hantera sina "egna" samtycken, samtidigt som samverkan möjliggörs med nationella e-tjänster som erbjuder direktåtkomst till patientuppgifter. Inga dubbelregistreringar ska behöva göras. Tjänstekontrakten gör det också möjligt att åberopa nödsituation, så att inte ett oregistrerat samtycke kan äventyra patientens liv och hälsa.: samtyckeshantering
* Beskrivning: Svenskt namn
  * OBSERVERA: Denna domän utvecklas inte längre, för nyutveckling, support och buggrättningar hänvisas till den nya domänen: samtyckestjänst - informationsecurity:authorization:consent För att vårdpersonalen ska få åtkomst till patientens information hos andra vårdgivare krävs patientens samtycke. Samtyckeshantering registrerar och lagrar information om patientens samtycke, och innehåller uppgifter om vilken tidsperiod samtycket ska gälla, och för vilken vårdpersonal/vårdenhet som samtycket ska gälla.Tjänstekontrakten för Samtyckeshantering gör det möjligt för vårdpersonal att genom sina vårdsystem på ett flexibelt sätt hantera sina "egna" samtycken, samtidigt som samverkan möjliggörs med nationella e-tjänster som erbjuder direktåtkomst till patientuppgifter. Inga dubbelregistreringar ska behöva göras. Tjänstekontrakten gör det också möjligt att åberopa nödsituation, så att inte ett oregistrerat samtycke kan äventyra patientens liv och hälsa.: infrastruktur:säkerhetstjänster:samtyckeshantering
* Beskrivning: Typ
  * OBSERVERA: Denna domän utvecklas inte längre, för nyutveckling, support och buggrättningar hänvisas till den nya domänen: samtyckestjänst - informationsecurity:authorization:consent För att vårdpersonalen ska få åtkomst till patientens information hos andra vårdgivare krävs patientens samtycke. Samtyckeshantering registrerar och lagrar information om patientens samtycke, och innehåller uppgifter om vilken tidsperiod samtycket ska gälla, och för vilken vårdpersonal/vårdenhet som samtycket ska gälla.Tjänstekontrakten för Samtyckeshantering gör det möjligt för vårdpersonal att genom sina vårdsystem på ett flexibelt sätt hantera sina "egna" samtycken, samtidigt som samverkan möjliggörs med nationella e-tjänster som erbjuder direktåtkomst till patientuppgifter. Inga dubbelregistreringar ska behöva göras. Tjänstekontrakten gör det också möjligt att åberopa nödsituation, så att inte ett oregistrerat samtycke kan äventyra patientens liv och hälsa.: Nationell tjänstedomän
* Beskrivning: Källkod
  * OBSERVERA: Denna domän utvecklas inte längre, för nyutveckling, support och buggrättningar hänvisas till den nya domänen: samtyckestjänst - informationsecurity:authorization:consent För att vårdpersonalen ska få åtkomst till patientens information hos andra vårdgivare krävs patientens samtycke. Samtyckeshantering registrerar och lagrar information om patientens samtycke, och innehåller uppgifter om vilken tidsperiod samtycket ska gälla, och för vilken vårdpersonal/vårdenhet som samtycket ska gälla.Tjänstekontrakten för Samtyckeshantering gör det möjligt för vårdpersonal att genom sina vårdsystem på ett flexibelt sätt hantera sina "egna" samtycken, samtidigt som samverkan möjliggörs med nationella e-tjänster som erbjuder direktåtkomst till patientuppgifter. Inga dubbelregistreringar ska behöva göras. Tjänstekontrakten gör det också möjligt att åberopa nödsituation, så att inte ett oregistrerat samtycke kan äventyra patientens liv och hälsa.: [Bitbucket](https://bitbucket.org/rivta-domains/riv.ehr.patientconsent/src)
* Beskrivning: Ärenden
  * OBSERVERA: Denna domän utvecklas inte längre, för nyutveckling, support och buggrättningar hänvisas till den nya domänen: samtyckestjänst - informationsecurity:authorization:consent För att vårdpersonalen ska få åtkomst till patientens information hos andra vårdgivare krävs patientens samtycke. Samtyckeshantering registrerar och lagrar information om patientens samtycke, och innehåller uppgifter om vilken tidsperiod samtycket ska gälla, och för vilken vårdpersonal/vårdenhet som samtycket ska gälla.Tjänstekontrakten för Samtyckeshantering gör det möjligt för vårdpersonal att genom sina vårdsystem på ett flexibelt sätt hantera sina "egna" samtycken, samtidigt som samverkan möjliggörs med nationella e-tjänster som erbjuder direktåtkomst till patientuppgifter. Inga dubbelregistreringar ska behöva göras. Tjänstekontrakten gör det också möjligt att åberopa nödsituation, så att inte ett oregistrerat samtycke kan äventyra patientens liv och hälsa.: [Bitbucket issues](https://bitbucket.org/rivta-domains/riv.ehr.patientconsent/issues)
* Beskrivning: Underlag för denna IG
  * OBSERVERA: Denna domän utvecklas inte längre, för nyutveckling, support och buggrättningar hänvisas till den nya domänen: samtyckestjänst - informationsecurity:authorization:consent För att vårdpersonalen ska få åtkomst till patientens information hos andra vårdgivare krävs patientens samtycke. Samtyckeshantering registrerar och lagrar information om patientens samtycke, och innehåller uppgifter om vilken tidsperiod samtycket ska gälla, och för vilken vårdpersonal/vårdenhet som samtycket ska gälla.Tjänstekontrakten för Samtyckeshantering gör det möjligt för vårdpersonal att genom sina vårdsystem på ett flexibelt sätt hantera sina "egna" samtycken, samtidigt som samverkan möjliggörs med nationella e-tjänster som erbjuder direktåtkomst till patientuppgifter. Inga dubbelregistreringar ska behöva göras. Tjänstekontrakten gör det också möjligt att åberopa nödsituation, så att inte ett oregistrerat samtycke kan äventyra patientens liv och hälsa.: Version 1.0.1 ·[commit d3d8cd596c49](https://bitbucket.org/rivta-domains/riv.ehr.patientconsent/src/d3d8cd596c494d091b2a26f92c5eb0b52bba4d21)
* Beskrivning: RIV-TA-portalen
  * OBSERVERA: Denna domän utvecklas inte längre, för nyutveckling, support och buggrättningar hänvisas till den nya domänen: samtyckestjänst - informationsecurity:authorization:consent För att vårdpersonalen ska få åtkomst till patientens information hos andra vårdgivare krävs patientens samtycke. Samtyckeshantering registrerar och lagrar information om patientens samtycke, och innehåller uppgifter om vilken tidsperiod samtycket ska gälla, och för vilken vårdpersonal/vårdenhet som samtycket ska gälla.Tjänstekontrakten för Samtyckeshantering gör det möjligt för vårdpersonal att genom sina vårdsystem på ett flexibelt sätt hantera sina "egna" samtycken, samtidigt som samverkan möjliggörs med nationella e-tjänster som erbjuder direktåtkomst till patientuppgifter. Inga dubbelregistreringar ska behöva göras. Tjänstekontrakten gör det också möjligt att åberopa nödsituation, så att inte ett oregistrerat samtycke kan äventyra patientens liv och hälsa.: [Alla tjänstedomäner](https://oskthu2.github.io/tkb-converter/rivta-portal/tjanstedomaner.html)·[Alla tjänstekontrakt](https://oskthu2.github.io/tkb-converter/rivta-portal/tjanstekontrakt.html)

FHIR Implementation Guide för tjänstedomänen **ehr: patientconsent** version 1.0.1. Genererad från Ineras Tjänstekontraktsbeskrivning (TKB).

Domänen avser samtyckeshantering för direktåtkomst till patientuppgifter mellan vårdgivare inom sammanhållen journalföring enligt Patientdatalagen (PDL).

Domänen innehåller följande tjänstekontrakt:

| | | | |
| :--- | :--- | :--- | :--- |
| [GetConsentsForPatient](7-tjanstekontrakt.md#getconsentsforpatient) | 1.0 | querying | Hämta giltiga samtycken för en specifik patient |
| [GetConsentsForCareProvider](7-tjanstekontrakt.md#getconsentsforcareprovider) | 1.0 | querying | Hämta alla giltiga samtycken för en vårdgivare |
| [GetExtendedConsentsForPatient](7-tjanstekontrakt.md#getextendedconsentsforpatient) | 1.0 | administration | Hämta samtycken med utökad information för en patient |
| [CheckConsent](7-tjanstekontrakt.md#checkconsent) | 1.0 | accesscontrol | Kontrollera om giltigt samtycke finns för en aktör |
| [RegisterExtendedConsent](7-tjanstekontrakt.md#registerextendedconsent) | 1.0 | administration | Registrera ett samtyckesintyg |
| [CancelExtendedConsent](7-tjanstekontrakt.md#cancelextendedconsent) | 1.0 | administration | Återkalla ett samtyckesintyg |
| [DeleteExtendedConsent](7-tjanstekontrakt.md#deleteextendedconsent) | 1.0 | administration | Makulera ett samtyckesintyg |

### Versioner och granskningar

| | | | |
| :--- | :--- | :--- | :--- |
| 1.0.1 | TKB, AB | Äldre granskningsprocess: Teknik: Godkänd | [zip](http://rivta.se/downloads/ehr_patientconsent/1.0.1/ServiceContracts_ehr_patientconsent_1_0_1.zip)·[källkod](https://bitbucket.org/rivta-domains/riv.ehr.patientconsent/src/ehr_patientconsent_1.0.1_RC1) |
| trunk | AB, TKB |  | [källkod](https://bitbucket.org/rivta-domains/riv.ehr.patientconsent/src/master) |

*Källa: ögonblicksbild av DOMDB från 2021-08-24, via RIV-TA-portalen.*

## Innehåll

* [1 Inledning](1-inledning.md)
* [2 Generella regler](2-generella-regler.md)
* [7 Tjänstekontrakt](7-tjanstekontrakt.md)
* [10 Datatyper](10-datatyper.md)
* [Artefakter](artifacts.md)

