# Hem - ehr: patientconsent — Samtyckeshantering v1.0.1

* [**Table of Contents**](toc.md)
* **Hem**

## Hem

| | |
| :--- | :--- |
| *Official URL*:https://fhir.inera.se/ig/ehr-patientconsent/ImplementationGuide/inera.ehr-patientconsent | *Version*:1.0.1 |
| Draft as of 2026-09-14 | *Computable Name*:ehrpatientconsent |
| **Copyright/Legal**: Copyright 2024 Inera AB. Licensieras under Creative Commons Attribution 4.0. | |

# ehr: patientconsent — Samtyckeshantering

## Översikt

FHIR Implementation Guide för tjänstedomänen **ehr: patientconsent** version 1.0.1. Genererad från Ineras Tjänstekontraktsbeskrivning (TKB).

Domänen avser samtyckeshantering för direktåtkomst till patientuppgifter mellan vårdgivare inom sammanhållen journalföring enligt Patientdatalagen (PDL).

Domänen innehåller följande tjänstekontrakt:

| | | | |
| :--- | :--- | :--- | :--- |
| [GetConsentsForPatient](7-tjanstekontrakt.md#getconsentsforpatient) | 1.0 | querying | Hämta giltiga samtycken för en specifik patient |
| [GetConsentsForCareProvider](7-tjanstekontrakt.md#getconsentsforcareprovider) | 1.0 | querying | Hämta alla giltiga samtycken för en vårdgivare |
| [GetExtendedConsentsForPatient](7-tjanstekontrakt.md#getextendedconsentsforpatient) | 1.0 | administration | Hämta samtycken med utökad information för en patient |
| [CheckConsent](7-tjanstekontrakt.md#checkconsent) | 1.0 | accesscontrol | Kontrollera om giltigt samtycke finns för en aktör |
| [RegisterExtendedConsent](7-tjanstekontrakt.md#registerextendedconsent) | 1.0 | administration | Registrera ett samtyckesintyg |
| [CancelExtendedConsent](7-tjanstekontrakt.md#cancelextendedconsent) | 1.0 | administration | Återkalla ett samtyckesintyg |
| [DeleteExtendedConsent](7-tjanstekontrakt.md#deleteextendedconsent) | 1.0 | administration | Makulera ett samtyckesintyg |

## Innehåll

* [1 Inledning](1-inledning.md)
* [2 Generella regler](2-generella-regler.md)
* [7 Tjänstekontrakt](7-tjanstekontrakt.md)
* [10 Datatyper](10-datatyper.md)
* [Artefakter](artifacts.md)

