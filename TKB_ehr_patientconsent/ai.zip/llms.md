# inera.ehr-patientconsent#1.0.1: ehr: patientconsent — Samtyckeshantering

## Pages

* [Hem](index.md)
* [2 Generella regler](2-generella-regler.md)
* [7 Tjänstekontrakt](7-tjanstekontrakt.md)
* [Artifacts Summary](artifacts.md)
* [10 Datatyper](10-datatyper.md)
* [1 Inledning](1-inledning.md)

## Resources

### CodeSystems

* [AssertionType](CodeSystem-assertiontype-cs.md)
* [ResultCode](CodeSystem-resultcode-cs.md)
* [Scope](CodeSystem-scope-cs.md)

### ValueSets

* [AssertionType — ValueSet](ValueSet-assertiontype-vs.md)
* [ResultCode — ValueSet](ValueSet-resultcode-vs.md)
* [Scope — ValueSet](ValueSet-scope-vs.md)

### Logicals

* [CancelExtendedConsent — Request](StructureDefinition-cancelextendedconsent-request.md)
* [CancelExtendedConsent](StructureDefinition-cancelextendedconsent.md)
* [CheckConsent — Request](StructureDefinition-checkconsent-request.md)
* [CheckConsent](StructureDefinition-checkconsent.md)
* [DeleteExtendedConsent — Request](StructureDefinition-deleteextendedconsent-request.md)
* [DeleteExtendedConsent](StructureDefinition-deleteextendedconsent.md)
* [GetConsentsForCareProvider — Request](StructureDefinition-getconsentsforcareprovider-request.md)
* [GetConsentsForCareProvider](StructureDefinition-getconsentsforcareprovider.md)
* [GetConsentsForPatient — Request](StructureDefinition-getconsentsforpatient-request.md)
* [GetConsentsForPatient](StructureDefinition-getconsentsforpatient.md)
* [GetExtendedConsentsForPatient — Request](StructureDefinition-getextendedconsentsforpatient-request.md)
* [GetExtendedConsentsForPatient](StructureDefinition-getextendedconsentsforpatient.md)
* [RegisterExtendedConsent — Request](StructureDefinition-registerextendedconsent-request.md)
* [RegisterExtendedConsent](StructureDefinition-registerextendedconsent.md)

### ImplementationGuides

* [ehr: patientconsent — Samtyckeshantering](index.md)
