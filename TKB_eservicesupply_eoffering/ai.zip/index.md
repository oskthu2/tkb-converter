# Hem - eservicesupply: eoffering v1.0.0-snapshot

* [**Table of Contents**](toc.md)
* **Hem**

## Hem

| | |
| :--- | :--- |
| *Official URL*:https://fhir.inera.se/ig/eservicesupply-eoffering/ImplementationGuide/inera.eservicesupply-eoffering | *Version*:1.0.0-snapshot |
| Draft as of 2026-11-09 | *Computable Name*:eservicesupplyeoffering |
| **Copyright/Legal**: Copyright 2024 Inera AB. Licensieras under Creative Commons Attribution 4.0. | |

# eservicesupply: eoffering

**TKB-version:** 1.0.0 · **IG-version:** 1.0.0-snapshot · **Källa:** Bitbucket-commit `4414f8292a4e` (ingen tagg) 

## Översikt

* Svenskt kortnamn: Svenskt namn
  * erbjuden e-tjänst: individens processtöd:tillgängliggör kontaktväg:erbjuden tjänst
* Svenskt kortnamn: Typ
  * erbjuden e-tjänst: Nationell tjänstedomän
* Svenskt kortnamn: Källkod
  * erbjuden e-tjänst: [Bitbucket](https://bitbucket.org/rivta-domains/riv.eservicesupply.eoffering/src)
* Svenskt kortnamn: Ärenden
  * erbjuden e-tjänst: [Bitbucket issues](https://bitbucket.org/rivta-domains/riv.eservicesupply.eoffering/issues)
* Svenskt kortnamn: Underlag för denna IG
  * erbjuden e-tjänst: Version 1.0.0 ·[commit 4414f8292a4e](https://bitbucket.org/rivta-domains/riv.eservicesupply.eoffering/src/4414f8292a4ed90dd29e707d022c90dd15920915)
* Svenskt kortnamn: RIV-TA-portalen
  * erbjuden e-tjänst: [Alla tjänstedomäner](https://oskthu2.github.io/tkb-converter/rivta-portal/tjanstedomaner.html)·[Alla tjänstekontrakt](https://oskthu2.github.io/tkb-converter/rivta-portal/tjanstekontrakt.html)

FHIR Implementation Guide för tjänstedomänen **eservicesupply: eoffering** version 1.0.0. Genererad från Ineras Tjänstekontraktsbeskrivning (TKB) v0.3 (2011-04-18).

Domänen **eservicesupply:eoffering** hanterar tjänstekontrakt för att presentera och administrera information om e-tjänsteutbudet. Tjänstekontraktets namnrymd är `urn:riv:eservicesupply:eoffering`.

Domänen innehåller följande tjänstekontrakt:

| | | |
| :--- | :--- | :--- |
| [GetAvailableEServices](7-tjanstekontrakt.md#getavailableeservices) | 1.0 | Hämtar information om vilka e-tjänster en vårdenhet erbjuder |

### Versioner och granskningar

| | | | |
| :--- | :--- | :--- | :--- |
| 1.0 |  | Äldre granskningsprocess: Teknik: Godkänd | [zip](https://bitbucket.org/rivta-domains/riv.eservicesupply.eoffering/get/EOFFERING_1_0_0.zip)·[källkod](https://bitbucket.org/rivta-domains/riv.eservicesupply.eoffering/src/EOFFERING_1_0_0) |
| trunk |  |  | [källkod](https://bitbucket.org/rivta-domains/riv.eservicesupply.eoffering/src/master) |

*Zip-arkiven hämtas från taggarna på Bitbucket. Granskningsprotokollen publicerades på rivta.se och länkas inte härifrån.*

*Källa: ögonblicksbild av DOMDB från 2021-08-24, via RIV-TA-portalen.*

## Innehåll

* [1 Inledning](1-inledning.md)
* [2 Versionsinformation](2-versionsinformation.md)
* [3 Tjänstedomänens arkitektur](3-tjanstedomanens-arkitektur.md)
* [4 Tjänstedomänens krav och regler](4-tjanstedomanens-krav-och-regler.md)
* [5 Tjänstedomänens meddelandemodeller](5-tjanstedomanens-meddelandemodeller.md)
* [6 Gemensamma informationskomponenter](6-gemensamma-informationskomponenter.md)
* [7 Tjänstekontrakt](7-tjanstekontrakt.md)
* [Artefakter](artifacts.md)

