# Hem - eservicesupply: eoffering v1.0.0

* [**Table of Contents**](toc.md)
* **Hem**

## Hem

| | |
| :--- | :--- |
| *Official URL*:https://fhir.inera.se/ig/eservicesupply-eoffering/ImplementationGuide/inera.eservicesupply-eoffering | *Version*:1.0.0 |
| Draft as of 2026-09-09 | *Computable Name*:eservicesupplyeoffering |
| **Copyright/Legal**: Copyright 2024 Inera AB. Licensieras under Creative Commons Attribution 4.0. | |

# eservicesupply: eoffering

## Översikt

FHIR Implementation Guide för tjänstedomänen **eservicesupply: eoffering** version 1.0. Genererad från Ineras Tjänstekontraktsbeskrivning (TKB) v0.3 (2011-04-18).

Domänen **eservicesupply:eoffering** hanterar tjänstekontrakt för att presentera och administrera information om e-tjänsteutbudet. Tjänstekontraktets namnrymd är `urn:riv:eservicesupply:eoffering`.

Domänen innehåller följande tjänstekontrakt:

| | | |
| :--- | :--- | :--- |
| [GetAvailableEServices](7-tjanstekontrakt.md#getavailableeservices) | 1.0 | Hämtar information om vilka e-tjänster en vårdenhet erbjuder |

## Innehåll

* [1 Inledning](1-inledning.md)
* [2 Versionsinformation](2-versionsinformation.md)
* [3 Tjänstedomänens arkitektur](3-tjanstedomanens-arkitektur.md)
* [4 Tjänstedomänens krav och regler](4-tjanstedomanens-krav-och-regler.md)
* [5 Tjänstedomänens meddelandemodeller](5-tjanstedomanens-meddelandemodeller.md)
* [6 Gemensamma informationskomponenter](6-gemensamma-informationskomponenter.md)
* [7 Tjänstekontrakt](7-tjanstekontrakt.md)
* [Artefakter](artifacts.md)

