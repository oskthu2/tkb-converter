# inera.eservicesupply-eoffering#1.0.0: eservicesupply: eoffering

## Pages

* [Hem](index.md)
* [7 Tjänstekontrakt](7-tjanstekontrakt.md)
* [5 Tjänstedomänens meddelandemodeller](5-tjanstedomanens-meddelandemodeller.md)
* [Artifacts Summary](artifacts.md)
* [6 Gemensamma informationskomponenter](6-gemensamma-informationskomponenter.md)
* [3 Tjänstedomänens arkitektur](3-tjanstedomanens-arkitektur.md)
* [4 Tjänstedomänens krav och regler](4-tjanstedomanens-krav-och-regler.md)
* [2 Versionsinformation](2-versionsinformation.md)
* [1 Inledning](1-inledning.md)

## Resources

### CodeSystems

* [Gender (eOffering)](CodeSystem-gender-eoffering-cs.md)
* [SecurityLevel](CodeSystem-securitylevel-cs.md)

### ValueSets

* [Gender (eOffering) — ValueSet](ValueSet-gender-eoffering-vs.md)
* [SecurityLevel — ValueSet](ValueSet-securitylevel-vs.md)

### Logicals

* [GetAvailableEServices](StructureDefinition-getavailableeservices.md)

### ImplementationGuides

* [eservicesupply: eoffering](index.md)
