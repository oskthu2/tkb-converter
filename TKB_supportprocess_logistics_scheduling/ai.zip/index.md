# Hem - supportprocess: logistics: scheduling v2.0.0

* [**Table of Contents**](toc.md)
* **Hem**

## Hem

| | |
| :--- | :--- |
| *Official URL*:https://fhir.inera.se/ig/supportprocess-logistics-scheduling/ImplementationGuide/inera.supportprocess-logistics-scheduling | *Version*:2.0.0 |
| Draft as of 2026-09-28 | *Computable Name*:supportprocesslogisticsscheduling |
| **Copyright/Legal**: Copyright 2024 Inera AB. Licensieras under Creative Commons Attribution 4.0. | |

# supportprocess: logistics: scheduling

## Översikt

FHIR Implementation Guide för tjänstedomänen **supportprocess: logistics: scheduling** (Tidbokning) version 2.0. Genererad från Ineras Tjänstekontraktsbeskrivning (TKB), version 2.0 RC2 (2023-11-01), och domänens WSDL- och XSD-filer (tagg 2.0_RC1).

Tjänstedomänen stöder invånarens tidbokning hos en vårdenhet: söka vårdcentraler, tidstyper och lediga tider, samt boka, omboka, avboka och bekräfta besök.

Domänen innehåller följande tjänstekontrakt:

| | | |
| :--- | :--- | :--- |
| [CancelAppointment](7-tjanstekontrakt.md#cancelappointment) | 2.0 | Tjänstekontraktet ger aktören möjlighet att avboka en befintlig bokning, baserat på kombinationen av unikt bokningsid samt personnummer för patienten som bokningen gäller. |
| [ConfirmAppointment](7-tjanstekontrakt.md#confirmappointment) | 1.0 | Tjänstekontraktet ger aktören möjlighet att bekräfta en tidbokning som verksamheten bokat åt patienten, baserat på kombinationen av ett unikt boknings-id samt personnummer för patienten som bokningen gäller. |
| [GetAppointment](7-tjanstekontrakt.md#getappointment) | 2.0 | Tjänstekontraktet hämtar detalj-information om en befintlig tidbokning vid en vårdenhet, baserat på kombinationen av ett unikt boknings-id samt personnummer för patienten som bokningen gäller. |
| [GetAppointments](7-tjanstekontrakt.md#getappointments) | 2.0 | Tjänstekontraktet hämtar lista med invånarens samtliga tidbokningar, baserat på personnummer för patienten som bokningen/bokningarna gäller. Konsument kan välja att begära filtrering på ett tidsspann, en specifik tidstyp eller vårdtjänst. |
| [GetTimeTypes](7-tjanstekontrakt.md#gettimetypes) | 2.0 | Tjänstekontraktet hämtar alla tidstyper som kan användas vid nybokning hos angiven vårdenhet. Tidstyperna kan filtreras för vald vårdtjänst, vårdpersonal och per invånare. Samtliga filter är frivilliga. En vårdenhet förväntas returnera alla tillgängliga tidstyper i fallet då konsument frågar utan att förmedla ett personnummer, ett scenario som skulle kunna vara tillämpbart i fallet då konsument implementerar administrativa funktioner kring tidstyper. |
| [GetAvailableDates](7-tjanstekontrakt.md#getavailabledates) | 2.0 | Tjänstekontraktet hämtar datum med lediga tider för angivet datumintervall. Vid anrop för att hämta datum med lediga tider gällande en ombokning skickar konsument den ursprungliga tidbokningens unika bokningsId. På så sätt kan en producent ta hänsyn till vilken vårdpersonal eller vilken/vilka resurs(er) som var allokerade för ursprungsbokningen och därmed endast returnera sådana datum som matchar de kriterier som vårdenhet bestämt. Observera att passerade tider inte ska returneras av producenten. |
| [GetAvailableTimeslots](7-tjanstekontrakt.md#getavailabletimeslots) | 2.0 | Tjänstekontraktet hämtar lediga tider för angivet datumintervall. Vid anrop för ombokning skickar konsument den ursprungliga tidbokningens unika bokningsId. På så sätt kan en producent ta hänsyn till vilken vårdpersonal eller vilken/vilka resurs(er) som var allokerade för ursprungsbokningen och därmed endast returnera sådana datum som matchar de kriter som vårdenhet bestämt. Observera att passerade tider inte ska returneras av tjänstekontraktet. |
| [GetHealthcareFacilities](7-tjanstekontrakt.md#gethealthcarefacilities) | 2.0 | Tjänstekontrakt för att hämta alla vårdenheter som erbjuds för nybokning eller ombokning för aktuell invånare (vårdenhet i begäran representerar då den kallande organisationen). Detta tjänstekontrakt följer inte riktigt samma mönster som övriga tjänstekontrakt, genom att vårdenheten som får begäran i någon mening agerar ställföreträdare för en sortiments- och utbudskatalog och därigenom svarar för andra vårdenheters räkning. Det är dock underförstått att de vårdenheter som listas i svaret utför samma typ av behandling som den vårdenhet som fick begäran och följer samma kodverk för AppointmentType (tidstyp), HealthcareService(s) (vårdtjänster) etc. Det är den svarande vårdenhetens ansvar att de vårdenheter som listas i svaret är bokningsbara, rent avtalsmässigt och att de har stöd för online-bokning enligt dessa tjänstekontrakt. |
| [GetHealthcareFacility](7-tjanstekontrakt.md#gethealthcarefacility) | 2.0 | Tjänstekontrakt för att hämta detaljerad information om en vårdenhet. Den detaljerade informationen kan innefatta en alternativ adress, om vårdenheten väljer att uttrycka en sådan. Den detaljerade informationen kan också innefatta information eller villkorstext som vårdenheten vill förmedla till invånaren/patienten i samband med bokningen. |
| [GetPractitioners](7-tjanstekontrakt.md#getpractitioners) | 2.0 | Tjänstekontrakt för att hämta en lista över medarbetare i vårdprofessionen som är bokningsbara online hos angiven vårdenhet för aktuell invånare. Tjänsteproducenten ansvarar för att tillämpa verksamhetens regelverk för att filtrera svaret (t.ex. en vårdenhet som bara tillåter invånare att boka tid enligt listad doktor). |
| [MakeAppointment](7-tjanstekontrakt.md#makeappointment) | 2.0 | Tjänstekontrakt för nybokning vid en vårdenhet. Tjänsten returnerar det unika boknings-id för bokningen vid lyckad genomförd nybokning. |
| [UpdateAppointment](7-tjanstekontrakt.md#updateappointment) | 2.0 | Tjänstekontrakt för att uppdatera en befintlig bokning med nytt datum och tid, alltså en ombokning. |

## Innehåll

* [1 Inledning](1-inledning.md)
* [2 Versionsinformation](2-versionsinformation.md)
* [3 Tjänstedomänens arkitektur](3-tjanstedomanens-arkitektur.md)
* [4 Tjänstedomänens krav och regler](4-tjanstedomanens-krav-och-regler.md)
* [5 Tjänstedomänens meddelandemodeller](5-tjanstedomanens-meddelandemodeller.md)
* [6 Gemensamma informationskomponenter](6-gemensamma-informationskomponenter.md)
* [7 Tjänstekontrakt](7-tjanstekontrakt.md)
* [Artefakter](artifacts.md)

