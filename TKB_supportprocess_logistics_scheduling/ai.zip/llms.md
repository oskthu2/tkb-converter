# inera.supportprocess-logistics-scheduling#2.0.0: supportprocess: logistics: scheduling

## Pages

* [Hem](index.md)
* [7 Tjänstekontrakt](7-tjanstekontrakt.md)
* [5 Tjänstedomänens meddelandemodeller](5-tjanstedomanens-meddelandemodeller.md)
* [Artifacts Summary](artifacts.md)
* [6 Gemensamma informationskomponenter](6-gemensamma-informationskomponenter.md)
* [3 Tjänstedomänens arkitektur](3-tjanstedomanens-arkitektur.md)
* [4 Tjänstedomänens krav och regler](4-tjanstedomanens-krav-och-regler.md)
* [2 Versionsinformation](2-versionsinformation.md)
* [1 Inledning](1-inledning.md)

## Resources

### CodeSystems

* [Bokningens tillstånd (AppointmentStatus)](CodeSystem-scheduling-appointmentstatus-cs.md)
* [Tidbokningsflöde (Process)](CodeSystem-scheduling-process-cs.md)
* [Krav på anledning (ReasonRequired)](CodeSystem-scheduling-reasonrequired-cs.md)
* [Resultatkod (ResultCode)](CodeSystem-scheduling-resultcode-cs.md)

### ValueSets

* [Bokningens tillstånd (AppointmentStatus)](ValueSet-scheduling-appointmentstatus-vs.md)
* [Tidbokningsflöde (Process)](ValueSet-scheduling-process-vs.md)
* [Krav på anledning (ReasonRequired)](ValueSet-scheduling-reasonrequired-vs.md)
* [Resultatkod (ResultCode)](ValueSet-scheduling-resultcode-vs.md)

### Logicals

* [CancelAppointment — Request](StructureDefinition-cancelappointment-request.md)
* [CancelAppointment — Response](StructureDefinition-cancelappointment.md)
* [ConfirmAppointment — Request](StructureDefinition-confirmappointment-request.md)
* [ConfirmAppointment — Response](StructureDefinition-confirmappointment.md)
* [GetAppointment — Request](StructureDefinition-getappointment-request.md)
* [GetAppointment — Response](StructureDefinition-getappointment.md)
* [GetAppointments — Request](StructureDefinition-getappointments-request.md)
* [GetAppointments — Response](StructureDefinition-getappointments.md)
* [GetAvailableDates — Request](StructureDefinition-getavailabledates-request.md)
* [GetAvailableDates — Response](StructureDefinition-getavailabledates.md)
* [GetAvailableTimeslots — Request](StructureDefinition-getavailabletimeslots-request.md)
* [GetAvailableTimeslots — Response](StructureDefinition-getavailabletimeslots.md)
* [GetHealthcareFacilities — Request](StructureDefinition-gethealthcarefacilities-request.md)
* [GetHealthcareFacilities — Response](StructureDefinition-gethealthcarefacilities.md)
* [GetHealthcareFacility — Request](StructureDefinition-gethealthcarefacility-request.md)
* [GetHealthcareFacility — Response](StructureDefinition-gethealthcarefacility.md)
* [GetPractitioners — Request](StructureDefinition-getpractitioners-request.md)
* [GetPractitioners — Response](StructureDefinition-getpractitioners.md)
* [GetTimeTypes — Request](StructureDefinition-gettimetypes-request.md)
* [GetTimeTypes — Response](StructureDefinition-gettimetypes.md)
* [MakeAppointment — Request](StructureDefinition-makeappointment-request.md)
* [MakeAppointment — Response](StructureDefinition-makeappointment.md)
* [UpdateAppointment — Request](StructureDefinition-updateappointment-request.md)
* [UpdateAppointment — Response](StructureDefinition-updateappointment.md)

### ImplementationGuides

* [supportprocess: logistics: scheduling](index.md)
