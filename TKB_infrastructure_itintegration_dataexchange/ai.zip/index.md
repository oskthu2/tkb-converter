# Hem - infrastructure: itintegration: dataexchange v1.0.0-snapshot

* [**Table of Contents**](toc.md)
* **Hem**

## Hem

| | |
| :--- | :--- |
| *Official URL*:https://fhir.inera.se/ig/infrastructure-itintegration-dataexchange/ImplementationGuide/inera.infrastructure-itintegration-dataexchange | *Version*:1.0.0-snapshot |
| Draft as of 2026-10-08 | *Computable Name*:infrastructureitintegrationdataexchange |
| **Copyright/Legal**: Copyright 2024 Inera AB. Licensieras under Creative Commons Attribution 4.0. | |

# infrastructure: itintegration: dataexchange

**TKB-version:** 1.0 · **IG-version:** 1.0.0-snapshot · **Källa:** Bitbucket-commit `7fdd1d090b32` (ingen tagg) 

## Översikt

FHIR Implementation Guide för tjänstedomänen **infrastructure: itintegration: dataexchange** (Datautbyte) version 1.0. Genererad från Ineras Tjänstekontraktsbeskrivning (TKB) och domänens WSDL- och XSD-filer på grenen develop (commit 7fdd1d090b32, 2025-09-11).

Domänen används för att hämta binära filer, t.ex. bilagor, som ett annat tjänstekontrakt eller meddelande refererar till. Den har inte släppts: det finns inga taggar, master innehåller bara en README, och TKB:ns revisionshistorik anger en preliminär version.

Domänen innehåller följande tjänstekontrakt:

| | | |
| :--- | :--- | :--- |
| [GetBinaryData](7-tjanstekontrakt.md#getbinarydata) | 1.0 | Tjänstekontraktet hanterar information som kodas och överförs i ett format bestående enbart av bitar (0 och 1), vilket kan inkludera filer, bilder, ljud eller andra typer av data som inte är textbaserade. |

## Innehåll

* [1 Inledning](1-inledning.md)
* [2 Versionsinformation](2-versionsinformation.md)
* [3 Tjänstedomänens arkitektur](3-tjanstedomanens-arkitektur.md)
* [4 Tjänstedomänens krav och regler](4-tjanstedomanens-krav-och-regler.md)
* [5 Tjänstedomänens meddelandemodeller](5-tjanstedomanens-meddelandemodeller.md)
* [6 Gemensamma informationskomponenter](6-gemensamma-informationskomponenter.md)
* [7 Tjänstekontrakt](7-tjanstekontrakt.md)
* [Artefakter](artifacts.md)

