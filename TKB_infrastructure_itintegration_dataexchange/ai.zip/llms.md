# inera.infrastructure-itintegration-dataexchange#1.0.0-snapshot: infrastructure: itintegration: dataexchange

## Pages

* [Hem](index.md)
* [7 Tjänstekontrakt](7-tjanstekontrakt.md)
* [5 Tjänstedomänens meddelandemodeller](5-tjanstedomanens-meddelandemodeller.md)
* [Artifacts Summary](artifacts.md)
* [6 Gemensamma informationskomponenter](6-gemensamma-informationskomponenter.md)
* [3 Tjänstedomänens arkitektur](3-tjanstedomanens-arkitektur.md)
* [4 Tjänstedomänens krav och regler](4-tjanstedomanens-krav-och-regler.md)
* [2 Versionsinformation](2-versionsinformation.md)
* [1 Inledning](1-inledning.md)

## Resources

### CodeSystems

* [ResultCode](CodeSystem-dataexchange-resultcode-cs.md)

### ValueSets

* [ResultCode](ValueSet-dataexchange-resultcode-vs.md)

### Logicals

* [GetBinaryData — Request](StructureDefinition-getbinarydata-request.md)
* [GetBinaryData — Response](StructureDefinition-getbinarydata.md)

### ImplementationGuides

* [infrastructure: itintegration: dataexchange](index.md)
