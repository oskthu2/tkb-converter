# Hem - clinicalprocess: activityprescription: prescribe v2

* [**Table of Contents**](toc.md)
* **Hem**

## Hem

| | |
| :--- | :--- |
| *Official URL*:https://fhir.inera.se/ig/clinicalprocess-activityprescription-prescribe/ImplementationGuide/inera.clinicalprocess-activityprescription-prescribe | *Version*:2 |
| Draft as of 2026-09-09 | *Computable Name*:clinicalprocessactivityprescriptionprescribe |
| **Copyright/Legal**: Copyright 2024 Inera AB. Licensieras under Creative Commons Attribution 4.0. | |

# clinicalprocess: activityprescription: prescribe

## Översikt

Detta är en FHIR Implementation Guide genererad från TKB-dokumentation för tjänstedomänen **clinicalprocess: activityprescription: prescribe** version 2.0.

Tjänstedomänen syftar till att hantera patientens samlade läkemedelslista (SLL), inklusive ordinationer, expedieringsunderlag, uthämtade läkemedel och egenmedicinering.

## Tjänstekontrakt

| | | |
| :--- | :--- | :--- |
| 7.1 | GetMedicationPrescriptions | 2.0 |
| 7.2 | RegisterMedicationPrescription | 2.0 |
| 7.3 | DiscontinueMedication | 2.0 |
| 7.4 | RegisterMedicationStatement | 1.0 |
| 7.5 | GetMedicationDispenseAuthorizations | 2.0 |
| 7.6 | RegisterMedicationDispenseAuthorization | 1.0 |
| 7.7 | RevokeMedicationDispenseAuthorization | 2.0 |
| 7.8 | AttachMedicationDispenseAuthorization | 2.0 |
| 7.9 | GetDispensedDrugs | 2.0 |
| 7.10 | GetDispensedDrugsConsent | 2.0 |
| 7.11 | RegisterDispensedDrugsConsent | 2.0 |
| 7.12 | RevokeDispensedDrugsConsent | 2.0 |
| 7.13 | SetMedicationListReviewed | 1.0 |
| 7.14 | SetMedicationListReviewNeeded | 1.0 |
| 7.15 | CheckMedicationListVersion | 1.0 |

## Innehåll

* [1 Inledning](1-inledning.md)
* [2 Versionsinformation](2-versionsinformation.md)
* [3 Tjänstedomänens arkitektur](3-tjanstedomanens-arkitektur.md)
* [4 Tjänstedomänens krav och regler](4-tjanstedomanens-krav-och-regler.md)
* [5 Tjänstedomänens meddelandemodeller](5-tjanstedomanens-meddelandemodeller.md)
* [6 Gemensamma informationskomponenter](6-gemensamma-informationskomponenter.md)
* [7 Tjänstekontrakt](7-tjanstekontrakt.md)

