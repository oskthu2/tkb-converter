# Hem - clinicalprocess: activityprescription: prescribe v2.0.0-rc1

* [**Table of Contents**](toc.md)
* **Hem**

## Hem

| | |
| :--- | :--- |
| *Official URL*:https://fhir.inera.se/ig/clinicalprocess-activityprescription-prescribe/ImplementationGuide/inera.clinicalprocess-activityprescription-prescribe | *Version*:2.0.0-rc1 |
| Draft as of 2026-11-09 | *Computable Name*:clinicalprocessactivityprescriptionprescribe |
| **Copyright/Legal**: Copyright 2024 Inera AB. Licensieras under Creative Commons Attribution 4.0. | |

# clinicalprocess: activityprescription: prescribe

**TKB-version:** 2.0_RC1 · **IG-version:** 2.0.0-rc1 · **Källa:** Bitbucket-tagg `clinicalprocess_activityprescription_prescribe_2.0_RC1` 

## Översikt

* Beskrivning: Svenskt kortnamn
  * Denna domänen är inte aktuellt längre och det är rest från Nodprojekte: ordination
* Beskrivning: Svenskt namn
  * Denna domänen är inte aktuellt längre och det är rest från Nodprojekte: vård- och omsorg kärnprocess:hantera aktiviteter:ordination
* Beskrivning: Typ
  * Denna domänen är inte aktuellt längre och det är rest från Nodprojekte: Nationell tjänstedomän
* Beskrivning: Anmärkning
  * Denna domänen är inte aktuellt längre och det är rest från Nodprojekte: dold på rivta.se
* Beskrivning: Källkod
  * Denna domänen är inte aktuellt längre och det är rest från Nodprojekte: [Bitbucket](https://bitbucket.org/rivta-domains/riv.clinicalprocess.activityprescription.prescribe/src)
* Beskrivning: Ärenden
  * Denna domänen är inte aktuellt längre och det är rest från Nodprojekte: [Bitbucket issues](https://bitbucket.org/rivta-domains/riv.clinicalprocess.activityprescription.prescribe/issues)
* Beskrivning: Underlag för denna IG
  * Denna domänen är inte aktuellt längre och det är rest från Nodprojekte: Version 2.0_RC1 ·[tagg clinicalprocess_activityprescription_prescribe_2.0_RC1](https://bitbucket.org/rivta-domains/riv.clinicalprocess.activityprescription.prescribe/src/clinicalprocess_activityprescription_prescribe_2.0_RC1)·[zip](https://bitbucket.org/rivta-domains/riv.clinicalprocess.activityprescription.prescribe/get/clinicalprocess_activityprescription_prescribe_2.0_RC1.zip)
* Beskrivning: RIV-TA-portalen
  * Denna domänen är inte aktuellt längre och det är rest från Nodprojekte: [Alla tjänstedomäner](https://oskthu2.github.io/tkb-converter/rivta-portal/tjanstedomaner.html)·[Alla tjänstekontrakt](https://oskthu2.github.io/tkb-converter/rivta-portal/tjanstekontrakt.html)

Detta är en FHIR Implementation Guide genererad från TKB-dokumentation för tjänstedomänen **clinicalprocess: activityprescription: prescribe** version 2.0_RC1.

Tjänstedomänen syftar till att hantera patientens samlade läkemedelslista (SLL), inklusive ordinationer, expedieringsunderlag, uthämtade läkemedel och egenmedicinering.

## Tjänstekontrakt

| | | |
| :--- | :--- | :--- |
| 7.1 | [GetMedicationPrescriptions](7-tjanstekontrakt.md#getmedicationprescriptions) | 2.0 |
| 7.2 | [RegisterMedicationPrescription](7-tjanstekontrakt.md#registermedicationprescription) | 2.0 |
| 7.3 | [DiscontinueMedication](7-tjanstekontrakt.md#discontinuemedication) | 2.0 |
| 7.4 | [RegisterMedicationStatement](7-tjanstekontrakt.md#registermedicationstatement) | 1.0 |
| 7.5 | [GetMedicationDispenseAuthorizations](7-tjanstekontrakt.md#getmedicationdispenseauthorizations) | 2.0 |
| 7.6 | [RegisterMedicationDispenseAuthorization](7-tjanstekontrakt.md#registermedicationdispenseauthorization) | 1.0 |
| 7.7 | [RevokeMedicationDispenseAuthorization](7-tjanstekontrakt.md#revokemedicationdispenseauthorization) | 2.0 |
| 7.8 | [AttachMedicationDispenseAuthorization](7-tjanstekontrakt.md#attachmedicationdispenseauthorization) | 2.0 |
| 7.9 | [GetDispensedDrugs](7-tjanstekontrakt.md#getdispenseddrugs) | 2.0 |
| 7.10 | [GetDispensedDrugsConsent](7-tjanstekontrakt.md#getdispenseddrugsconsent) | 2.0 |
| 7.11 | [RegisterDispensedDrugsConsent](7-tjanstekontrakt.md#registerdispenseddrugsconsent) | 2.0 |
| 7.12 | [RevokeDispensedDrugsConsent](7-tjanstekontrakt.md#revokedispenseddrugsconsent) | 2.0 |
| 7.13 | [SetMedicationListReviewed](7-tjanstekontrakt.md#setmedicationlistreviewed) | 1.0 |
| 7.14 | [SetMedicationListReviewNeeded](7-tjanstekontrakt.md#setmedicationlistreviewneeded) | 1.0 |
| 7.15 | [CheckMedicationListVersion](7-tjanstekontrakt.md#checkmedicationlistversion) | 1.0 |

### Versioner och granskningar

| | | | |
| :--- | :--- | :--- | :--- |
| 1.0.0_beta_r2037 |  | Äldre granskningsprocess: Teknik: GodkändÄldre granskningsprocess: Informatik: GodkändÄldre granskningsprocess: Säkerhet: Godkänd | [zip](https://bitbucket.org/rivta-domains/riv.clinicalprocess.activityprescription.prescribe/get/69d203aad41f2136989cd8681bdd48d7b88e9698.zip)·[källkod](https://bitbucket.org/rivta-domains/riv.clinicalprocess.activityprescription.prescribe/src/69d203aad41f2136989cd8681bdd48d7b88e9698) |
| trunk | IS, TKB, AB, IS |  | [källkod](https://bitbucket.org/rivta-domains/riv.clinicalprocess.activityprescription.prescribe/src/master) |

*Zip-arkiven hämtas från taggarna på Bitbucket. Granskningsprotokollen publicerades på rivta.se och länkas inte härifrån.*

*Källa: ögonblicksbild av DOMDB från 2021-08-24, via RIV-TA-portalen.*

## Innehåll

* [1 Inledning](1-inledning.md)
* [2 Versionsinformation](2-versionsinformation.md)
* [3 Tjänstedomänens arkitektur](3-tjanstedomanens-arkitektur.md)
* [4 Tjänstedomänens krav och regler](4-tjanstedomanens-krav-och-regler.md)
* [5 Tjänstedomänens meddelandemodeller](5-tjanstedomanens-meddelandemodeller.md)
* [6 Gemensamma informationskomponenter](6-gemensamma-informationskomponenter.md)
* [7 Tjänstekontrakt](7-tjanstekontrakt.md)

