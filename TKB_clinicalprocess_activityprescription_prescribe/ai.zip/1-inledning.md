# 1 Inledning - clinicalprocess: activityprescription: prescribe v2

* [**Table of Contents**](toc.md)
* **1 Inledning**

## 1 Inledning

## Inledning

### Svenskt namn

vård- och omsorg kärnprocess: hantera aktiviteter:ordination

### WEB-beskrivning

Domänen syftar till att tillmötesgå vårdprofessionens behov av komma åt och arbeta aktivt med en gemensam patientens samlade läkemedelslista, såväl som patientens egen tillgång till läkemedelslistan. Målet med den samlade läkemedelslistan är att skapa en gemensam samlad bild av vilka läkemedel en patient har, har haft och kommer att ha, samt varför läkemedlet har ordinerats (ordinationsorsak), oavsett hur och var patienten ordinerats dem. Det går även att följa hur mycket av läkemedlen som hämtas ut av patienten. Tjänstekontrakten i denna processtödjande domän stödjer att behörig vårdpersonal som är delaktiga i patientens läkemedelsbehandling kan läsa och uppdatera den samlade läkemedelslistan. Flödena omfattar bla. att registrera och läsa läkemedelsordinationer och de underlag som krävs för att expediera ordinerade läkemedel. Det finns vidare stöd för att sätta ut läkemedelsbehandling, makulera expedieringsunderlag, läsa expedieringar och funktioner för att underlätta avstämning av läkemedelslistan.

