# inera.clinicalprocess-activityprescription-prescribe#2: clinicalprocess: activityprescription: prescribe

## Pages

* [Hem](index.md)
* [7 Tjänstekontrakt](7-tjanstekontrakt.md)
* [1 Inledning](1-inledning.md)
* [4 Tjänstedomänens krav och regler](4-tjanstedomanens-krav-och-regler.md)
* [6 Gemensamma informationskomponenter](6-gemensamma-informationskomponenter.md)
* [3 Tjänstedomänens arkitektur](3-tjanstedomanens-arkitektur.md)
* [Artifacts Summary](artifacts.md)
* [Versionsinformation](2-versionsinformation.md)
* [5 Tjänstedomänens meddelandemodeller](5-tjanstedomanens-meddelandemodeller.md)

## Resources

### CodeSystems

* [DispenseAuthorizationStatus — Status på expedieringsunderlag](CodeSystem-dispenseauthorizationstatus-cs.md)
* [DispensedDrugsConsentOrder — Samtyckesorder](CodeSystem-dispenseddrugsconsentorder-cs.md)
* [DispensedDrugsTypeOfResponse — Svarstyp](CodeSystem-dispenseddrugstypeofresponse-cs.md)
* [ErrorCode — Felkod](CodeSystem-errorcode-cs.md)
* [Gender — Kön](CodeSystem-gender-cs.md)
* [LFConsent — Samtyckestyp](CodeSystem-lfconsent-cs.md)
* [ResultCode — Svarskod](CodeSystem-resultcode-cs.md)

### ValueSets

* [DispenseAuthorizationStatus — ValueSet](ValueSet-dispenseauthorizationstatus-vs.md)
* [DispensedDrugsConsentOrder — ValueSet](ValueSet-dispenseddrugsconsentorder-vs.md)
* [DispensedDrugsTypeOfResponse — ValueSet](ValueSet-dispenseddrugstypeofresponse-vs.md)
* [ErrorCode — ValueSet](ValueSet-errorcode-vs.md)
* [Gender — ValueSet](ValueSet-gender-vs.md)
* [LFConsent — ValueSet](ValueSet-lfconsent-vs.md)
* [ResultCode — ValueSet](ValueSet-resultcode-vs.md)

### Logicals

* [AttachMedicationDispenseAuthorization](StructureDefinition-attachmedicationdispenseauthorization.md)
* [CheckMedicationListVersion](StructureDefinition-checkmedicationlistversion.md)
* [DiscontinueMedication](StructureDefinition-discontinuemedication.md)
* [GetDispensedDrugs](StructureDefinition-getdispenseddrugs.md)
* [GetDispensedDrugsConsent](StructureDefinition-getdispenseddrugsConsent.md)
* [GetMedicationDispenseAuthorizations](StructureDefinition-getmedicationdispenseauthorizations.md)
* [GetMedicationPrescriptions — Request](StructureDefinition-getmedicationprescriptions-request.md)
* [GetMedicationPrescriptions](StructureDefinition-getmedicationprescriptions.md)
* [RegisterDispensedDrugsConsent](StructureDefinition-registerdispenseddrugsConsent.md)
* [RegisterMedicationDispenseAuthorization](StructureDefinition-registermedicationdispenseauthorization.md)
* [RegisterMedicationPrescription — Request](StructureDefinition-registermedicationprescription-request.md)
* [RegisterMedicationPrescription](StructureDefinition-registermedicationprescription.md)
* [RegisterMedicationStatement](StructureDefinition-registermedicationstatement.md)
* [RevokeDispensedDrugsConsent](StructureDefinition-revokedispenseddrugsConsent.md)
* [RevokeMedicationDispenseAuthorization](StructureDefinition-revokemedicationdispenseauthorization.md)
* [SetMedicationListReviewed](StructureDefinition-setmedicationlistreviewed.md)
* [SetMedicationListReviewNeeded](StructureDefinition-setmedicationlistreviewneeded.md)

### ImplementationGuides

* [clinicalprocess: activityprescription: prescribe](index.md)
