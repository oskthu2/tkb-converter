# inera.masterdata-organisationalresources-licensetopractice#2.0.0: masterdata: organisationalresources: licensetopractice

## Pages

* [Hem](index.md)
* [7 Tjänstekontrakt](7-tjanstekontrakt.md)
* [5 Tjänstedomänens meddelandemodeller](5-tjanstedomanens-meddelandemodeller.md)
* [Artifacts Summary](artifacts.md)
* [6 Gemensamma informationskomponenter](6-gemensamma-informationskomponenter.md)
* [3 Tjänstedomänens arkitektur](3-tjanstedomanens-arkitektur.md)
* [4 Tjänstedomänens krav och regler](4-tjanstedomanens-krav-och-regler.md)
* [2 Versionsinformation](2-versionsinformation.md)
* [1 Inledning](1-inledning.md)

## Resources

### CodeSystems

* [Kön](CodeSystem-kon-cs.md)
* [Legitimerat yrke](CodeSystem-legitimerat-yrke-cs.md)
* [Typ av behörighetsbegränsning](CodeSystem-typ-av-behorighetsbegransning-cs.md)

### ValueSets

* [Kön — ValueSet](ValueSet-kon-vs.md)
* [Legitimerat yrke — ValueSet](ValueSet-legitimerat-yrke-vs.md)
* [Typ av behörighetsbegränsning — ValueSet](ValueSet-typ-av-behorighetsbegransning-vs.md)

### Logicals

* [GetHospPersonForIVO — Request](StructureDefinition-gethosppersonforivo-request.md)
* [GetHospPersonForIVO](StructureDefinition-gethosppersonforivo.md)
* [GetHospPersonForPublicHealthcare — Request](StructureDefinition-gethosppersonforpublichealthcare-request.md)
* [GetHospPersonForPublicHealthcare](StructureDefinition-gethosppersonforpublichealthcare.md)

### ImplementationGuides

* [masterdata: organisationalresources: licensetopractice](index.md)
