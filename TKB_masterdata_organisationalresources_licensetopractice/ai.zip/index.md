# Hem - masterdata: organisationalresources: licensetopractice v2.0.0

* [**Table of Contents**](toc.md)
* **Hem**

## Hem

| | |
| :--- | :--- |
| *Official URL*:https://fhir.inera.se/ig/masterdata-organisationalresources-licensetopractice/ImplementationGuide/inera.masterdata-organisationalresources-licensetopractice | *Version*:2.0.0 |
| Active as of 2026-10-12 | *Computable Name*:masterdataorganisationalresourceslicensetopractice |
| **Copyright/Legal**: Copyright 2024 Inera AB. Licensieras under Creative Commons Attribution 4.0. | |

# masterdata: organisationalresources: licensetopractice

**TKB-version:** 2.0 · **IG-version:** 2.0.0 · **Källa:** Bitbucket-commit `cc58351d9e83`, efter taggen `masterdata.organisationalresources.licensetopractice_2.0` 

## Översikt

* Beskrivning: Svenskt kortnamn
  * Syftet med tjänstedomänen är att ge direktåtkomst till Socialstyrelsens register över hälso- och sjukvårdspersonal (HoSp) för offentliga vårdgivare samt Inspektionen för vård-och omsorg, genom att låta dem söka efter personer i HoSp-registret. Tjänstekontrakten inom domänen kan användas på två sätt av offentliga vårdgivare. Antingen kan man söka efter en person genom att ange dennes personnummer eller samordningsnummer. Alternativt kan man söka efter en person genom att ange efternamn, ett eller flera förnamn och/eller födelsedatum. Inspektionen för vård och omsorg (IVO) får söka på flera sätt.: yrkeslegitimering
* Beskrivning: Svenskt namn
  * Syftet med tjänstedomänen är att ge direktåtkomst till Socialstyrelsens register över hälso- och sjukvårdspersonal (HoSp) för offentliga vårdgivare samt Inspektionen för vård-och omsorg, genom att låta dem söka efter personer i HoSp-registret. Tjänstekontrakten inom domänen kan användas på två sätt av offentliga vårdgivare. Antingen kan man söka efter en person genom att ange dennes personnummer eller samordningsnummer. Alternativt kan man söka efter en person genom att ange efternamn, ett eller flera förnamn och/eller födelsedatum. Inspektionen för vård och omsorg (IVO) får söka på flera sätt.: underlagförprocesstöd:personella resurser:yrkeslegitimering
* Beskrivning: Typ
  * Syftet med tjänstedomänen är att ge direktåtkomst till Socialstyrelsens register över hälso- och sjukvårdspersonal (HoSp) för offentliga vårdgivare samt Inspektionen för vård-och omsorg, genom att låta dem söka efter personer i HoSp-registret. Tjänstekontrakten inom domänen kan användas på två sätt av offentliga vårdgivare. Antingen kan man söka efter en person genom att ange dennes personnummer eller samordningsnummer. Alternativt kan man söka efter en person genom att ange efternamn, ett eller flera förnamn och/eller födelsedatum. Inspektionen för vård och omsorg (IVO) får söka på flera sätt.: Extern tjänstedomän
* Beskrivning: Förvaltare
  * Syftet med tjänstedomänen är att ge direktåtkomst till Socialstyrelsens register över hälso- och sjukvårdspersonal (HoSp) för offentliga vårdgivare samt Inspektionen för vård-och omsorg, genom att låta dem söka efter personer i HoSp-registret. Tjänstekontrakten inom domänen kan användas på två sätt av offentliga vårdgivare. Antingen kan man söka efter en person genom att ange dennes personnummer eller samordningsnummer. Alternativt kan man söka efter en person genom att ange efternamn, ett eller flera förnamn och/eller födelsedatum. Inspektionen för vård och omsorg (IVO) får söka på flera sätt.: Socialstyrelse
* Beskrivning: Källkod
  * Syftet med tjänstedomänen är att ge direktåtkomst till Socialstyrelsens register över hälso- och sjukvårdspersonal (HoSp) för offentliga vårdgivare samt Inspektionen för vård-och omsorg, genom att låta dem söka efter personer i HoSp-registret. Tjänstekontrakten inom domänen kan användas på två sätt av offentliga vårdgivare. Antingen kan man söka efter en person genom att ange dennes personnummer eller samordningsnummer. Alternativt kan man söka efter en person genom att ange efternamn, ett eller flera förnamn och/eller födelsedatum. Inspektionen för vård och omsorg (IVO) får söka på flera sätt.: [Bitbucket](https://bitbucket.org/rivta-domains/riv.masterdata.organisationalresources.licensetopractice/src/)
* Beskrivning: Ärenden
  * Syftet med tjänstedomänen är att ge direktåtkomst till Socialstyrelsens register över hälso- och sjukvårdspersonal (HoSp) för offentliga vårdgivare samt Inspektionen för vård-och omsorg, genom att låta dem söka efter personer i HoSp-registret. Tjänstekontrakten inom domänen kan användas på två sätt av offentliga vårdgivare. Antingen kan man söka efter en person genom att ange dennes personnummer eller samordningsnummer. Alternativt kan man söka efter en person genom att ange efternamn, ett eller flera förnamn och/eller födelsedatum. Inspektionen för vård och omsorg (IVO) får söka på flera sätt.: [Bitbucket issues](https://bitbucket.org/rivta-domains/riv.masterdata.organisationalresources.licensetopractice/issues)
* Beskrivning: Underlag för denna IG
  * Syftet med tjänstedomänen är att ge direktåtkomst till Socialstyrelsens register över hälso- och sjukvårdspersonal (HoSp) för offentliga vårdgivare samt Inspektionen för vård-och omsorg, genom att låta dem söka efter personer i HoSp-registret. Tjänstekontrakten inom domänen kan användas på två sätt av offentliga vårdgivare. Antingen kan man söka efter en person genom att ange dennes personnummer eller samordningsnummer. Alternativt kan man söka efter en person genom att ange efternamn, ett eller flera förnamn och/eller födelsedatum. Inspektionen för vård och omsorg (IVO) får söka på flera sätt.: Version 2.0 ·[tagg masterdata.organisationalresources.licensetopractice_2.0](https://bitbucket.org/rivta-domains/riv.masterdata.organisationalresources.licensetopractice/src/masterdata.organisationalresources.licensetopractice_2.0)·[zip](https://bitbucket.org/rivta-domains/riv.masterdata.organisationalresources.licensetopractice/src/master/)
* Beskrivning: RIV-TA-portalen
  * Syftet med tjänstedomänen är att ge direktåtkomst till Socialstyrelsens register över hälso- och sjukvårdspersonal (HoSp) för offentliga vårdgivare samt Inspektionen för vård-och omsorg, genom att låta dem söka efter personer i HoSp-registret. Tjänstekontrakten inom domänen kan användas på två sätt av offentliga vårdgivare. Antingen kan man söka efter en person genom att ange dennes personnummer eller samordningsnummer. Alternativt kan man söka efter en person genom att ange efternamn, ett eller flera förnamn och/eller födelsedatum. Inspektionen för vård och omsorg (IVO) får söka på flera sätt.: [Alla tjänstedomäner](https://oskthu2.github.io/tkb-converter/rivta-portal/tjanstedomaner.html)·[Alla tjänstekontrakt](https://oskthu2.github.io/tkb-converter/rivta-portal/tjanstekontrakt.html)

FHIR Implementation Guide för tjänstedomänen **masterdata: organisationalresources: licensetopractice** version 2.0. Genererad från Ineras Tjänstekontraktsbeskrivning (TKB).

Domänen syftar till att ge direktåtkomst till Socialstyrelsens register över hälso- och sjukvårdspersonal (HoSp) för offentliga vårdgivare samt Inspektionen för vård och omsorg (IVO).

Domänen innehåller följande tjänstekontrakt:

| | | |
| :--- | :--- | :--- |
| [GetHospPersonForPublicHealthcare](7-tjanstekontrakt.md#gethosppersonforpublichealthcare) | 2.0 | Hämtar behörighetsinformation för en person för offentliga vårdgivare |
| [GetHospPersonForIVO](7-tjanstekontrakt.md#gethosppersonforivo) | 2.0 | Hämtar behörighetsinformation för en person för IVO |

### Versioner och granskningar

| | | | |
| :--- | :--- | :--- | :--- |
| 2.0 | AB, TKB | [Arkitektur & Regelverk: Informatik: Godkänd](http://rivta.se/downloads//masterdata_organisationalresources_licensetopractice/2.0/VIS_granskning%20masterdata.organisationalresources.licensetopractice%202.0_RC1.docx)[Arkitektur & Regelverk: Teknik: Godkänd](http://rivta.se/downloads//masterdata_organisationalresources_licensetopractice/2.0/AL%20T-granskning%20masterdata.organisationalresources.licensetopractice_2.0_RC1.doc)[Arkitektur & Regelverk: Säkerhet: Godkänd](http://rivta.se/downloads//masterdata_organisationalresources_licensetopractice/2.0/VIS_granskning%20masterdata.organisationalresources.licensetopractice%202.0_RC1.docx) | [zip](http://rivta.se/downloads//masterdata_organisationalresources_licensetopractice/2.0/ServiceContracts_masterdata_organisationalresources_licensetopractice_2.0.zip)·[källkod](https://bitbucket.org/rivta-domains/riv.masterdata.organisationalresources.licensetopractice/src/masterdata.organisationalresources.licensetopractice_2.0) |
| 1.1 | IS, AB, TKB | [Arkitektur & Regelverk: Teknik: Godkänd](http://rivta.se/downloads/masterdata_organisationalresources_licensetopractice/1.1/AL%20T-granskning%20Infrastructure.directory.licensetopractice_1.1.doc)[Arkitektur & Regelverk: Informatik: Godkänd](http://rivta.se/downloads//masterdata_organisationalresources_licensetopractice/1.1/VIS_granskning%20infrastructure.directory.licensetopractice%201.1.docx)[Arkitektur & Regelverk: Säkerhet: Godkänd](http://rivta.se/downloads//masterdata_organisationalresources_licensetopractice/1.1/VIS_granskning%20infrastructure.directory.licensetopractice%201.1.docx) | [zip](http://rivta.se/downloads/masterdata_organisationalresources_licensetopractice/1.1/ServiceContracts_Infrastructure.directory.licensetopractice_1.1.zip)·[källkod](https://bitbucket.org/rivta-domains/riv.masterdata.organisationalresources.licensetopractice/src/Infrastructure.directory.licensetopractice_1.1) |
| trunk | TKB, AB |  | [källkod](https://bitbucket.org/rivta-domains/riv.masterdata.organisationalresources.licensetopractice/src/master) |

*Källa: ögonblicksbild av DOMDB från 2021-08-24, via RIV-TA-portalen.*

## Innehåll

* [1 Inledning](1-inledning.md)
* [2 Versionsinformation](2-versionsinformation.md)
* [3 Tjänstedomänens arkitektur](3-tjanstedomanens-arkitektur.md)
* [4 Tjänstedomänens krav och regler](4-tjanstedomanens-krav-och-regler.md)
* [5 Tjänstedomänens meddelandemodeller](5-tjanstedomanens-meddelandemodeller.md)
* [6 Gemensamma informationskomponenter](6-gemensamma-informationskomponenter.md)
* [7 Tjänstekontrakt](7-tjanstekontrakt.md)
* [Artefakter](artifacts.md)

