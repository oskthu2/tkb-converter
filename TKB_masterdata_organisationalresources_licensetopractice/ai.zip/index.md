# Hem - masterdata: organisationalresources: licensetopractice v2.0.0

* [**Table of Contents**](toc.md)
* **Hem**

## Hem

| | |
| :--- | :--- |
| *Official URL*:https://fhir.inera.se/ig/masterdata-organisationalresources-licensetopractice/ImplementationGuide/inera.masterdata-organisationalresources-licensetopractice | *Version*:2.0.0 |
| Draft as of 2026-09-09 | *Computable Name*:masterdataorganisationalresourceslicensetopractice |
| **Copyright/Legal**: Copyright 2024 Inera AB. Licensieras under Creative Commons Attribution 4.0. | |

# masterdata: organisationalresources: licensetopractice

## Översikt

FHIR Implementation Guide för tjänstedomänen **masterdata: organisationalresources: licensetopractice** version 2.0. Genererad från Ineras Tjänstekontraktsbeskrivning (TKB).

Domänen syftar till att ge direktåtkomst till Socialstyrelsens register över hälso- och sjukvårdspersonal (HoSp) för offentliga vårdgivare samt Inspektionen för vård och omsorg (IVO).

Domänen innehåller följande tjänstekontrakt:

| | | |
| :--- | :--- | :--- |
| [GetHospPersonForPublicHealthcare](7-tjanstekontrakt.md#gethosppersonforpublichealthcare) | 2.0 | Hämtar behörighetsinformation för en person för offentliga vårdgivare |
| [GetHospPersonForIVO](7-tjanstekontrakt.md#gethosppersonforivo) | 2.0 | Hämtar behörighetsinformation för en person för IVO |

## Innehåll

* [1 Inledning](1-inledning.md)
* [2 Versionsinformation](2-versionsinformation.md)
* [3 Tjänstedomänens arkitektur](3-tjanstedomanens-arkitektur.md)
* [4 Tjänstedomänens krav och regler](4-tjanstedomanens-krav-och-regler.md)
* [5 Tjänstedomänens meddelandemodeller](5-tjanstedomanens-meddelandemodeller.md)
* [6 Gemensamma informationskomponenter](6-gemensamma-informationskomponenter.md)
* [7 Tjänstekontrakt](7-tjanstekontrakt.md)
* [Artefakter](artifacts.md)

