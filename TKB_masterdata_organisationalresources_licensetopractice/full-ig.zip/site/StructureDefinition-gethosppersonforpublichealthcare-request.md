# GetHospPersonForPublicHealthcare — Request - masterdata: organisationalresources: licensetopractice v2.0.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **GetHospPersonForPublicHealthcare — Request**

## Logical Model: GetHospPersonForPublicHealthcare — Request 

| | |
| :--- | :--- |
| *Official URL*:https://fhir.inera.se/ig/masterdata-organisationalresources-licensetopractice/StructureDefinition/gethosppersonforpublichealthcare-request | *Version*:2.0.0 |
| Draft as of 2026-09-14 | *Computable Name*:GetHospPersonForPublicHealthcareRequest |
| **Copyright/Legal**: Copyright 2024 Inera AB. Licensieras under Creative Commons Attribution 4.0. | |

 
Logisk modell för requestparametrar i GetHospPersonForPublicHealthcare. Antingen anges personId, eller ett eller flera av fälten efternamn, fornamn, fodelsedatum. 

**Usages:**

* This Logical Model is not used by any profiles in this Specification

You can also check for [usages in the FHIR IG Statistics](https://packages2.fhir.org/xig/resource/inera.masterdata-organisationalresources-licensetopractice|current/StructureDefinition/StructureDefinition-gethosppersonforpublichealthcare-request.json)

### Formal Views of Profile Content

 [Description of Profiles, Differentials, Snapshots and how the different presentations work](http://build.fhir.org/ig/FHIR/ig-guidance/readingIgs.html#structure-definitions). 

 

Other representations of profile: [CSV](StructureDefinition-gethosppersonforpublichealthcare-request.csv), [Excel](StructureDefinition-gethosppersonforpublichealthcare-request.xlsx) 



## Resource Content

```json
{
  "resourceType" : "StructureDefinition",
  "id" : "gethosppersonforpublichealthcare-request",
  "extension" : [{
    "url" : "http://hl7.org/fhir/StructureDefinition/structuredefinition-type-characteristics",
    "valueCode" : "can-be-target"
  }],
  "url" : "https://fhir.inera.se/ig/masterdata-organisationalresources-licensetopractice/StructureDefinition/gethosppersonforpublichealthcare-request",
  "version" : "2.0.0",
  "name" : "GetHospPersonForPublicHealthcareRequest",
  "title" : "GetHospPersonForPublicHealthcare — Request",
  "status" : "draft",
  "date" : "2026-09-14T12:54:04+00:00",
  "contact" : [{
    "name" : "Inera Arkitektur",
    "telecom" : [{
      "system" : "url",
      "value" : "https://www.inera.se"
    }]
  }],
  "description" : "Logisk modell för requestparametrar i GetHospPersonForPublicHealthcare.\nAntingen anges personId, eller ett eller flera av fälten efternamn, fornamn, fodelsedatum.",
  "copyright" : "Copyright 2024 Inera AB. Licensieras under Creative Commons Attribution 4.0.",
  "fhirVersion" : "4.0.1",
  "kind" : "logical",
  "abstract" : false,
  "type" : "https://fhir.inera.se/ig/masterdata-organisationalresources-licensetopractice/StructureDefinition/gethosppersonforpublichealthcare-request",
  "baseDefinition" : "http://hl7.org/fhir/StructureDefinition/Base",
  "derivation" : "specialization",
  "differential" : {
    "element" : [{
      "id" : "gethosppersonforpublichealthcare-request",
      "path" : "gethosppersonforpublichealthcare-request",
      "short" : "GetHospPersonForPublicHealthcare — Request",
      "definition" : "Logisk modell för requestparametrar i GetHospPersonForPublicHealthcare.\nAntingen anges personId, eller ett eller flera av fälten efternamn, fornamn, fodelsedatum."
    },
    {
      "id" : "gethosppersonforpublichealthcare-request.personId",
      "path" : "gethosppersonforpublichealthcare-request.personId",
      "short" : "Personnummer eller samordningsnummer",
      "definition" : "Personnummer (OID: 1.2.752.129.2.1.3.1) eller\nsamordningsnummer (OID: 1.2.752.129.2.1.3.3).\nFormat: ÅÅÅÅMMDDXXXX (12 siffror).\nOm personId inte anges måste minst ett av efternamn, fornamn eller fodelsedatum anges.",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "Identifier"
      }]
    },
    {
      "id" : "gethosppersonforpublichealthcare-request.fodelsedatum",
      "path" : "gethosppersonforpublichealthcare-request.fodelsedatum",
      "short" : "Födelsedatum (ÅÅÅÅMMDD)",
      "definition" : "Söker personer efter födelsedatum. Format: ÅÅÅÅMMDD.",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "gethosppersonforpublichealthcare-request.efternamn",
      "path" : "gethosppersonforpublichealthcare-request.efternamn",
      "short" : "Efternamn",
      "definition" : "Söker personer efter efternamn.",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "gethosppersonforpublichealthcare-request.fornamn",
      "path" : "gethosppersonforpublichealthcare-request.fornamn",
      "short" : "Förnamn",
      "definition" : "Söker personer efter förnamn. Kan anges 0 eller fler.",
      "min" : 0,
      "max" : "*",
      "type" : [{
        "code" : "string"
      }]
    }]
  }
}

```
