# Hem - clinicalprocess: activity: actions v1.3.4

* [**Table of Contents**](toc.md)
* **Hem**

## Hem

| | |
| :--- | :--- |
| *Official URL*:https://fhir.inera.se/ig/clinicalprocess-activity-actions/ImplementationGuide/inera.clinicalprocess-activity-actions | *Version*:1.3.4 |
| Active as of 2026-10-26 | *Computable Name*:clinicalprocessactivityactions |
| **Copyright/Legal**: Copyright 2024 Inera AB. Licensieras under Creative Commons Attribution 4.0. | |

# clinicalprocess: activity: actions

**TKB-version:** 1.3.4 · **IG-version:** 1.3.4 · **Källa:** Bitbucket-commit `abc18c8b1767`, efter taggen `1.3.4` 

## Översikt

* Beskrivning: Svenskt kortnamn
  * Denna domän hanterar information gällande vårdaktiviteter kopplade till en patient, till exempel operationer och undersökningar.: aktivitetshantering
* Beskrivning: Svenskt namn
  * Denna domän hanterar information gällande vårdaktiviteter kopplade till en patient, till exempel operationer och undersökningar.: vård- och omsorg kärnprocess:hantera aktiviteter:aktiviteter
* Beskrivning: Typ
  * Denna domän hanterar information gällande vårdaktiviteter kopplade till en patient, till exempel operationer och undersökningar.: Nationell tjänstedomän
* Beskrivning: Förvaltare
  * Denna domän hanterar information gällande vårdaktiviteter kopplade till en patient, till exempel operationer och undersökningar.: Tjänstekontraktsförvaltningen, TK-forvaltningen@inera.se
* Beskrivning: Källkod
  * Denna domän hanterar information gällande vårdaktiviteter kopplade till en patient, till exempel operationer och undersökningar.: [Bitbucket](https://bitbucket.org/rivta-domains/riv.clinicalprocess.activity.actions/src)
* Beskrivning: Ärenden
  * Denna domän hanterar information gällande vårdaktiviteter kopplade till en patient, till exempel operationer och undersökningar.: [Bitbucket issues](https://bitbucket.org/rivta-domains/riv.clinicalprocess.activity.actions/issues)
* Beskrivning: Informationssida
  * Denna domän hanterar information gällande vårdaktiviteter kopplade till en patient, till exempel operationer och undersökningar.: [Confluence](https://inera.atlassian.net/wiki/spaces/OITOF/pages/272835781/clinicalprocess+activity+actions+aktivitetshantering)
* Beskrivning: Underlag för denna IG
  * Denna domän hanterar information gällande vårdaktiviteter kopplade till en patient, till exempel operationer och undersökningar.: Version 1.3.4 ·[tagg 1.3.4](https://bitbucket.org/rivta-domains/riv.clinicalprocess.activity.actions/src/1.3.4)·[zip](https://api.bitbucket.org/2.0/repositories/rivta-domains/riv.clinicalprocess.activity.actions/src/master/%20(no%20zip%20downloads;%20sourced%20via%20Bitbucket%20src%20API))
* Beskrivning: RIV-TA-portalen
  * Denna domän hanterar information gällande vårdaktiviteter kopplade till en patient, till exempel operationer och undersökningar.: [Alla tjänstedomäner](https://oskthu2.github.io/tkb-converter/rivta-portal/tjanstedomaner.html)·[Alla tjänstekontrakt](https://oskthu2.github.io/tkb-converter/rivta-portal/tjanstekontrakt.html)

FHIR Implementation Guide för tjänstedomänen **clinicalprocess: activity: actions** version 1.3.4. Genererad från Ineras Tjänstekontraktsbeskrivning (TKB).

Domänen hanterar information gällande vårdaktiviteter kopplade till en patient, till exempel operationer och undersökningar. Syftet med domänen är att tillgängliggöra journalförd strukturerad information om aktiviteter i kärnprocessen på ett strukturerat sätt.

Domänen innehåller följande tjänstekontrakt:

| | | |
| :--- | :--- | :--- |
| [GetActivities](7-tjanstekontrakt.md#getactivities) | 1.3 | Returnerar strukturerade aktiviteter för en patient, t.ex. operationer och undersökningar |

### Versioner och granskningar

| | | | |
| :--- | :--- | :--- | :--- |
| 1.0.6 | TKB, AB | [Arkitektur & Regelverk: Säkerhet: Godkänd](http://rivta.se/downloads//clinicalprocess_activity_actions/1.0.6/VIS_granskning%20-%20clinicalprocess_activity_actions_1.0.6.docx)[Arkitektur & Regelverk: Teknik: Godkänd](http://rivta.se/downloads//clinicalprocess_activity_actions/1.0.6/T-granskning_clinicalprocess.activity.actions_1.0.6.docx)[Arkitektur & Regelverk: Informatik: Godkänd](http://rivta.se/downloads//clinicalprocess_activity_actions/1.0.6/VIS_granskning%20-%20clinicalprocess_activity_actions_1.0.6.docx) | [zip](http://rivta.se/downloads//clinicalprocess_activity_actions/1.0.6/ServiceContracts_clinicalprocess_activity_actions_1.0.6.zip)·[källkod](https://bitbucket.org/rivta-domains/riv.clinicalprocess.activity.actions/src/1.0.6) |
| trunk | AB, TKB |  | [källkod](https://bitbucket.org/rivta-domains/riv.clinicalprocess.activity.actions/src/master) |

*Källa: ögonblicksbild av DOMDB från 2021-08-24, via RIV-TA-portalen.*

## Innehåll

* [1 Inledning](1-inledning.md)
* [2 Versionsinformation](2-versionsinformation.md)
* [3 Tjänstedomänens arkitektur](3-tjanstedomanens-arkitektur.md)
* [4 Tjänstedomänens krav och regler](4-tjanstedomanens-krav-och-regler.md)
* [5 Tjänstedomänens meddelandemodeller](5-tjanstedomanens-meddelandemodeller.md)
* [6 Gemensamma informationskomponenter](6-gemensamma-informationskomponenter.md)
* [7 Tjänstekontrakt](7-tjanstekontrakt.md)
* [Artefakter](artifacts.md)

