# Hem - clinicalprocess: activity: actions v1.3

* [**Table of Contents**](toc.md)
* **Hem**

## Hem

| | |
| :--- | :--- |
| *Official URL*:https://fhir.inera.se/ig/clinicalprocess-activity-actions/ImplementationGuide/inera.clinicalprocess-activity-actions | *Version*:1.3 |
| Draft as of 2026-09-09 | *Computable Name*:clinicalprocessactivityactions |
| **Copyright/Legal**: Copyright 2024 Inera AB. Licensieras under Creative Commons Attribution 4.0. | |

# clinicalprocess: activity: actions

## Översikt

FHIR Implementation Guide för tjänstedomänen **clinicalprocess: activity: actions** version 1.3. Genererad från Ineras Tjänstekontraktsbeskrivning (TKB).

Domänen hanterar information gällande vårdaktiviteter kopplade till en patient, till exempel operationer och undersökningar. Syftet med domänen är att tillgängliggöra journalförd strukturerad information om aktiviteter i kärnprocessen på ett strukturerat sätt.

Domänen innehåller följande tjänstekontrakt:

| | | |
| :--- | :--- | :--- |
| [GetActivities](7-tjanstekontrakt.md#getactivities) | 1.3 | Returnerar strukturerade aktiviteter för en patient, t.ex. operationer och undersökningar |

## Innehåll

* [1 Inledning](1-inledning.md)
* [2 Versionsinformation](2-versionsinformation.md)
* [3 Tjänstedomänens arkitektur](3-tjanstedomanens-arkitektur.md)
* [4 Tjänstedomänens krav och regler](4-tjanstedomanens-krav-och-regler.md)
* [5 Tjänstedomänens meddelandemodeller](5-tjanstedomanens-meddelandemodeller.md)
* [6 Gemensamma informationskomponenter](6-gemensamma-informationskomponenter.md)
* [7 Tjänstekontrakt](7-tjanstekontrakt.md)
* [Artefakter](artifacts.md)

