# inera.clinicalprocess-activity-actions#1.3.4: clinicalprocess: activity: actions

## Pages

* [Hem](index.md)
* [7 Tjänstekontrakt](7-tjanstekontrakt.md)
* [2 Versionsinformation](2-versionsinformation.md)
* [3 Tjänstedomänens arkitektur](3-tjanstedomanens-arkitektur.md)
* [1 Inledning](1-inledning.md)
* [Artifacts Summary](artifacts.md)
* [6 Gemensamma informationskomponenter](6-gemensamma-informationskomponenter.md)
* [5 Tjänstedomänens meddelandemodeller](5-tjanstedomanens-meddelandemodeller.md)
* [4 Tjänstedomänens krav och regler](4-tjanstedomanens-krav-och-regler.md)

## Resources

### Logicals

* [IIType](StructureDefinition-IIType.md)
* [GetActivities — Request](StructureDefinition-getactivities-request.md)
* [GetActivities](StructureDefinition-getactivities.md)

### Primitive-type Profiles

* [PartialTimeStampValueType](StructureDefinition-PartialTimeStampValueType.md)
* [UUIDType](StructureDefinition-UUIDType.md)

### ImplementationGuides

* [clinicalprocess: activity: actions](index.md)
