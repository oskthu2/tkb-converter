# Hem - clinicalprocess: activityprescription: actoutcome 1.0 v1.0.2

* [**Table of Contents**](toc.md)
* **Hem**

## Hem

| | |
| :--- | :--- |
| *Official URL*:https://fhir.inera.se/ig/clinicalprocess-activityprescription-actoutcome/ImplementationGuide/inera.clinicalprocess-activityprescription-actoutcome | *Version*:1.0.2 |
| Active as of 2026-11-06 | *Computable Name*:clinicalprocessactivityprescriptionactoutcome |
| **Copyright/Legal**: Copyright 2024 Inera AB. Licensieras under Creative Commons Attribution 4.0. | |

# clinicalprocess: activityprescription: actoutcome 1.0

**TKB-version:** 1.0.2 · **IG-version:** 1.0.2 · **Källa:** Bitbucket-tagg `1.0.2` · **Andra huvudversioner:** [2.2.1](https://oskthu2.github.io/tkb-converter/TKB_clinicalprocess_activityprescription_actoutcome/index.html) 

> **Äldre huvudversion.** Detta är TKB 1.0 (Bitbucket-taggen 1.0.2). Den senaste huvudversionen, 2.2, finns på [clinicalprocess: activityprescription: actoutcome](https://oskthu2.github.io/tkb-converter/TKB_clinicalprocess_activityprescription_actoutcome/index.html).

## Översikt

* Beskrivning: Svenskt kortnamn
  * Denna domän hanterat information gällande en patients ordinationer, förskrivning och administrering av läkemedel och vaccinationer. OBS! För verifiering enligt testmodell 2.0 skall testsviter och självdeklarationer i releasepaketet för domänversion 2.1_RC4 användas. Gäller kontrakten GetMedicationHistory 2.0 och GetVaccinationHistory 2.0.: ordinationsutfall
* Beskrivning: Svenskt namn
  * Denna domän hanterat information gällande en patients ordinationer, förskrivning och administrering av läkemedel och vaccinationer. OBS! För verifiering enligt testmodell 2.0 skall testsviter och självdeklarationer i releasepaketet för domänversion 2.1_RC4 användas. Gäller kontrakten GetMedicationHistory 2.0 och GetVaccinationHistory 2.0.: vård- och omsorg kärnprocess:hantera aktiviteter:ordinationsutfall
* Beskrivning: Typ
  * Denna domän hanterat information gällande en patients ordinationer, förskrivning och administrering av läkemedel och vaccinationer. OBS! För verifiering enligt testmodell 2.0 skall testsviter och självdeklarationer i releasepaketet för domänversion 2.1_RC4 användas. Gäller kontrakten GetMedicationHistory 2.0 och GetVaccinationHistory 2.0.: Nationell tjänstedomän
* Beskrivning: Förvaltare
  * Denna domän hanterat information gällande en patients ordinationer, förskrivning och administrering av läkemedel och vaccinationer. OBS! För verifiering enligt testmodell 2.0 skall testsviter och självdeklarationer i releasepaketet för domänversion 2.1_RC4 användas. Gäller kontrakten GetMedicationHistory 2.0 och GetVaccinationHistory 2.0.: Tjänstekontraktsförvaltningen, TK-forvaltningen@inera.se
* Beskrivning: Källkod
  * Denna domän hanterat information gällande en patients ordinationer, förskrivning och administrering av läkemedel och vaccinationer. OBS! För verifiering enligt testmodell 2.0 skall testsviter och självdeklarationer i releasepaketet för domänversion 2.1_RC4 användas. Gäller kontrakten GetMedicationHistory 2.0 och GetVaccinationHistory 2.0.: [Bitbucket](https://bitbucket.org/rivta-domains/riv.clinicalprocess.activityprescription.actoutcome/src)
* Beskrivning: Ärenden
  * Denna domän hanterat information gällande en patients ordinationer, förskrivning och administrering av läkemedel och vaccinationer. OBS! För verifiering enligt testmodell 2.0 skall testsviter och självdeklarationer i releasepaketet för domänversion 2.1_RC4 användas. Gäller kontrakten GetMedicationHistory 2.0 och GetVaccinationHistory 2.0.: [Bitbucket issues](https://bitbucket.org/rivta-domains/riv.clinicalprocess.activityprescription.actoutcome/issues)
* Beskrivning: Informationssida
  * Denna domän hanterat information gällande en patients ordinationer, förskrivning och administrering av läkemedel och vaccinationer. OBS! För verifiering enligt testmodell 2.0 skall testsviter och självdeklarationer i releasepaketet för domänversion 2.1_RC4 användas. Gäller kontrakten GetMedicationHistory 2.0 och GetVaccinationHistory 2.0.: [Confluence](https://inera.atlassian.net/wiki/spaces/OITOF/pages/275088118/clinicalprocess+activityprescription+actoutcome+ordinationsutfall)
* Beskrivning: Underlag för denna IG
  * Denna domän hanterat information gällande en patients ordinationer, förskrivning och administrering av läkemedel och vaccinationer. OBS! För verifiering enligt testmodell 2.0 skall testsviter och självdeklarationer i releasepaketet för domänversion 2.1_RC4 användas. Gäller kontrakten GetMedicationHistory 2.0 och GetVaccinationHistory 2.0.: Version 1.0.2 ·[tagg 1.0.2](https://bitbucket.org/rivta-domains/riv.clinicalprocess.activityprescription.actoutcome/src/1.0.2)·[zip](https://bitbucket.org/rivta-domains/riv.clinicalprocess.activityprescription.actoutcome/get/1.0.2.zip)
* Beskrivning: RIV-TA-portalen
  * Denna domän hanterat information gällande en patients ordinationer, förskrivning och administrering av läkemedel och vaccinationer. OBS! För verifiering enligt testmodell 2.0 skall testsviter och självdeklarationer i releasepaketet för domänversion 2.1_RC4 användas. Gäller kontrakten GetMedicationHistory 2.0 och GetVaccinationHistory 2.0.: [Alla tjänstedomäner](https://oskthu2.github.io/tkb-converter/rivta-portal/tjanstedomaner.html)·[Alla tjänstekontrakt](https://oskthu2.github.io/tkb-converter/rivta-portal/tjanstekontrakt.html)

Detta är en FHIR Implementation Guide genererad från TKB-dokumentation för tjänstedomänen **clinicalprocess: activityprescription: actoutcome** version 1.0.2.

Den svenska benämningen är ”Hantera ordinations- och förskrivningsrelaterat utfall av aktivitet”. Tjänstedomänen syftar till att tillmötesgå behovet av systemoberoende åtkomst till information om utfallet av ordinations- och förskrivningsrelaterade aktiviteter för såväl vårdgivar- som invånartjänster. I version 1.0 innehåller domänen ett tjänstekontrakt, GetVaccinationHistory.

Källdokumentet är **Tjänstekontraktsbeskrivning riv clinicalprocess activityprescription actoutcome**, utgåva 1.0.2 (2022-02-16). Dess kapitelindelning skiljer sig från senare TKB-mallar. IG:n följer projektets gemensamma kapitelindelning, och varje sida anger var texten står i källdokumentet.

RIV-TA namespace: `urn:riv:clinicalprocess:activityprescription:actoutcome`

## Tjänstekontrakt

Domänen innehåller följande tjänstekontrakt:

| | | |
| :--- | :--- | :--- |
| [GetVaccinationHistory](7-tjanstekontrakt.md#getvaccinationhistory) | 1.0 | Returnerar strukturerad eller ostrukturerad information om patientens vaccinationer |

### Versioner och granskningar

| | | | |
| :--- | :--- | :--- | :--- |
| 2.1.3 | AB, TKB | Arkitektur & Regelverk: Informatik: GodkändArkitektur & Regelverk: Säkerhet: GodkändArkitektur & Regelverk: Teknik: Godkänd | [zip](https://bitbucket.org/rivta-domains/riv.clinicalprocess.activityprescription.actoutcome/get/2.1.3.zip)·[källkod](https://bitbucket.org/rivta-domains/riv.clinicalprocess.activityprescription.actoutcome/src/2.1.3) |
| 1.0.1 | AB, TKB | Äldre granskningsprocess: Teknik: Godkänd | [zip](https://bitbucket.org/rivta-domains/riv.clinicalprocess.activityprescription.actoutcome/get/clinicalprocess_activityprescription_actoutcome_1.0.1.zip)·[källkod](https://bitbucket.org/rivta-domains/riv.clinicalprocess.activityprescription.actoutcome/src/clinicalprocess_activityprescription_actoutcome_1.0.1) |
| trunk | AB, TKB |  | [källkod](https://bitbucket.org/rivta-domains/riv.clinicalprocess.activityprescription.actoutcome/src/master) |

*Zip-arkiven hämtas från taggarna på Bitbucket. Granskningsprotokollen publicerades på rivta.se och länkas inte härifrån.*

*Källa: ögonblicksbild av DOMDB från 2021-08-24, via RIV-TA-portalen.*

## Innehåll

* [1 Inledning](1-inledning.md)
* [2 Versionsinformation](2-versionsinformation.md)
* [3 Tjänstedomänens arkitektur](3-tjanstedomanens-arkitektur.md)
* [4 Tjänstedomänens krav och regler](4-tjanstedomanens-krav-och-regler.md)
* [5 Tjänstedomänens meddelandemodeller](5-tjanstedomanens-meddelandemodeller.md)
* [6 Gemensamma informationskomponenter](6-gemensamma-informationskomponenter.md)
* [7 Tjänstekontrakt](7-tjanstekontrakt.md)
* [Artefakter](artifacts.md)

