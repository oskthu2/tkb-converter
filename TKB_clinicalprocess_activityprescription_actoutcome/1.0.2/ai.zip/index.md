# Hem - clinicalprocess: activityprescription: actoutcome 1.0 v1.0.2

* [**Table of Contents**](toc.md)
* **Hem**

## Hem

| | |
| :--- | :--- |
| *Official URL*:https://fhir.inera.se/ig/clinicalprocess-activityprescription-actoutcome/ImplementationGuide/inera.clinicalprocess-activityprescription-actoutcome | *Version*:1.0.2 |
| Active as of 2026-10-08 | *Computable Name*:clinicalprocessactivityprescriptionactoutcome |
| **Copyright/Legal**: Copyright 2024 Inera AB. Licensieras under Creative Commons Attribution 4.0. | |

# clinicalprocess: activityprescription: actoutcome 1.0

**TKB-version:** 1.0.2 · **IG-version:** 1.0.2 · **Källa:** Bitbucket-tagg `1.0.2` · **Andra huvudversioner:** [2.2.1](https://oskthu2.github.io/tkb-converter/TKB_clinicalprocess_activityprescription_actoutcome/index.html) 

> **Äldre huvudversion.** Detta är TKB 1.0 (Bitbucket-taggen 1.0.2). Den senaste huvudversionen, 2.2, finns på [clinicalprocess: activityprescription: actoutcome](https://oskthu2.github.io/tkb-converter/TKB_clinicalprocess_activityprescription_actoutcome/index.html).

## Översikt

Detta är en FHIR Implementation Guide genererad från TKB-dokumentation för tjänstedomänen **clinicalprocess: activityprescription: actoutcome** version 1.0.2.

Den svenska benämningen är ”Hantera ordinations- och förskrivningsrelaterat utfall av aktivitet”. Tjänstedomänen syftar till att tillmötesgå behovet av systemoberoende åtkomst till information om utfallet av ordinations- och förskrivningsrelaterade aktiviteter för såväl vårdgivar- som invånartjänster. I version 1.0 innehåller domänen ett tjänstekontrakt, GetVaccinationHistory.

Källdokumentet är **Tjänstekontraktsbeskrivning riv clinicalprocess activityprescription actoutcome**, utgåva 1.0.2 (2022-02-16). Dess kapitelindelning skiljer sig från senare TKB-mallar. IG:n följer projektets gemensamma kapitelindelning, och varje sida anger var texten står i källdokumentet.

RIV-TA namespace: `urn:riv:clinicalprocess:activityprescription:actoutcome`

## Tjänstekontrakt

Domänen innehåller följande tjänstekontrakt:

| | | |
| :--- | :--- | :--- |
| [GetVaccinationHistory](7-tjanstekontrakt.md#getvaccinationhistory) | 1.0 | Returnerar strukturerad eller ostrukturerad information om patientens vaccinationer |

## Innehåll

* [1 Inledning](1-inledning.md)
* [2 Versionsinformation](2-versionsinformation.md)
* [3 Tjänstedomänens arkitektur](3-tjanstedomanens-arkitektur.md)
* [4 Tjänstedomänens krav och regler](4-tjanstedomanens-krav-och-regler.md)
* [5 Tjänstedomänens meddelandemodeller](5-tjanstedomanens-meddelandemodeller.md)
* [6 Gemensamma informationskomponenter](6-gemensamma-informationskomponenter.md)
* [7 Tjänstekontrakt](7-tjanstekontrakt.md)
* [Artefakter](artifacts.md)

