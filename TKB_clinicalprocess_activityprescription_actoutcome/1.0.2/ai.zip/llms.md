# inera.clinicalprocess-activityprescription-actoutcome#1.0.2: clinicalprocess: activityprescription: actoutcome 1.0

## Pages

* [Hem](index.md)
* [7 Tjänstekontrakt](7-tjanstekontrakt.md)
* [5 Tjänstedomänens meddelandemodeller](5-tjanstedomanens-meddelandemodeller.md)
* [Artifacts Summary](artifacts.md)
* [6 Gemensamma informationskomponenter](6-gemensamma-informationskomponenter.md)
* [3 Tjänstedomänens arkitektur](3-tjanstedomanens-arkitektur.md)
* [4 Tjänstedomänens krav och regler](4-tjanstedomanens-krav-och-regler.md)
* [2 Versionsinformation](2-versionsinformation.md)
* [1 Inledning](1-inledning.md)

## Resources

### Logicals

* [GetVaccinationHistory — Request](StructureDefinition-getvaccinationhistory-request.md)
* [GetVaccinationHistory](StructureDefinition-getvaccinationhistory.md)

### ImplementationGuides

* [clinicalprocess: activityprescription: actoutcome 1.0](index.md)
