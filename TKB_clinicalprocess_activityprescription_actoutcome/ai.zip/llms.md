# inera.clinicalprocess-activityprescription-actoutcome#2.2.1: clinicalprocess: activityprescription: actoutcome

## Pages

* [Hem](index.md)
* [7 Tjänstekontrakt](7-tjanstekontrakt.md)
* [5 Tjänstedomänens meddelandemodeller](5-tjanstedomanens-meddelandemodeller.md)
* [Artifacts Summary](artifacts.md)
* [6 Gemensamma informationskomponenter](6-gemensamma-informationskomponenter.md)
* [3 Tjänstedomänens arkitektur](3-tjanstedomanens-arkitektur.md)
* [4 Tjänstedomänens krav och regler](4-tjanstedomanens-krav-och-regler.md)
* [2 Versionsinformation](2-versionsinformation.md)
* [1 Inledning](1-inledning.md)

## Resources

### CodeSystems

* [ErrorCode](CodeSystem-errorcode-cs.md)
* [NonReplaceable](CodeSystem-nonreplaceable-cs.md)
* [PrescriptionStatus](CodeSystem-prescriptionstatus-cs.md)
* [ResultCode](CodeSystem-resultcode-cs.md)
* [TypeOfPrescription](CodeSystem-typeofprescription-cs.md)

### ValueSets

* [ErrorCode — ValueSet](ValueSet-errorcode-vs.md)
* [PrescriptionStatus — ValueSet](ValueSet-prescriptionstatus-vs.md)
* [ResultCode — ValueSet](ValueSet-resultcode-vs.md)
* [TypeOfPrescription — ValueSet](ValueSet-typeofprescription-vs.md)

### Logicals

* [GetMedicationHistory — Request](StructureDefinition-getmedicationhistory-request.md)
* [GetMedicationHistory](StructureDefinition-getmedicationhistory.md)
* [GetVaccinationHistory — Request](StructureDefinition-getvaccinationhistory-request.md)
* [GetVaccinationHistory](StructureDefinition-getvaccinationhistory.md)

### ImplementationGuides

* [clinicalprocess: activityprescription: actoutcome](index.md)
