# Hem - clinicalprocess: activityprescription: actoutcome v2.2.1

* [**Table of Contents**](toc.md)
* **Hem**

## Hem

| | |
| :--- | :--- |
| *Official URL*:https://fhir.inera.se/ig/clinicalprocess-activityprescription-actoutcome/ImplementationGuide/inera.clinicalprocess-activityprescription-actoutcome | *Version*:2.2.1 |
| Active as of 2026-11-09 | *Computable Name*:clinicalprocessactivityprescriptionactoutcome |
| **Copyright/Legal**: Copyright 2024 Inera AB. Licensieras under Creative Commons Attribution 4.0. | |

# clinicalprocess: activityprescription: actoutcome

**TKB-version:** 2.2.1 · **IG-version:** 2.2.1 · **Källa:** Bitbucket-tagg `2.2.1` · **Andra huvudversioner:** [1.0.2](https://oskthu2.github.io/tkb-converter/TKB_clinicalprocess_activityprescription_actoutcome/1.0.2/index.html) 

## Översikt

* Beskrivning: Svenskt kortnamn
  * Denna domän hanterat information gällande en patients ordinationer, förskrivning och administrering av läkemedel och vaccinationer. OBS! För verifiering enligt testmodell 2.0 skall testsviter och självdeklarationer i releasepaketet för domänversion 2.1_RC4 användas. Gäller kontrakten GetMedicationHistory 2.0 och GetVaccinationHistory 2.0.: ordinationsutfall
* Beskrivning: Svenskt namn
  * Denna domän hanterat information gällande en patients ordinationer, förskrivning och administrering av läkemedel och vaccinationer. OBS! För verifiering enligt testmodell 2.0 skall testsviter och självdeklarationer i releasepaketet för domänversion 2.1_RC4 användas. Gäller kontrakten GetMedicationHistory 2.0 och GetVaccinationHistory 2.0.: vård- och omsorg kärnprocess:hantera aktiviteter:ordinationsutfall
* Beskrivning: Typ
  * Denna domän hanterat information gällande en patients ordinationer, förskrivning och administrering av läkemedel och vaccinationer. OBS! För verifiering enligt testmodell 2.0 skall testsviter och självdeklarationer i releasepaketet för domänversion 2.1_RC4 användas. Gäller kontrakten GetMedicationHistory 2.0 och GetVaccinationHistory 2.0.: Nationell tjänstedomän
* Beskrivning: Förvaltare
  * Denna domän hanterat information gällande en patients ordinationer, förskrivning och administrering av läkemedel och vaccinationer. OBS! För verifiering enligt testmodell 2.0 skall testsviter och självdeklarationer i releasepaketet för domänversion 2.1_RC4 användas. Gäller kontrakten GetMedicationHistory 2.0 och GetVaccinationHistory 2.0.: Tjänstekontraktsförvaltningen, TK-forvaltningen@inera.se
* Beskrivning: Källkod
  * Denna domän hanterat information gällande en patients ordinationer, förskrivning och administrering av läkemedel och vaccinationer. OBS! För verifiering enligt testmodell 2.0 skall testsviter och självdeklarationer i releasepaketet för domänversion 2.1_RC4 användas. Gäller kontrakten GetMedicationHistory 2.0 och GetVaccinationHistory 2.0.: [Bitbucket](https://bitbucket.org/rivta-domains/riv.clinicalprocess.activityprescription.actoutcome/src)
* Beskrivning: Ärenden
  * Denna domän hanterat information gällande en patients ordinationer, förskrivning och administrering av läkemedel och vaccinationer. OBS! För verifiering enligt testmodell 2.0 skall testsviter och självdeklarationer i releasepaketet för domänversion 2.1_RC4 användas. Gäller kontrakten GetMedicationHistory 2.0 och GetVaccinationHistory 2.0.: [Bitbucket issues](https://bitbucket.org/rivta-domains/riv.clinicalprocess.activityprescription.actoutcome/issues)
* Beskrivning: Informationssida
  * Denna domän hanterat information gällande en patients ordinationer, förskrivning och administrering av läkemedel och vaccinationer. OBS! För verifiering enligt testmodell 2.0 skall testsviter och självdeklarationer i releasepaketet för domänversion 2.1_RC4 användas. Gäller kontrakten GetMedicationHistory 2.0 och GetVaccinationHistory 2.0.: [Confluence](https://inera.atlassian.net/wiki/spaces/OITOF/pages/275088118/clinicalprocess+activityprescription+actoutcome+ordinationsutfall)
* Beskrivning: Underlag för denna IG
  * Denna domän hanterat information gällande en patients ordinationer, förskrivning och administrering av läkemedel och vaccinationer. OBS! För verifiering enligt testmodell 2.0 skall testsviter och självdeklarationer i releasepaketet för domänversion 2.1_RC4 användas. Gäller kontrakten GetMedicationHistory 2.0 och GetVaccinationHistory 2.0.: Version 2.2.1 ·[tagg 2.2.1](https://bitbucket.org/rivta-domains/riv.clinicalprocess.activityprescription.actoutcome/src/2.2.1)·[zip](https://bitbucket.org/rivta-domains/riv.clinicalprocess.activityprescription.actoutcome/get/2.2.1.zip)
* Beskrivning: RIV-TA-portalen
  * Denna domän hanterat information gällande en patients ordinationer, förskrivning och administrering av läkemedel och vaccinationer. OBS! För verifiering enligt testmodell 2.0 skall testsviter och självdeklarationer i releasepaketet för domänversion 2.1_RC4 användas. Gäller kontrakten GetMedicationHistory 2.0 och GetVaccinationHistory 2.0.: [Alla tjänstedomäner](https://oskthu2.github.io/tkb-converter/rivta-portal/tjanstedomaner.html)·[Alla tjänstekontrakt](https://oskthu2.github.io/tkb-converter/rivta-portal/tjanstekontrakt.html)

Detta är en FHIR Implementation Guide genererad från TKB-dokumentation för tjänstedomänen **clinicalprocess: activityprescription: actoutcome** version 2.2.1.

Tjänstedomänen möjliggör hantering av information kopplad till patients ordinationer, förskrivning och administrering av läkemedel och vaccinationer. Tjänstekontrakten erbjuder möjlighet att nå information från ett specifikt källsystem eller aggregerat via en nationell tjänsteplattform.

RIV-TA namespace: `urn:riv:clinicalprocess:activityprescription:actoutcome`

## Tjänstekontrakt

Domänen innehåller följande tjänstekontrakt:

| | | |
| :--- | :--- | :--- |
| [GetVaccinationHistory](7-tjanstekontrakt.md#getvaccinationhistory) | 2.0 | Returnerar ordinerade och/eller administrerade vaccinationer för en patient |
| [GetMedicationHistory](7-tjanstekontrakt.md#getmedicationhistory) | 2.2 | Returnerar ordinerade, förskrivna och/eller administrerade läkemedel för en patient |

### Versioner och granskningar

| | | | |
| :--- | :--- | :--- | :--- |
| 2.1.3 | AB, TKB | Arkitektur & Regelverk: Informatik: GodkändArkitektur & Regelverk: Säkerhet: GodkändArkitektur & Regelverk: Teknik: Godkänd | [zip](https://bitbucket.org/rivta-domains/riv.clinicalprocess.activityprescription.actoutcome/get/2.1.3.zip)·[källkod](https://bitbucket.org/rivta-domains/riv.clinicalprocess.activityprescription.actoutcome/src/2.1.3) |
| 1.0.1 | AB, TKB | Äldre granskningsprocess: Teknik: Godkänd | [zip](https://bitbucket.org/rivta-domains/riv.clinicalprocess.activityprescription.actoutcome/get/clinicalprocess_activityprescription_actoutcome_1.0.1.zip)·[källkod](https://bitbucket.org/rivta-domains/riv.clinicalprocess.activityprescription.actoutcome/src/clinicalprocess_activityprescription_actoutcome_1.0.1) |
| trunk | AB, TKB |  | [källkod](https://bitbucket.org/rivta-domains/riv.clinicalprocess.activityprescription.actoutcome/src/master) |

*Zip-arkiven hämtas från taggarna på Bitbucket. Granskningsprotokollen publicerades på rivta.se och länkas inte härifrån.*

*Källa: ögonblicksbild av DOMDB från 2021-08-24, via RIV-TA-portalen.*

## Innehåll

* [1 Inledning](1-inledning.md)
* [2 Versionsinformation](2-versionsinformation.md)
* [3 Tjänstedomänens arkitektur](3-tjanstedomanens-arkitektur.md)
* [4 Tjänstedomänens krav och regler](4-tjanstedomanens-krav-och-regler.md)
* [5 Tjänstedomänens meddelandemodeller](5-tjanstedomanens-meddelandemodeller.md)
* [6 Gemensamma informationskomponenter](6-gemensamma-informationskomponenter.md)
* [7 Tjänstekontrakt](7-tjanstekontrakt.md)

