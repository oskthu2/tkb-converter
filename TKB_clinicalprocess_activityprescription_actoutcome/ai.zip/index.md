# Hem - clinicalprocess: activityprescription: actoutcome v2.2.1

* [**Table of Contents**](toc.md)
* **Hem**

## Hem

| | |
| :--- | :--- |
| *Official URL*:https://fhir.inera.se/ig/clinicalprocess-activityprescription-actoutcome/ImplementationGuide/inera.clinicalprocess-activityprescription-actoutcome | *Version*:2.2.1 |
| Draft as of 2026-09-09 | *Computable Name*:clinicalprocessactivityprescriptionactoutcome |
| **Copyright/Legal**: Copyright 2024 Inera AB. Licensieras under Creative Commons Attribution 4.0. | |

# clinicalprocess: activityprescription: actoutcome

## Översikt

Detta är en FHIR Implementation Guide genererad från TKB-dokumentation för tjänstedomänen **clinicalprocess: activityprescription: actoutcome** version 2.2.1.

Tjänstedomänen möjliggör hantering av information kopplad till patients ordinationer, förskrivning och administrering av läkemedel och vaccinationer. Tjänstekontrakten erbjuder möjlighet att nå information från ett specifikt källsystem eller aggregerat via en nationell tjänsteplattform.

RIV-TA namespace: `urn:riv:clinicalprocess:activityprescription:actoutcome`

## Tjänstekontrakt

Domänen innehåller följande tjänstekontrakt:

| | | |
| :--- | :--- | :--- |
| [GetVaccinationHistory](7-tjanstekontrakt.md#getvaccinationhistory) | 2.0 | Returnerar ordinerade och/eller administrerade vaccinationer för en patient |
| [GetMedicationHistory](7-tjanstekontrakt.md#getmedicationhistory) | 2.2 | Returnerar ordinerade, förskrivna och/eller administrerade läkemedel för en patient |

## Innehåll

* [1 Inledning](1-inledning.md)
* [2 Versionsinformation](2-versionsinformation.md)
* [3 Tjänstedomänens arkitektur](3-tjanstedomanens-arkitektur.md)
* [4 Tjänstedomänens krav och regler](4-tjanstedomanens-krav-och-regler.md)
* [5 Tjänstedomänens meddelandemodeller](5-tjanstedomanens-meddelandemodeller.md)
* [6 Gemensamma informationskomponenter](6-gemensamma-informationskomponenter.md)
* [7 Tjänstekontrakt](7-tjanstekontrakt.md)

