# GetMedicationHistory - clinicalprocess: activityprescription: actoutcome v2.2.1

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **GetMedicationHistory**

## Logical Model: GetMedicationHistory 

| | |
| :--- | :--- |
| *Official URL*:https://fhir.inera.se/ig/clinicalprocess-activityprescription-actoutcome/StructureDefinition/getmedicationhistory | *Version*:2.2.1 |
| Draft as of 2026-09-26 | *Computable Name*:GetMedicationHistory |
| **Copyright/Legal**: Copyright 2024 Inera AB. Licensieras under Creative Commons Attribution 4.0. | |

 
Logisk modell för tjänstekontraktet GetMedicationHistory (RIV-TA urn:riv:clinicalprocess:activityprescription:actoutcome:GetMedicationHistoryResponder:2). Representerar responsens informationsstruktur — läkemedelshistorik per patient. 
OBS: Kontraktet är tämligen omfattande. Se tillämpningsanvisningen (AB_clinicalprocess_activityprescription_actoutcome.docx) för implementationsdetaljer. 

**Usages:**

* This Logical Model is not used by any profiles in this Specification

You can also check for [usages in the FHIR IG Statistics](https://packages2.fhir.org/xig/resource/inera.clinicalprocess-activityprescription-actoutcome|current/StructureDefinition/StructureDefinition-getmedicationhistory.json)

### Formal Views of Profile Content

 [Description of Profiles, Differentials, Snapshots and how the different presentations work](http://build.fhir.org/ig/FHIR/ig-guidance/readingIgs.html#structure-definitions). 

 

Other representations of profile: [CSV](StructureDefinition-getmedicationhistory.csv), [Excel](StructureDefinition-getmedicationhistory.xlsx) 



## Resource Content

```json
{
  "resourceType" : "StructureDefinition",
  "id" : "getmedicationhistory",
  "extension" : [{
    "url" : "http://hl7.org/fhir/StructureDefinition/structuredefinition-type-characteristics",
    "valueCode" : "can-be-target"
  }],
  "url" : "https://fhir.inera.se/ig/clinicalprocess-activityprescription-actoutcome/StructureDefinition/getmedicationhistory",
  "version" : "2.2.1",
  "name" : "GetMedicationHistory",
  "title" : "GetMedicationHistory",
  "status" : "draft",
  "date" : "2026-09-26T19:15:31+00:00",
  "contact" : [{
    "name" : "Inera Arkitektur",
    "telecom" : [{
      "system" : "url",
      "value" : "https://www.inera.se"
    }]
  }],
  "description" : "Logisk modell för tjänstekontraktet GetMedicationHistory\n(RIV-TA urn:riv:clinicalprocess:activityprescription:actoutcome:GetMedicationHistoryResponder:2).\nRepresenterar responsens informationsstruktur — läkemedelshistorik per patient.\n\nOBS: Kontraktet är tämligen omfattande. Se tillämpningsanvisningen\n(AB_clinicalprocess_activityprescription_actoutcome.docx) för implementationsdetaljer.",
  "copyright" : "Copyright 2024 Inera AB. Licensieras under Creative Commons Attribution 4.0.",
  "fhirVersion" : "4.0.1",
  "kind" : "logical",
  "abstract" : false,
  "type" : "https://fhir.inera.se/ig/clinicalprocess-activityprescription-actoutcome/StructureDefinition/getmedicationhistory",
  "baseDefinition" : "http://hl7.org/fhir/StructureDefinition/Base",
  "derivation" : "specialization",
  "differential" : {
    "element" : [{
      "id" : "getmedicationhistory",
      "path" : "getmedicationhistory",
      "short" : "GetMedicationHistory",
      "definition" : "Logisk modell för tjänstekontraktet GetMedicationHistory\n(RIV-TA urn:riv:clinicalprocess:activityprescription:actoutcome:GetMedicationHistoryResponder:2).\nRepresenterar responsens informationsstruktur — läkemedelshistorik per patient.\n\nOBS: Kontraktet är tämligen omfattande. Se tillämpningsanvisningen\n(AB_clinicalprocess_activityprescription_actoutcome.docx) för implementationsdetaljer."
    },
    {
      "id" : "getmedicationhistory.medicationMedicalRecord",
      "path" : "getmedicationhistory.medicationMedicalRecord",
      "short" : "Patientens läkemedelshistorik",
      "definition" : "En läkemedelsjournalpost per ordination. En patient kan ha många poster.\nKardinalitet: Valfri, lista.",
      "min" : 0,
      "max" : "*",
      "type" : [{
        "code" : "BackboneElement"
      }]
    },
    {
      "id" : "getmedicationhistory.medicationMedicalRecord.medicationMedicalRecordHeader",
      "path" : "getmedicationhistory.medicationMedicalRecord.medicationMedicalRecordHeader",
      "short" : "Basinformation om dokumentet",
      "definition" : "Basinformation om dokumentet",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "BackboneElement"
      }]
    },
    {
      "id" : "getmedicationhistory.medicationMedicalRecord.medicationMedicalRecordHeader.documentId",
      "path" : "getmedicationhistory.medicationMedicalRecord.medicationMedicalRecordHeader.documentId",
      "short" : "Identifierare för uppgift (vanligtvis ordinations-id)",
      "definition" : "Vanligtvis ordinations-id eller ordinations-id kompletterat med löpnummer.",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "getmedicationhistory.medicationMedicalRecord.medicationMedicalRecordHeader.sourceSystemHSAId",
      "path" : "getmedicationhistory.medicationMedicalRecord.medicationMedicalRecordHeader.sourceSystemHSAId",
      "short" : "Källsystemets HSA-id",
      "definition" : "Källsystemets HSA-id",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "Identifier"
      }]
    },
    {
      "id" : "getmedicationhistory.medicationMedicalRecord.medicationMedicalRecordHeader.documentTitle",
      "path" : "getmedicationhistory.medicationMedicalRecord.medicationMedicalRecordHeader.documentTitle",
      "short" : "Titel som beskriver informationen",
      "definition" : "Titel som beskriver informationen",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "getmedicationhistory.medicationMedicalRecord.medicationMedicalRecordHeader.patientId",
      "path" : "getmedicationhistory.medicationMedicalRecord.medicationMedicalRecordHeader.patientId",
      "short" : "Personidentifierare för patienten",
      "definition" : "Personidentifierare för patienten",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "Identifier"
      }]
    },
    {
      "id" : "getmedicationhistory.medicationMedicalRecord.medicationMedicalRecordHeader.accountableHealthcareProfessional",
      "path" : "getmedicationhistory.medicationMedicalRecord.medicationMedicalRecordHeader.accountableHealthcareProfessional",
      "short" : "Dokumentationsansvarig",
      "definition" : "Dokumentationsansvarig",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "BackboneElement"
      }]
    },
    {
      "id" : "getmedicationhistory.medicationMedicalRecord.medicationMedicalRecordHeader.accountableHealthcareProfessional.authorTime",
      "path" : "getmedicationhistory.medicationMedicalRecord.medicationMedicalRecordHeader.accountableHealthcareProfessional.authorTime",
      "short" : "Tidpunkt för dokumentation",
      "definition" : "Tidpunkt för dokumentation",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "instant"
      }]
    },
    {
      "id" : "getmedicationhistory.medicationMedicalRecord.medicationMedicalRecordHeader.accountableHealthcareProfessional.healthcareProfessionalHSAId",
      "path" : "getmedicationhistory.medicationMedicalRecord.medicationMedicalRecordHeader.accountableHealthcareProfessional.healthcareProfessionalHSAId",
      "short" : "HSA-id för personal",
      "definition" : "HSA-id för personal",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "Identifier"
      }]
    },
    {
      "id" : "getmedicationhistory.medicationMedicalRecord.medicationMedicalRecordHeader.accountableHealthcareProfessional.healthcareProfessionalName",
      "path" : "getmedicationhistory.medicationMedicalRecord.medicationMedicalRecordHeader.accountableHealthcareProfessional.healthcareProfessionalName",
      "short" : "Namn på personal",
      "definition" : "Namn på personal",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "getmedicationhistory.medicationMedicalRecord.medicationMedicalRecordHeader.accountableHealthcareProfessional.healthcareProfessionalRoleCode",
      "path" : "getmedicationhistory.medicationMedicalRecord.medicationMedicalRecordHeader.accountableHealthcareProfessional.healthcareProfessionalRoleCode",
      "short" : "Befattning (KV Befattning OID 1.2.752.129.2.2.1.4)",
      "definition" : "Befattning (KV Befattning OID 1.2.752.129.2.2.1.4)",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "CodeableConcept"
      }]
    },
    {
      "id" : "getmedicationhistory.medicationMedicalRecord.medicationMedicalRecordHeader.accountableHealthcareProfessional.healthcareProfessionalOrgUnit",
      "path" : "getmedicationhistory.medicationMedicalRecord.medicationMedicalRecordHeader.accountableHealthcareProfessional.healthcareProfessionalOrgUnit",
      "short" : "Organisationsenhet",
      "definition" : "Organisationsenhet",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "BackboneElement"
      }]
    },
    {
      "id" : "getmedicationhistory.medicationMedicalRecord.medicationMedicalRecordHeader.accountableHealthcareProfessional.healthcareProfessionalOrgUnit.orgUnitHSAId",
      "path" : "getmedicationhistory.medicationMedicalRecord.medicationMedicalRecordHeader.accountableHealthcareProfessional.healthcareProfessionalOrgUnit.orgUnitHSAId",
      "short" : "HSA-id för organisationsenhet",
      "definition" : "HSA-id för organisationsenhet",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "Identifier"
      }]
    },
    {
      "id" : "getmedicationhistory.medicationMedicalRecord.medicationMedicalRecordHeader.accountableHealthcareProfessional.healthcareProfessionalOrgUnit.orgUnitName",
      "path" : "getmedicationhistory.medicationMedicalRecord.medicationMedicalRecordHeader.accountableHealthcareProfessional.healthcareProfessionalOrgUnit.orgUnitName",
      "short" : "Namn på organisationsenhet",
      "definition" : "Namn på organisationsenhet",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "getmedicationhistory.medicationMedicalRecord.medicationMedicalRecordHeader.accountableHealthcareProfessional.healthcareProfessionalOrgUnit.orgUnitTelecom",
      "path" : "getmedicationhistory.medicationMedicalRecord.medicationMedicalRecordHeader.accountableHealthcareProfessional.healthcareProfessionalOrgUnit.orgUnitTelecom",
      "short" : "Telefon",
      "definition" : "Telefon",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "getmedicationhistory.medicationMedicalRecord.medicationMedicalRecordHeader.accountableHealthcareProfessional.healthcareProfessionalOrgUnit.orgUnitEmail",
      "path" : "getmedicationhistory.medicationMedicalRecord.medicationMedicalRecordHeader.accountableHealthcareProfessional.healthcareProfessionalOrgUnit.orgUnitEmail",
      "short" : "E-post",
      "definition" : "E-post",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "getmedicationhistory.medicationMedicalRecord.medicationMedicalRecordHeader.accountableHealthcareProfessional.healthcareProfessionalOrgUnit.orgUnitAddress",
      "path" : "getmedicationhistory.medicationMedicalRecord.medicationMedicalRecordHeader.accountableHealthcareProfessional.healthcareProfessionalOrgUnit.orgUnitAddress",
      "short" : "Postadress",
      "definition" : "Postadress",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "getmedicationhistory.medicationMedicalRecord.medicationMedicalRecordHeader.accountableHealthcareProfessional.healthcareProfessionalOrgUnit.orgUnitLocation",
      "path" : "getmedicationhistory.medicationMedicalRecord.medicationMedicalRecordHeader.accountableHealthcareProfessional.healthcareProfessionalOrgUnit.orgUnitLocation",
      "short" : "Plats/ort",
      "definition" : "Plats/ort",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "getmedicationhistory.medicationMedicalRecord.medicationMedicalRecordHeader.accountableHealthcareProfessional.healthcareProfessionalcareUnitHSAId",
      "path" : "getmedicationhistory.medicationMedicalRecord.medicationMedicalRecordHeader.accountableHealthcareProfessional.healthcareProfessionalcareUnitHSAId",
      "short" : "HSA-id för vårdenhet",
      "definition" : "HSA-id för vårdenhet",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "Identifier"
      }]
    },
    {
      "id" : "getmedicationhistory.medicationMedicalRecord.medicationMedicalRecordHeader.accountableHealthcareProfessional.healthcareProfessionalcareGiverHSAId",
      "path" : "getmedicationhistory.medicationMedicalRecord.medicationMedicalRecordHeader.accountableHealthcareProfessional.healthcareProfessionalcareGiverHSAId",
      "short" : "HSA-id/id för vårdgivare",
      "definition" : "HSA-id/id för vårdgivare",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "Identifier"
      }]
    },
    {
      "id" : "getmedicationhistory.medicationMedicalRecord.medicationMedicalRecordHeader.legalAuthenticator",
      "path" : "getmedicationhistory.medicationMedicalRecord.medicationMedicalRecordHeader.legalAuthenticator",
      "short" : "Information om signering",
      "definition" : "Information om signering",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "BackboneElement"
      }]
    },
    {
      "id" : "getmedicationhistory.medicationMedicalRecord.medicationMedicalRecordHeader.legalAuthenticator.signatureTime",
      "path" : "getmedicationhistory.medicationMedicalRecord.medicationMedicalRecordHeader.legalAuthenticator.signatureTime",
      "short" : "Tidpunkt för signering",
      "definition" : "Tidpunkt för signering",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "instant"
      }]
    },
    {
      "id" : "getmedicationhistory.medicationMedicalRecord.medicationMedicalRecordHeader.legalAuthenticator.legalAuthenticatorHSAId",
      "path" : "getmedicationhistory.medicationMedicalRecord.medicationMedicalRecordHeader.legalAuthenticator.legalAuthenticatorHSAId",
      "short" : "HSA-id för signerande personal",
      "definition" : "HSA-id för signerande personal",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "Identifier"
      }]
    },
    {
      "id" : "getmedicationhistory.medicationMedicalRecord.medicationMedicalRecordHeader.legalAuthenticator.legalAuthenticatorName",
      "path" : "getmedicationhistory.medicationMedicalRecord.medicationMedicalRecordHeader.legalAuthenticator.legalAuthenticatorName",
      "short" : "Namn på signerande personal",
      "definition" : "Namn på signerande personal",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "getmedicationhistory.medicationMedicalRecord.medicationMedicalRecordHeader.approvedForPatient",
      "path" : "getmedicationhistory.medicationMedicalRecord.medicationMedicalRecordHeader.approvedForPatient",
      "short" : "Ansvarig vårdpersonals beslut om synlighet (PDL-prövning)",
      "definition" : "Ansvarig vårdpersonals beslut om synlighet (PDL-prövning)",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "boolean"
      }]
    },
    {
      "id" : "getmedicationhistory.medicationMedicalRecord.medicationMedicalRecordHeader.careContactId",
      "path" : "getmedicationhistory.medicationMedicalRecord.medicationMedicalRecordHeader.careContactId",
      "short" : "Identitet för vård- och omsorgskontakt",
      "definition" : "Identitet för vård- och omsorgskontakt",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "getmedicationhistory.medicationMedicalRecord.medicationMedicalRecordBody",
      "path" : "getmedicationhistory.medicationMedicalRecord.medicationMedicalRecordBody",
      "short" : "Läkemedelshistorikens innehåll",
      "definition" : "Läkemedelshistorikens innehåll",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "BackboneElement"
      }]
    },
    {
      "id" : "getmedicationhistory.medicationMedicalRecord.medicationMedicalRecordBody.medicationPrescription",
      "path" : "getmedicationhistory.medicationMedicalRecord.medicationMedicalRecordBody.medicationPrescription",
      "short" : "Läkemedelsordination",
      "definition" : "Läkemedelsordination",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "BackboneElement"
      }]
    },
    {
      "id" : "getmedicationhistory.medicationMedicalRecord.medicationMedicalRecordBody.medicationPrescription.prescriptionId",
      "path" : "getmedicationhistory.medicationMedicalRecord.medicationMedicalRecordBody.medicationPrescription.prescriptionId",
      "short" : "Ordinations-id",
      "definition" : "Unik identifierare för aktuell läkemedelsordination.\nroot = UUID eller OID som pekar på källsystem.\nextension = ordinations-id unikt inom källsystemet.",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "Identifier"
      }]
    },
    {
      "id" : "getmedicationhistory.medicationMedicalRecord.medicationMedicalRecordBody.medicationPrescription.typeOfPrescription",
      "path" : "getmedicationhistory.medicationMedicalRecord.medicationMedicalRecordBody.medicationPrescription.typeOfPrescription",
      "short" : "Ordinationstyp (I=insättning, U=utsättning)",
      "definition" : "Ordinationstyp (I=insättning, U=utsättning)",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "code"
      }],
      "binding" : {
        "strength" : "required",
        "valueSet" : "https://fhir.inera.se/ig/clinicalprocess-activityprescription-actoutcome/ValueSet/typeofprescription-vs"
      }
    },
    {
      "id" : "getmedicationhistory.medicationMedicalRecord.medicationMedicalRecordBody.medicationPrescription.prescriptionStatus",
      "path" : "getmedicationhistory.medicationMedicalRecord.medicationMedicalRecordBody.medicationPrescription.prescriptionStatus",
      "short" : "Ordinationsstatus (Active/Inactive)",
      "definition" : "Ordinationsstatus (Active/Inactive)",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "code"
      }],
      "binding" : {
        "strength" : "required",
        "valueSet" : "https://fhir.inera.se/ig/clinicalprocess-activityprescription-actoutcome/ValueSet/prescriptionstatus-vs"
      }
    },
    {
      "id" : "getmedicationhistory.medicationMedicalRecord.medicationMedicalRecordBody.medicationPrescription.prescriptionNote",
      "path" : "getmedicationhistory.medicationMedicalRecord.medicationMedicalRecordBody.medicationPrescription.prescriptionNote",
      "short" : "Notat om ordinationen (del av Läkemedelsberättelse)",
      "definition" : "Notat om ordinationen (del av Läkemedelsberättelse)",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "getmedicationhistory.medicationMedicalRecord.medicationMedicalRecordBody.medicationPrescription.principalPrescriptionReason",
      "path" : "getmedicationhistory.medicationMedicalRecord.medicationMedicalRecordBody.medicationPrescription.principalPrescriptionReason",
      "short" : "Ordinationshuvudorsak",
      "definition" : "Den eller de viktigaste av de ordinationsorsaker som anges.\nAnges med Socialstyrelsens kodsystem för ordinationsorsaker.",
      "min" : 0,
      "max" : "*",
      "type" : [{
        "code" : "BackboneElement"
      }]
    },
    {
      "id" : "getmedicationhistory.medicationMedicalRecord.medicationMedicalRecordBody.medicationPrescription.principalPrescriptionReason.reason",
      "path" : "getmedicationhistory.medicationMedicalRecord.medicationMedicalRecordBody.medicationPrescription.principalPrescriptionReason.reason",
      "short" : "Ordinationsorsak (Socialstyrelsens kodsystem)",
      "definition" : "Ordinationsorsak (Socialstyrelsens kodsystem)",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "CodeableConcept"
      }]
    },
    {
      "id" : "getmedicationhistory.medicationMedicalRecord.medicationMedicalRecordBody.medicationPrescription.principalPrescriptionReason.otherReason",
      "path" : "getmedicationhistory.medicationMedicalRecord.medicationMedicalRecordBody.medicationPrescription.principalPrescriptionReason.otherReason",
      "short" : "Beskrivning om 'Annan ordinationsorsak' väljs",
      "definition" : "Beskrivning om 'Annan ordinationsorsak' väljs",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "getmedicationhistory.medicationMedicalRecord.medicationMedicalRecordBody.medicationPrescription.additionalPrescriptionReason",
      "path" : "getmedicationhistory.medicationMedicalRecord.medicationMedicalRecordBody.medicationPrescription.additionalPrescriptionReason",
      "short" : "Övriga ordinationsorsaker",
      "definition" : "Anges en övrig ordinationsorsak måste minst en ordinationshuvudorsak vara angiven.",
      "min" : 0,
      "max" : "*",
      "type" : [{
        "code" : "BackboneElement"
      }]
    },
    {
      "id" : "getmedicationhistory.medicationMedicalRecord.medicationMedicalRecordBody.medicationPrescription.additionalPrescriptionReason.reason",
      "path" : "getmedicationhistory.medicationMedicalRecord.medicationMedicalRecordBody.medicationPrescription.additionalPrescriptionReason.reason",
      "short" : "Ordinationsorsak",
      "definition" : "Ordinationsorsak",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "CodeableConcept"
      }]
    },
    {
      "id" : "getmedicationhistory.medicationMedicalRecord.medicationMedicalRecordBody.medicationPrescription.additionalPrescriptionReason.otherReason",
      "path" : "getmedicationhistory.medicationMedicalRecord.medicationMedicalRecordBody.medicationPrescription.additionalPrescriptionReason.otherReason",
      "short" : "Beskrivning om 'Annan ordinationsorsak' väljs",
      "definition" : "Beskrivning om 'Annan ordinationsorsak' väljs",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "getmedicationhistory.medicationMedicalRecord.medicationMedicalRecordBody.medicationPrescription.evaluationTime",
      "path" : "getmedicationhistory.medicationMedicalRecord.medicationMedicalRecordBody.medicationPrescription.evaluationTime",
      "short" : "Nästa planerade utvärderingstidpunkt",
      "definition" : "Nästa planerade utvärderingstidpunkt",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "instant"
      }]
    },
    {
      "id" : "getmedicationhistory.medicationMedicalRecord.medicationMedicalRecordBody.medicationPrescription.treatmentPurpose",
      "path" : "getmedicationhistory.medicationMedicalRecord.medicationMedicalRecordBody.medicationPrescription.treatmentPurpose",
      "short" : "Behandlingsändamål",
      "definition" : "Behandlingsändamål",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "getmedicationhistory.medicationMedicalRecord.medicationMedicalRecordBody.medicationPrescription.prescriptionChainId",
      "path" : "getmedicationhistory.medicationMedicalRecord.medicationMedicalRecordBody.medicationPrescription.prescriptionChainId",
      "short" : "Ordinationskedje-id",
      "definition" : "Ordinationskedje-id",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "Identifier"
      }]
    },
    {
      "id" : "getmedicationhistory.medicationMedicalRecord.medicationMedicalRecordBody.medicationPrescription.precedingPrescriptionId",
      "path" : "getmedicationhistory.medicationMedicalRecord.medicationMedicalRecordBody.medicationPrescription.precedingPrescriptionId",
      "short" : "Föregående ordinations-id",
      "definition" : "Föregående ordinations-id",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "Identifier"
      }]
    },
    {
      "id" : "getmedicationhistory.medicationMedicalRecord.medicationMedicalRecordBody.medicationPrescription.succeedingPrescriptionId",
      "path" : "getmedicationhistory.medicationMedicalRecord.medicationMedicalRecordBody.medicationPrescription.succeedingPrescriptionId",
      "short" : "Efterföljande ordinations-id",
      "definition" : "Efterföljande ordinations-id",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "Identifier"
      }]
    },
    {
      "id" : "getmedicationhistory.medicationMedicalRecord.medicationMedicalRecordBody.medicationPrescription.prescriber",
      "path" : "getmedicationhistory.medicationMedicalRecord.medicationMedicalRecordBody.medicationPrescription.prescriber",
      "short" : "Ordinatör",
      "definition" : "Icke att beblandas med accountableHealthcareProfessional (den som registrerat).",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "BackboneElement"
      }]
    },
    {
      "id" : "getmedicationhistory.medicationMedicalRecord.medicationMedicalRecordBody.medicationPrescription.prescriber.authorTime",
      "path" : "getmedicationhistory.medicationMedicalRecord.medicationMedicalRecordBody.medicationPrescription.prescriber.authorTime",
      "short" : "Beslutstidpunkt/ordinationstidpunkt",
      "definition" : "Beslutstidpunkt/ordinationstidpunkt",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "instant"
      }]
    },
    {
      "id" : "getmedicationhistory.medicationMedicalRecord.medicationMedicalRecordBody.medicationPrescription.prescriber.healthcareProfessionalHSAId",
      "path" : "getmedicationhistory.medicationMedicalRecord.medicationMedicalRecordBody.medicationPrescription.prescriber.healthcareProfessionalHSAId",
      "short" : "Ordinatörens HSA-id",
      "definition" : "Ordinatörens HSA-id",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "Identifier"
      }]
    },
    {
      "id" : "getmedicationhistory.medicationMedicalRecord.medicationMedicalRecordBody.medicationPrescription.prescriber.healthcareProfessionalName",
      "path" : "getmedicationhistory.medicationMedicalRecord.medicationMedicalRecordBody.medicationPrescription.prescriber.healthcareProfessionalName",
      "short" : "Namn på ordinatören",
      "definition" : "Namn på ordinatören",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "getmedicationhistory.medicationMedicalRecord.medicationMedicalRecordBody.medicationPrescription.prescriber.healthcareProfessionalRoleCode",
      "path" : "getmedicationhistory.medicationMedicalRecord.medicationMedicalRecordBody.medicationPrescription.prescriber.healthcareProfessionalRoleCode",
      "short" : "Ordinatörens befattning",
      "definition" : "Ordinatörens befattning",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "CodeableConcept"
      }]
    },
    {
      "id" : "getmedicationhistory.medicationMedicalRecord.medicationMedicalRecordBody.medicationPrescription.prescriber.healthcareProfessionalOrgUnit",
      "path" : "getmedicationhistory.medicationMedicalRecord.medicationMedicalRecordBody.medicationPrescription.prescriber.healthcareProfessionalOrgUnit",
      "short" : "Organisation ordinatören är uppdragstagare på",
      "definition" : "Organisation ordinatören är uppdragstagare på",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "BackboneElement"
      }]
    },
    {
      "id" : "getmedicationhistory.medicationMedicalRecord.medicationMedicalRecordBody.medicationPrescription.prescriber.healthcareProfessionalOrgUnit.orgUnitHSAId",
      "path" : "getmedicationhistory.medicationMedicalRecord.medicationMedicalRecordBody.medicationPrescription.prescriber.healthcareProfessionalOrgUnit.orgUnitHSAId",
      "short" : "HSA-id",
      "definition" : "HSA-id",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "Identifier"
      }]
    },
    {
      "id" : "getmedicationhistory.medicationMedicalRecord.medicationMedicalRecordBody.medicationPrescription.prescriber.healthcareProfessionalOrgUnit.orgUnitName",
      "path" : "getmedicationhistory.medicationMedicalRecord.medicationMedicalRecordBody.medicationPrescription.prescriber.healthcareProfessionalOrgUnit.orgUnitName",
      "short" : "Namn",
      "definition" : "Namn",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "getmedicationhistory.medicationMedicalRecord.medicationMedicalRecordBody.medicationPrescription.prescriber.healthcareProfessionalOrgUnit.orgUnitTelecom",
      "path" : "getmedicationhistory.medicationMedicalRecord.medicationMedicalRecordBody.medicationPrescription.prescriber.healthcareProfessionalOrgUnit.orgUnitTelecom",
      "short" : "Telefon",
      "definition" : "Telefon",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "getmedicationhistory.medicationMedicalRecord.medicationMedicalRecordBody.medicationPrescription.prescriber.healthcareProfessionalOrgUnit.orgUnitEmail",
      "path" : "getmedicationhistory.medicationMedicalRecord.medicationMedicalRecordBody.medicationPrescription.prescriber.healthcareProfessionalOrgUnit.orgUnitEmail",
      "short" : "E-post",
      "definition" : "E-post",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "getmedicationhistory.medicationMedicalRecord.medicationMedicalRecordBody.medicationPrescription.prescriber.healthcareProfessionalOrgUnit.orgUnitAddress",
      "path" : "getmedicationhistory.medicationMedicalRecord.medicationMedicalRecordBody.medicationPrescription.prescriber.healthcareProfessionalOrgUnit.orgUnitAddress",
      "short" : "Postadress",
      "definition" : "Postadress",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "getmedicationhistory.medicationMedicalRecord.medicationMedicalRecordBody.medicationPrescription.prescriber.healthcareProfessionalOrgUnit.orgUnitLocation",
      "path" : "getmedicationhistory.medicationMedicalRecord.medicationMedicalRecordBody.medicationPrescription.prescriber.healthcareProfessionalOrgUnit.orgUnitLocation",
      "short" : "Plats/ort",
      "definition" : "Plats/ort",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "getmedicationhistory.medicationMedicalRecord.medicationMedicalRecordBody.medicationPrescription.evaluator",
      "path" : "getmedicationhistory.medicationMedicalRecord.medicationMedicalRecordBody.medicationPrescription.evaluator",
      "short" : "'Utvärderat av' — person som utvärderat utfallet",
      "definition" : "'Utvärderat av' — person som utvärderat utfallet",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "BackboneElement"
      }]
    },
    {
      "id" : "getmedicationhistory.medicationMedicalRecord.medicationMedicalRecordBody.medicationPrescription.evaluator.authorTime",
      "path" : "getmedicationhistory.medicationMedicalRecord.medicationMedicalRecordBody.medicationPrescription.evaluator.authorTime",
      "short" : "Faktisk utvärderingstidpunkt",
      "definition" : "Faktisk utvärderingstidpunkt",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "instant"
      }]
    },
    {
      "id" : "getmedicationhistory.medicationMedicalRecord.medicationMedicalRecordBody.medicationPrescription.evaluator.healthcareProfessionalHSAId",
      "path" : "getmedicationhistory.medicationMedicalRecord.medicationMedicalRecordBody.medicationPrescription.evaluator.healthcareProfessionalHSAId",
      "short" : "Utvärderande persons HSA-id",
      "definition" : "Utvärderande persons HSA-id",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "Identifier"
      }]
    },
    {
      "id" : "getmedicationhistory.medicationMedicalRecord.medicationMedicalRecordBody.medicationPrescription.evaluator.healthcareProfessionalName",
      "path" : "getmedicationhistory.medicationMedicalRecord.medicationMedicalRecordBody.medicationPrescription.evaluator.healthcareProfessionalName",
      "short" : "Namn på utvärderande person",
      "definition" : "Namn på utvärderande person",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "getmedicationhistory.medicationMedicalRecord.medicationMedicalRecordBody.medicationPrescription.evaluator.healthcareProfessionalRoleCode",
      "path" : "getmedicationhistory.medicationMedicalRecord.medicationMedicalRecordBody.medicationPrescription.evaluator.healthcareProfessionalRoleCode",
      "short" : "Utvärderande persons befattning",
      "definition" : "Utvärderande persons befattning",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "CodeableConcept"
      }]
    },
    {
      "id" : "getmedicationhistory.medicationMedicalRecord.medicationMedicalRecordBody.medicationPrescription.evaluator.healthcareProfessionalOrgUnit",
      "path" : "getmedicationhistory.medicationMedicalRecord.medicationMedicalRecordBody.medicationPrescription.evaluator.healthcareProfessionalOrgUnit",
      "short" : "Utvärderande persons organisation",
      "definition" : "Utvärderande persons organisation",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "BackboneElement"
      }]
    },
    {
      "id" : "getmedicationhistory.medicationMedicalRecord.medicationMedicalRecordBody.medicationPrescription.evaluator.healthcareProfessionalOrgUnit.orgUnitHSAId",
      "path" : "getmedicationhistory.medicationMedicalRecord.medicationMedicalRecordBody.medicationPrescription.evaluator.healthcareProfessionalOrgUnit.orgUnitHSAId",
      "short" : "HSA-id",
      "definition" : "HSA-id",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "Identifier"
      }]
    },
    {
      "id" : "getmedicationhistory.medicationMedicalRecord.medicationMedicalRecordBody.medicationPrescription.evaluator.healthcareProfessionalOrgUnit.orgUnitName",
      "path" : "getmedicationhistory.medicationMedicalRecord.medicationMedicalRecordBody.medicationPrescription.evaluator.healthcareProfessionalOrgUnit.orgUnitName",
      "short" : "Namn",
      "definition" : "Namn",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "getmedicationhistory.medicationMedicalRecord.medicationMedicalRecordBody.medicationPrescription.startOfFirstTreatment",
      "path" : "getmedicationhistory.medicationMedicalRecord.medicationMedicalRecordBody.medicationPrescription.startOfFirstTreatment",
      "short" : "Första insättningstidpunkt (beräknad från ordinationskedjan)",
      "definition" : "Första insättningstidpunkt (beräknad från ordinationskedjan)",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "instant"
      }]
    },
    {
      "id" : "getmedicationhistory.medicationMedicalRecord.medicationMedicalRecordBody.medicationPrescription.startOfTreatment",
      "path" : "getmedicationhistory.medicationMedicalRecord.medicationMedicalRecordBody.medicationPrescription.startOfTreatment",
      "short" : "Insättningstidpunkt",
      "definition" : "Insättningstidpunkt",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "instant"
      }]
    },
    {
      "id" : "getmedicationhistory.medicationMedicalRecord.medicationMedicalRecordBody.medicationPrescription.endOfTreatment",
      "path" : "getmedicationhistory.medicationMedicalRecord.medicationMedicalRecordBody.medicationPrescription.endOfTreatment",
      "short" : "Utsättningstidpunkt",
      "definition" : "Utsättningstidpunkt",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "instant"
      }]
    },
    {
      "id" : "getmedicationhistory.medicationMedicalRecord.medicationMedicalRecordBody.medicationPrescription.endOfTreatmentReason",
      "path" : "getmedicationhistory.medicationMedicalRecord.medicationMedicalRecordBody.medicationPrescription.endOfTreatmentReason",
      "short" : "Utsättningsorsak",
      "definition" : "Utsättningsorsak",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "CodeableConcept"
      }]
    },
    {
      "id" : "getmedicationhistory.medicationMedicalRecord.medicationMedicalRecordBody.medicationPrescription.selfMedication",
      "path" : "getmedicationhistory.medicationMedicalRecord.medicationMedicalRecordBody.medicationPrescription.selfMedication",
      "short" : "Anger om ordination är utfärdad av patienten själv",
      "definition" : "Anger om ordination är utfärdad av patienten själv",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "boolean"
      }]
    },
    {
      "id" : "getmedicationhistory.medicationMedicalRecord.medicationMedicalRecordBody.medicationPrescription.drug",
      "path" : "getmedicationhistory.medicationMedicalRecord.medicationMedicalRecordBody.medicationPrescription.drug",
      "short" : "Läkemedelsval (ett av: unstructured/merchandise/drugArticle/drug/generics)",
      "definition" : "OBS: Ett och endast ett av följande alternativ ska anges.\nASSUME-ACT-003: XOR-villkor kan inte uttryckas direkt i FSH-kardinaliteten (alla är 0..1).",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "BackboneElement"
      }]
    },
    {
      "id" : "getmedicationhistory.medicationMedicalRecord.medicationMedicalRecordBody.medicationPrescription.drug.comment",
      "path" : "getmedicationhistory.medicationMedicalRecord.medicationMedicalRecordBody.medicationPrescription.drug.comment",
      "short" : "Kommentar om läkemedelsval",
      "definition" : "Kommentar om läkemedelsval",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "getmedicationhistory.medicationMedicalRecord.medicationMedicalRecordBody.medicationPrescription.drug.unstructuredDrugInformation",
      "path" : "getmedicationhistory.medicationMedicalRecord.medicationMedicalRecordBody.medicationPrescription.drug.unstructuredDrugInformation",
      "short" : "Fritextval (extemporeberedning, licensläkemedel m.m.)",
      "definition" : "Fritextval (extemporeberedning, licensläkemedel m.m.)",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "BackboneElement"
      }]
    },
    {
      "id" : "getmedicationhistory.medicationMedicalRecord.medicationMedicalRecordBody.medicationPrescription.drug.unstructuredDrugInformation.unstructuredInformation",
      "path" : "getmedicationhistory.medicationMedicalRecord.medicationMedicalRecordBody.medicationPrescription.drug.unstructuredDrugInformation.unstructuredInformation",
      "short" : "Fritextbeskrivning",
      "definition" : "Fritextbeskrivning",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "getmedicationhistory.medicationMedicalRecord.medicationMedicalRecordBody.medicationPrescription.drug.merchandise",
      "path" : "getmedicationhistory.medicationMedicalRecord.medicationMedicalRecordBody.medicationPrescription.drug.merchandise",
      "short" : "Handelsvara",
      "definition" : "Handelsvara",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "BackboneElement"
      }]
    },
    {
      "id" : "getmedicationhistory.medicationMedicalRecord.medicationMedicalRecordBody.medicationPrescription.drug.merchandise.articleNumber",
      "path" : "getmedicationhistory.medicationMedicalRecord.medicationMedicalRecordBody.medicationPrescription.drug.merchandise.articleNumber",
      "short" : "Varunummer (från SIL)",
      "definition" : "Varunummer (från SIL)",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "CodeableConcept"
      }]
    },
    {
      "id" : "getmedicationhistory.medicationMedicalRecord.medicationMedicalRecordBody.medicationPrescription.drug.drugArticle",
      "path" : "getmedicationhistory.medicationMedicalRecord.medicationMedicalRecordBody.medicationPrescription.drug.drugArticle",
      "short" : "Läkemedelsartikel",
      "definition" : "Läkemedelsartikel",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "BackboneElement"
      }]
    },
    {
      "id" : "getmedicationhistory.medicationMedicalRecord.medicationMedicalRecordBody.medicationPrescription.drug.drugArticle.nplPackId",
      "path" : "getmedicationhistory.medicationMedicalRecord.medicationMedicalRecordBody.medicationPrescription.drug.drugArticle.nplPackId",
      "short" : "NPL pack-id (OID 1.2.752.129.2.1.5.2)",
      "definition" : "NPL pack-id (OID 1.2.752.129.2.1.5.2)",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "CodeableConcept"
      }]
    },
    {
      "id" : "getmedicationhistory.medicationMedicalRecord.medicationMedicalRecordBody.medicationPrescription.drug.drug",
      "path" : "getmedicationhistory.medicationMedicalRecord.medicationMedicalRecordBody.medicationPrescription.drug.drug",
      "short" : "Läkemedelsprodukt",
      "definition" : "Läkemedelsprodukt",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "BackboneElement"
      }]
    },
    {
      "id" : "getmedicationhistory.medicationMedicalRecord.medicationMedicalRecordBody.medicationPrescription.drug.drug.nplId",
      "path" : "getmedicationhistory.medicationMedicalRecord.medicationMedicalRecordBody.medicationPrescription.drug.drug.nplId",
      "short" : "NPL-id (OID 1.2.752.129.2.1.5.1)",
      "definition" : "NPL-id (OID 1.2.752.129.2.1.5.1)",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "CodeableConcept"
      }]
    },
    {
      "id" : "getmedicationhistory.medicationMedicalRecord.medicationMedicalRecordBody.medicationPrescription.drug.drug.atcCode",
      "path" : "getmedicationhistory.medicationMedicalRecord.medicationMedicalRecordBody.medicationPrescription.drug.drug.atcCode",
      "short" : "ATC-kod (OID 1.2.752.129.2.2.3.1.1)",
      "definition" : "ATC-kod (OID 1.2.752.129.2.2.3.1.1)",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "CodeableConcept"
      }]
    },
    {
      "id" : "getmedicationhistory.medicationMedicalRecord.medicationMedicalRecordBody.medicationPrescription.drug.drug.routeOfAdministration",
      "path" : "getmedicationhistory.medicationMedicalRecord.medicationMedicalRecordBody.medicationPrescription.drug.drug.routeOfAdministration",
      "short" : "Administreringssätt",
      "definition" : "Administreringssätt",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "CodeableConcept"
      }]
    },
    {
      "id" : "getmedicationhistory.medicationMedicalRecord.medicationMedicalRecordBody.medicationPrescription.drug.drug.pharmaceuticalForm",
      "path" : "getmedicationhistory.medicationMedicalRecord.medicationMedicalRecordBody.medicationPrescription.drug.drug.pharmaceuticalForm",
      "short" : "Läkemedelsform (t.ex. Tablett)",
      "definition" : "Läkemedelsform (t.ex. Tablett)",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "getmedicationhistory.medicationMedicalRecord.medicationMedicalRecordBody.medicationPrescription.drug.drug.strength",
      "path" : "getmedicationhistory.medicationMedicalRecord.medicationMedicalRecordBody.medicationPrescription.drug.drug.strength",
      "short" : "Styrka (t.ex. 20.0)",
      "definition" : "Styrka (t.ex. 20.0)",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "decimal"
      }]
    },
    {
      "id" : "getmedicationhistory.medicationMedicalRecord.medicationMedicalRecordBody.medicationPrescription.drug.drug.strengthUnit",
      "path" : "getmedicationhistory.medicationMedicalRecord.medicationMedicalRecordBody.medicationPrescription.drug.drug.strengthUnit",
      "short" : "Enhet på styrka (t.ex. mg)",
      "definition" : "Enhet på styrka (t.ex. mg)",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "getmedicationhistory.medicationMedicalRecord.medicationMedicalRecordBody.medicationPrescription.drug.generics",
      "path" : "getmedicationhistory.medicationMedicalRecord.medicationMedicalRecordBody.medicationPrescription.drug.generics",
      "short" : "Generiskt läkemedelsval",
      "definition" : "Generiskt läkemedelsval",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "BackboneElement"
      }]
    },
    {
      "id" : "getmedicationhistory.medicationMedicalRecord.medicationMedicalRecordBody.medicationPrescription.drug.generics.substance",
      "path" : "getmedicationhistory.medicationMedicalRecord.medicationMedicalRecordBody.medicationPrescription.drug.generics.substance",
      "short" : "Substansgrupp",
      "definition" : "Substansgrupp",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "getmedicationhistory.medicationMedicalRecord.medicationMedicalRecordBody.medicationPrescription.drug.generics.strength",
      "path" : "getmedicationhistory.medicationMedicalRecord.medicationMedicalRecordBody.medicationPrescription.drug.generics.strength",
      "short" : "Önskad styrka",
      "definition" : "Önskad styrka",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "Quantity"
      }]
    },
    {
      "id" : "getmedicationhistory.medicationMedicalRecord.medicationMedicalRecordBody.medicationPrescription.drug.generics.form",
      "path" : "getmedicationhistory.medicationMedicalRecord.medicationMedicalRecordBody.medicationPrescription.drug.generics.form",
      "short" : "Läkemedelsform",
      "definition" : "Läkemedelsform",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "getmedicationhistory.medicationMedicalRecord.medicationMedicalRecordBody.medicationPrescription.dosage",
      "path" : "getmedicationhistory.medicationMedicalRecord.medicationMedicalRecordBody.medicationPrescription.dosage",
      "short" : "Dosering",
      "definition" : "Dosering",
      "min" : 0,
      "max" : "*",
      "type" : [{
        "code" : "BackboneElement"
      }]
    },
    {
      "id" : "getmedicationhistory.medicationMedicalRecord.medicationMedicalRecordBody.medicationPrescription.dosage.lengthOfTreatment",
      "path" : "getmedicationhistory.medicationMedicalRecord.medicationMedicalRecordBody.medicationPrescription.dosage.lengthOfTreatment",
      "short" : "Behandlingstid",
      "definition" : "Behandlingstid",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "BackboneElement"
      }]
    },
    {
      "id" : "getmedicationhistory.medicationMedicalRecord.medicationMedicalRecordBody.medicationPrescription.dosage.lengthOfTreatment.treatmentInterval",
      "path" : "getmedicationhistory.medicationMedicalRecord.medicationMedicalRecordBody.medicationPrescription.dosage.lengthOfTreatment.treatmentInterval",
      "short" : "Tidsintervall för behandling (PQIntervalType)",
      "definition" : "Tidsintervall för behandling (PQIntervalType)",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "Range"
      }]
    },
    {
      "id" : "getmedicationhistory.medicationMedicalRecord.medicationMedicalRecordBody.medicationPrescription.dosage.lengthOfTreatment.isMaximumTreatmentTime",
      "path" : "getmedicationhistory.medicationMedicalRecord.medicationMedicalRecordBody.medicationPrescription.dosage.lengthOfTreatment.isMaximumTreatmentTime",
      "short" : "Om true: maximalt tillåten tid",
      "definition" : "Om true: maximalt tillåten tid",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "boolean"
      }]
    },
    {
      "id" : "getmedicationhistory.medicationMedicalRecord.medicationMedicalRecordBody.medicationPrescription.dosage.dosageInstruction",
      "path" : "getmedicationhistory.medicationMedicalRecord.medicationMedicalRecordBody.medicationPrescription.dosage.dosageInstruction",
      "short" : "Doseringsanvisning",
      "definition" : "Doseringsanvisning",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "getmedicationhistory.medicationMedicalRecord.medicationMedicalRecordBody.medicationPrescription.dosage.unitDose",
      "path" : "getmedicationhistory.medicationMedicalRecord.medicationMedicalRecordBody.medicationPrescription.dosage.unitDose",
      "short" : "Doseringsenhet",
      "definition" : "Doseringsenhet",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "CodeableConcept"
      }]
    },
    {
      "id" : "getmedicationhistory.medicationMedicalRecord.medicationMedicalRecordBody.medicationPrescription.dosage.shortNotation",
      "path" : "getmedicationhistory.medicationMedicalRecord.medicationMedicalRecordBody.medicationPrescription.dosage.shortNotation",
      "short" : "Kortnotation, t.ex. '1x2'",
      "definition" : "Kortnotation, t.ex. '1x2'",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "getmedicationhistory.medicationMedicalRecord.medicationMedicalRecordBody.medicationPrescription.dosage.setDosage",
      "path" : "getmedicationhistory.medicationMedicalRecord.medicationMedicalRecordBody.medicationPrescription.dosage.setDosage",
      "short" : "Fastdosering",
      "definition" : "Dosering där ordinatören har bestämt mängd och periodicitet.",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "BackboneElement"
      }]
    },
    {
      "id" : "getmedicationhistory.medicationMedicalRecord.medicationMedicalRecordBody.medicationPrescription.dosage.maximumDosage",
      "path" : "getmedicationhistory.medicationMedicalRecord.medicationMedicalRecordBody.medicationPrescription.dosage.maximumDosage",
      "short" : "Maxdosering",
      "definition" : "Den högsta tillåtna mängden under en viss period.",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "BackboneElement"
      }]
    },
    {
      "id" : "getmedicationhistory.medicationMedicalRecord.medicationMedicalRecordBody.medicationPrescription.dosage.conditionalDosage",
      "path" : "getmedicationhistory.medicationMedicalRecord.medicationMedicalRecordBody.medicationPrescription.dosage.conditionalDosage",
      "short" : "Villkorsdosering",
      "definition" : "Ordinerad mängd och periodicitet som gäller om ett visst villkor är uppfyllt.",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "BackboneElement"
      }]
    },
    {
      "id" : "getmedicationhistory.medicationMedicalRecord.medicationMedicalRecordBody.medicationPrescription.dosage.conditionalDosage.conditionDescription",
      "path" : "getmedicationhistory.medicationMedicalRecord.medicationMedicalRecordBody.medicationPrescription.dosage.conditionalDosage.conditionDescription",
      "short" : "Villkorstext",
      "definition" : "Villkorstext",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "getmedicationhistory.medicationMedicalRecord.medicationMedicalRecordBody.medicationPrescription.dispensationAuthorization",
      "path" : "getmedicationhistory.medicationMedicalRecord.medicationMedicalRecordBody.medicationPrescription.dispensationAuthorization",
      "short" : "Förskrivning",
      "definition" : "Se XSD DispensationAuthorizationType för fullständig struktur.\n// SAKNAS I KÄLLDOKUMENT - endast delvis extraherat — kontrollera manuellt",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "BackboneElement"
      }]
    },
    {
      "id" : "getmedicationhistory.medicationMedicalRecord.medicationMedicalRecordBody.medicationPrescription.administration",
      "path" : "getmedicationhistory.medicationMedicalRecord.medicationMedicalRecordBody.medicationPrescription.administration",
      "short" : "Information om administrering av läkemedel",
      "definition" : "Bara administreringstillfällen som faktiskt ägt rum kan anges.\nSe XSD AdministrationType för fullständig struktur.\n// SAKNAS I KÄLLDOKUMENT - endast delvis extraherat — kontrollera manuellt",
      "min" : 0,
      "max" : "*",
      "type" : [{
        "code" : "BackboneElement"
      }]
    },
    {
      "id" : "getmedicationhistory.medicationMedicalRecord.medicationMedicalRecordBody.medicationPrescription.relation",
      "path" : "getmedicationhistory.medicationMedicalRecord.medicationMedicalRecordBody.medicationPrescription.relation",
      "short" : "Sambandsklass",
      "definition" : "Alla meddelandeposter som i ordinationen pekas ut med samma relationstyp.\nSe XSD RelationType för fullständig struktur.\n// SAKNAS I KÄLLDOKUMENT - endast delvis extraherat — kontrollera manuellt",
      "min" : 0,
      "max" : "*",
      "type" : [{
        "code" : "BackboneElement"
      }]
    },
    {
      "id" : "getmedicationhistory.medicationMedicalRecord.medicationMedicalRecordBody.additionalPatientInformation",
      "path" : "getmedicationhistory.medicationMedicalRecord.medicationMedicalRecordBody.additionalPatientInformation",
      "short" : "Ytterligare patientinformation",
      "definition" : "Ytterligare patientinformation",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "BackboneElement"
      }]
    },
    {
      "id" : "getmedicationhistory.medicationMedicalRecord.medicationMedicalRecordBody.additionalPatientInformation.dateOfBirth",
      "path" : "getmedicationhistory.medicationMedicalRecord.medicationMedicalRecordBody.additionalPatientInformation.dateOfBirth",
      "short" : "Patientens födelsedatum",
      "definition" : "Patientens födelsedatum",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "date"
      }]
    },
    {
      "id" : "getmedicationhistory.medicationMedicalRecord.medicationMedicalRecordBody.additionalPatientInformation.gender",
      "path" : "getmedicationhistory.medicationMedicalRecord.medicationMedicalRecordBody.additionalPatientInformation.gender",
      "short" : "Patientens kön. KV Kön (OID 1.2.752.129.2.2.1.1) bör användas",
      "definition" : "Patientens kön. KV Kön (OID 1.2.752.129.2.2.1.1) bör användas",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "CodeableConcept"
      }]
    },
    {
      "id" : "getmedicationhistory.result",
      "path" : "getmedicationhistory.result",
      "short" : "Svarsstatus",
      "definition" : "Svarsstatus",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "BackboneElement"
      }]
    },
    {
      "id" : "getmedicationhistory.result.resultCode",
      "path" : "getmedicationhistory.result.resultCode",
      "short" : "OK, INFO eller ERROR",
      "definition" : "OK, INFO eller ERROR",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "code"
      }],
      "binding" : {
        "strength" : "required",
        "valueSet" : "https://fhir.inera.se/ig/clinicalprocess-activityprescription-actoutcome/ValueSet/resultcode-vs"
      }
    },
    {
      "id" : "getmedicationhistory.result.errorCode",
      "path" : "getmedicationhistory.result.errorCode",
      "short" : "Sätts om resultCode är ERROR",
      "definition" : "Sätts om resultCode är ERROR",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "code"
      }],
      "binding" : {
        "strength" : "required",
        "valueSet" : "https://fhir.inera.se/ig/clinicalprocess-activityprescription-actoutcome/ValueSet/errorcode-vs"
      }
    },
    {
      "id" : "getmedicationhistory.result.subcode",
      "path" : "getmedicationhistory.result.subcode",
      "short" : "Inga subkoder specificerade",
      "definition" : "Inga subkoder specificerade",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "getmedicationhistory.result.logId",
      "path" : "getmedicationhistory.result.logId",
      "short" : "UUID för felsökning hos producent",
      "definition" : "UUID för felsökning hos producent",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "getmedicationhistory.result.message",
      "path" : "getmedicationhistory.result.message",
      "short" : "Beskrivande text för användaren",
      "definition" : "Beskrivande text för användaren",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    }]
  }
}

```
