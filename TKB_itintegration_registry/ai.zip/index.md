# Hem - itintegration: registry v1.0.0

* [**Table of Contents**](toc.md)
* **Hem**

## Hem

| | |
| :--- | :--- |
| *Official URL*:https://fhir.inera.se/ig/itintegration-registry/ImplementationGuide/inera.itintegration-registry | *Version*:1.0.0 |
| Active as of 2026-11-06 | *Computable Name*:itintegrationregistry |
| **Copyright/Legal**: Copyright 2024 Inera AB. Licensieras under Creative Commons Attribution 4.0. | |

# itintegration: registry

**TKB-version:** 1.0.0 · **IG-version:** 1.0.0 · **Källa:** Bitbucket-tagg `TD_REGISTRY_1_0_0_R` 

## Översikt

* Beskrivning: Svenskt kortnamn
  * Tjänsteadressering är en stödtjänst som används av en tjänsteplattform. Denna tjänstedomän omfattar informationsstrukturer och tjänster för åtkomst och hantering av tjänsteadressringsinformation. Tjänsteadressering syftar på den i T-boken beskrivna logiska komponenten tjänsteadresseringskatalog. Denna tjänstedomän utvecklas inte längre och har ersatts av domänen infrastructure:itintegration:registry.: tjänsteadressering
* Beskrivning: Svenskt namn
  * Tjänsteadressering är en stödtjänst som används av en tjänsteplattform. Denna tjänstedomän omfattar informationsstrukturer och tjänster för åtkomst och hantering av tjänsteadressringsinformation. Tjänsteadressering syftar på den i T-boken beskrivna logiska komponenten tjänsteadresseringskatalog. Denna tjänstedomän utvecklas inte längre och har ersatts av domänen infrastructure:itintegration:registry.: infrastruktur:tjänsteförmedlingstjänster:adressering
* Beskrivning: Typ
  * Tjänsteadressering är en stödtjänst som används av en tjänsteplattform. Denna tjänstedomän omfattar informationsstrukturer och tjänster för åtkomst och hantering av tjänsteadressringsinformation. Tjänsteadressering syftar på den i T-boken beskrivna logiska komponenten tjänsteadresseringskatalog. Denna tjänstedomän utvecklas inte längre och har ersatts av domänen infrastructure:itintegration:registry.: Nationell tjänstedomän
* Beskrivning: Källkod
  * Tjänsteadressering är en stödtjänst som används av en tjänsteplattform. Denna tjänstedomän omfattar informationsstrukturer och tjänster för åtkomst och hantering av tjänsteadressringsinformation. Tjänsteadressering syftar på den i T-boken beskrivna logiska komponenten tjänsteadresseringskatalog. Denna tjänstedomän utvecklas inte längre och har ersatts av domänen infrastructure:itintegration:registry.: [Bitbucket](https://bitbucket.org/rivta-domains/riv.itintegration.registry/src)
* Beskrivning: Underlag för denna IG
  * Tjänsteadressering är en stödtjänst som används av en tjänsteplattform. Denna tjänstedomän omfattar informationsstrukturer och tjänster för åtkomst och hantering av tjänsteadressringsinformation. Tjänsteadressering syftar på den i T-boken beskrivna logiska komponenten tjänsteadresseringskatalog. Denna tjänstedomän utvecklas inte längre och har ersatts av domänen infrastructure:itintegration:registry.: Version 1.0.0 ·[tagg TD_REGISTRY_1_0_0_R](https://bitbucket.org/rivta-domains/riv.itintegration.registry/src/TD_REGISTRY_1_0_0_R)·[zip](https://bitbucket.org/rivta-domains/riv.itintegration.registry/get/TD_REGISTRY_1_0_0_R.zip)
* Beskrivning: RIV-TA-portalen
  * Tjänsteadressering är en stödtjänst som används av en tjänsteplattform. Denna tjänstedomän omfattar informationsstrukturer och tjänster för åtkomst och hantering av tjänsteadressringsinformation. Tjänsteadressering syftar på den i T-boken beskrivna logiska komponenten tjänsteadresseringskatalog. Denna tjänstedomän utvecklas inte längre och har ersatts av domänen infrastructure:itintegration:registry.: [Alla tjänstedomäner](https://oskthu2.github.io/tkb-converter/rivta-portal/tjanstedomaner.html)·[Alla tjänstekontrakt](https://oskthu2.github.io/tkb-converter/rivta-portal/tjanstekontrakt.html)

FHIR Implementation Guide för tjänstedomänen **itintegration: registry** (tjänsteadresseringskatalog) version 1.0.0. Genererad från Ineras tjänstekontraktsbeskrivning, utgåva A (2012-04-14), och domänens WSDL- och XSD-filer.

Version 2.0 av domänen (namnrymd `urn:riv:infrastructure:itintegration:registry:2`) finns i IG:n för infrastructure: itintegration: registry.

Domänen innehåller följande tjänstekontrakt:

| | | |
| :--- | :--- | :--- |
| [GetLogicalAddresseesByServiceContract](7-tjanstekontrakt.md#getlogicaladdresseesbyservicecontract) | 1.0 | Listar logiska adressater som har en tjänsteproducent för ett tjänstekontrakt |
| [GetSupportedServiceContracts](7-tjanstekontrakt.md#getsupportedservicecontracts) | 1.0 | Listar tjänstekontrakt som stöds av en logisk adressat |

### Versioner och granskningar

| | | | |
| :--- | :--- | :--- | :--- |
| 1.0.0 |  | Äldre granskningsprocess: Teknik: Godkänd | [zip](https://bitbucket.org/rivta-domains/riv.itintegration.registry/get/TD_REGISTRY_1_0_0_R.zip)·[källkod](https://bitbucket.org/rivta-domains/riv.itintegration.registry/src/TD_REGISTRY_1_0_0_R) |

*Zip-arkiven hämtas från taggarna på Bitbucket. Granskningsprotokollen publicerades på rivta.se och länkas inte härifrån.*

*Källa: ögonblicksbild av DOMDB från 2021-08-24, via RIV-TA-portalen.*

## Innehåll

* [1 Inledning](1-inledning.md)
* [2 Informationsmodell](2-informationsmodell.md)
* [3 Versionsinformation](3-versionsinformation.md)
* [4 Generella regler](4-generella-regler.md)
* [5 SLA-krav](5-sla-krav.md)
* [7 Tjänstekontrakt](7-tjanstekontrakt.md)
* [8 Datatyper](8-datatyper.md)
* [Artefakter](artifacts.md)

