# Hem - itintegration: registry v1.0.0

* [**Table of Contents**](toc.md)
* **Hem**

## Hem

| | |
| :--- | :--- |
| *Official URL*:https://fhir.inera.se/ig/itintegration-registry/ImplementationGuide/inera.itintegration-registry | *Version*:1.0.0 |
| Draft as of 2026-09-28 | *Computable Name*:itintegrationregistry |
| **Copyright/Legal**: Copyright 2024 Inera AB. Licensieras under Creative Commons Attribution 4.0. | |

# itintegration: registry

## Översikt

FHIR Implementation Guide för tjänstedomänen **itintegration: registry** (tjänsteadresseringskatalog) version 1.0.0. Genererad från Ineras tjänstekontraktsbeskrivning, utgåva A (2012-04-14), och domänens WSDL- och XSD-filer.

Version 2.0 av domänen (namnrymd `urn:riv:infrastructure:itintegration:registry:2`) finns i IG:n för infrastructure: itintegration: registry.

Domänen innehåller följande tjänstekontrakt:

| | | |
| :--- | :--- | :--- |
| [GetLogicalAddresseesByServiceContract](7-tjanstekontrakt.md#getlogicaladdresseesbyservicecontract) | 1.0 | Listar logiska adressater som har en tjänsteproducent för ett tjänstekontrakt |
| [GetSupportedServiceContracts](7-tjanstekontrakt.md#getsupportedservicecontracts) | 1.0 | Listar tjänstekontrakt som stöds av en logisk adressat |

## Innehåll

* [1 Inledning](1-inledning.md)
* [2 Informationsmodell](2-informationsmodell.md)
* [3 Versionsinformation](3-versionsinformation.md)
* [4 Generella regler](4-generella-regler.md)
* [5 SLA-krav](5-sla-krav.md)
* [7 Tjänstekontrakt](7-tjanstekontrakt.md)
* [8 Datatyper](8-datatyper.md)
* [Artefakter](artifacts.md)

