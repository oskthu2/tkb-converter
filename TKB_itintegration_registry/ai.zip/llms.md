# inera.itintegration-registry#1.0.0: itintegration: registry

## Pages

* [Hem](index.md)
* [4 Generella regler](4-generella-regler.md)
* [7 Tjänstekontrakt](7-tjanstekontrakt.md)
* [8 Datatyper](8-datatyper.md)
* [3 Versionsinformation](3-versionsinformation.md)
* [Artifacts Summary](artifacts.md)
* [5 SLA-krav](5-sla-krav.md)
* [2 Informationsmodell](2-informationsmodell.md)
* [1 Inledning](1-inledning.md)

## Resources

### Logicals

* [GetLogicalAddresseesByServiceContract — Request](StructureDefinition-getlogicaladdresseesbyservicecontract-request.md)
* [GetLogicalAddresseesByServiceContract — Response](StructureDefinition-getlogicaladdresseesbyservicecontract.md)
* [GetSupportedServiceContracts — Request](StructureDefinition-getsupportedservicecontracts-request.md)
* [GetSupportedServiceContracts — Response](StructureDefinition-getsupportedservicecontracts.md)

### ImplementationGuides

* [itintegration: registry](index.md)
