# GetAllBlocksForPatient - ehr: blocking — Spärrhantering v3.2.2

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **GetAllBlocksForPatient**

## Logical Model: GetAllBlocksForPatient 

| | |
| :--- | :--- |
| *Official URL*:https://fhir.inera.se/ig/ehr-blocking/StructureDefinition/getallblocksforpatient | *Version*:3.2.2 |
| Draft as of 2026-09-26 | *Computable Name*:GetAllBlocksForPatient |
| **Copyright/Legal**: Copyright 2024 Inera AB. Licensieras under Creative Commons Attribution 4.0. | |

 
Logisk modell för tjänstekontraktet GetAllBlocksForPatient (RIV-TA urn:riv:ehr:blocking:querying:GetAllBlocksForPatientResponder:2). Läser alla nationellt kända/lagrade spärrar för en viss patient. Representerar responsens informationsstruktur. 

**Usages:**

* This Logical Model is not used by any profiles in this Specification

You can also check for [usages in the FHIR IG Statistics](https://packages2.fhir.org/xig/resource/inera.ehr-blocking|current/StructureDefinition/StructureDefinition-getallblocksforpatient.json)

### Formal Views of Profile Content

 [Description of Profiles, Differentials, Snapshots and how the different presentations work](http://build.fhir.org/ig/FHIR/ig-guidance/readingIgs.html#structure-definitions). 

 

Other representations of profile: [CSV](StructureDefinition-getallblocksforpatient.csv), [Excel](StructureDefinition-getallblocksforpatient.xlsx) 



## Resource Content

```json
{
  "resourceType" : "StructureDefinition",
  "id" : "getallblocksforpatient",
  "extension" : [{
    "url" : "http://hl7.org/fhir/StructureDefinition/structuredefinition-type-characteristics",
    "valueCode" : "can-be-target"
  }],
  "url" : "https://fhir.inera.se/ig/ehr-blocking/StructureDefinition/getallblocksforpatient",
  "version" : "3.2.2",
  "name" : "GetAllBlocksForPatient",
  "title" : "GetAllBlocksForPatient",
  "status" : "draft",
  "date" : "2026-09-26T19:23:06+00:00",
  "contact" : [{
    "name" : "Inera Arkitektur",
    "telecom" : [{
      "system" : "url",
      "value" : "https://www.inera.se"
    }]
  }],
  "description" : "Logisk modell för tjänstekontraktet GetAllBlocksForPatient\n(RIV-TA urn:riv:ehr:blocking:querying:GetAllBlocksForPatientResponder:2).\nLäser alla nationellt kända/lagrade spärrar för en viss patient.\nRepresenterar responsens informationsstruktur.",
  "copyright" : "Copyright 2024 Inera AB. Licensieras under Creative Commons Attribution 4.0.",
  "fhirVersion" : "4.0.1",
  "kind" : "logical",
  "abstract" : false,
  "type" : "https://fhir.inera.se/ig/ehr-blocking/StructureDefinition/getallblocksforpatient",
  "baseDefinition" : "http://hl7.org/fhir/StructureDefinition/Base",
  "derivation" : "specialization",
  "differential" : {
    "element" : [{
      "id" : "getallblocksforpatient",
      "path" : "getallblocksforpatient",
      "short" : "GetAllBlocksForPatient",
      "definition" : "Logisk modell för tjänstekontraktet GetAllBlocksForPatient\n(RIV-TA urn:riv:ehr:blocking:querying:GetAllBlocksForPatientResponder:2).\nLäser alla nationellt kända/lagrade spärrar för en viss patient.\nRepresenterar responsens informationsstruktur."
    },
    {
      "id" : "getallblocksforpatient.result",
      "path" : "getallblocksforpatient.result",
      "short" : "Resultat av anropet",
      "definition" : "Resultat av anropet",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "BackboneElement"
      }]
    },
    {
      "id" : "getallblocksforpatient.result.resultCode",
      "path" : "getallblocksforpatient.result.resultCode",
      "short" : "Svarskod",
      "definition" : "Svarskod",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "code"
      }],
      "binding" : {
        "strength" : "required",
        "valueSet" : "https://fhir.inera.se/ig/ehr-blocking/ValueSet/resultcode-vs"
      }
    },
    {
      "id" : "getallblocksforpatient.result.resultText",
      "path" : "getallblocksforpatient.result.resultText",
      "short" : "Beskrivande text till svarskoden",
      "definition" : "Beskrivande text till svarskoden",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "getallblocksforpatient.blocks",
      "path" : "getallblocksforpatient.blocks",
      "short" : "Lista över funna aktiva spärrar för angiven patient",
      "definition" : "Lista över funna aktiva spärrar för angiven patient",
      "min" : 0,
      "max" : "*",
      "type" : [{
        "code" : "BackboneElement"
      }]
    },
    {
      "id" : "getallblocksforpatient.blocks.blockId",
      "path" : "getallblocksforpatient.blocks.blockId",
      "short" : "Unik identifierare för spärren (UUID)",
      "definition" : "Unik identifierare för spärren (UUID)",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "getallblocksforpatient.blocks.blockType",
      "path" : "getallblocksforpatient.blocks.blockType",
      "short" : "Typ av spärr",
      "definition" : "Typ av spärr",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "code"
      }],
      "binding" : {
        "strength" : "required",
        "valueSet" : "https://fhir.inera.se/ig/ehr-blocking/ValueSet/blocktype-vs"
      }
    },
    {
      "id" : "getallblocksforpatient.blocks.patientId",
      "path" : "getallblocksforpatient.blocks.patientId",
      "short" : "Patientens personnummer eller samordningsnummer",
      "definition" : "Patientens personnummer eller samordningsnummer",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "getallblocksforpatient.blocks.informationStartDate",
      "path" : "getallblocksforpatient.blocks.informationStartDate",
      "short" : "Startdatum för vilken information spärren gäller",
      "definition" : "Startdatum för vilken information spärren gäller",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "dateTime"
      }]
    },
    {
      "id" : "getallblocksforpatient.blocks.informationEndDate",
      "path" : "getallblocksforpatient.blocks.informationEndDate",
      "short" : "Slutdatum för vilken information spärren gäller",
      "definition" : "Slutdatum för vilken information spärren gäller",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "dateTime"
      }]
    },
    {
      "id" : "getallblocksforpatient.blocks.informationCareUnitId",
      "path" : "getallblocksforpatient.blocks.informationCareUnitId",
      "short" : "HSA-id för vårdenhet (vid inre spärr)",
      "definition" : "HSA-id för vårdenhet (vid inre spärr)",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "getallblocksforpatient.blocks.informationCareProviderId",
      "path" : "getallblocksforpatient.blocks.informationCareProviderId",
      "short" : "HSA-id för vårdgivare",
      "definition" : "HSA-id för vårdgivare",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "getallblocksforpatient.blocks.excludedInformationTypes",
      "path" : "getallblocksforpatient.blocks.excludedInformationTypes",
      "short" : "Informationstyper undantagna från spärren",
      "definition" : "Informationstyper undantagna från spärren",
      "min" : 0,
      "max" : "*",
      "type" : [{
        "code" : "BackboneElement"
      }]
    },
    {
      "id" : "getallblocksforpatient.blocks.excludedInformationTypes.infoTypeId",
      "path" : "getallblocksforpatient.blocks.excludedInformationTypes.infoTypeId",
      "short" : "ID för informationstypen",
      "definition" : "ID för informationstypen",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "getallblocksforpatient.blocks.excludedInformationTypes.infoTypeDescription",
      "path" : "getallblocksforpatient.blocks.excludedInformationTypes.infoTypeDescription",
      "short" : "Beskrivning av informationstypen",
      "definition" : "Beskrivning av informationstypen",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "getallblocksforpatient.blocks.temporaryRevokes",
      "path" : "getallblocksforpatient.blocks.temporaryRevokes",
      "short" : "Aktiva tillfälliga hävningar",
      "definition" : "Aktiva tillfälliga hävningar",
      "min" : 0,
      "max" : "*",
      "type" : [{
        "code" : "BackboneElement"
      }]
    },
    {
      "id" : "getallblocksforpatient.blocks.temporaryRevokes.temporaryRevokeId",
      "path" : "getallblocksforpatient.blocks.temporaryRevokes.temporaryRevokeId",
      "short" : "Unik ID för tillfällig hävning",
      "definition" : "Unik ID för tillfällig hävning",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "getallblocksforpatient.blocks.temporaryRevokes.endDate",
      "path" : "getallblocksforpatient.blocks.temporaryRevokes.endDate",
      "short" : "Datum när hävningen upphör",
      "definition" : "Datum när hävningen upphör",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "dateTime"
      }]
    },
    {
      "id" : "getallblocksforpatient.blocks.temporaryRevokes.revokedForCareUnitId",
      "path" : "getallblocksforpatient.blocks.temporaryRevokes.revokedForCareUnitId",
      "short" : "HSA-id för vårdenhet med hävning",
      "definition" : "HSA-id för vårdenhet med hävning",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "getallblocksforpatient.blocks.temporaryRevokes.revokedForEmployeeId",
      "path" : "getallblocksforpatient.blocks.temporaryRevokes.revokedForEmployeeId",
      "short" : "HSA-id för enskild medarbetare",
      "definition" : "HSA-id för enskild medarbetare",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "getallblocksforpatient.blocks.temporaryRevokes.ownerId",
      "path" : "getallblocksforpatient.blocks.temporaryRevokes.ownerId",
      "short" : "System som registrerade hävningen",
      "definition" : "System som registrerade hävningen",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "getallblocksforpatient.blocks.ownerId",
      "path" : "getallblocksforpatient.blocks.ownerId",
      "short" : "System som registrerade spärren",
      "definition" : "System som registrerade spärren",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "getallblocksforpatient.nextCreatedOnOrAfter",
      "path" : "getallblocksforpatient.nextCreatedOnOrAfter",
      "short" : "Tidsstämpel för nästa inkrementella hämtning",
      "definition" : "Tidsstämpel för nästa inkrementella hämtning",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "dateTime"
      }]
    },
    {
      "id" : "getallblocksforpatient.latestCancellation",
      "path" : "getallblocksforpatient.latestCancellation",
      "short" : "Senaste makulerings- eller hävningstidpunkt",
      "definition" : "Senaste makulerings- eller hävningstidpunkt",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "dateTime"
      }]
    }]
  }
}

```
