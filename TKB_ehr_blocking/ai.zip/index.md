# Hem - ehr: blocking — Spärrhantering v3.2.2

* [**Table of Contents**](toc.md)
* **Hem**

## Hem

| | |
| :--- | :--- |
| *Official URL*:https://fhir.inera.se/ig/ehr-blocking/ImplementationGuide/inera.ehr-blocking | *Version*:3.2.2 |
| Draft as of 2026-09-14 | *Computable Name*:ehrblocking |
| **Copyright/Legal**: Copyright 2024 Inera AB. Licensieras under Creative Commons Attribution 4.0. | |

# ehr: blocking — Spärrhantering

## Översikt

FHIR Implementation Guide för tjänstedomänen **ehr: blocking** (Spärrhantering) version 3.2.2. Genererad från Ineras Tjänstekontraktsbeskrivning (TKB).

Domänen hanterar spärrhantering för vårdgivare som behöver registrera spärr av uppgifter på patientens begäran enligt Patientdatalagens regleringar samt att utföra kontroll mot spärr i vårdsystemen.

RIV-TA namnrymd: `urn:riv:ehr:blocking`

## Tjänstekontrakt

Domänen innehåller följande tjänstekontrakt, organiserade i fyra underdomäner:

### Querying — Frågetjänster

| | | |
| :--- | :--- | :--- |
| [GetAllBlocks](7-tjanstekontrakt.md#getallblocks) | 2.0 | Läs alla spärrar (nationell nivå) |
| [GetAllBlocksForPatient](7-tjanstekontrakt.md#getallblocksforpatient) | 2.0 | Läs alla spärrar för en patient |
| [GetBlocks](7-tjanstekontrakt.md#getblocks) | 2.0 | Läs spärrar för en vårdgivare |
| [GetBlocksForPatient](7-tjanstekontrakt.md#getblocksforpatient) | 2.0 | Läs spärrar för patient och vårdgivare |

### Accesscontrol — Spärrkontroll

| | | |
| :--- | :--- | :--- |
| [CheckBlocks](7-tjanstekontrakt.md#checkblocks) | 3.0 | Kontrollera om spärr finns för given personal/vårdenhet |

### Synchronization — Replikering till nationell tjänst

| | | |
| :--- | :--- | :--- |
| [RegisterBlock](7-tjanstekontrakt.md#registerblock) | 2.0 | Registrera spärr i nationell spärrtjänst |
| [UnregisterBlock](7-tjanstekontrakt.md#unregisterblock) | 2.0 | Avregistrera spärr från nationell spärrtjänst |
| [RegisterTemporaryRevoke](7-tjanstekontrakt.md#registertemporaryrevoke) | 2.0 | Registrera tillfällig hävning |
| [UnregisterTemporaryRevoke](7-tjanstekontrakt.md#unregistertemporaryrevoke) | 2.0 | Avregistrera tillfällig hävning |

### Administration — Lokal spärradministration

| | | |
| :--- | :--- | :--- |
| [GetPatientIds](7-tjanstekontrakt.md#getpatientids) | 2.0 | Läs patient-ID för spärrade patienter |
| [GetExtendedBlocksForPatient](7-tjanstekontrakt.md#getextendedblockforpatient) | 2.0 | Läs utökade spärrar för patient |
| [RegisterExtendedBlock](7-tjanstekontrakt.md#registerextendedblock) | 2.0 | Registrera utökad spärr |
| [RevokeExtendedBlock](7-tjanstekontrakt.md#revokeextendedblock) | 2.0 | Häv spärr permanent |
| [DeleteExtendedBlock](7-tjanstekontrakt.md#deleteextendedblock) | 2.0 | Makulera spärr |
| [RegisterTemporaryExtendedRevoke](7-tjanstekontrakt.md#registertemporaryextendedrevoke) | 2.0 | Registrera tillfällig hävning (utökad) |
| [CancelTemporaryExtendedRevoke](7-tjanstekontrakt.md#canceltemporaryextendedrevoke) | 2.0 | Återkalla tillfällig hävning |

## Innehåll

* [1 Inledning](1-inledning.md)
* [2 Generella regler](2-generella-regler.md)
* [7 Tjänstekontrakt](7-tjanstekontrakt.md)
* [Artefakter](artifacts.md)

