# Hem - ehr: blocking — Spärrhantering v3.2.2

* [**Table of Contents**](toc.md)
* **Hem**

## Hem

| | |
| :--- | :--- |
| *Official URL*:https://fhir.inera.se/ig/ehr-blocking/ImplementationGuide/inera.ehr-blocking | *Version*:3.2.2 |
| Active as of 2026-10-26 | *Computable Name*:ehrblocking |
| **Copyright/Legal**: Copyright 2024 Inera AB. Licensieras under Creative Commons Attribution 4.0. | |

# ehr: blocking — Spärrhantering

**TKB-version:** 3.2.2 · **IG-version:** 3.2.2 · **Källa:** Bitbucket-commit `caadc6edb904`, efter taggen `ehr_blocking_3.2.2` 

## Översikt

* Beskrivning: Svenskt kortnamn
  * OBSERVERA: Denna domän utvecklas inte längre, för nyutveckling, support och buggrättningar hänvisas till den nya domänen: spärrhantering - informationsecurity:authorization:blocking Spärrhantering registrerar spärrar och kontrollerar om en patient har spärrat tillgång till patientinformation från IT-system inom och mellan vårdgivare. Tjänstekontrakten för Spärrhantering gör det möjligt för vårdpersonal att genom sina egna vårdsystem registrera lokala spärrar. Tjänstekontrakten gör det också möjligt att replikera de lokala spärrarna till den nationella spärrtjänsten. Detta är nödvändigt för att lokalt spärrad information även ska vara spärrad i nationella tjänster som har åtkomst till patientinformation, till exempel NPÖ.: spärrhantering
* Beskrivning: Svenskt namn
  * OBSERVERA: Denna domän utvecklas inte längre, för nyutveckling, support och buggrättningar hänvisas till den nya domänen: spärrhantering - informationsecurity:authorization:blocking Spärrhantering registrerar spärrar och kontrollerar om en patient har spärrat tillgång till patientinformation från IT-system inom och mellan vårdgivare. Tjänstekontrakten för Spärrhantering gör det möjligt för vårdpersonal att genom sina egna vårdsystem registrera lokala spärrar. Tjänstekontrakten gör det också möjligt att replikera de lokala spärrarna till den nationella spärrtjänsten. Detta är nödvändigt för att lokalt spärrad information även ska vara spärrad i nationella tjänster som har åtkomst till patientinformation, till exempel NPÖ.: infrastruktur:säkerhetstjänster:spärrhantering
* Beskrivning: Typ
  * OBSERVERA: Denna domän utvecklas inte längre, för nyutveckling, support och buggrättningar hänvisas till den nya domänen: spärrhantering - informationsecurity:authorization:blocking Spärrhantering registrerar spärrar och kontrollerar om en patient har spärrat tillgång till patientinformation från IT-system inom och mellan vårdgivare. Tjänstekontrakten för Spärrhantering gör det möjligt för vårdpersonal att genom sina egna vårdsystem registrera lokala spärrar. Tjänstekontrakten gör det också möjligt att replikera de lokala spärrarna till den nationella spärrtjänsten. Detta är nödvändigt för att lokalt spärrad information även ska vara spärrad i nationella tjänster som har åtkomst till patientinformation, till exempel NPÖ.: Nationell tjänstedomän
* Beskrivning: Källkod
  * OBSERVERA: Denna domän utvecklas inte längre, för nyutveckling, support och buggrättningar hänvisas till den nya domänen: spärrhantering - informationsecurity:authorization:blocking Spärrhantering registrerar spärrar och kontrollerar om en patient har spärrat tillgång till patientinformation från IT-system inom och mellan vårdgivare. Tjänstekontrakten för Spärrhantering gör det möjligt för vårdpersonal att genom sina egna vårdsystem registrera lokala spärrar. Tjänstekontrakten gör det också möjligt att replikera de lokala spärrarna till den nationella spärrtjänsten. Detta är nödvändigt för att lokalt spärrad information även ska vara spärrad i nationella tjänster som har åtkomst till patientinformation, till exempel NPÖ.: [Bitbucket](https://bitbucket.org/rivta-domains/riv.ehr.blocking/src)
* Beskrivning: Ärenden
  * OBSERVERA: Denna domän utvecklas inte längre, för nyutveckling, support och buggrättningar hänvisas till den nya domänen: spärrhantering - informationsecurity:authorization:blocking Spärrhantering registrerar spärrar och kontrollerar om en patient har spärrat tillgång till patientinformation från IT-system inom och mellan vårdgivare. Tjänstekontrakten för Spärrhantering gör det möjligt för vårdpersonal att genom sina egna vårdsystem registrera lokala spärrar. Tjänstekontrakten gör det också möjligt att replikera de lokala spärrarna till den nationella spärrtjänsten. Detta är nödvändigt för att lokalt spärrad information även ska vara spärrad i nationella tjänster som har åtkomst till patientinformation, till exempel NPÖ.: [Bitbucket issues](https://bitbucket.org/rivta-domains/riv.ehr.blocking/issues)
* Beskrivning: Underlag för denna IG
  * OBSERVERA: Denna domän utvecklas inte längre, för nyutveckling, support och buggrättningar hänvisas till den nya domänen: spärrhantering - informationsecurity:authorization:blocking Spärrhantering registrerar spärrar och kontrollerar om en patient har spärrat tillgång till patientinformation från IT-system inom och mellan vårdgivare. Tjänstekontrakten för Spärrhantering gör det möjligt för vårdpersonal att genom sina egna vårdsystem registrera lokala spärrar. Tjänstekontrakten gör det också möjligt att replikera de lokala spärrarna till den nationella spärrtjänsten. Detta är nödvändigt för att lokalt spärrad information även ska vara spärrad i nationella tjänster som har åtkomst till patientinformation, till exempel NPÖ.: Version 3.2.2 ·[tagg ehr_blocking_3.2.2](https://bitbucket.org/rivta-domains/riv.ehr.blocking/src/ehr_blocking_3.2.2)·[zip](https://bitbucket.org/rivta-domains/riv.ehr.blocking/src/master/docs/TKB_ehr_blocking_3.2.2.docx)
* Beskrivning: RIV-TA-portalen
  * OBSERVERA: Denna domän utvecklas inte längre, för nyutveckling, support och buggrättningar hänvisas till den nya domänen: spärrhantering - informationsecurity:authorization:blocking Spärrhantering registrerar spärrar och kontrollerar om en patient har spärrat tillgång till patientinformation från IT-system inom och mellan vårdgivare. Tjänstekontrakten för Spärrhantering gör det möjligt för vårdpersonal att genom sina egna vårdsystem registrera lokala spärrar. Tjänstekontrakten gör det också möjligt att replikera de lokala spärrarna till den nationella spärrtjänsten. Detta är nödvändigt för att lokalt spärrad information även ska vara spärrad i nationella tjänster som har åtkomst till patientinformation, till exempel NPÖ.: [Alla tjänstedomäner](https://oskthu2.github.io/tkb-converter/rivta-portal/tjanstedomaner.html)·[Alla tjänstekontrakt](https://oskthu2.github.io/tkb-converter/rivta-portal/tjanstekontrakt.html)

FHIR Implementation Guide för tjänstedomänen **ehr: blocking** (Spärrhantering) version 3.2.2. Genererad från Ineras Tjänstekontraktsbeskrivning (TKB).

Domänen hanterar spärrhantering för vårdgivare som behöver registrera spärr av uppgifter på patientens begäran enligt Patientdatalagens regleringar samt att utföra kontroll mot spärr i vårdsystemen.

RIV-TA namnrymd: `urn:riv:ehr:blocking`

## Tjänstekontrakt

Domänen innehåller följande tjänstekontrakt, organiserade i fyra underdomäner:

### Querying — Frågetjänster

| | | |
| :--- | :--- | :--- |
| [GetAllBlocks](7-tjanstekontrakt.md#getallblocks) | 2.0 | Läs alla spärrar (nationell nivå) |
| [GetAllBlocksForPatient](7-tjanstekontrakt.md#getallblocksforpatient) | 2.0 | Läs alla spärrar för en patient |
| [GetBlocks](7-tjanstekontrakt.md#getblocks) | 2.0 | Läs spärrar för en vårdgivare |
| [GetBlocksForPatient](7-tjanstekontrakt.md#getblocksforpatient) | 2.0 | Läs spärrar för patient och vårdgivare |

### Accesscontrol — Spärrkontroll

| | | |
| :--- | :--- | :--- |
| [CheckBlocks](7-tjanstekontrakt.md#checkblocks) | 3.0 | Kontrollera om spärr finns för given personal/vårdenhet |

### Synchronization — Replikering till nationell tjänst

| | | |
| :--- | :--- | :--- |
| [RegisterBlock](7-tjanstekontrakt.md#registerblock) | 2.0 | Registrera spärr i nationell spärrtjänst |
| [UnregisterBlock](7-tjanstekontrakt.md#unregisterblock) | 2.0 | Avregistrera spärr från nationell spärrtjänst |
| [RegisterTemporaryRevoke](7-tjanstekontrakt.md#registertemporaryrevoke) | 2.0 | Registrera tillfällig hävning |
| [UnregisterTemporaryRevoke](7-tjanstekontrakt.md#unregistertemporaryrevoke) | 2.0 | Avregistrera tillfällig hävning |

### Administration — Lokal spärradministration

| | | |
| :--- | :--- | :--- |
| [GetPatientIds](7-tjanstekontrakt.md#getpatientids) | 2.0 | Läs patient-ID för spärrade patienter |
| [GetExtendedBlocksForPatient](7-tjanstekontrakt.md#getextendedblocksforpatient) | 2.0 | Läs utökade spärrar för patient |
| [RegisterExtendedBlock](7-tjanstekontrakt.md#registerextendedblock) | 2.0 | Registrera utökad spärr |
| [RevokeExtendedBlock](7-tjanstekontrakt.md#revokeextendedblock) | 2.0 | Häv spärr permanent |
| [DeleteExtendedBlock](7-tjanstekontrakt.md#deleteextendedblock) | 2.0 | Makulera spärr |
| [RegisterTemporaryExtendedRevoke](7-tjanstekontrakt.md#registertemporaryextendedrevoke) | 2.0 | Registrera tillfällig hävning (utökad) |
| [CancelTemporaryExtendedRevoke](7-tjanstekontrakt.md#canceltemporaryextendedrevoke) | 2.0 | Återkalla tillfällig hävning |

### Versioner och granskningar

| | | | |
| :--- | :--- | :--- | :--- |
| 3.2.2 | AB, TKB | [Arkitektur & Regelverk: Teknik: Godkänd](http://rivta.se/downloads//ehr_blocking/3.2.2/T-granskning%20-%20ehr_blocking_3.2.2.docx) | [zip](http://rivta.se/downloads//ehr_blocking/3.2.2/ServiceContracts_ehr_blocking_3.2.2.zip)·[källkod](https://bitbucket.org/rivta-domains/riv.ehr.blocking/src/ehr_blocking_3.2.2) |
| 2.0 |  | Äldre granskningsprocess: Teknik: Godkänd | [zip](http://rivta.se/downloads/ehr_blocking/2.0/ServiceContracts_ehr_blocking_2.0.zip)·[källkod](https://bitbucket.org/rivta-domains/riv.ehr.blocking/src/ehr_blocking_2.0) |
| trunk | TKB, AB |  | [källkod](https://bitbucket.org/rivta-domains/riv.ehr.blocking/src/master) |

*Källa: ögonblicksbild av DOMDB från 2021-08-24, via RIV-TA-portalen.*

## Innehåll

* [1 Inledning](1-inledning.md)
* [2 Generella regler](2-generella-regler.md)
* [7 Tjänstekontrakt](7-tjanstekontrakt.md)
* [Artefakter](artifacts.md)

