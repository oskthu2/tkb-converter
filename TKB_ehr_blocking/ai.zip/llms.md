# inera.ehr-blocking#3.2.2: ehr: blocking — Spärrhantering

## Pages

* [Hem](index.md)
* [7 Tjänstekontrakt](7-tjanstekontrakt.md)
* [1 Inledning](1-inledning.md)
* [2 Generella regler](2-generella-regler.md)
* [Artifacts Summary](artifacts.md)

## Resources

### CodeSystems

* [BlockType](CodeSystem-blocktype-cs.md)
* [ResultCode](CodeSystem-resultcode-cs.md)
* [TemporaryRevokeReason](CodeSystem-temporaryrevokereason-cs.md)

### ValueSets

* [BlockType — ValueSet](ValueSet-blocktype-vs.md)
* [ResultCode — ValueSet](ValueSet-resultcode-vs.md)
* [TemporaryRevokeReason — ValueSet](ValueSet-temporaryrevokereason-vs.md)

### Logicals

* [CheckBlocks — Request](StructureDefinition-checkblocks-request.md)
* [CheckBlocks](StructureDefinition-checkblocks.md)
* [DeleteExtendedBlock — Request](StructureDefinition-deleteextendedblock-request.md)
* [DeleteExtendedBlock](StructureDefinition-deleteextendedblock.md)
* [GetAllBlocks — Request](StructureDefinition-getallblocks-request.md)
* [GetAllBlocks](StructureDefinition-getallblocks.md)
* [GetAllBlocksForPatient — Request](StructureDefinition-getallblocksforpatient-request.md)
* [GetAllBlocksForPatient](StructureDefinition-getallblocksforpatient.md)
* [GetBlocks — Request](StructureDefinition-getblocks-request.md)
* [GetBlocks](StructureDefinition-getblocks.md)
* [GetBlocksForPatient — Request](StructureDefinition-getblocksforpatient-request.md)
* [GetBlocksForPatient](StructureDefinition-getblocksforpatient.md)
* [GetExtendedBlocksForPatient — Request](StructureDefinition-getextendedblockforpatient-request.md)
* [GetExtendedBlocksForPatient](StructureDefinition-getextendedblockforpatient.md)
* [GetPatientIds — Request](StructureDefinition-getpatientids-request.md)
* [GetPatientIds](StructureDefinition-getpatientids.md)
* [RegisterBlock — Request](StructureDefinition-registerblock-request.md)
* [RegisterBlock](StructureDefinition-registerblock.md)
* [RegisterExtendedBlock — Request](StructureDefinition-registerextendedblock-request.md)
* [RegisterExtendedBlock](StructureDefinition-registerextendedblock.md)
* [RegisterTemporaryExtendedRevoke](StructureDefinition-registertemporaryextendedrevoke.md)
* [RegisterTemporaryRevoke — Request](StructureDefinition-registertemporaryrevoke-request.md)
* [RegisterTemporaryRevoke](StructureDefinition-registertemporaryrevoke.md)
* [RevokeExtendedBlock — Request](StructureDefinition-revokeextendedblock-request.md)
* [RevokeExtendedBlock](StructureDefinition-revokeextendedblock.md)
* [UnregisterBlock — Request](StructureDefinition-unregisterblock-request.md)
* [UnregisterBlock](StructureDefinition-unregisterblock.md)
* [UnregisterTemporaryRevoke — Request](StructureDefinition-unregistertemporaryrevoke-request.md)
* [UnregisterTemporaryRevoke](StructureDefinition-unregistertemporaryrevoke.md)

### ImplementationGuides

* [ehr: blocking — Spärrhantering](index.md)
