# GetBlocksForPatient — Request - ehr: blocking — Spärrhantering v3.2.2

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **GetBlocksForPatient — Request**

## Logical Model: GetBlocksForPatient — Request 

| | |
| :--- | :--- |
| *Official URL*:https://fhir.inera.se/ig/ehr-blocking/StructureDefinition/getblocksforpatient-request | *Version*:2.0 |
| Active as of 2026-11-06 | *Computable Name*:GetBlocksForPatientRequest |
| **Copyright/Legal**: Copyright 2024 Inera AB. Licensieras under Creative Commons Attribution 4.0. | |

 
Logisk modell för requestparametrar i GetBlocksForPatient. 

**Usages:**

* This Logical Model is not used by any profiles in this Specification

You can also check for [usages in the FHIR IG Statistics](https://packages2.fhir.org/xig/resource/inera.ehr-blocking|current/StructureDefinition/StructureDefinition-getblocksforpatient-request.json)

### Formal Views of Profile Content

 [Description of Profiles, Differentials, Snapshots and how the different presentations work](http://build.fhir.org/ig/FHIR/ig-guidance/readingIgs.html#structure-definitions). 

 

Other representations of profile: [CSV](StructureDefinition-getblocksforpatient-request.csv), [Excel](StructureDefinition-getblocksforpatient-request.xlsx) 



## Resource Content

```json
{
  "resourceType" : "StructureDefinition",
  "id" : "getblocksforpatient-request",
  "extension" : [{
    "url" : "http://hl7.org/fhir/StructureDefinition/structuredefinition-type-characteristics",
    "valueCode" : "can-be-target"
  }],
  "url" : "https://fhir.inera.se/ig/ehr-blocking/StructureDefinition/getblocksforpatient-request",
  "version" : "2.0",
  "name" : "GetBlocksForPatientRequest",
  "title" : "GetBlocksForPatient — Request",
  "status" : "active",
  "date" : "2026-11-06T21:14:37+00:00",
  "contact" : [{
    "name" : "Inera Arkitektur",
    "telecom" : [{
      "system" : "url",
      "value" : "https://www.inera.se"
    }]
  }],
  "description" : "Logisk modell för requestparametrar i GetBlocksForPatient.",
  "copyright" : "Copyright 2024 Inera AB. Licensieras under Creative Commons Attribution 4.0.",
  "fhirVersion" : "4.0.1",
  "kind" : "logical",
  "abstract" : false,
  "type" : "https://fhir.inera.se/ig/ehr-blocking/StructureDefinition/getblocksforpatient-request",
  "baseDefinition" : "http://hl7.org/fhir/StructureDefinition/Base",
  "derivation" : "specialization",
  "differential" : {
    "element" : [{
      "id" : "getblocksforpatient-request",
      "path" : "getblocksforpatient-request",
      "short" : "GetBlocksForPatient — Request",
      "definition" : "Logisk modell för requestparametrar i GetBlocksForPatient."
    },
    {
      "id" : "getblocksforpatient-request.patientId",
      "path" : "getblocksforpatient-request.patientId",
      "short" : "Patientens personnummer eller samordningsnummer vars spärrar skall hämtas.",
      "definition" : "Patientens personnummer eller samordningsnummer vars spärrar skall hämtas.",
      "comment" : "TKB-fält: `patientId` (`blocking:PersonIdValue`, kardinalitet 1..1).",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "getblocksforpatient-request.careProviderId",
      "path" : "getblocksforpatient-request.careProviderId",
      "short" : "HSA-id på den vårdgivare vars spärrar skall hämtas.",
      "definition" : "HSA-id på den vårdgivare vars spärrar skall hämtas.",
      "comment" : "TKB-fält: `careProviderId` (`blocking:HsaId`, kardinalitet 1..1).",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "getblocksforpatient-request.createdOnOrAfter",
      "path" : "getblocksforpatient-request.createdOnOrAfter",
      "short" : "Startdatum för inkrementell hämtning.",
      "definition" : "Ej obligatoriskt startdatum för hur gamla spärrobjekt som skall hämtas. Om angivet returneras endast spärrar och/eller tillfälliga hävningar lagrade/förändrade i tjänsten på eller efter denna tidpunkt. Användbart vid upprepande förfrågningar och undviker att data som redan inhämtats returneras.",
      "comment" : "TKB-fält: `createdOnOrAfter` (`xs:dateTime`, kardinalitet 0..1).",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "dateTime"
      }]
    }]
  }
}

```
