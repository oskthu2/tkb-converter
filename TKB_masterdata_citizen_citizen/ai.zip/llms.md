# inera.masterdata-citizen-citizen#2.0.0: masterdata: citizen: citizen

## Pages

* [Hem](index.md)
* [7 Tjänstekontrakt](7-tjanstekontrakt.md)
* [5 Tjänstedomänens meddelandemodeller](5-tjanstedomanens-meddelandemodeller.md)
* [Artifacts Summary](artifacts.md)
* [6 Gemensamma informationskomponenter](6-gemensamma-informationskomponenter.md)
* [3 Tjänstedomänens arkitektur](3-tjanstedomanens-arkitektur.md)
* [8 Aktuella profiler](8-aktuella-profiler.md)
* [4 Tjänstedomänens krav och regler](4-tjanstedomanens-krav-och-regler.md)
* [2 Versionsinformation](2-versionsinformation.md)
* [1 Inledning](1-inledning.md)

## Resources

### CodeSystems

* [Statuskod för medborgarskap](CodeSystem-masterdata-citizen-citizen-citizenshipstatus-cs.md)
* [Datumformat (noggrannhet)](CodeSystem-masterdata-citizen-citizen-datetypeformat-cs.md)
* [Kod för avregistreringsorsak](CodeSystem-masterdata-citizen-citizen-deregistrationreasoncode-cs.md)
* [Profil](CodeSystem-masterdata-citizen-citizen-lookupprofile-cs.md)
* [Civilståndskod](CodeSystem-masterdata-citizen-citizen-maritalstatuscode-cs.md)
* [Kod för folkbokföringskategori](CodeSystem-masterdata-citizen-citizen-populationregistrationtype-cs.md)
* [Statuskod för relation](CodeSystem-masterdata-citizen-citizen-relationshipstatus-cs.md)
* [Relationstyp](CodeSystem-masterdata-citizen-citizen-relationshiptype-cs.md)

### ValueSets

* [Statuskod för medborgarskap](ValueSet-masterdata-citizen-citizen-citizenshipstatus-vs.md)
* [Datumformat (noggrannhet)](ValueSet-masterdata-citizen-citizen-datetypeformat-vs.md)
* [Kod för avregistreringsorsak](ValueSet-masterdata-citizen-citizen-deregistrationreasoncode-vs.md)
* [Profil](ValueSet-masterdata-citizen-citizen-lookupprofile-vs.md)
* [Civilståndskod](ValueSet-masterdata-citizen-citizen-maritalstatuscode-vs.md)
* [Kod för folkbokföringskategori](ValueSet-masterdata-citizen-citizen-populationregistrationtype-vs.md)
* [Statuskod för relation](ValueSet-masterdata-citizen-citizen-relationshipstatus-vs.md)
* [Relationstyp](ValueSet-masterdata-citizen-citizen-relationshiptype-vs.md)

### Logicals

* [LookupResidentsForProfile — Request](StructureDefinition-lookupresidentsforprofile-request.md)
* [LookupResidentsForProfile — Response](StructureDefinition-lookupresidentsforprofile.md)

### ImplementationGuides

* [masterdata: citizen: citizen](index.md)
