# Hem - masterdata: citizen: citizen v2.0.0

* [**Table of Contents**](toc.md)
* **Hem**

## Hem

| | |
| :--- | :--- |
| *Official URL*:https://fhir.inera.se/ig/masterdata-citizen-citizen/ImplementationGuide/inera.masterdata-citizen-citizen | *Version*:2.0.0 |
| Active as of 2026-10-08 | *Computable Name*:masterdatacitizencitizen |
| **Copyright/Legal**: Copyright 2024 Inera AB. Licensieras under Creative Commons Attribution 4.0. | |

# masterdata: citizen: citizen

**TKB-version:** 2.0 · **IG-version:** 2.0.0 · **Källa:** Bitbucket-tagg `2.0` 

## Översikt

FHIR Implementation Guide för tjänstedomänen **masterdata: citizen: citizen** (Personuppgifter) version 2.0. Genererad från Ineras Tjänstekontraktsbeskrivning (TKB), version 2.0 (revision RC3, 2016-04-22), och domänens WSDL- och XSD-filer (tagg 2.0).

Syftet med domänen är att tillgängliggöra personuppgifter ur Skatteverkets folkbokföringsregister (Navet) för invånare bosatta i Sverige, till exempel namn, adress och relationer. Domänen ersätter riv.population.residentmaster.

Domänen innehåller följande tjänstekontrakt:

| | | |
| :--- | :--- | :--- |
| [LookupResidentsForProfile](7-tjanstekontrakt.md#lookupresidentsforprofile) | 2.0 | Tjänst för att hämta uppgifter för 1..* personidentiteter. |

## Innehåll

* [1 Inledning](1-inledning.md)
* [2 Versionsinformation](2-versionsinformation.md)
* [3 Tjänstedomänens arkitektur](3-tjanstedomanens-arkitektur.md)
* [4 Tjänstedomänens krav och regler](4-tjanstedomanens-krav-och-regler.md)
* [5 Tjänstedomänens meddelandemodeller](5-tjanstedomanens-meddelandemodeller.md)
* [6 Gemensamma informationskomponenter](6-gemensamma-informationskomponenter.md)
* [7 Tjänstekontrakt](7-tjanstekontrakt.md)
* [8 Aktuella profiler](8-aktuella-profiler.md)
* [Artefakter](artifacts.md)

