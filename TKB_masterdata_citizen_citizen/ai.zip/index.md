# Hem - masterdata: citizen: citizen v2.0.0

* [**Table of Contents**](toc.md)
* **Hem**

## Hem

| | |
| :--- | :--- |
| *Official URL*:https://fhir.inera.se/ig/masterdata-citizen-citizen/ImplementationGuide/inera.masterdata-citizen-citizen | *Version*:2.0.0 |
| Active as of 2026-10-12 | *Computable Name*:masterdatacitizencitizen |
| **Copyright/Legal**: Copyright 2024 Inera AB. Licensieras under Creative Commons Attribution 4.0. | |

# masterdata: citizen: citizen

**TKB-version:** 2.0 · **IG-version:** 2.0.0 · **Källa:** Bitbucket-tagg `2.0` 

## Översikt

* Beskrivning: Svenskt kortnamn
  * OBSERVERA: Denna domän utvecklas inte längre, för nyutveckling, support och buggrättningar hänvisas till den nya domänen: personuppgiftshantering - strategicresourcemanagement:persons:person Syftet med denna domän är primärt att tillgängliggöra personuppgifter registrerade i Skatteverkets folkbokföringsregister för invånare bosatta i Sverige. Folkbokföringsuppgifterna omfattar bland annat namn, adress, fastighetsuppgifter mm. Konsumenter på domänens information kan vara de flesta vård- och omsorgssystem som hanterar patienter/invånare, men kan även behövas i system som hanterar medarbetare, katalogsystem, identitetshanteringssystem etc. Uppgifterna i tjänsteproducent hålls ajour med uppgifterna i bakomliggande register primärt genom regelbundna aviseringar (alla förändringar sedan sist), kompletterat med online-slagning om uppgift saknas i tjänsteproducent.: personuppgiftshantering
* Beskrivning: Svenskt namn
  * OBSERVERA: Denna domän utvecklas inte längre, för nyutveckling, support och buggrättningar hänvisas till den nya domänen: personuppgiftshantering - strategicresourcemanagement:persons:person Syftet med denna domän är primärt att tillgängliggöra personuppgifter registrerade i Skatteverkets folkbokföringsregister för invånare bosatta i Sverige. Folkbokföringsuppgifterna omfattar bland annat namn, adress, fastighetsuppgifter mm. Konsumenter på domänens information kan vara de flesta vård- och omsorgssystem som hanterar patienter/invånare, men kan även behövas i system som hanterar medarbetare, katalogsystem, identitetshanteringssystem etc. Uppgifterna i tjänsteproducent hålls ajour med uppgifterna i bakomliggande register primärt genom regelbundna aviseringar (alla förändringar sedan sist), kompletterat med online-slagning om uppgift saknas i tjänsteproducent.: underlagförprocesstöd:invånare:personuppgifter
* Beskrivning: Typ
  * OBSERVERA: Denna domän utvecklas inte längre, för nyutveckling, support och buggrättningar hänvisas till den nya domänen: personuppgiftshantering - strategicresourcemanagement:persons:person Syftet med denna domän är primärt att tillgängliggöra personuppgifter registrerade i Skatteverkets folkbokföringsregister för invånare bosatta i Sverige. Folkbokföringsuppgifterna omfattar bland annat namn, adress, fastighetsuppgifter mm. Konsumenter på domänens information kan vara de flesta vård- och omsorgssystem som hanterar patienter/invånare, men kan även behövas i system som hanterar medarbetare, katalogsystem, identitetshanteringssystem etc. Uppgifterna i tjänsteproducent hålls ajour med uppgifterna i bakomliggande register primärt genom regelbundna aviseringar (alla förändringar sedan sist), kompletterat med online-slagning om uppgift saknas i tjänsteproducent.: Nationell tjänstedomän
* Beskrivning: Källkod
  * OBSERVERA: Denna domän utvecklas inte längre, för nyutveckling, support och buggrättningar hänvisas till den nya domänen: personuppgiftshantering - strategicresourcemanagement:persons:person Syftet med denna domän är primärt att tillgängliggöra personuppgifter registrerade i Skatteverkets folkbokföringsregister för invånare bosatta i Sverige. Folkbokföringsuppgifterna omfattar bland annat namn, adress, fastighetsuppgifter mm. Konsumenter på domänens information kan vara de flesta vård- och omsorgssystem som hanterar patienter/invånare, men kan även behövas i system som hanterar medarbetare, katalogsystem, identitetshanteringssystem etc. Uppgifterna i tjänsteproducent hålls ajour med uppgifterna i bakomliggande register primärt genom regelbundna aviseringar (alla förändringar sedan sist), kompletterat med online-slagning om uppgift saknas i tjänsteproducent.: [Bitbucket](https://bitbucket.org/rivta-domains/riv.masterdata.citizen.citizen/src)
* Beskrivning: Ärenden
  * OBSERVERA: Denna domän utvecklas inte längre, för nyutveckling, support och buggrättningar hänvisas till den nya domänen: personuppgiftshantering - strategicresourcemanagement:persons:person Syftet med denna domän är primärt att tillgängliggöra personuppgifter registrerade i Skatteverkets folkbokföringsregister för invånare bosatta i Sverige. Folkbokföringsuppgifterna omfattar bland annat namn, adress, fastighetsuppgifter mm. Konsumenter på domänens information kan vara de flesta vård- och omsorgssystem som hanterar patienter/invånare, men kan även behövas i system som hanterar medarbetare, katalogsystem, identitetshanteringssystem etc. Uppgifterna i tjänsteproducent hålls ajour med uppgifterna i bakomliggande register primärt genom regelbundna aviseringar (alla förändringar sedan sist), kompletterat med online-slagning om uppgift saknas i tjänsteproducent.: [Bitbucket issues](https://bitbucket.org/rivta-domains/riv.masterdata.citizen.citizen/issues)
* Beskrivning: Underlag för denna IG
  * OBSERVERA: Denna domän utvecklas inte längre, för nyutveckling, support och buggrättningar hänvisas till den nya domänen: personuppgiftshantering - strategicresourcemanagement:persons:person Syftet med denna domän är primärt att tillgängliggöra personuppgifter registrerade i Skatteverkets folkbokföringsregister för invånare bosatta i Sverige. Folkbokföringsuppgifterna omfattar bland annat namn, adress, fastighetsuppgifter mm. Konsumenter på domänens information kan vara de flesta vård- och omsorgssystem som hanterar patienter/invånare, men kan även behövas i system som hanterar medarbetare, katalogsystem, identitetshanteringssystem etc. Uppgifterna i tjänsteproducent hålls ajour med uppgifterna i bakomliggande register primärt genom regelbundna aviseringar (alla förändringar sedan sist), kompletterat med online-slagning om uppgift saknas i tjänsteproducent.: Version 2.0 ·[tagg 2.0](https://bitbucket.org/rivta-domains/riv.masterdata.citizen.citizen/src/2.0)·[zip](https://bitbucket.org/rivta-domains/riv.masterdata.citizen.citizen/get/2.0.zip)
* Beskrivning: RIV-TA-portalen
  * OBSERVERA: Denna domän utvecklas inte längre, för nyutveckling, support och buggrättningar hänvisas till den nya domänen: personuppgiftshantering - strategicresourcemanagement:persons:person Syftet med denna domän är primärt att tillgängliggöra personuppgifter registrerade i Skatteverkets folkbokföringsregister för invånare bosatta i Sverige. Folkbokföringsuppgifterna omfattar bland annat namn, adress, fastighetsuppgifter mm. Konsumenter på domänens information kan vara de flesta vård- och omsorgssystem som hanterar patienter/invånare, men kan även behövas i system som hanterar medarbetare, katalogsystem, identitetshanteringssystem etc. Uppgifterna i tjänsteproducent hålls ajour med uppgifterna i bakomliggande register primärt genom regelbundna aviseringar (alla förändringar sedan sist), kompletterat med online-slagning om uppgift saknas i tjänsteproducent.: [Alla tjänstedomäner](https://oskthu2.github.io/tkb-converter/rivta-portal/tjanstedomaner.html)·[Alla tjänstekontrakt](https://oskthu2.github.io/tkb-converter/rivta-portal/tjanstekontrakt.html)

FHIR Implementation Guide för tjänstedomänen **masterdata: citizen: citizen** (Personuppgifter) version 2.0. Genererad från Ineras Tjänstekontraktsbeskrivning (TKB), version 2.0 (revision RC3, 2016-04-22), och domänens WSDL- och XSD-filer (tagg 2.0).

Syftet med domänen är att tillgängliggöra personuppgifter ur Skatteverkets folkbokföringsregister (Navet) för invånare bosatta i Sverige, till exempel namn, adress och relationer. Domänen ersätter riv.population.residentmaster.

Domänen innehåller följande tjänstekontrakt:

| | | |
| :--- | :--- | :--- |
| [LookupResidentsForProfile](7-tjanstekontrakt.md#lookupresidentsforprofile) | 2.0 | Tjänst för att hämta uppgifter för 1..* personidentiteter. |

### Versioner och granskningar

| | | | |
| :--- | :--- | :--- | :--- |
| 2.1_RC1 | AB, IS, TKB | [Arkitektur & Regelverk: Säkerhet: Delvis Godkänd](http://rivta.se/downloads//masterdata_citizen_citizen/2.1_RC1/VIS_granskning%20-%20masterdata_citizen_citizen_2.1_RC1.docx)[Arkitektur & Regelverk: Teknik: Godkänd](http://rivta.se/downloads//masterdata_citizen_citizen/2.1_RC1/T-granskning%20masterdata_citizen_citizen_2.1_RC1.docx)[Arkitektur & Regelverk: Informatik: Godkänd](http://rivta.se/downloads//masterdata_citizen_citizen/2.1_RC1/VIS_granskning%20-%20masterdata_citizen_citizen_2.1_RC1.docx) | [zip](http://rivta.se/downloads//masterdata_citizen_citizen/2.1_RC1/ServiceContracts_masterdata_citizen_citizen_2.1_RC1.zip)·[källkod](https://bitbucket.org/rivta-domains/riv.masterdata.citizen.citizen/src/2.1_RC1) |
| 2.0 | AB, IS, TKB | [Arkitektur & Regelverk: Säkerhet: Godkänd](http://rivta.se/downloads//masterdata_citizen_citizen/2.0/VIS_granskning_masterdata_citizen_citizen_2.0.docx)[Arkitektur & Regelverk: Teknik: Godkänd](http://rivta.se/downloads//masterdata_citizen_citizen/2.0/AL%20T-Granskning%20masterdata_citizen_citizen_2.0.docx)[Arkitektur & Regelverk: Informatik: Godkänd](http://rivta.se/downloads//masterdata_citizen_citizen/2.0/VIS_granskning_masterdata_citizen_citizen_2.0.docx) | [zip](http://rivta.se/downloads//masterdata_citizen_citizen/2.0/ServiceContracts_masterdata_citizen_citizen_2.0.zip)·[källkod](https://bitbucket.org/rivta-domains/riv.masterdata.citizen.citizen/src/2.0) |
| trunk | IS, AB, TKB |  | [källkod](https://bitbucket.org/rivta-domains/riv.masterdata.citizen.citizen/src/master) |

*Källa: ögonblicksbild av DOMDB från 2021-08-24, via RIV-TA-portalen.*

## Innehåll

* [1 Inledning](1-inledning.md)
* [2 Versionsinformation](2-versionsinformation.md)
* [3 Tjänstedomänens arkitektur](3-tjanstedomanens-arkitektur.md)
* [4 Tjänstedomänens krav och regler](4-tjanstedomanens-krav-och-regler.md)
* [5 Tjänstedomänens meddelandemodeller](5-tjanstedomanens-meddelandemodeller.md)
* [6 Gemensamma informationskomponenter](6-gemensamma-informationskomponenter.md)
* [7 Tjänstekontrakt](7-tjanstekontrakt.md)
* [8 Aktuella profiler](8-aktuella-profiler.md)
* [Artefakter](artifacts.md)

