# GetSeals — Request - informationsecurity: authorization: pip v1.0.0-rc1.snapshot

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **GetSeals — Request**

## Logical Model: GetSeals — Request 

| | |
| :--- | :--- |
| *Official URL*:https://fhir.inera.se/ig/informationsecurity-authorization-pip/StructureDefinition/getseals-request | *Version*:1.0 |
| Draft as of 2026-10-12 | *Computable Name*:GetSealsRequest |
| **Copyright/Legal**: Copyright 2024 Inera AB. Licensieras under Creative Commons Attribution 4.0. | |

 
Logisk modell för begäran i GetSeals (urn:riv:informationsecurity:authorization:pip:GetSealsResponder:1, GetSealsType), inklusive SOAP-huvuden enligt WSDL. 

**Usages:**

* This Logical Model is not used by any profiles in this Specification

You can also check for [usages in the FHIR IG Statistics](https://packages2.fhir.org/xig/resource/inera.informationsecurity-authorization-pip|current/StructureDefinition/StructureDefinition-getseals-request.json)

### Formal Views of Profile Content

 [Description of Profiles, Differentials, Snapshots and how the different presentations work](http://build.fhir.org/ig/FHIR/ig-guidance/readingIgs.html#structure-definitions). 

 

Other representations of profile: [CSV](StructureDefinition-getseals-request.csv), [Excel](StructureDefinition-getseals-request.xlsx) 



## Resource Content

```json
{
  "resourceType" : "StructureDefinition",
  "id" : "getseals-request",
  "extension" : [{
    "url" : "http://hl7.org/fhir/StructureDefinition/structuredefinition-type-characteristics",
    "valueCode" : "can-be-target"
  }],
  "url" : "https://fhir.inera.se/ig/informationsecurity-authorization-pip/StructureDefinition/getseals-request",
  "version" : "1.0",
  "name" : "GetSealsRequest",
  "title" : "GetSeals — Request",
  "status" : "draft",
  "date" : "2026-10-12T12:30:26+00:00",
  "contact" : [{
    "name" : "Inera Arkitektur",
    "telecom" : [{
      "system" : "url",
      "value" : "https://www.inera.se"
    }]
  }],
  "description" : "Logisk modell för begäran i GetSeals\n(urn:riv:informationsecurity:authorization:pip:GetSealsResponder:1, GetSealsType), inklusive SOAP-huvuden enligt WSDL.",
  "copyright" : "Copyright 2024 Inera AB. Licensieras under Creative Commons Attribution 4.0.",
  "fhirVersion" : "4.0.1",
  "kind" : "logical",
  "abstract" : false,
  "type" : "https://fhir.inera.se/ig/informationsecurity-authorization-pip/StructureDefinition/getseals-request",
  "baseDefinition" : "http://hl7.org/fhir/StructureDefinition/Base",
  "derivation" : "specialization",
  "differential" : {
    "element" : [{
      "id" : "getseals-request",
      "path" : "getseals-request",
      "short" : "GetSeals — Request",
      "definition" : "Logisk modell för begäran i GetSeals\n(urn:riv:informationsecurity:authorization:pip:GetSealsResponder:1, GetSealsType), inklusive SOAP-huvuden enligt WSDL."
    },
    {
      "id" : "getseals-request.logicalAddress",
      "path" : "getseals-request.logicalAddress",
      "short" : "logicalAddress",
      "definition" : "SOAP-huvud LogicalAddress. The HSA id of Inera (5565594230)",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "getseals-request.patientId",
      "path" : "getseals-request.patientId",
      "short" : "patientId",
      "definition" : "patientId",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "BackboneElement"
      }]
    },
    {
      "id" : "getseals-request.patientId.root",
      "path" : "getseals-request.patientId.root",
      "short" : "root",
      "definition" : "root",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "getseals-request.patientId.iiExtension",
      "path" : "getseals-request.patientId.iiExtension",
      "short" : "iiExtension",
      "definition" : "iiExtension Heter extension i schemat.",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    }]
  }
}

```
