# Hem - informationsecurity: authorization: pip v1.0.0-rc1.snapshot

* [**Table of Contents**](toc.md)
* **Hem**

## Hem

| | |
| :--- | :--- |
| *Official URL*:https://fhir.inera.se/ig/informationsecurity-authorization-pip/ImplementationGuide/inera.informationsecurity-authorization-pip | *Version*:1.0.0-rc1.snapshot |
| Draft as of 2026-10-12 | *Computable Name*:informationsecurityauthorizationpip |
| **Copyright/Legal**: Copyright 2024 Inera AB. Licensieras under Creative Commons Attribution 4.0. | |

# informationsecurity: authorization: pip

**TKB-version:** 1.0_RC1 · **IG-version:** 1.0.0-rc1.snapshot · **Källa:** Bitbucket-commit `729301865b83` (ingen tagg) 

## Översikt

* Beskrivning: Svenskt kortnamn
  * Tjänstedomänens ändamål är att förse övriga tjänster med kvalitetssäkrad och aktuell behörighetsgrundande information. Användningsområden utgörs främst av sökningar efter behörighetsgrundande egenskaper i form av information om personers uppdrag kopplade till organisation samt anställningsrelaterade och personliga egenskaper av betydelse för åtkomst till information, vilket ofta, men inte alltid, är relaterat till Patientdatalagen, PDL.: behörighetshantering
* Beskrivning: Svenskt namn
  * Tjänstedomänens ändamål är att förse övriga tjänster med kvalitetssäkrad och aktuell behörighetsgrundande information. Användningsområden utgörs främst av sökningar efter behörighetsgrundande egenskaper i form av information om personers uppdrag kopplade till organisation samt anställningsrelaterade och personliga egenskaper av betydelse för åtkomst till information, vilket ofta, men inte alltid, är relaterat till Patientdatalagen, PDL.: infrastruktur:katalogtjänster:behörighetshantering
* Beskrivning: Typ
  * Tjänstedomänens ändamål är att förse övriga tjänster med kvalitetssäkrad och aktuell behörighetsgrundande information. Användningsområden utgörs främst av sökningar efter behörighetsgrundande egenskaper i form av information om personers uppdrag kopplade till organisation samt anställningsrelaterade och personliga egenskaper av betydelse för åtkomst till information, vilket ofta, men inte alltid, är relaterat till Patientdatalagen, PDL.: Nationell tjänstedomän
* Beskrivning: Anmärkning
  * Tjänstedomänens ändamål är att förse övriga tjänster med kvalitetssäkrad och aktuell behörighetsgrundande information. Användningsområden utgörs främst av sökningar efter behörighetsgrundande egenskaper i form av information om personers uppdrag kopplade till organisation samt anställningsrelaterade och personliga egenskaper av betydelse för åtkomst till information, vilket ofta, men inte alltid, är relaterat till Patientdatalagen, PDL.: dold på rivta.se
* Beskrivning: Källkod
  * Tjänstedomänens ändamål är att förse övriga tjänster med kvalitetssäkrad och aktuell behörighetsgrundande information. Användningsområden utgörs främst av sökningar efter behörighetsgrundande egenskaper i form av information om personers uppdrag kopplade till organisation samt anställningsrelaterade och personliga egenskaper av betydelse för åtkomst till information, vilket ofta, men inte alltid, är relaterat till Patientdatalagen, PDL.: [Bitbucket](https://bitbucket.org/rivta-domains/riv.informationsecurity.authorization.pip/src)
* Beskrivning: Ärenden
  * Tjänstedomänens ändamål är att förse övriga tjänster med kvalitetssäkrad och aktuell behörighetsgrundande information. Användningsområden utgörs främst av sökningar efter behörighetsgrundande egenskaper i form av information om personers uppdrag kopplade till organisation samt anställningsrelaterade och personliga egenskaper av betydelse för åtkomst till information, vilket ofta, men inte alltid, är relaterat till Patientdatalagen, PDL.: [Bitbucket issues](https://bitbucket.org/rivta-domains/riv.informationsecurity.authorization.pip/issues)
* Beskrivning: Underlag för denna IG
  * Tjänstedomänens ändamål är att förse övriga tjänster med kvalitetssäkrad och aktuell behörighetsgrundande information. Användningsområden utgörs främst av sökningar efter behörighetsgrundande egenskaper i form av information om personers uppdrag kopplade till organisation samt anställningsrelaterade och personliga egenskaper av betydelse för åtkomst till information, vilket ofta, men inte alltid, är relaterat till Patientdatalagen, PDL.: Version 1.0_RC1 ·[commit 729301865b83](https://bitbucket.org/rivta-domains/riv.informationsecurity.authorization.pip/src/729301865b83463d7ae96302329aac91301921df)·[zip](https://bitbucket.org/rivta-domains/riv.informationsecurity.authorization.pip/get/729301865b83.zip)
* Beskrivning: RIV-TA-portalen
  * Tjänstedomänens ändamål är att förse övriga tjänster med kvalitetssäkrad och aktuell behörighetsgrundande information. Användningsområden utgörs främst av sökningar efter behörighetsgrundande egenskaper i form av information om personers uppdrag kopplade till organisation samt anställningsrelaterade och personliga egenskaper av betydelse för åtkomst till information, vilket ofta, men inte alltid, är relaterat till Patientdatalagen, PDL.: [Alla tjänstedomäner](https://oskthu2.github.io/tkb-converter/rivta-portal/tjanstedomaner.html)·[Alla tjänstekontrakt](https://oskthu2.github.io/tkb-converter/rivta-portal/tjanstekontrakt.html)

FHIR Implementation Guide för tjänstedomänen **informationsecurity: authorization: pip** (Behörighetsinformation) version 1.0. Genererad från Ineras Tjänstekontraktsbeskrivning (TKB), version 1.0_RC1 (2017-06-28), och domänens WSDL- och XSD-filer (senaste commit på master, 729301865b83).

Tjänstedomänen tillhandahåller beslutsunderlag för åtkomstkontroll. Producenter har rollen som **policy information point**. Tjänstekontraktet GetSeals ger e-tjänster invånarens förseglingar, så att förseglad journalinformation kan filtreras bort innan den visas för invånaren.

Domänen innehåller följande tjänstekontrakt:

| | | |
| :--- | :--- | :--- |
| [GetSeals](7-tjanstekontrakt.md#getseals) | 1.0 | Tjänstekontraktet GetSeals används för att vårdgivare skall kunna försegla invånarens åtkomst till sin egen information. Invånarens information blir då ej tillgänglig för invånaren via självbetjäningstjänster. Används då det finns risk att invånaren befinner sig i vanmaktssituation eller då invånaren ej önskar åtkomst alls till sin journalinformation. Beslut om att försegla journalinformation ligger hos invånaren. Efter taget beslut kan försegling göras av invånaren själv (endast full försegling) eller av vårdpersonal hos vårdgivare som hjälper invånaren att försegla delar av (vårdgivarförsegling eller enhetsförsegling) alternativt all journalinformation (full försegling). |

### Versioner och granskningar

| | | | |
| :--- | :--- | :--- | :--- |
| trunk |  |  |  |

*Källa: ögonblicksbild av DOMDB från 2021-08-24, via RIV-TA-portalen.*

## Innehåll

* [1 Inledning](1-inledning.md)
* [2 Versionsinformation](2-versionsinformation.md)
* [3 Tjänstedomänens arkitektur](3-tjanstedomanens-arkitektur.md)
* [4 Tjänstedomänens krav och regler](4-tjanstedomanens-krav-och-regler.md)
* [5 Tjänstedomänens meddelandemodeller](5-tjanstedomanens-meddelandemodeller.md)
* [6 Gemensamma informationskomponenter](6-gemensamma-informationskomponenter.md)
* [7 Tjänstekontrakt](7-tjanstekontrakt.md)
* [Artefakter](artifacts.md)

