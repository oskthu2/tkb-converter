# inera.informationsecurity-authorization-pip#1.0.0-rc1.snapshot: informationsecurity: authorization: pip

## Pages

* [Hem](index.md)
* [7 Tjänstekontrakt](7-tjanstekontrakt.md)
* [2 Versionsinformation](2-versionsinformation.md)
* [3 Tjänstedomänens arkitektur](3-tjanstedomanens-arkitektur.md)
* [1 Inledning](1-inledning.md)
* [Artifacts Summary](artifacts.md)
* [6 Gemensamma informationskomponenter](6-gemensamma-informationskomponenter.md)
* [5 Tjänstedomänens meddelandemodeller](5-tjanstedomanens-meddelandemodeller.md)
* [4 Tjänstedomänens krav och regler](4-tjanstedomanens-krav-och-regler.md)

## Resources

### Logicals

* [DatePeriodType](StructureDefinition-DatePeriodType.md)
* [IIType](StructureDefinition-IIType.md)
* [GetSeals — Request](StructureDefinition-getseals-request.md)
* [GetSeals — Response](StructureDefinition-getseals.md)

### ImplementationGuides

* [informationsecurity: authorization: pip](index.md)
