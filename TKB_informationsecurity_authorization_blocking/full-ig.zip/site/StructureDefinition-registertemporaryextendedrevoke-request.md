# RegisterTemporaryExtendedRevoke — Request - informationsecurity: authorization: blocking v4.0.4

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **RegisterTemporaryExtendedRevoke — Request**

## Logical Model: RegisterTemporaryExtendedRevoke — Request 

| | |
| :--- | :--- |
| *Official URL*:https://fhir.inera.se/ig/informationsecurity-authorization-blocking/StructureDefinition/registertemporaryextendedrevoke-request | *Version*:4.0 |
| Active as of 2026-11-09 | *Computable Name*:RegisterTemporaryExtendedRevokeRequest |
| **Copyright/Legal**: Copyright 2024 Inera AB. Licensieras under Creative Commons Attribution 4.0. | |

 
Logisk modell för begäran i RegisterTemporaryExtendedRevoke (urn:riv:informationsecurity:authorization:blocking:RegisterTemporaryExtendedRevokeResponder:4, RegisterTemporaryExtendedRevokeType), inklusive SOAP-huvuden enligt WSDL. 

**Usages:**

* This Logical Model is not used by any profiles in this Specification

You can also check for [usages in the FHIR IG Statistics](https://packages2.fhir.org/xig/resource/inera.informationsecurity-authorization-blocking|current/StructureDefinition/StructureDefinition-registertemporaryextendedrevoke-request.json)

### Formal Views of Profile Content

 [Description of Profiles, Differentials, Snapshots and how the different presentations work](http://build.fhir.org/ig/FHIR/ig-guidance/readingIgs.html#structure-definitions). 

 

Other representations of profile: [CSV](StructureDefinition-registertemporaryextendedrevoke-request.csv), [Excel](StructureDefinition-registertemporaryextendedrevoke-request.xlsx) 



## Resource Content

```json
{
  "resourceType" : "StructureDefinition",
  "id" : "registertemporaryextendedrevoke-request",
  "extension" : [{
    "url" : "http://hl7.org/fhir/StructureDefinition/structuredefinition-type-characteristics",
    "valueCode" : "can-be-target"
  }],
  "url" : "https://fhir.inera.se/ig/informationsecurity-authorization-blocking/StructureDefinition/registertemporaryextendedrevoke-request",
  "version" : "4.0",
  "name" : "RegisterTemporaryExtendedRevokeRequest",
  "title" : "RegisterTemporaryExtendedRevoke — Request",
  "status" : "active",
  "date" : "2026-11-09T03:35:16+00:00",
  "contact" : [{
    "name" : "Inera Arkitektur",
    "telecom" : [{
      "system" : "url",
      "value" : "https://www.inera.se"
    }]
  }],
  "description" : "Logisk modell för begäran i RegisterTemporaryExtendedRevoke\n(urn:riv:informationsecurity:authorization:blocking:RegisterTemporaryExtendedRevokeResponder:4, RegisterTemporaryExtendedRevokeType), inklusive SOAP-huvuden enligt WSDL.",
  "copyright" : "Copyright 2024 Inera AB. Licensieras under Creative Commons Attribution 4.0.",
  "fhirVersion" : "4.0.1",
  "kind" : "logical",
  "abstract" : false,
  "type" : "https://fhir.inera.se/ig/informationsecurity-authorization-blocking/StructureDefinition/registertemporaryextendedrevoke-request",
  "baseDefinition" : "http://hl7.org/fhir/StructureDefinition/Base",
  "derivation" : "specialization",
  "differential" : {
    "element" : [{
      "id" : "registertemporaryextendedrevoke-request",
      "path" : "registertemporaryextendedrevoke-request",
      "short" : "RegisterTemporaryExtendedRevoke — Request",
      "definition" : "Logisk modell för begäran i RegisterTemporaryExtendedRevoke\n(urn:riv:informationsecurity:authorization:blocking:RegisterTemporaryExtendedRevokeResponder:4, RegisterTemporaryExtendedRevokeType), inklusive SOAP-huvuden enligt WSDL."
    },
    {
      "id" : "registertemporaryextendedrevoke-request.temporaryRevokeId",
      "path" : "registertemporaryextendedrevoke-request.temporaryRevokeId",
      "short" : "temporaryRevokeId",
      "definition" : "Unik, global identifierare för den tillfälliga hävningen. Tjänstekonsumenten ansvarar för att generera id:et.",
      "comment" : "TKB-fält: `temporaryRevokeId` (`urn:riv:informationsecurity:authorization:blocking:4:Id`, kardinalitet 1..1).",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "registertemporaryextendedrevoke-request.blockId",
      "path" : "registertemporaryextendedrevoke-request.blockId",
      "short" : "blockId",
      "definition" : "Identifierare för den spärr som skall tillfälligt hävas.",
      "comment" : "TKB-fält: `blockId` (`urn:riv:informationsecurity:authorization:blocking:4:Id`, kardinalitet 1..1).",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "registertemporaryextendedrevoke-request.endDate",
      "path" : "registertemporaryextendedrevoke-request.endDate",
      "short" : "endDate",
      "definition" : "Den tillfälliga hävningens giltighetsdatum. Hävningen upphör att gälla då denna tidpunkt inträffat.",
      "comment" : "TKB-fält: `endDate` (`xs:DateTime`, kardinalitet 1..1).",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "dateTime"
      }]
    },
    {
      "id" : "registertemporaryextendedrevoke-request.revokedForCareUnitId",
      "path" : "registertemporaryextendedrevoke-request.revokedForCareUnitId",
      "short" : "revokedForCareUnitId",
      "definition" : "Anger HSA-id för den vårdenhet hävningen gäller för.",
      "comment" : "TKB-fält: `revokedForCareUnitId` (`urn:riv:informationsecurity:authorization:blocking:4:HsaId`, kardinalitet 1..1).",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "registertemporaryextendedrevoke-request.revokedForEmployeeId",
      "path" : "registertemporaryextendedrevoke-request.revokedForEmployeeId",
      "short" : "revokedForEmployeeId",
      "definition" : "Anger HSA-id för den medarbetare/person hävningen gäller för. Anges om hävningen skall gälla för en medarbetare/person, annars gäller hävningen för all behörig personal på vårdenheten.",
      "comment" : "TKB-fält: `revokedForEmployeeId` (`urn:riv:informationsecurity:authorization:blocking:4:HsaId`, kardinalitet 0..1).",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "registertemporaryextendedrevoke-request.registerAction",
      "path" : "registertemporaryextendedrevoke-request.registerAction",
      "short" : "ActionType",
      "definition" : "Identifierar de personer som begärt och registrerat den tillfälliga hävningen samt tidpunkter för dessa.",
      "comment" : "TKB-fält: `registerAction` (`urn:riv:informationsecurity:authorization:blocking:4:ActionType`, kardinalitet 1..1).",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "Base"
      }]
    },
    {
      "id" : "registertemporaryextendedrevoke-request.registerAction.requestDate",
      "path" : "registertemporaryextendedrevoke-request.registerAction.requestDate",
      "short" : "requestDate",
      "definition" : "requestDate",
      "comment" : "TKB-fält: `../requestDate` (`dateTime`, kardinalitet 1..1).",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "dateTime"
      }]
    },
    {
      "id" : "registertemporaryextendedrevoke-request.registerAction.requestedBy",
      "path" : "registertemporaryextendedrevoke-request.registerAction.requestedBy",
      "short" : "ActorType",
      "definition" : "Datatyp som identifierar en medarbetare/person.",
      "comment" : "TKB-fält: `../requestedBy` (`ActorType`, kardinalitet 1..1).",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "Base"
      }]
    },
    {
      "id" : "registertemporaryextendedrevoke-request.registerAction.requestedBy.employeeId",
      "path" : "registertemporaryextendedrevoke-request.registerAction.requestedBy.employeeId",
      "short" : "employeeId",
      "definition" : "employeeId",
      "comment" : "TKB-fält: `../../employeeId` (`HsaId`, kardinalitet 1..1).",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "registertemporaryextendedrevoke-request.registerAction.requestedBy.assignmentId",
      "path" : "registertemporaryextendedrevoke-request.registerAction.requestedBy.assignmentId",
      "short" : "assignmentId",
      "definition" : "assignmentId",
      "comment" : "TKB-fält: `../../assignmentId` (`HsaId`, kardinalitet 0..1).",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "registertemporaryextendedrevoke-request.registerAction.requestedBy.assignmentName",
      "path" : "registertemporaryextendedrevoke-request.registerAction.requestedBy.assignmentName",
      "short" : "assignmentName",
      "definition" : "assignmentName",
      "comment" : "TKB-fält: `../../assignmentName` (`AssignmentNameType`, kardinalitet 0..1).",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "registertemporaryextendedrevoke-request.registerAction.registrationDate",
      "path" : "registertemporaryextendedrevoke-request.registerAction.registrationDate",
      "short" : "registrationDate",
      "definition" : "registrationDate",
      "comment" : "TKB-fält: `../registrationDate` (`dateTime`, kardinalitet 1..1).",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "dateTime"
      }]
    },
    {
      "id" : "registertemporaryextendedrevoke-request.registerAction.registeredBy",
      "path" : "registertemporaryextendedrevoke-request.registerAction.registeredBy",
      "short" : "ActorType",
      "definition" : "Datatyp som identifierar en medarbetare/person.",
      "comment" : "TKB-fält: `../registeredBy` (`ActorType`, kardinalitet 1..1).",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "Base"
      }]
    },
    {
      "id" : "registertemporaryextendedrevoke-request.registerAction.registeredBy.employeeId",
      "path" : "registertemporaryextendedrevoke-request.registerAction.registeredBy.employeeId",
      "short" : "employeeId",
      "definition" : "employeeId",
      "comment" : "TKB-fält: `../../employeeId` (`HsaId`, kardinalitet 1..1).",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "registertemporaryextendedrevoke-request.registerAction.registeredBy.assignmentId",
      "path" : "registertemporaryextendedrevoke-request.registerAction.registeredBy.assignmentId",
      "short" : "assignmentId",
      "definition" : "assignmentId",
      "comment" : "TKB-fält: `../../assignmentId` (`HsaId`, kardinalitet 0..1).",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "registertemporaryextendedrevoke-request.registerAction.registeredBy.assignmentName",
      "path" : "registertemporaryextendedrevoke-request.registerAction.registeredBy.assignmentName",
      "short" : "assignmentName",
      "definition" : "assignmentName",
      "comment" : "TKB-fält: `../../assignmentName` (`AssignmentNameType`, kardinalitet 0..1).",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "registertemporaryextendedrevoke-request.registerAction.reasonText",
      "path" : "registertemporaryextendedrevoke-request.registerAction.reasonText",
      "short" : "reasonText",
      "definition" : "reasonText",
      "comment" : "TKB-fält: `../reasonText` (`ReasonText`, kardinalitet 0..1).",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "registertemporaryextendedrevoke-request.revokeReason",
      "path" : "registertemporaryextendedrevoke-request.revokeReason",
      "short" : "revokeReason",
      "definition" : "Enumerationsvärde för orsak till tillfällig hävning.",
      "comment" : "TKB-fält: `revokeReason` (`urn:riv:informationsecurity:authorization:blocking:4:TemporaryRevokeReasonType`, kardinalitet 1..1).\n\n**Modellanteckning:** revokeReason Tillåtna värden: PatientsConsent, Emergency.",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "code"
      }],
      "binding" : {
        "strength" : "required",
        "valueSet" : "https://fhir.inera.se/ig/informationsecurity-authorization-blocking/ValueSet/authorization-blocking-temporaryrevokereason-vs"
      }
    },
    {
      "id" : "registertemporaryextendedrevoke-request.revokeReasonText",
      "path" : "registertemporaryextendedrevoke-request.revokeReasonText",
      "short" : "revokeReasonText",
      "definition" : "Kompletterande text för orsak till tillfällig hävning.",
      "comment" : "TKB-fält: `revokeReasonText` (`urn:riv:informationsecurity:authorization:blocking:4:ReasonText`, kardinalitet 0..1).",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "registertemporaryextendedrevoke-request.replicationTimeout",
      "path" : "registertemporaryextendedrevoke-request.replicationTimeout",
      "short" : "replicationTimeout",
      "definition" : "Anger hur replikering till nationell spärrtjänst ska ske.\n\n-   Om -1 anges kommer anropet att vänta på att replikering är utförd innan det avslutas eller om ws anropet gör timeout. Anropet kommer då att misslyckas.\n\n-   Om 0 anges kommer anropet att avslutas direkt och replikering sker asynkront så snabbt som möjligt.\n\n-   Om > 0 anges är det den tid, i millisekunder, som anropet väntar på att replikering ska ske innan anropet avslutas. Om anropet avslutas innan replikering är klar (ReplicationTimeout tiden uppnås) kommer replikeringen att ske asynkront så snabbt som möjligt.",
      "comment" : "TKB-fält: `replicationTimeout` (`xs:Int`, kardinalitet 1..1).",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "integer"
      }]
    }]
  }
}

```
