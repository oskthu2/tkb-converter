# RegisterTemporaryExtendedRevoke — Request - informationsecurity: authorization: blocking v4.0.4

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **RegisterTemporaryExtendedRevoke — Request**

## Logical Model: RegisterTemporaryExtendedRevoke — Request 

| | |
| :--- | :--- |
| *Official URL*:https://fhir.inera.se/ig/informationsecurity-authorization-blocking/StructureDefinition/registertemporaryextendedrevoke-request | *Version*:4.0.4 |
| Draft as of 2026-09-28 | *Computable Name*:RegisterTemporaryExtendedRevokeRequest |
| **Copyright/Legal**: Copyright 2024 Inera AB. Licensieras under Creative Commons Attribution 4.0. | |

 
Logisk modell för begäran i RegisterTemporaryExtendedRevoke (urn:riv:informationsecurity:authorization:blocking:RegisterTemporaryExtendedRevokeResponder:4, RegisterTemporaryExtendedRevokeType), inklusive SOAP-huvuden enligt WSDL. 

**Usages:**

* This Logical Model is not used by any profiles in this Specification

You can also check for [usages in the FHIR IG Statistics](https://packages2.fhir.org/xig/resource/inera.informationsecurity-authorization-blocking|current/StructureDefinition/StructureDefinition-registertemporaryextendedrevoke-request.json)

### Formal Views of Profile Content

 [Description of Profiles, Differentials, Snapshots and how the different presentations work](http://build.fhir.org/ig/FHIR/ig-guidance/readingIgs.html#structure-definitions). 

 

Other representations of profile: [CSV](StructureDefinition-registertemporaryextendedrevoke-request.csv), [Excel](StructureDefinition-registertemporaryextendedrevoke-request.xlsx) 



## Resource Content

```json
{
  "resourceType" : "StructureDefinition",
  "id" : "registertemporaryextendedrevoke-request",
  "extension" : [{
    "url" : "http://hl7.org/fhir/StructureDefinition/structuredefinition-type-characteristics",
    "valueCode" : "can-be-target"
  }],
  "url" : "https://fhir.inera.se/ig/informationsecurity-authorization-blocking/StructureDefinition/registertemporaryextendedrevoke-request",
  "version" : "4.0.4",
  "name" : "RegisterTemporaryExtendedRevokeRequest",
  "title" : "RegisterTemporaryExtendedRevoke — Request",
  "status" : "draft",
  "date" : "2026-09-28T09:02:10+00:00",
  "contact" : [{
    "name" : "Inera Arkitektur",
    "telecom" : [{
      "system" : "url",
      "value" : "https://www.inera.se"
    }]
  }],
  "description" : "Logisk modell för begäran i RegisterTemporaryExtendedRevoke\n(urn:riv:informationsecurity:authorization:blocking:RegisterTemporaryExtendedRevokeResponder:4, RegisterTemporaryExtendedRevokeType), inklusive SOAP-huvuden enligt WSDL.",
  "copyright" : "Copyright 2024 Inera AB. Licensieras under Creative Commons Attribution 4.0.",
  "fhirVersion" : "4.0.1",
  "kind" : "logical",
  "abstract" : false,
  "type" : "https://fhir.inera.se/ig/informationsecurity-authorization-blocking/StructureDefinition/registertemporaryextendedrevoke-request",
  "baseDefinition" : "http://hl7.org/fhir/StructureDefinition/Base",
  "derivation" : "specialization",
  "differential" : {
    "element" : [{
      "id" : "registertemporaryextendedrevoke-request",
      "path" : "registertemporaryextendedrevoke-request",
      "short" : "RegisterTemporaryExtendedRevoke — Request",
      "definition" : "Logisk modell för begäran i RegisterTemporaryExtendedRevoke\n(urn:riv:informationsecurity:authorization:blocking:RegisterTemporaryExtendedRevokeResponder:4, RegisterTemporaryExtendedRevokeType), inklusive SOAP-huvuden enligt WSDL."
    },
    {
      "id" : "registertemporaryextendedrevoke-request.logicalAddress",
      "path" : "registertemporaryextendedrevoke-request.logicalAddress",
      "short" : "logicalAddress",
      "definition" : "SOAP-huvud LogicalAddress. Som logisk adress anges HSA-id för vårdgivaren som spärren gäller för.",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "registertemporaryextendedrevoke-request.temporaryRevokeId",
      "path" : "registertemporaryextendedrevoke-request.temporaryRevokeId",
      "short" : "temporaryRevokeId",
      "definition" : "temporaryRevokeId",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "registertemporaryextendedrevoke-request.blockId",
      "path" : "registertemporaryextendedrevoke-request.blockId",
      "short" : "blockId",
      "definition" : "blockId",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "registertemporaryextendedrevoke-request.endDate",
      "path" : "registertemporaryextendedrevoke-request.endDate",
      "short" : "endDate",
      "definition" : "endDate",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "dateTime"
      }]
    },
    {
      "id" : "registertemporaryextendedrevoke-request.revokedForCareUnitId",
      "path" : "registertemporaryextendedrevoke-request.revokedForCareUnitId",
      "short" : "revokedForCareUnitId",
      "definition" : "revokedForCareUnitId",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "registertemporaryextendedrevoke-request.revokedForEmployeeId",
      "path" : "registertemporaryextendedrevoke-request.revokedForEmployeeId",
      "short" : "revokedForEmployeeId",
      "definition" : "revokedForEmployeeId",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "registertemporaryextendedrevoke-request.registerAction",
      "path" : "registertemporaryextendedrevoke-request.registerAction",
      "short" : "registerAction",
      "definition" : "Datatyp som representerar den eller de aktörer/personer som begärt och/eller utfört en åtgärd med en möjlig orsak/anledning angivet som fritext.",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "BackboneElement"
      }]
    },
    {
      "id" : "registertemporaryextendedrevoke-request.registerAction.requestDate",
      "path" : "registertemporaryextendedrevoke-request.registerAction.requestDate",
      "short" : "requestDate",
      "definition" : "requestDate",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "dateTime"
      }]
    },
    {
      "id" : "registertemporaryextendedrevoke-request.registerAction.requestedBy",
      "path" : "registertemporaryextendedrevoke-request.registerAction.requestedBy",
      "short" : "requestedBy",
      "definition" : "Datatyp som identifierar en medarbetare/person.",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "BackboneElement"
      }]
    },
    {
      "id" : "registertemporaryextendedrevoke-request.registerAction.requestedBy.employeeId",
      "path" : "registertemporaryextendedrevoke-request.registerAction.requestedBy.employeeId",
      "short" : "employeeId",
      "definition" : "employeeId",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "registertemporaryextendedrevoke-request.registerAction.requestedBy.assignmentId",
      "path" : "registertemporaryextendedrevoke-request.registerAction.requestedBy.assignmentId",
      "short" : "assignmentId",
      "definition" : "assignmentId",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "registertemporaryextendedrevoke-request.registerAction.requestedBy.assignmentName",
      "path" : "registertemporaryextendedrevoke-request.registerAction.requestedBy.assignmentName",
      "short" : "assignmentName",
      "definition" : "assignmentName",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "registertemporaryextendedrevoke-request.registerAction.registrationDate",
      "path" : "registertemporaryextendedrevoke-request.registerAction.registrationDate",
      "short" : "registrationDate",
      "definition" : "registrationDate",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "dateTime"
      }]
    },
    {
      "id" : "registertemporaryextendedrevoke-request.registerAction.registeredBy",
      "path" : "registertemporaryextendedrevoke-request.registerAction.registeredBy",
      "short" : "registeredBy",
      "definition" : "Datatyp som identifierar en medarbetare/person.",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "BackboneElement"
      }]
    },
    {
      "id" : "registertemporaryextendedrevoke-request.registerAction.registeredBy.employeeId",
      "path" : "registertemporaryextendedrevoke-request.registerAction.registeredBy.employeeId",
      "short" : "employeeId",
      "definition" : "employeeId",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "registertemporaryextendedrevoke-request.registerAction.registeredBy.assignmentId",
      "path" : "registertemporaryextendedrevoke-request.registerAction.registeredBy.assignmentId",
      "short" : "assignmentId",
      "definition" : "assignmentId",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "registertemporaryextendedrevoke-request.registerAction.registeredBy.assignmentName",
      "path" : "registertemporaryextendedrevoke-request.registerAction.registeredBy.assignmentName",
      "short" : "assignmentName",
      "definition" : "assignmentName",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "registertemporaryextendedrevoke-request.registerAction.reasonText",
      "path" : "registertemporaryextendedrevoke-request.registerAction.reasonText",
      "short" : "reasonText",
      "definition" : "reasonText",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "registertemporaryextendedrevoke-request.revokeReason",
      "path" : "registertemporaryextendedrevoke-request.revokeReason",
      "short" : "revokeReason",
      "definition" : "revokeReason",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "code"
      }],
      "binding" : {
        "strength" : "required",
        "valueSet" : "https://fhir.inera.se/ig/informationsecurity-authorization-blocking/ValueSet/authorization-blocking-temporaryrevokereason-vs"
      }
    },
    {
      "id" : "registertemporaryextendedrevoke-request.revokeReasonText",
      "path" : "registertemporaryextendedrevoke-request.revokeReasonText",
      "short" : "revokeReasonText",
      "definition" : "revokeReasonText",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "registertemporaryextendedrevoke-request.replicationTimeout",
      "path" : "registertemporaryextendedrevoke-request.replicationTimeout",
      "short" : "replicationTimeout",
      "definition" : "replicationTimeout",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "integer"
      }]
    }]
  }
}

```
