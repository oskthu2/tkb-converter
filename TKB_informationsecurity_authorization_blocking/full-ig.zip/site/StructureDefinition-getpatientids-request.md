# GetPatientIds — Request - informationsecurity: authorization: blocking v4.0.4

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **GetPatientIds — Request**

## Logical Model: GetPatientIds — Request 

| | |
| :--- | :--- |
| *Official URL*:https://fhir.inera.se/ig/informationsecurity-authorization-blocking/StructureDefinition/getpatientids-request | *Version*:4.0 |
| Active as of 2026-11-09 | *Computable Name*:GetPatientIdsRequest |
| **Copyright/Legal**: Copyright 2024 Inera AB. Licensieras under Creative Commons Attribution 4.0. | |

 
Logisk modell för begäran i GetPatientIds (urn:riv:informationsecurity:authorization:blocking:GetPatientIdsResponder:4, GetPatientIdsType), inklusive SOAP-huvuden enligt WSDL. 

**Usages:**

* This Logical Model is not used by any profiles in this Specification

You can also check for [usages in the FHIR IG Statistics](https://packages2.fhir.org/xig/resource/inera.informationsecurity-authorization-blocking|current/StructureDefinition/StructureDefinition-getpatientids-request.json)

### Formal Views of Profile Content

 [Description of Profiles, Differentials, Snapshots and how the different presentations work](http://build.fhir.org/ig/FHIR/ig-guidance/readingIgs.html#structure-definitions). 

 

Other representations of profile: [CSV](StructureDefinition-getpatientids-request.csv), [Excel](StructureDefinition-getpatientids-request.xlsx) 



## Resource Content

```json
{
  "resourceType" : "StructureDefinition",
  "id" : "getpatientids-request",
  "extension" : [{
    "url" : "http://hl7.org/fhir/StructureDefinition/structuredefinition-type-characteristics",
    "valueCode" : "can-be-target"
  }],
  "url" : "https://fhir.inera.se/ig/informationsecurity-authorization-blocking/StructureDefinition/getpatientids-request",
  "version" : "4.0",
  "name" : "GetPatientIdsRequest",
  "title" : "GetPatientIds — Request",
  "status" : "active",
  "date" : "2026-11-09T03:35:16+00:00",
  "contact" : [{
    "name" : "Inera Arkitektur",
    "telecom" : [{
      "system" : "url",
      "value" : "https://www.inera.se"
    }]
  }],
  "description" : "Logisk modell för begäran i GetPatientIds\n(urn:riv:informationsecurity:authorization:blocking:GetPatientIdsResponder:4, GetPatientIdsType), inklusive SOAP-huvuden enligt WSDL.",
  "copyright" : "Copyright 2024 Inera AB. Licensieras under Creative Commons Attribution 4.0.",
  "fhirVersion" : "4.0.1",
  "kind" : "logical",
  "abstract" : false,
  "type" : "https://fhir.inera.se/ig/informationsecurity-authorization-blocking/StructureDefinition/getpatientids-request",
  "baseDefinition" : "http://hl7.org/fhir/StructureDefinition/Base",
  "derivation" : "specialization",
  "differential" : {
    "element" : [{
      "id" : "getpatientids-request",
      "path" : "getpatientids-request",
      "short" : "GetPatientIds — Request",
      "definition" : "Logisk modell för begäran i GetPatientIds\n(urn:riv:informationsecurity:authorization:blocking:GetPatientIdsResponder:4, GetPatientIdsType), inklusive SOAP-huvuden enligt WSDL."
    },
    {
      "id" : "getpatientids-request.careProviderId",
      "path" : "getpatientids-request.careProviderId",
      "short" : "careProviderId",
      "definition" : "HSA-id på den vårdgivare vars spärrar skall hämtas.",
      "comment" : "TKB-fält: `careProviderId` (`urn:riv:informationsecurity:authorization:blocking:4:HsaId`, kardinalitet 1..1).",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    }]
  }
}

```
