# inera.informationsecurity-authorization-blocking#4.0.4: informationsecurity: authorization: blocking

## Pages

* [Hem](index.md)
* [7 Tjänstekontrakt](7-tjanstekontrakt.md)
* [5 Tjänstedomänens meddelandemodeller](5-tjanstedomanens-meddelandemodeller.md)
* [Artifacts Summary](artifacts.md)
* [6 Gemensamma informationskomponenter](6-gemensamma-informationskomponenter.md)
* [3 Tjänstedomänens arkitektur](3-tjanstedomanens-arkitektur.md)
* [4 Tjänstedomänens krav och regler](4-tjanstedomanens-krav-och-regler.md)
* [2 Versionsinformation](2-versionsinformation.md)
* [1 Inledning](1-inledning.md)

## Resources

### CodeSystems

* [BlockType](CodeSystem-authorization-blocking-blocktype-cs.md)
* [CheckStatus](CodeSystem-authorization-blocking-checkstatus-cs.md)
* [ResultCode](CodeSystem-authorization-blocking-resultcode-cs.md)
* [TemporaryRevokeReason](CodeSystem-authorization-blocking-temporaryrevokereason-cs.md)

### ValueSets

* [BlockType](ValueSet-authorization-blocking-blocktype-vs.md)
* [CheckStatus](ValueSet-authorization-blocking-checkstatus-vs.md)
* [ResultCode](ValueSet-authorization-blocking-resultcode-vs.md)
* [TemporaryRevokeReason](ValueSet-authorization-blocking-temporaryrevokereason-vs.md)

### Logicals

* [CancelTemporaryExtendedRevoke — Request](StructureDefinition-canceltemporaryextendedrevoke-request.md)
* [CancelTemporaryExtendedRevoke — Response](StructureDefinition-canceltemporaryextendedrevoke.md)
* [CheckBlocks — Request](StructureDefinition-checkblocks-request.md)
* [CheckBlocks — Response](StructureDefinition-checkblocks.md)
* [DeleteExtendedBlock — Request](StructureDefinition-deleteextendedblock-request.md)
* [DeleteExtendedBlock — Response](StructureDefinition-deleteextendedblock.md)
* [GetBlocks — Request](StructureDefinition-getblocks-request.md)
* [GetBlocks — Response](StructureDefinition-getblocks.md)
* [GetExtendedBlocksForPatient — Request](StructureDefinition-getextendedblocksforpatient-request.md)
* [GetExtendedBlocksForPatient — Response](StructureDefinition-getextendedblocksforpatient.md)
* [GetPatientIds — Request](StructureDefinition-getpatientids-request.md)
* [GetPatientIds — Response](StructureDefinition-getpatientids.md)
* [RegisterBlock — Request](StructureDefinition-registerblock-request.md)
* [RegisterBlock — Response](StructureDefinition-registerblock.md)
* [RegisterExtendedBlock — Request](StructureDefinition-registerextendedblock-request.md)
* [RegisterExtendedBlock — Response](StructureDefinition-registerextendedblock.md)
* [RegisterTemporaryExtendedRevoke — Request](StructureDefinition-registertemporaryextendedrevoke-request.md)
* [RegisterTemporaryExtendedRevoke — Response](StructureDefinition-registertemporaryextendedrevoke.md)
* [RegisterTemporaryRevoke — Request](StructureDefinition-registertemporaryrevoke-request.md)
* [RegisterTemporaryRevoke — Response](StructureDefinition-registertemporaryrevoke.md)
* [RevokeExtendedBlock — Request](StructureDefinition-revokeextendedblock-request.md)
* [RevokeExtendedBlock — Response](StructureDefinition-revokeextendedblock.md)
* [UnregisterBlock — Request](StructureDefinition-unregisterblock-request.md)
* [UnregisterBlock — Response](StructureDefinition-unregisterblock.md)
* [UnregisterTemporaryRevoke — Request](StructureDefinition-unregistertemporaryrevoke-request.md)
* [UnregisterTemporaryRevoke — Response](StructureDefinition-unregistertemporaryrevoke.md)

### ImplementationGuides

* [informationsecurity: authorization: blocking](index.md)
