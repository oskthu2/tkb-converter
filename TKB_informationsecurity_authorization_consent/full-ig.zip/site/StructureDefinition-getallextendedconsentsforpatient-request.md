# GetAllExtendedConsentsForPatient — Request - informationsecurity: authorization: consent v2.0.4

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **GetAllExtendedConsentsForPatient — Request**

## Logical Model: GetAllExtendedConsentsForPatient — Request 

| | |
| :--- | :--- |
| *Official URL*:https://fhir.inera.se/ig/informationsecurity-authorization-consent/StructureDefinition/getallextendedconsentsforpatient-request | *Version*:1.0 |
| Active as of 2026-11-09 | *Computable Name*:GetAllExtendedConsentsForPatientRequest |
| **Copyright/Legal**: Copyright 2024 Inera AB. Licensieras under Creative Commons Attribution 4.0. | |

 
Logisk modell för begäran i GetAllExtendedConsentsForPatient (urn:riv:informationsecurity:authorization:consent:GetAllExtendedConsentsForPatientResponder:1, GetAllExtendedConsentsForPatientType), inklusive SOAP-huvuden enligt WSDL. 

**Usages:**

* This Logical Model is not used by any profiles in this Specification

You can also check for [usages in the FHIR IG Statistics](https://packages2.fhir.org/xig/resource/inera.informationsecurity-authorization-consent|current/StructureDefinition/StructureDefinition-getallextendedconsentsforpatient-request.json)

### Formal Views of Profile Content

 [Description of Profiles, Differentials, Snapshots and how the different presentations work](http://build.fhir.org/ig/FHIR/ig-guidance/readingIgs.html#structure-definitions). 

 

Other representations of profile: [CSV](StructureDefinition-getallextendedconsentsforpatient-request.csv), [Excel](StructureDefinition-getallextendedconsentsforpatient-request.xlsx) 



## Resource Content

```json
{
  "resourceType" : "StructureDefinition",
  "id" : "getallextendedconsentsforpatient-request",
  "extension" : [{
    "url" : "http://hl7.org/fhir/StructureDefinition/structuredefinition-type-characteristics",
    "valueCode" : "can-be-target"
  }],
  "url" : "https://fhir.inera.se/ig/informationsecurity-authorization-consent/StructureDefinition/getallextendedconsentsforpatient-request",
  "version" : "1.0",
  "name" : "GetAllExtendedConsentsForPatientRequest",
  "title" : "GetAllExtendedConsentsForPatient — Request",
  "status" : "active",
  "date" : "2026-11-09T03:35:51+00:00",
  "contact" : [{
    "name" : "Inera Arkitektur",
    "telecom" : [{
      "system" : "url",
      "value" : "https://www.inera.se"
    }]
  }],
  "description" : "Logisk modell för begäran i GetAllExtendedConsentsForPatient\n(urn:riv:informationsecurity:authorization:consent:GetAllExtendedConsentsForPatientResponder:1, GetAllExtendedConsentsForPatientType), inklusive SOAP-huvuden enligt WSDL.",
  "copyright" : "Copyright 2024 Inera AB. Licensieras under Creative Commons Attribution 4.0.",
  "fhirVersion" : "4.0.1",
  "kind" : "logical",
  "abstract" : false,
  "type" : "https://fhir.inera.se/ig/informationsecurity-authorization-consent/StructureDefinition/getallextendedconsentsforpatient-request",
  "baseDefinition" : "http://hl7.org/fhir/StructureDefinition/Base",
  "derivation" : "specialization",
  "differential" : {
    "element" : [{
      "id" : "getallextendedconsentsforpatient-request",
      "path" : "getallextendedconsentsforpatient-request",
      "short" : "GetAllExtendedConsentsForPatient — Request",
      "definition" : "Logisk modell för begäran i GetAllExtendedConsentsForPatient\n(urn:riv:informationsecurity:authorization:consent:GetAllExtendedConsentsForPatientResponder:1, GetAllExtendedConsentsForPatientType), inklusive SOAP-huvuden enligt WSDL."
    },
    {
      "id" : "getallextendedconsentsforpatient-request.patientId",
      "path" : "getallextendedconsentsforpatient-request.patientId",
      "short" : "patientId",
      "definition" : "Personidentitet på patienten/brukaren vars samtycken skall hämtas.",
      "comment" : "TKB-fält: `patientId` (`urn:riv:informationsecurity:authorization:consent:2:IIType`, kardinalitet 1..1).",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "https://fhir.inera.se/ig/rivta-datatypes/StructureDefinition/IIType"
      }]
    },
    {
      "id" : "getallextendedconsentsforpatient-request.getCancelledFlag",
      "path" : "getallextendedconsentsforpatient-request.getCancelledFlag",
      "short" : "getCancelledFlag",
      "definition" : "Flagga som avgör om ogiltiga samtyckesintyg skall returneras.",
      "comment" : "TKB-fält: `getCancelledFlag` (`xs:Boolean`, kardinalitet 1..1).",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "boolean"
      }]
    }]
  }
}

```
