# inera.informationsecurity-authorization-consent#2.0.4: informationsecurity: authorization: consent

## Pages

* [Hem](index.md)
* [7 Tjänstekontrakt](7-tjanstekontrakt.md)
* [5 Tjänstedomänens meddelandemodeller](5-tjanstedomanens-meddelandemodeller.md)
* [Artifacts Summary](artifacts.md)
* [6 Gemensamma informationskomponenter](6-gemensamma-informationskomponenter.md)
* [3 Tjänstedomänens arkitektur](3-tjanstedomanens-arkitektur.md)
* [4 Tjänstedomänens krav och regler](4-tjanstedomanens-krav-och-regler.md)
* [2 Versionsinformation](2-versionsinformation.md)
* [1 Inledning](1-inledning.md)

## Resources

### CodeSystems

* [AssertionType](CodeSystem-authorization-consent-assertiontype-cs.md)
* [ResultCode](CodeSystem-authorization-consent-resultcode-cs.md)
* [Scope](CodeSystem-authorization-consent-scope-cs.md)

### ValueSets

* [AssertionType](ValueSet-authorization-consent-assertiontype-vs.md)
* [ResultCode](ValueSet-authorization-consent-resultcode-vs.md)
* [Scope](ValueSet-authorization-consent-scope-vs.md)

### Logicals

* [CancelExtendedConsent — Request](StructureDefinition-cancelextendedconsent-request.md)
* [CancelExtendedConsent — Response](StructureDefinition-cancelextendedconsent.md)
* [CheckConsent — Request](StructureDefinition-checkconsent-request.md)
* [CheckConsent — Response](StructureDefinition-checkconsent.md)
* [DeleteExtendedConsent — Request](StructureDefinition-deleteextendedconsent-request.md)
* [DeleteExtendedConsent — Response](StructureDefinition-deleteextendedconsent.md)
* [EndConsentByPatient — Request](StructureDefinition-endconsentbypatient-request.md)
* [EndConsentByPatient — Response](StructureDefinition-endconsentbypatient.md)
* [GetAllExtendedConsentsForPatient — Request](StructureDefinition-getallextendedconsentsforpatient-request.md)
* [GetAllExtendedConsentsForPatient — Response](StructureDefinition-getallextendedconsentsforpatient.md)
* [GetConsentsForCareProvider — Request](StructureDefinition-getconsentsforcareprovider-request.md)
* [GetConsentsForCareProvider — Response](StructureDefinition-getconsentsforcareprovider.md)
* [GetConsentsForPatient — Request](StructureDefinition-getconsentsforpatient-request.md)
* [GetConsentsForPatient — Response](StructureDefinition-getconsentsforpatient.md)
* [GetExtendedConsentsForPatient — Request](StructureDefinition-getextendedconsentsforpatient-request.md)
* [GetExtendedConsentsForPatient — Response](StructureDefinition-getextendedconsentsforpatient.md)
* [RegisterExtendedConsent — Request](StructureDefinition-registerextendedconsent-request.md)
* [RegisterExtendedConsent — Response](StructureDefinition-registerextendedconsent.md)

### ImplementationGuides

* [informationsecurity: authorization: consent](index.md)
