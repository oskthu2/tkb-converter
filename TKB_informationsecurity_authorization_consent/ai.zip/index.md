# Hem - informationsecurity: authorization: consent v2.0.4

* [**Table of Contents**](toc.md)
* **Hem**

## Hem

| | |
| :--- | :--- |
| *Official URL*:https://fhir.inera.se/ig/informationsecurity-authorization-consent/ImplementationGuide/inera.informationsecurity-authorization-consent | *Version*:2.0.4 |
| Active as of 2026-11-06 | *Computable Name*:informationsecurityauthorizationconsent |
| **Copyright/Legal**: Copyright 2024 Inera AB. Licensieras under Creative Commons Attribution 4.0. | |

# informationsecurity: authorization: consent

**TKB-version:** 2.0.4 · **IG-version:** 2.0.4 · **Källa:** Bitbucket-tagg `2.0.4` 

## Översikt

* Beskrivning: Svenskt kortnamn
  * För att vårdpersonalen ska få åtkomst till patientens information hos andra vårdgivare krävs patientens samtycke. Samtyckeshantering registrerar och lagrar information om patientens samtycke, och innehåller uppgifter om vilken tidsperiod samtycket ska gälla, och för vilken vårdpersonal/vårdenhet som samtycket ska gälla.Tjänstekontrakten för Samtyckeshantering gör det möjligt för vårdpersonal att genom sina vårdsystem på ett flexibelt sätt hantera sina "egna" samtycken, samtidigt som samverkan möjliggörs med nationella e-tjänster som erbjuder direktåtkomst till patientuppgifter. Inga dubbelregistreringar ska behöva göras. Tjänstekontrakten gör det också möjligt att åberopa nödsituation, så att inte ett oregistrerat samtycke kan äventyra patientens liv och hälsa. *OBSERVERA: I releasepaketet nedan finns testsviter för tre av tjänstekontrakten, dessa testsviter kan med fördel användas vid testning. Skicka i nuläget däremot inte in testresultat i de mallar för självdeklarationer som också finns där, då Ineras testmodell ännu inte är införd för den här tjänsten.”: samtyckestjänst
* Beskrivning: Svenskt namn
  * För att vårdpersonalen ska få åtkomst till patientens information hos andra vårdgivare krävs patientens samtycke. Samtyckeshantering registrerar och lagrar information om patientens samtycke, och innehåller uppgifter om vilken tidsperiod samtycket ska gälla, och för vilken vårdpersonal/vårdenhet som samtycket ska gälla.Tjänstekontrakten för Samtyckeshantering gör det möjligt för vårdpersonal att genom sina vårdsystem på ett flexibelt sätt hantera sina "egna" samtycken, samtidigt som samverkan möjliggörs med nationella e-tjänster som erbjuder direktåtkomst till patientuppgifter. Inga dubbelregistreringar ska behöva göras. Tjänstekontrakten gör det också möjligt att åberopa nödsituation, så att inte ett oregistrerat samtycke kan äventyra patientens liv och hälsa. *OBSERVERA: I releasepaketet nedan finns testsviter för tre av tjänstekontrakten, dessa testsviter kan med fördel användas vid testning. Skicka i nuläget däremot inte in testresultat i de mallar för självdeklarationer som också finns där, då Ineras testmodell ännu inte är införd för den här tjänsten.”: informationssäkerhet:säkerhetstjänster:samtyckestjänst
* Beskrivning: Typ
  * För att vårdpersonalen ska få åtkomst till patientens information hos andra vårdgivare krävs patientens samtycke. Samtyckeshantering registrerar och lagrar information om patientens samtycke, och innehåller uppgifter om vilken tidsperiod samtycket ska gälla, och för vilken vårdpersonal/vårdenhet som samtycket ska gälla.Tjänstekontrakten för Samtyckeshantering gör det möjligt för vårdpersonal att genom sina vårdsystem på ett flexibelt sätt hantera sina "egna" samtycken, samtidigt som samverkan möjliggörs med nationella e-tjänster som erbjuder direktåtkomst till patientuppgifter. Inga dubbelregistreringar ska behöva göras. Tjänstekontrakten gör det också möjligt att åberopa nödsituation, så att inte ett oregistrerat samtycke kan äventyra patientens liv och hälsa. *OBSERVERA: I releasepaketet nedan finns testsviter för tre av tjänstekontrakten, dessa testsviter kan med fördel användas vid testning. Skicka i nuläget däremot inte in testresultat i de mallar för självdeklarationer som också finns där, då Ineras testmodell ännu inte är införd för den här tjänsten.”: Nationell tjänstedomän
* Beskrivning: Källkod
  * För att vårdpersonalen ska få åtkomst till patientens information hos andra vårdgivare krävs patientens samtycke. Samtyckeshantering registrerar och lagrar information om patientens samtycke, och innehåller uppgifter om vilken tidsperiod samtycket ska gälla, och för vilken vårdpersonal/vårdenhet som samtycket ska gälla.Tjänstekontrakten för Samtyckeshantering gör det möjligt för vårdpersonal att genom sina vårdsystem på ett flexibelt sätt hantera sina "egna" samtycken, samtidigt som samverkan möjliggörs med nationella e-tjänster som erbjuder direktåtkomst till patientuppgifter. Inga dubbelregistreringar ska behöva göras. Tjänstekontrakten gör det också möjligt att åberopa nödsituation, så att inte ett oregistrerat samtycke kan äventyra patientens liv och hälsa. *OBSERVERA: I releasepaketet nedan finns testsviter för tre av tjänstekontrakten, dessa testsviter kan med fördel användas vid testning. Skicka i nuläget däremot inte in testresultat i de mallar för självdeklarationer som också finns där, då Ineras testmodell ännu inte är införd för den här tjänsten.”: [Bitbucket](https://bitbucket.org/rivta-domains/riv.informationsecurity.authorization.consent/src)
* Beskrivning: Underlag för denna IG
  * För att vårdpersonalen ska få åtkomst till patientens information hos andra vårdgivare krävs patientens samtycke. Samtyckeshantering registrerar och lagrar information om patientens samtycke, och innehåller uppgifter om vilken tidsperiod samtycket ska gälla, och för vilken vårdpersonal/vårdenhet som samtycket ska gälla.Tjänstekontrakten för Samtyckeshantering gör det möjligt för vårdpersonal att genom sina vårdsystem på ett flexibelt sätt hantera sina "egna" samtycken, samtidigt som samverkan möjliggörs med nationella e-tjänster som erbjuder direktåtkomst till patientuppgifter. Inga dubbelregistreringar ska behöva göras. Tjänstekontrakten gör det också möjligt att åberopa nödsituation, så att inte ett oregistrerat samtycke kan äventyra patientens liv och hälsa. *OBSERVERA: I releasepaketet nedan finns testsviter för tre av tjänstekontrakten, dessa testsviter kan med fördel användas vid testning. Skicka i nuläget däremot inte in testresultat i de mallar för självdeklarationer som också finns där, då Ineras testmodell ännu inte är införd för den här tjänsten.”: Version 2.0.4 ·[tagg 2.0.4](https://bitbucket.org/rivta-domains/riv.informationsecurity.authorization.consent/src/2.0.4)·[zip](https://bitbucket.org/rivta-domains/riv.informationsecurity.authorization.consent/get/2.0.4.zip)
* Beskrivning: RIV-TA-portalen
  * För att vårdpersonalen ska få åtkomst till patientens information hos andra vårdgivare krävs patientens samtycke. Samtyckeshantering registrerar och lagrar information om patientens samtycke, och innehåller uppgifter om vilken tidsperiod samtycket ska gälla, och för vilken vårdpersonal/vårdenhet som samtycket ska gälla.Tjänstekontrakten för Samtyckeshantering gör det möjligt för vårdpersonal att genom sina vårdsystem på ett flexibelt sätt hantera sina "egna" samtycken, samtidigt som samverkan möjliggörs med nationella e-tjänster som erbjuder direktåtkomst till patientuppgifter. Inga dubbelregistreringar ska behöva göras. Tjänstekontrakten gör det också möjligt att åberopa nödsituation, så att inte ett oregistrerat samtycke kan äventyra patientens liv och hälsa. *OBSERVERA: I releasepaketet nedan finns testsviter för tre av tjänstekontrakten, dessa testsviter kan med fördel användas vid testning. Skicka i nuläget däremot inte in testresultat i de mallar för självdeklarationer som också finns där, då Ineras testmodell ännu inte är införd för den här tjänsten.”: [Alla tjänstedomäner](https://oskthu2.github.io/tkb-converter/rivta-portal/tjanstedomaner.html)·[Alla tjänstekontrakt](https://oskthu2.github.io/tkb-converter/rivta-portal/tjanstekontrakt.html)

FHIR Implementation Guide för tjänstedomänen **informationsecurity: authorization: consent** (Samtyckestjänst) version 2.0.4. Genererad från Ineras Tjänstekontraktsbeskrivning (TKB), version 2.0.4, och domänens WSDL- och XSD-filer (tagg 2.0.4, 2025-12-09).

Domänen hanterar patientens eller brukarens samtycke till direktåtkomst inom sammanhållen vård- och omsorgsdokumentation, och registrering av nödsituationer där samtycke inte kan inhämtas: registrering, avslut, makulering, kontroll och läsning av samtycken.

Domänen innehåller följande tjänstekontrakt:

| | | |
| :--- | :--- | :--- |
| [GetConsentsForPatient](7-tjanstekontrakt.md#getconsentsforpatient) | 2.0 | Tjänst som läser giltiga samtyckesintyg för en viss patient och en viss vårdgivare med grundinformation. |
| [GetConsentsForCareProvider](7-tjanstekontrakt.md#getconsentsforcareprovider) | 2.0 | Tjänst som läser alla giltiga samtyckesintyg för en viss vård-/omsorgsgivare med grundinformation. |
| [GetExtendedConsentsForPatient](7-tjanstekontrakt.md#getextendedconsentsforpatient) | 2.0 | Tjänst som läser registrerade samtyckesintyg för en viss patient/brukare med utökad information. |
| [CheckConsent](7-tjanstekontrakt.md#checkconsent) | 2.0 | Tjänst som kontrollerar om det finns ett giltigt samtycke, alternativt intyg om nödsituation, gällande åtkomst för viss aktör (vårdenhet eller medarbetare). |
| [RegisterExtendedConsent](7-tjanstekontrakt.md#registerextendedconsent) | 2.0 | Tjänst som registrerar ett intyg gällande viss patient som ger direktåtkomst till patientens/brukarens information från andra vårdgivare enligt PDL. |
| [CancelExtendedConsent](7-tjanstekontrakt.md#cancelextendedconsent) | 2.0 | Tjänst som avslutar ett samtycke i samtyckestjänsten. Intyget raderas inte från samtyckestjänsten utan markeras som avslutat (ej längre giltig) för historikens skull. Ett avslutat samtycke kan ej återtas. |
| [DeleteExtendedConsent](7-tjanstekontrakt.md#deleteextendedconsent) | 2.0 | Tjänst som makulerar ett samtycke i samtyckestjänsten. Makulering av samtycke används enbart för borttagning av felregistrerade samtycken. |
| [GetAllExtendedConsentsForPatient](7-tjanstekontrakt.md#getallextendedconsentsforpatient) | 1.0 | Tjänst som läser registrerade samtyckesintyg för en viss patient/brukare med utökad information. |
| [EndConsentByPatient](7-tjanstekontrakt.md#endconsentbypatient) | 1.0 | Tjänst som ger patient/brukare möjlighet att avsluta ett tidigare givet samtycke i förtid. |

### Versioner och granskningar

| | | | |
| :--- | :--- | :--- | :--- |
| 2.0.2 | IS, AB, TKB | Arkitektur & Regelverk: Säkerhet: GodkändArkitektur & Regelverk: Informatik: GodkändArkitektur & Regelverk: Teknik: Godkänd | [zip](https://bitbucket.org/rivta-domains/riv.informationsecurity.authorization.consent/get/2.0.2.zip)·[källkod](https://bitbucket.org/rivta-domains/riv.informationsecurity.authorization.consent/src/2.0.2) |
| 2.0 | AB, IS, TKB, TKB | Arkitektur & Regelverk: Informatik: GodkändArkitektur & Regelverk: Säkerhet: Delvis GodkändArkitektur & Regelverk: Teknik: Godkänd | [zip](https://bitbucket.org/rivta-domains/riv.informationsecurity.authorization.consent/get/2.0.zip)·[källkod](https://bitbucket.org/rivta-domains/riv.informationsecurity.authorization.consent/src/2.0) |
| trunk |  |  |  |

*Zip-arkiven hämtas från taggarna på Bitbucket. Granskningsprotokollen publicerades på rivta.se och länkas inte härifrån.*

*Källa: ögonblicksbild av DOMDB från 2021-08-24, via RIV-TA-portalen.*

## Innehåll

* [1 Inledning](1-inledning.md)
* [2 Versionsinformation](2-versionsinformation.md)
* [3 Tjänstedomänens arkitektur](3-tjanstedomanens-arkitektur.md)
* [4 Tjänstedomänens krav och regler](4-tjanstedomanens-krav-och-regler.md)
* [5 Tjänstedomänens meddelandemodeller](5-tjanstedomanens-meddelandemodeller.md)
* [6 Gemensamma informationskomponenter](6-gemensamma-informationskomponenter.md)
* [7 Tjänstekontrakt](7-tjanstekontrakt.md)
* [Artefakter](artifacts.md)

