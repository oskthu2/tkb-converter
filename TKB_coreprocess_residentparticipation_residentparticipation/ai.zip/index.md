# Hem - coreprocess: residentparticipation: residentparticipation v1.0.0-rc2

* [**Table of Contents**](toc.md)
* **Hem**

## Hem

| | |
| :--- | :--- |
| *Official URL*:https://fhir.inera.se/ig/coreprocess-residentparticipation-residentparticipation/ImplementationGuide/inera.coreprocess-residentparticipation-residentparticipation | *Version*:1.0.0-rc2 |
| Draft as of 2026-10-08 | *Computable Name*:coreprocessresidentparticipationresidentparticipation |
| **Copyright/Legal**: Copyright 2024 Inera AB. Licensieras under Creative Commons Attribution 4.0. | |

# coreprocess: residentparticipation: residentparticipation

**TKB-version:** 1.0_RC2 · **IG-version:** 1.0.0-rc2 · **Källa:** Bitbucket-tagg `1.0_RC2` 

## Översikt

FHIR Implementation Guide för tjänstedomänen **coreprocess: residentparticipation: residentparticipation** (Fasta kontakter) version 1.0 RC2. Genererad från Ineras Tjänstekontraktsbeskrivning (TKB) och domänens WSDL- och XSD-filer i taggen 1.0_RC2 (2026-06-29).

Domänen tillgängliggör information om en patients fasta kontakter (fast vårdkontakt, fast omsorgskontakt, fast läkarkontakt och kontaktsjuksköterska) för patienten själv och för vård- och omsorgspersonal. Version 1.0 finns bara som release candidate.

Domänen innehåller följande tjänstekontrakt:

| | | |
| :--- | :--- | :--- |
| [GetCareManagers](7-tjanstekontrakt.md#getcaremanagers) | 1.0 | Hämtar en patients alla fasta kontakter. |

## Innehåll

* [1 Inledning](1-inledning.md)
* [2 Versionsinformation](2-versionsinformation.md)
* [3 Tjänstedomänens arkitektur](3-tjanstedomanens-arkitektur.md)
* [4 Tjänstedomänens krav och regler](4-tjanstedomanens-krav-och-regler.md)
* [5 Tjänstedomänens meddelandemodeller](5-tjanstedomanens-meddelandemodeller.md)
* [6 Gemensamma informationskomponenter](6-gemensamma-informationskomponenter.md)
* [7 Tjänstekontrakt](7-tjanstekontrakt.md)
* [Artefakter](artifacts.md)

