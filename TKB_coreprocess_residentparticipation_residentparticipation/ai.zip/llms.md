# inera.coreprocess-residentparticipation-residentparticipation#1.0.0-rc2: coreprocess: residentparticipation: residentparticipation

## Pages

* [Hem](index.md)
* [7 Tjänstekontrakt](7-tjanstekontrakt.md)
* [5 Tjänstedomänens meddelandemodeller](5-tjanstedomanens-meddelandemodeller.md)
* [Artifacts Summary](artifacts.md)
* [6 Gemensamma informationskomponenter](6-gemensamma-informationskomponenter.md)
* [3 Tjänstedomänens arkitektur](3-tjanstedomanens-arkitektur.md)
* [4 Tjänstedomänens krav och regler](4-tjanstedomanens-krav-och-regler.md)
* [2 Versionsinformation](2-versionsinformation.md)
* [1 Inledning](1-inledning.md)

## Resources

### CodeSystems

* [Months](CodeSystem-residentparticipation-months-cs.md)
* [WeekDays](CodeSystem-residentparticipation-weekdays-cs.md)

### ValueSets

* [Months](ValueSet-residentparticipation-months-vs.md)
* [WeekDays](ValueSet-residentparticipation-weekdays-vs.md)

### Logicals

* [GetCareManagers — Request](StructureDefinition-getcaremanagers-request.md)
* [GetCareManagers — Response](StructureDefinition-getcaremanagers.md)

### ImplementationGuides

* [coreprocess: residentparticipation: residentparticipation](index.md)
