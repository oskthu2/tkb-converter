# inera.supportprocess-logistics-carelisting#2.1.0: supportprocess: logistics: carelisting

## Pages

* [Hem](index.md)
* [7 Tjänstekontrakt](7-tjanstekontrakt.md)
* [5 Tjänstedomänens meddelandemodeller](5-tjanstedomanens-meddelandemodeller.md)
* [Artifacts Summary](artifacts.md)
* [6 Gemensamma informationskomponenter](6-gemensamma-informationskomponenter.md)
* [3 Tjänstedomänens arkitektur](3-tjanstedomanens-arkitektur.md)
* [4 Tjänstedomänens krav och regler](4-tjanstedomanens-krav-och-regler.md)
* [2 Versionsinformation](2-versionsinformation.md)
* [1 Inledning](1-inledning.md)

## Resources

### CodeSystems

* [ActorType](CodeSystem-carelisting-actortype-cs.md)
* [ResultCode](CodeSystem-carelisting-resultcode-cs.md)

### ValueSets

* [ActorType](ValueSet-carelisting-actortype-vs.md)
* [ResultCode](ValueSet-carelisting-resultcode-vs.md)

### Logicals

* [CreateListing — Request](StructureDefinition-createlisting-request.md)
* [CreateListing — Response](StructureDefinition-createlisting.md)
* [GetAvailableHealthcareFacilities — Request](StructureDefinition-getavailablehealthcarefacilities-request.md)
* [GetAvailableHealthcareFacilities — Response](StructureDefinition-getavailablehealthcarefacilities.md)
* [GetAvailableHealthcarePersonnel — Request](StructureDefinition-getavailablehealthcarepersonnel-request.md)
* [GetAvailableHealthcarePersonnel — Response](StructureDefinition-getavailablehealthcarepersonnel.md)
* [GetListing — Request](StructureDefinition-getlisting-request.md)
* [GetListing — Response](StructureDefinition-getlisting.md)
* [GetListingCounty — Request](StructureDefinition-getlistingcounty-request.md)
* [GetListingCounty — Response](StructureDefinition-getlistingcounty.md)
* [GetListingTypes — Request](StructureDefinition-getlistingtypes-request.md)
* [GetListingTypes — Response](StructureDefinition-getlistingtypes.md)
* [UpdateListing — Request](StructureDefinition-updatelisting-request.md)
* [UpdateListing — Response](StructureDefinition-updatelisting.md)

### ImplementationGuides

* [supportprocess: logistics: carelisting](index.md)
