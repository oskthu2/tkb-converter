# Hem - supportprocess: logistics: carelisting v2.1.0

* [**Table of Contents**](toc.md)
* **Hem**

## Hem

| | |
| :--- | :--- |
| *Official URL*:https://fhir.inera.se/ig/supportprocess-logistics-carelisting/ImplementationGuide/inera.supportprocess-logistics-carelisting | *Version*:2.1.0 |
| Draft as of 2026-09-28 | *Computable Name*:supportprocesslogisticscarelisting |
| **Copyright/Legal**: Copyright 2024 Inera AB. Licensieras under Creative Commons Attribution 4.0. | |

# supportprocess: logistics: carelisting

## Översikt

FHIR Implementation Guide för tjänstedomänen **supportprocess: logistics: carelisting** (Listning) version 2.1. Genererad från Ineras Tjänstekontraktsbeskrivning (TKB), version 2.1 (2025-06-13), och domänens WSDL- och XSD-filer (tagg 2.1).

Domänen används för invånares listning på vårdcentral eller annan listningsbar mottagning: att hämta listningstyper, mottagningar och vårdpersonal, att lista sig eller lista om sig, också över regiongräns, och att hämta var och hur invånaren är listad. Domänen ersätter crm:carelisting 1.0, som har en egen IG.

Domänen innehåller följande tjänstekontrakt:

| | | |
| :--- | :--- | :--- |
| [CreateListing](7-tjanstekontrakt.md#createlisting) | 2.0 | Tjänstekontraktet CreateListing anropas av tjänstekonsument för att förmedla att invånare önskar lista sig /lista om sig på vald listningsbar mottagning/vårdenhet. Aktören för tjänstekonsumenten är invånaren eller vårdnadshavare som på uppdrag av invånaren önskar utföra omlistningen. Tjänstekontraktet får inte anropas av övriga aktörer. |
| [GetAvailableHealthcareFacilities](7-tjanstekontrakt.md#getavailablehealthcarefacilities) | 2.1 | Tjänstekontraktet GetAvailableHealthcareFacilities anropas av tjänstekonsument för att hämta lista med listningsbara mottagningar som en region erbjuder. Listan kan i anropet filtreras för att endast hämta mottagningar som stödjer ett urval av listningstyper (för region som exponerar flera olika listningstyper) eller en lista med HSAId:n för de mottagningar som ska returneras. |
| [GetAvailableHealthcarePersonnel](7-tjanstekontrakt.md#getavailablehealthcarepersonnel) | 2.0 | Tjänstekontraktet GetAvailableHealthcarePersonnel anropas av tjänstekonsument för att hämta lista med valbar vårdpersonal för specifik listningsbar mottagning, motsvarande den lista med ”fast läkarkontakt” som mottagningen/vårdenheten erbjuder. |
| [GetListingCounty](7-tjanstekontrakt.md#getlistingcounty) | 2.0 | Tjänstekontraktet GetListingCounty anropas av tjänstekonsument för att hämta invånares nuvarande listningsregion(er). En tjänstekonsument ska adressera anropet av tjänstekontraktet till den region där invånaren är folkbokförd. Tjänstekontraktets syfte är att kunna förmedla om invånare eventuellt är utomlänslistad. Det är folkbokföringsregionens ansvar att hålla reda på i vilken annan region en invånare är listad hos, om invånaren är utomlänslistad. Om en region erbjuder mer än en listningstyp kan det inträffa att svaret innehåller mer än en region – se scenario 3 nedan. |
| [GetListing](7-tjanstekontrakt.md#getlisting) | 2.1 | Tjänstekontraktet GetListing anropas av tjänstekonsument för att hämta invånares nuvarande listningsdetaljer. En invånare kan vara listad hos mer än en region samtidigt, i det fall då hemregionen (folkbokföringsregionen) erbjuder mer än en listningstyp (läs mer om listningstyper i Informationsspecifikation R3). I ett sådant fall behöver tjänstekonsumenten anropa respektive region separat via tjänstekontraktet. |
| [GetListingTypes](7-tjanstekontrakt.md#getlistingtypes) | 2.0 | Tjänstekontraktet GetListingTypes anropas av tjänstekonsument för att hämta de listningstyper som erbjuds invånare i den adresserade regionen. Tjänstekontraktet kan användas i två olika sammanhang. |
| [UpdateListing](7-tjanstekontrakt.md#updatelisting) | 2.0 | Tjänstekontraktet UpdateListing anropas av tjänstekonsument (region) för att meddela annan region om att en utomlänslistning har skett för berörd invånare. Tjänstekonsument är normalt alltid en regions listningssystem. |

## Innehåll

* [1 Inledning](1-inledning.md)
* [2 Versionsinformation](2-versionsinformation.md)
* [3 Tjänstedomänens arkitektur](3-tjanstedomanens-arkitektur.md)
* [4 Tjänstedomänens krav och regler](4-tjanstedomanens-krav-och-regler.md)
* [5 Tjänstedomänens meddelandemodeller](5-tjanstedomanens-meddelandemodeller.md)
* [6 Gemensamma informationskomponenter](6-gemensamma-informationskomponenter.md)
* [7 Tjänstekontrakt](7-tjanstekontrakt.md)
* [Artefakter](artifacts.md)

