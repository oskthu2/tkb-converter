# Hem - ehr: patientsummary v1.0.0-snapshot

* [**Table of Contents**](toc.md)
* **Hem**

## Hem

| | |
| :--- | :--- |
| *Official URL*:https://fhir.inera.se/ig/ehr-patientsummary/ImplementationGuide/inera.ehr-patientsummary | *Version*:1.0.0-snapshot |
| Draft as of 2026-10-12 | *Computable Name*:ehrpatientsummary |
| **Copyright/Legal**: Copyright 2024 Inera AB. Licensieras under Creative Commons Attribution 4.0. | |

# ehr: patientsummary

**TKB-version:** 1.0 · **IG-version:** 1.0.0-snapshot · **Källa:** Bitbucket-commit `4714d3acbda3` (ingen tagg) 

## Översikt

* Typ: Anmärkning
  * Nationell tjänstedomän: dold på rivta.se
* Typ: Källkod
  * Nationell tjänstedomän: [Bitbucket](https://bitbucket.org/rivta-domains/riv.ehr.patientsummary/src)
* Typ: Ärenden
  * Nationell tjänstedomän: [Bitbucket issues](https://bitbucket.org/rivta-domains/riv.ehr.patientsummary/issues)
* Typ: Underlag för denna IG
  * Nationell tjänstedomän: Version 1.0 ·[commit 4714d3acbda3](https://bitbucket.org/rivta-domains/riv.ehr.patientsummary/src/4714d3acbda37dd093e2d5475403ed5cf44a6fe1)·[zip](https://bitbucket.org/rivta-domains/riv.ehr.patientsummary/get/4714d3acbda3.zip)
* Typ: RIV-TA-portalen
  * Nationell tjänstedomän: [Alla tjänstedomäner](https://oskthu2.github.io/tkb-converter/rivta-portal/tjanstedomaner.html)·[Alla tjänstekontrakt](https://oskthu2.github.io/tkb-converter/rivta-portal/tjanstekontrakt.html)

FHIR Implementation Guide för tjänstedomänen **ehr: patientsummary** (Patientöversikt) version 1.0. Genererad från Ineras Tjänstekontraktsbeskrivning (TKB), utgåva PA1 (2012-11-16), och domänens WSDL- och XSD-filer.

Tjänstedomänen används för att dela detaljerad patientinformation på formatet EN13606 med en patientöversikt, i praktiken Nationell patientöversikt (NPÖ). Den är en RIVTA 2.1-anpassning av de tidigare EN13606-tjänsterna RIV13606REQUEST_EHR_EXTRACT och SendEhrExtract.

Domänen innehåller följande tjänstekontrakt:

| | | |
| :--- | :--- | :--- |
| [GetEhrExtract](7-tjanstekontrakt.md#getehrextract) | 1.0 | Hämtar detaljerad patientinformation (EN13606-extrakt) |
| [ReceiveEhrExtract](7-tjanstekontrakt.md#receiveehrextract) | 1.0 | Tar emot detaljerad patientinformation som en part vill dela |
| [ReceiveEhrExtractStatus](7-tjanstekontrakt.md#receiveehrextractstatus) | 1.0 | Tar emot status för ett tidigare ReceiveEhrExtract-anrop |
| [DeleteEhrExtract](7-tjanstekontrakt.md#deleteehrextract) | 1.0 | Tar bort information som delats med ReceiveEhrExtract |
| [DeleteEhrExtractStatus](7-tjanstekontrakt.md#deleteehrextractstatus) | 1.0 | Tar emot status för ett tidigare DeleteEhrExtract-anrop |

**Om källan:** TKB:n är ett remissutkast (utgåva PA1) i det äldre Word-formatet (.doc). Källan saknar versionstaggar; IG:n bygger på senaste commit på `master` (2013-10-11). Källan innehåller också ett utkast till en version 2 av domänen, som återges i [bilaga 9](9-bilaga-utkast-version-2.md).

### Versioner och granskningar

| | | | |
| :--- | :--- | :--- | :--- |
| trunk | TKB |  | [källkod](https://bitbucket.org/rivta-domains/riv.ehr.patientsummary/src/master) |

*Källa: ögonblicksbild av DOMDB från 2021-08-24, via RIV-TA-portalen.*

## Innehåll

* [1 Inledning](1-inledning.md)
* [2 Generella regler](2-generella-regler.md)
* [7 Tjänstekontrakt](7-tjanstekontrakt.md)
* [8 Datatyper](8-datatyper.md)
* [9 Bilaga: utkast version 2](9-bilaga-utkast-version-2.md)
* [Artefakter](artifacts.md)

