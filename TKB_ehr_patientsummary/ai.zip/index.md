# Hem - ehr: patientsummary v1.0.0

* [**Table of Contents**](toc.md)
* **Hem**

## Hem

| | |
| :--- | :--- |
| *Official URL*:https://fhir.inera.se/ig/ehr-patientsummary/ImplementationGuide/inera.ehr-patientsummary | *Version*:1.0.0 |
| Draft as of 2026-09-26 | *Computable Name*:ehrpatientsummary |
| **Copyright/Legal**: Copyright 2024 Inera AB. Licensieras under Creative Commons Attribution 4.0. | |

# ehr: patientsummary

## Översikt

FHIR Implementation Guide för tjänstedomänen **ehr: patientsummary** (Patientöversikt) version 1.0. Genererad från Ineras Tjänstekontraktsbeskrivning (TKB), utgåva PA1 (2012-11-16), och domänens WSDL- och XSD-filer.

Tjänstedomänen används för att dela detaljerad patientinformation på formatet EN13606 med en patientöversikt, i praktiken Nationell patientöversikt (NPÖ). Den är en RIVTA 2.1-anpassning av de tidigare EN13606-tjänsterna RIV13606REQUEST_EHR_EXTRACT och SendEhrExtract.

Domänen innehåller följande tjänstekontrakt:

| | | |
| :--- | :--- | :--- |
| [GetEhrExtract](7-tjanstekontrakt.md#getehrextract) | 1.0 | Hämtar detaljerad patientinformation (EN13606-extrakt) |
| [ReceiveEhrExtract](7-tjanstekontrakt.md#receiveehrextract) | 1.0 | Tar emot detaljerad patientinformation som en part vill dela |
| [ReceiveEhrExtractStatus](7-tjanstekontrakt.md#receiveehrextractstatus) | 1.0 | Tar emot status för ett tidigare ReceiveEhrExtract-anrop |
| [DeleteEhrExtract](7-tjanstekontrakt.md#deleteehrextract) | 1.0 | Tar bort information som delats med ReceiveEhrExtract |
| [DeleteEhrExtractStatus](7-tjanstekontrakt.md#deleteehrextractstatus) | 1.0 | Tar emot status för ett tidigare DeleteEhrExtract-anrop |

**Om källan:** TKB:n är ett remissutkast (utgåva PA1) i det äldre Word-formatet (.doc). Källan saknar versionstaggar; IG:n bygger på senaste commit på `master` (2013-10-11). Källan innehåller också ett utkast till en version 2 av domänen, som återges i [bilaga 9](9-bilaga-utkast-version-2.md).

## Innehåll

* [1 Inledning](1-inledning.md)
* [2 Generella regler](2-generella-regler.md)
* [7 Tjänstekontrakt](7-tjanstekontrakt.md)
* [8 Datatyper](8-datatyper.md)
* [9 Bilaga: utkast version 2](9-bilaga-utkast-version-2.md)
* [Artefakter](artifacts.md)

