# Hem - clinicalprocess: activity: request — Remisshantering v2.2.0

* [**Table of Contents**](toc.md)
* **Hem**

## Hem

| | |
| :--- | :--- |
| *Official URL*:https://fhir.inera.se/ig/clinicalprocess-activity-request/ImplementationGuide/inera.clinicalprocess-activity-request | *Version*:2.2.0 |
| Active as of 2026-10-12 | *Computable Name*:clinicalprocessactivityrequest |
| **Copyright/Legal**: Copyright 2024 Inera AB. Licensieras under Creative Commons Attribution 4.0. | |

# clinicalprocess: activity: request — Remisshantering

**TKB-version:** 2.2 · **IG-version:** 2.2.0 · **Källa:** Bitbucket-tagg `2.2` 

## Översikt

* Beskrivning: Svenskt kortnamn
  * Syftet med domänen är att hantera remissprocessen nationellt och lokalt, mellan och inom vårdgivare, från remiss till svar. Domänen innehåller specifikationer för att skicka och ta emot remisser, bekräftelser och svar samt tjänster för att leverera statusinformation för remisser.: remisshantering
* Beskrivning: Svenskt namn
  * Syftet med domänen är att hantera remissprocessen nationellt och lokalt, mellan och inom vårdgivare, från remiss till svar. Domänen innehåller specifikationer för att skicka och ta emot remisser, bekräftelser och svar samt tjänster för att leverera statusinformation för remisser.: vård- och omsorg kärnprocess:hantera aktiviteter:remisshantering
* Beskrivning: Typ
  * Syftet med domänen är att hantera remissprocessen nationellt och lokalt, mellan och inom vårdgivare, från remiss till svar. Domänen innehåller specifikationer för att skicka och ta emot remisser, bekräftelser och svar samt tjänster för att leverera statusinformation för remisser.: Nationell tjänstedomän
* Beskrivning: Källkod
  * Syftet med domänen är att hantera remissprocessen nationellt och lokalt, mellan och inom vårdgivare, från remiss till svar. Domänen innehåller specifikationer för att skicka och ta emot remisser, bekräftelser och svar samt tjänster för att leverera statusinformation för remisser.: [Bitbucket](https://bitbucket.org/rivta-domains/riv.clinicalprocess.activity.request/src)
* Beskrivning: Ärenden
  * Syftet med domänen är att hantera remissprocessen nationellt och lokalt, mellan och inom vårdgivare, från remiss till svar. Domänen innehåller specifikationer för att skicka och ta emot remisser, bekräftelser och svar samt tjänster för att leverera statusinformation för remisser.: [Bitbucket issues](https://bitbucket.org/rivta-domains/riv.clinicalprocess.activity.request/issues)
* Beskrivning: Underlag för denna IG
  * Syftet med domänen är att hantera remissprocessen nationellt och lokalt, mellan och inom vårdgivare, från remiss till svar. Domänen innehåller specifikationer för att skicka och ta emot remisser, bekräftelser och svar samt tjänster för att leverera statusinformation för remisser.: Version 2.2 ·[tagg 2.2](https://bitbucket.org/rivta-domains/riv.clinicalprocess.activity.request/src/2.2)·[zip](https://bitbucket.org/rivta-domains/riv.clinicalprocess.activity.request/get/2.2.zip)
* Beskrivning: RIV-TA-portalen
  * Syftet med domänen är att hantera remissprocessen nationellt och lokalt, mellan och inom vårdgivare, från remiss till svar. Domänen innehåller specifikationer för att skicka och ta emot remisser, bekräftelser och svar samt tjänster för att leverera statusinformation för remisser.: [Alla tjänstedomäner](https://oskthu2.github.io/tkb-converter/rivta-portal/tjanstedomaner.html)·[Alla tjänstekontrakt](https://oskthu2.github.io/tkb-converter/rivta-portal/tjanstekontrakt.html)

FHIR Implementation Guide för tjänstedomänen **clinicalprocess: activity: request** ("Remisshantering") version 2.2. Genererad från Ineras Tjänstekontraktsbeskrivning (TKB).

Domänen innehåller tjänster för att hantera remissprocessen nationellt och lokalt, mellan och inom vårdgivare, från remiss till svar. I denna domänversion avser remiss en så kallad allmänremiss.

RIV-TA namnrymd: `urn:riv:clinicalprocess:activity:request`

Domänen innehåller följande tjänstekontrakt:

| | | |
| :--- | :--- | :--- |
| [ProcessRequest](7-tjanstekontrakt.md#processrequest) | 2.2 | Skickar en remiss från remittent till remissmottagare |
| [ProcessRequestConfirmation](7-tjanstekontrakt.md#processrequestconfirmation) | 2.2 | Skickar bekräftelse, besked om vidareskickning, kompletteringsbegäran, avbrott eller avvisning till remittenten |
| [ProcessRequestOutcome](7-tjanstekontrakt.md#processrequestoutcome) | 2.2 | Skickar delsvar, preliminärt svar eller slutsvar till remittenten |

Alla tre kontrakten skickar information (push). Den logiska modellen för respektive kontrakt beskriver därför begäran, och svaret beskrivs av den gemensamma modellen [ProcessResult](StructureDefinition-process-result.md).

**Källa:** TKB-dokumentet (`TKB_clinicalprocess_activity_request.docx`, version 2.2 fastställd 2026-04-22) från Bitbucket `rivta-domains/riv.clinicalprocess.activity.request`, tagg `2.2`. Brödtexten i avsnitt 2 och 7 anger fortfarande version 2.1; revisionshistoriken och scheman anger 2.2.

### Versioner och granskningar

| | | | |
| :--- | :--- | :--- | :--- |
| 1.0.2 | TKB, AB, IS | [Arkitektur & Regelverk: Informatik: Godkänd](http://rivta.se/downloads//clinicalprocess_activity_request/1.0.2/VIS_granskning%20-%20clinicalprocess_activity_request_1.0.2.docx)[Arkitektur & Regelverk: Säkerhet: Godkänd](http://rivta.se/downloads//clinicalprocess_activity_request/1.0.2/VIS_granskning%20-%20clinicalprocess_activity_request_1.0.2.docx)[Arkitektur & Regelverk: Teknik: Godkänd](http://rivta.se/downloads//clinicalprocess_activity_request/1.0.2/T-granskning%20-%20clinicalprocess_activity_request_1.0.2%20(1).docx) | [zip](http://rivta.se/downloads//clinicalprocess_activity_request/1.0.2/ServiceContracts_clinicalprocess_activity_request_1.0.2.zip)·[källkod](https://bitbucket.org/rivta-domains/riv.clinicalprocess.activity.request/src/1.0.2) |
| 1.0.1 | TKB, IS, AB | [Arkitektur & Regelverk: Teknik: Godkänd](http://rivta.se/downloads//clinicalprocess_activity_request/1.0.1/T-granskning%20-clinicalprocess_activity_request_1.0.1.docx)[Arkitektur & Regelverk: Säkerhet: Godkänd](http://rivta.se/downloads//clinicalprocess_activity_request/1.0.1/VIS_granskning%20-%20clinicalprocess_activity_request_1.0.1.docx)[Arkitektur & Regelverk: Informatik: Godkänd](http://rivta.se/downloads//clinicalprocess_activity_request/1.0.1/VIS_granskning%20-%20clinicalprocess_activity_request_1.0.1.docx) | [zip](http://rivta.se/downloads//clinicalprocess_activity_request/1.0.1/ServiceContracts_clinicalprocess_activity_request_1.0.1%20(1).zip)·[källkod](https://bitbucket.org/rivta-domains/riv.clinicalprocess.activity.request/src/1.0.1) |
| trunk | IS, TKB, AB |  | [källkod](https://bitbucket.org/rivta-domains/riv.clinicalprocess.activity.request/src/master) |

*Källa: ögonblicksbild av DOMDB från 2021-08-24, via RIV-TA-portalen.*

## Innehåll

* [1 Inledning](1-inledning.md)
* [2 Versionsinformation](2-versionsinformation.md)
* [3 Tjänstedomänens arkitektur](3-tjanstedomanens-arkitektur.md)
* [4 Tjänstedomänens krav och regler](4-tjanstedomanens-krav-och-regler.md)
* [5 Tjänstedomänens meddelandemodeller](5-tjanstedomanens-meddelandemodeller.md)
* [6 Gemensamma informationskomponenter](6-gemensamma-informationskomponenter.md)
* [7 Tjänstekontrakt](7-tjanstekontrakt.md)
* [Artefakter](artifacts.md)

