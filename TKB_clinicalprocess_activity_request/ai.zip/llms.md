# inera.clinicalprocess-activity-request#2.2.0: clinicalprocess: activity: request — Remisshantering

## Pages

* [Hem](index.md)
* [7 Tjänstekontrakt](7-tjanstekontrakt.md)
* [5 Tjänstedomänens meddelandemodeller](5-tjanstedomanens-meddelandemodeller.md)
* [Artifacts Summary](artifacts.md)
* [6 Gemensamma informationskomponenter](6-gemensamma-informationskomponenter.md)
* [3 Tjänstedomänens arkitektur](3-tjanstedomanens-arkitektur.md)
* [4 Tjänstedomänens krav och regler](4-tjanstedomanens-krav-och-regler.md)
* [2 Versionsinformation](2-versionsinformation.md)
* [1 Inledning](1-inledning.md)

## Resources

### CodeSystems

* [ErrorCodeEnum](CodeSystem-errorcode-cs.md)
* [codeForGenderType](CodeSystem-gender-cs.md)
* [codeRequestConfirmationType](CodeSystem-requestconfirmationtype-cs.md)
* [codeRequestOutcomeType](CodeSystem-requestoutcometype-cs.md)
* [codeForRequestType](CodeSystem-requesttype-cs.md)
* [ResultCodeEnum](CodeSystem-resultcode-cs.md)
* [codeForTelecomType](CodeSystem-telecomtype-cs.md)
* [codeVersionReason](CodeSystem-versionreason-cs.md)

### ValueSets

* [ErrorCodeEnum](ValueSet-errorcode-vs.md)
* [codeForGenderType](ValueSet-gender-vs.md)
* [codeRequestConfirmationType](ValueSet-requestconfirmationtype-vs.md)
* [codeRequestOutcomeType](ValueSet-requestoutcometype-vs.md)
* [codeForRequestType](ValueSet-requesttype-vs.md)
* [ResultCodeEnum](ValueSet-resultcode-vs.md)
* [codeForTelecomType](ValueSet-telecomtype-vs.md)
* [codeVersionReason](ValueSet-versionreason-vs.md)

### Logicals

* [Process* — Svar (ResultType)](StructureDefinition-process-result.md)
* [ProcessRequest — Remiss (begäran)](StructureDefinition-processrequest.md)
* [ProcessRequestConfirmation — Remissbekräftelse (begäran)](StructureDefinition-processrequestconfirmation.md)
* [ProcessRequestOutcome — Remissvar (begäran)](StructureDefinition-processrequestoutcome.md)

### ImplementationGuides

* [clinicalprocess: activity: request — Remisshantering](index.md)
