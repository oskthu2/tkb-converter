# Hem - clinicalprocess: healthcond: actoutcome v4.2.2

* [**Table of Contents**](toc.md)
* **Hem**

## Hem

| | |
| :--- | :--- |
| *Official URL*:https://fhir.inera.se/ig/clinicalprocess-healthcond-actoutcome/ImplementationGuide/inera.clinicalprocess-healthcond-actoutcome | *Version*:4.2.2 |
| Active as of 2026-10-26 | *Computable Name*:clinicalprocesshealthcondactoutcome |
| **Copyright/Legal**: Copyright 2024 Inera AB. Licensieras under Creative Commons Attribution 4.0. | |

# clinicalprocess: healthcond: actoutcome

**TKB-version:** 4.2.2 · **IG-version:** 4.2.2 · **Källa:** Bitbucket-tagg `4.2.2` · **Andra huvudversioner:** [3.1.10](https://oskthu2.github.io/tkb-converter/TKB_clinicalprocess_healthcond_actoutcome/3.1.10/index.html) 

## Översikt

* Beskrivning: Svenskt kortnamn
  * Denna domän hanterar information gällande utfall av olika undersökningar och aktiviteter, till exempel laboratoriesvar och bilddiagnostik.: utfall av aktiviteter
* Beskrivning: Svenskt namn
  * Denna domän hanterar information gällande utfall av olika undersökningar och aktiviteter, till exempel laboratoriesvar och bilddiagnostik.: vård- och omsorg kärnprocess:hantera hälsorelaterade tillstånd:utfall av aktivitet
* Beskrivning: Typ
  * Denna domän hanterar information gällande utfall av olika undersökningar och aktiviteter, till exempel laboratoriesvar och bilddiagnostik.: Nationell tjänstedomän
* Beskrivning: Förvaltare
  * Denna domän hanterar information gällande utfall av olika undersökningar och aktiviteter, till exempel laboratoriesvar och bilddiagnostik.: Tjänstekontraktsförvaltningen, TK-forvaltningen@inera.se
* Beskrivning: Källkod
  * Denna domän hanterar information gällande utfall av olika undersökningar och aktiviteter, till exempel laboratoriesvar och bilddiagnostik.: [Bitbucket](https://bitbucket.org/rivta-domains/riv.clinicalprocess.healthcond.actoutcome/src)
* Beskrivning: Ärenden
  * Denna domän hanterar information gällande utfall av olika undersökningar och aktiviteter, till exempel laboratoriesvar och bilddiagnostik.: [Bitbucket issues](https://bitbucket.org/rivta-domains/riv.clinicalprocess.healthcond.actoutcome/issues)
* Beskrivning: Informationssida
  * Denna domän hanterar information gällande utfall av olika undersökningar och aktiviteter, till exempel laboratoriesvar och bilddiagnostik.: [Confluence](https://inera.atlassian.net/wiki/spaces/OITOF/pages/22216799/clinicalprocess+healthcond+actoutcome+utfall+av+aktiviteter)
* Beskrivning: Underlag för denna IG
  * Denna domän hanterar information gällande utfall av olika undersökningar och aktiviteter, till exempel laboratoriesvar och bilddiagnostik.: Version 4.2.2 ·[tagg 4.2.2](https://bitbucket.org/rivta-domains/riv.clinicalprocess.healthcond.actoutcome/src/4.2.2)·[zip](https://bitbucket.org/rivta-domains/riv.clinicalprocess.healthcond.actoutcome/get/4.2.2.zip)
* Beskrivning: RIV-TA-portalen
  * Denna domän hanterar information gällande utfall av olika undersökningar och aktiviteter, till exempel laboratoriesvar och bilddiagnostik.: [Alla tjänstedomäner](https://oskthu2.github.io/tkb-converter/rivta-portal/tjanstedomaner.html)·[Alla tjänstekontrakt](https://oskthu2.github.io/tkb-converter/rivta-portal/tjanstekontrakt.html)

Detta är en FHIR Implementation Guide genererad från TKB-dokumentation för tjänstedomänen **clinicalprocess: healthcond: actoutcome** version 4.2.2.

Domänen hanterar information gällande utfall av olika undersökningar och aktiviteter, till exempel laboratoriesvar och bilddiagnostik. Tjänstekontrakten är baserade på RIVTA 2.1 och reglerade genom arkitekturella beslut.

Namespace-bas: `urn:riv:clinicalprocess:healthcond:actoutcome`

## Tjänstekontrakt i denna domän

| | | |
| :--- | :--- | :--- |
| [GetLaboratoryOrderOutcome](7-tjanstekontrakt.md#getlaboratoryorderoutcome) | 4.2 | Returnerar multidisciplinära laboratoriesvar för en patient |
| [GetReferralOutcome](7-tjanstekontrakt.md#getreferraloutcome) | 3.2 | Returnerar svar på konsultationsremiss och begäran om övertagande av vårdansvar |
| [GetMaternityMedicalHistory](7-tjanstekontrakt.md#getmaternitymedicalhistory) | 2.0 | Returnerar mödravårdsjournal för en patient |
| [GetImagingOutcome](7-tjanstekontrakt.md#getimagingoutcome) | 1.0 | Returnerar bilddiagnostiska resultat för en patient |

### Versioner och granskningar

| | | | |
| :--- | :--- | :--- | :--- |
| 4.0.1 | TKB, AB, IS | [Arkitektur & Regelverk: Säkerhet: Godkänd](http://rivta.se/downloads//clinicalprocess_healthcond_actoutcome/4.0.1/VIS_granskning%20-%20clinicalprocess_healthcond_actoutcome_4.0.1.docx)[Arkitektur & Regelverk: Teknik: Godkänd](http://rivta.se/downloads//clinicalprocess_healthcond_actoutcome/4.0.1/T-granskning%20-%20%20clinicalprocess_healthcond_actoutcome_4.0.1.docx)[Arkitektur & Regelverk: Informatik: Godkänd](http://rivta.se/downloads//clinicalprocess_healthcond_actoutcome/4.0.1/VIS_granskning%20-%20clinicalprocess_healthcond_actoutcome_4.0.1.docx) | [zip](http://rivta.se/downloads//clinicalprocess_healthcond_actoutcome/4.0.1/ServiceContracts_clinicalprocess_healthcond_actoutcome_4.0.1.zip)·[källkod](https://bitbucket.org/rivta-domains/riv.clinicalprocess.healthcond.actoutcome/src/4.0.1) |
| 3.1.8 | TKB, AB | [Arkitektur & Regelverk: Informatik: Godkänd](http://rivta.se/downloads//clinicalprocess_healthcond_actoutcome/3.1.8/VIS_granskning%20-%20clinicalprocess.healthcond.actoutcome%203.1.8.docx)[Arkitektur & Regelverk: Teknik: Godkänd](http://rivta.se/downloads//clinicalprocess_healthcond_actoutcome/3.1.8/T_granskning%20-%20clinicalprocess.healthcond.actoutcome%203.1.8.docx)[Arkitektur & Regelverk: Säkerhet: Godkänd](http://rivta.se/downloads//clinicalprocess_healthcond_actoutcome/3.1.8/VIS_granskning%20-%20clinicalprocess.healthcond.actoutcome%203.1.8.docx) | [zip](http://rivta.se/downloads//clinicalprocess_healthcond_actoutcome/3.1.8/ServiceContracts_clinicalprocess_healthcond_actoutcome_3.1.8.zip)·[källkod](https://bitbucket.org/rivta-domains/riv.clinicalprocess.healthcond.actoutcome/src/3.1.8) |
| 2.0.5 | TKB, AB | [Arkitektur & Regelverk: Teknik: Godkänd](http://rivta.se/downloads//clinicalprocess_healthcond_actoutcome/2.0.5/T_granskning%20-%20clinicalprocess_healthcond_actoutcome_2.0.5.docx)[Arkitektur & Regelverk: Säkerhet: Godkänd](http://rivta.se/downloads//clinicalprocess_healthcond_actoutcome/2.0.5/VIS_granskning%20-%20clinicalprocess_healthcond_actoutcome_2.0.5.docx)[Arkitektur & Regelverk: Informatik: Godkänd](http://rivta.se/downloads//clinicalprocess_healthcond_actoutcome/2.0.5/VIS_granskning%20-%20clinicalprocess_healthcond_actoutcome_2.0.5.docx) | [zip](http://rivta.se/downloads//clinicalprocess_healthcond_actoutcome/2.0.5/ServiceContracts_clinicalprocess_healthcond_actoutcome_2.0.5.zip)·[källkod](https://bitbucket.org/rivta-domains/riv.clinicalprocess.healthcond.actoutcome/src/2.0.5) |
| trunk | TKB, IS, AB |  | [källkod](https://bitbucket.org/rivta-domains/riv.clinicalprocess.healthcond.actoutcome/src/master) |

*Källa: ögonblicksbild av DOMDB från 2021-08-24, via RIV-TA-portalen.*

## Innehåll

* [1 Inledning](1-inledning.md)
* [2 Versionsinformation](2-versionsinformation.md)
* [3 Tjänstedomänens arkitektur](3-tjanstedomanens-arkitektur.md)
* [4 Tjänstedomänens krav och regler](4-tjanstedomanens-krav-och-regler.md)
* [5 Gemensamma informationskomponenter](5-gemensamma-informationskomponenter.md)
* [6 Tjänstedomänens meddelandemodeller](6-tjanstedomanens-meddelandemodeller.md)
* [7 Tjänstekontrakt](7-tjanstekontrakt.md)

