# Hem - clinicalprocess: healthcond: actoutcome v4.2.2

* [**Table of Contents**](toc.md)
* **Hem**

## Hem

| | |
| :--- | :--- |
| *Official URL*:https://fhir.inera.se/ig/clinicalprocess-healthcond-actoutcome/ImplementationGuide/inera.clinicalprocess-healthcond-actoutcome | *Version*:4.2.2 |
| Draft as of 2026-09-14 | *Computable Name*:clinicalprocesshealthcondactoutcome |
| **Copyright/Legal**: Copyright 2024 Inera AB. Licensieras under Creative Commons Attribution 4.0. | |

# clinicalprocess: healthcond: actoutcome

## Översikt

Detta är en FHIR Implementation Guide genererad från TKB-dokumentation för tjänstedomänen **clinicalprocess: healthcond: actoutcome** version 4.2.2.

Domänen hanterar information gällande utfall av olika undersökningar och aktiviteter, till exempel laboratoriesvar och bilddiagnostik. Tjänstekontrakten är baserade på RIVTA 2.1 och reglerade genom arkitekturella beslut.

Namespace-bas: `urn:riv:clinicalprocess:healthcond:actoutcome`

## Tjänstekontrakt i denna domän

| | | |
| :--- | :--- | :--- |
| [GetLaboratoryOrderOutcome](7-tjanstekontrakt.md#getlaboratoryorderoutcome) | 4.2 | Returnerar multidisciplinära laboratoriesvar för en patient |
| [GetReferralOutcome](7-tjanstekontrakt.md#getreferraloutcome) | 3.2 | Returnerar svar på konsultationsremiss och begäran om övertagande av vårdansvar |
| [GetMaternityMedicalHistory](7-tjanstekontrakt.md#getmaternitymedicalhistory) | 2.0 | Returnerar mödravårdsjournal för en patient |
| [GetImagingOutcome](7-tjanstekontrakt.md#getimagingoutcome) | 1.0 | Returnerar bilddiagnostiska resultat för en patient |

## Innehåll

* [1 Inledning](1-inledning.md)
* [2 Versionsinformation](2-versionsinformation.md)
* [3 Tjänstedomänens arkitektur](3-tjanstedomanens-arkitektur.md)
* [4 Tjänstedomänens krav och regler](4-tjanstedomanens-krav-och-regler.md)
* [5 Gemensamma informationskomponenter](5-gemensamma-informationskomponenter.md)
* [6 Tjänstedomänens meddelandemodeller](6-tjanstedomanens-meddelandemodeller.md)
* [7 Tjänstekontrakt](7-tjanstekontrakt.md)

