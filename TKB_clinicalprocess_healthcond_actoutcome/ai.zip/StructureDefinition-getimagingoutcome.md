# GetImagingOutcome - clinicalprocess: healthcond: actoutcome v4.2.2

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **GetImagingOutcome**

## Logical Model: GetImagingOutcome 

| | |
| :--- | :--- |
| *Official URL*:https://fhir.inera.se/ig/clinicalprocess-healthcond-actoutcome/StructureDefinition/getimagingoutcome | *Version*:4.2.2 |
| Draft as of 2026-09-14 | *Computable Name*:GetImagingOutcome |
| **Copyright/Legal**: Copyright 2024 Inera AB. Licensieras under Creative Commons Attribution 4.0. | |

 
Logisk modell för tjänstekontraktet GetImagingOutcome (RIV-TA urn:riv:clinicalprocess:healthcond:actoutcome:GetImagingOutcome:1). Representerar responsens informationsstruktur — bilddiagnostiska resultat för en patient. Baseras på NPÖ RIV 2.2.0-specifikation. 

**Usages:**

* This Logical Model is not used by any profiles in this Specification

You can also check for [usages in the FHIR IG Statistics](https://packages2.fhir.org/xig/resource/inera.clinicalprocess-healthcond-actoutcome|current/StructureDefinition/StructureDefinition-getimagingoutcome.json)

### Formal Views of Profile Content

 [Description of Profiles, Differentials, Snapshots and how the different presentations work](http://build.fhir.org/ig/FHIR/ig-guidance/readingIgs.html#structure-definitions). 

 

Other representations of profile: [CSV](StructureDefinition-getimagingoutcome.csv), [Excel](StructureDefinition-getimagingoutcome.xlsx) 



## Resource Content

```json
{
  "resourceType" : "StructureDefinition",
  "id" : "getimagingoutcome",
  "extension" : [{
    "url" : "http://hl7.org/fhir/StructureDefinition/structuredefinition-type-characteristics",
    "valueCode" : "can-be-target"
  }],
  "url" : "https://fhir.inera.se/ig/clinicalprocess-healthcond-actoutcome/StructureDefinition/getimagingoutcome",
  "version" : "4.2.2",
  "name" : "GetImagingOutcome",
  "title" : "GetImagingOutcome",
  "status" : "draft",
  "date" : "2026-09-14T12:36:53+00:00",
  "contact" : [{
    "name" : "Inera Arkitektur",
    "telecom" : [{
      "system" : "url",
      "value" : "https://www.inera.se"
    }]
  }],
  "description" : "Logisk modell för tjänstekontraktet GetImagingOutcome\n(RIV-TA urn:riv:clinicalprocess:healthcond:actoutcome:GetImagingOutcome:1).\nRepresenterar responsens informationsstruktur — bilddiagnostiska resultat\nför en patient. Baseras på NPÖ RIV 2.2.0-specifikation.",
  "copyright" : "Copyright 2024 Inera AB. Licensieras under Creative Commons Attribution 4.0.",
  "fhirVersion" : "4.0.1",
  "kind" : "logical",
  "abstract" : false,
  "type" : "https://fhir.inera.se/ig/clinicalprocess-healthcond-actoutcome/StructureDefinition/getimagingoutcome",
  "baseDefinition" : "http://hl7.org/fhir/StructureDefinition/Base",
  "derivation" : "specialization",
  "differential" : {
    "element" : [{
      "id" : "getimagingoutcome",
      "path" : "getimagingoutcome",
      "short" : "GetImagingOutcome",
      "definition" : "Logisk modell för tjänstekontraktet GetImagingOutcome\n(RIV-TA urn:riv:clinicalprocess:healthcond:actoutcome:GetImagingOutcome:1).\nRepresenterar responsens informationsstruktur — bilddiagnostiska resultat\nför en patient. Baseras på NPÖ RIV 2.2.0-specifikation."
    },
    {
      "id" : "getimagingoutcome.imagingOutcome",
      "path" : "getimagingoutcome.imagingOutcome",
      "short" : "Bilddiagnostiskt resultat (ett per undersökning)",
      "definition" : "Bilddiagnostiskt resultat (ett per undersökning)",
      "min" : 0,
      "max" : "*",
      "type" : [{
        "code" : "BackboneElement"
      }]
    },
    {
      "id" : "getimagingoutcome.imagingOutcome.imagingOutcomeHeader",
      "path" : "getimagingoutcome.imagingOutcome.imagingOutcomeHeader",
      "short" : "PatientSummaryHeader",
      "definition" : "PatientSummaryHeader",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "BackboneElement"
      }]
    },
    {
      "id" : "getimagingoutcome.imagingOutcome.imagingOutcomeHeader.documentId",
      "path" : "getimagingoutcome.imagingOutcome.imagingOutcomeHeader.documentId",
      "short" : "Dokumentets unika id",
      "definition" : "Dokumentets unika id",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "getimagingoutcome.imagingOutcome.imagingOutcomeHeader.sourceSystemHSAId",
      "path" : "getimagingoutcome.imagingOutcome.imagingOutcomeHeader.sourceSystemHSAId",
      "short" : "Källsystemets HSA-id",
      "definition" : "Källsystemets HSA-id",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "Identifier"
      }]
    },
    {
      "id" : "getimagingoutcome.imagingOutcome.imagingOutcomeHeader.documentTitle",
      "path" : "getimagingoutcome.imagingOutcome.imagingOutcomeHeader.documentTitle",
      "short" : "Dokumentets titel",
      "definition" : "Dokumentets titel",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "getimagingoutcome.imagingOutcome.imagingOutcomeHeader.documentTime",
      "path" : "getimagingoutcome.imagingOutcome.imagingOutcomeHeader.documentTime",
      "short" : "Dokumentets tidpunkt",
      "definition" : "Dokumentets tidpunkt",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "instant"
      }]
    },
    {
      "id" : "getimagingoutcome.imagingOutcome.imagingOutcomeHeader.patientId",
      "path" : "getimagingoutcome.imagingOutcome.imagingOutcomeHeader.patientId",
      "short" : "Patientens id",
      "definition" : "Patientens id",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "Identifier"
      }]
    },
    {
      "id" : "getimagingoutcome.imagingOutcome.imagingOutcomeHeader.patientId.value",
      "path" : "getimagingoutcome.imagingOutcome.imagingOutcomeHeader.patientId.value",
      "short" : "Patientens personnummer/samordningsnummer",
      "definition" : "Patientens personnummer/samordningsnummer",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "getimagingoutcome.imagingOutcome.imagingOutcomeHeader.patientId.system",
      "path" : "getimagingoutcome.imagingOutcome.imagingOutcomeHeader.patientId.system",
      "short" : "OID för identifierartyp",
      "definition" : "OID för identifierartyp",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "uri"
      }]
    },
    {
      "id" : "getimagingoutcome.imagingOutcome.imagingOutcomeHeader.accountableHealthcareProfessional",
      "path" : "getimagingoutcome.imagingOutcome.imagingOutcomeHeader.accountableHealthcareProfessional",
      "short" : "Ansvarig hälso- och sjukvårdspersonal",
      "definition" : "Ansvarig hälso- och sjukvårdspersonal",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "BackboneElement"
      }]
    },
    {
      "id" : "getimagingoutcome.imagingOutcome.imagingOutcomeHeader.accountableHealthcareProfessional.authorTime",
      "path" : "getimagingoutcome.imagingOutcome.imagingOutcomeHeader.accountableHealthcareProfessional.authorTime",
      "short" : "Tidpunkt",
      "definition" : "Tidpunkt",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "instant"
      }]
    },
    {
      "id" : "getimagingoutcome.imagingOutcome.imagingOutcomeHeader.accountableHealthcareProfessional.healthcareProfessionalHSAId",
      "path" : "getimagingoutcome.imagingOutcome.imagingOutcomeHeader.accountableHealthcareProfessional.healthcareProfessionalHSAId",
      "short" : "HSA-id",
      "definition" : "HSA-id",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "Identifier"
      }]
    },
    {
      "id" : "getimagingoutcome.imagingOutcome.imagingOutcomeHeader.accountableHealthcareProfessional.healthcareProfessionalName",
      "path" : "getimagingoutcome.imagingOutcome.imagingOutcomeHeader.accountableHealthcareProfessional.healthcareProfessionalName",
      "short" : "Namn",
      "definition" : "Namn",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "getimagingoutcome.imagingOutcome.imagingOutcomeHeader.accountableHealthcareProfessional.healthcareProfessionalRoleCode",
      "path" : "getimagingoutcome.imagingOutcome.imagingOutcomeHeader.accountableHealthcareProfessional.healthcareProfessionalRoleCode",
      "short" : "Yrkesroll",
      "definition" : "Yrkesroll",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "CodeableConcept"
      }]
    },
    {
      "id" : "getimagingoutcome.imagingOutcome.imagingOutcomeHeader.accountableHealthcareProfessional.healthcareProfessionalOrgUnit",
      "path" : "getimagingoutcome.imagingOutcome.imagingOutcomeHeader.accountableHealthcareProfessional.healthcareProfessionalOrgUnit",
      "short" : "Org-enhet",
      "definition" : "Org-enhet",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "BackboneElement"
      }]
    },
    {
      "id" : "getimagingoutcome.imagingOutcome.imagingOutcomeHeader.accountableHealthcareProfessional.healthcareProfessionalOrgUnit.orgUnitHSAId",
      "path" : "getimagingoutcome.imagingOutcome.imagingOutcomeHeader.accountableHealthcareProfessional.healthcareProfessionalOrgUnit.orgUnitHSAId",
      "short" : "OrgUnit HSA-id",
      "definition" : "OrgUnit HSA-id",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "Identifier"
      }]
    },
    {
      "id" : "getimagingoutcome.imagingOutcome.imagingOutcomeHeader.accountableHealthcareProfessional.healthcareProfessionalOrgUnit.orgUnitName",
      "path" : "getimagingoutcome.imagingOutcome.imagingOutcomeHeader.accountableHealthcareProfessional.healthcareProfessionalOrgUnit.orgUnitName",
      "short" : "OrgUnit namn",
      "definition" : "OrgUnit namn",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "getimagingoutcome.imagingOutcome.imagingOutcomeHeader.accountableHealthcareProfessional.healthcareProfessionalOrgUnit.orgUnitTelecom",
      "path" : "getimagingoutcome.imagingOutcome.imagingOutcomeHeader.accountableHealthcareProfessional.healthcareProfessionalOrgUnit.orgUnitTelecom",
      "short" : "Telefon",
      "definition" : "Telefon",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "getimagingoutcome.imagingOutcome.imagingOutcomeHeader.accountableHealthcareProfessional.healthcareProfessionalOrgUnit.orgUnitEmail",
      "path" : "getimagingoutcome.imagingOutcome.imagingOutcomeHeader.accountableHealthcareProfessional.healthcareProfessionalOrgUnit.orgUnitEmail",
      "short" : "E-post",
      "definition" : "E-post",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "getimagingoutcome.imagingOutcome.imagingOutcomeHeader.accountableHealthcareProfessional.healthcareProfessionalOrgUnit.orgUnitAddress",
      "path" : "getimagingoutcome.imagingOutcome.imagingOutcomeHeader.accountableHealthcareProfessional.healthcareProfessionalOrgUnit.orgUnitAddress",
      "short" : "Adress",
      "definition" : "Adress",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "getimagingoutcome.imagingOutcome.imagingOutcomeHeader.accountableHealthcareProfessional.healthcareProfessionalOrgUnit.orgUnitLocation",
      "path" : "getimagingoutcome.imagingOutcome.imagingOutcomeHeader.accountableHealthcareProfessional.healthcareProfessionalOrgUnit.orgUnitLocation",
      "short" : "Plats",
      "definition" : "Plats",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "getimagingoutcome.imagingOutcome.imagingOutcomeHeader.accountableHealthcareProfessional.healthcareProfessionalCareUnitHSAId",
      "path" : "getimagingoutcome.imagingOutcome.imagingOutcomeHeader.accountableHealthcareProfessional.healthcareProfessionalCareUnitHSAId",
      "short" : "Vårdenhetens HSA-id",
      "definition" : "Regel 1: Används för spärrhantering och åtkomstkontroll.",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "Identifier"
      }]
    },
    {
      "id" : "getimagingoutcome.imagingOutcome.imagingOutcomeHeader.accountableHealthcareProfessional.healthcareProfessionalCareGiverHSAId",
      "path" : "getimagingoutcome.imagingOutcome.imagingOutcomeHeader.accountableHealthcareProfessional.healthcareProfessionalCareGiverHSAId",
      "short" : "Vårdgivarens HSA-id",
      "definition" : "Regel 1: Används för spärrhantering och åtkomstkontroll.",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "Identifier"
      }]
    },
    {
      "id" : "getimagingoutcome.imagingOutcome.imagingOutcomeHeader.legalAuthenticator",
      "path" : "getimagingoutcome.imagingOutcome.imagingOutcomeHeader.legalAuthenticator",
      "short" : "Juridiskt ansvarig",
      "definition" : "Juridiskt ansvarig",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "BackboneElement"
      }]
    },
    {
      "id" : "getimagingoutcome.imagingOutcome.imagingOutcomeHeader.legalAuthenticator.signatureTime",
      "path" : "getimagingoutcome.imagingOutcome.imagingOutcomeHeader.legalAuthenticator.signatureTime",
      "short" : "Signeringstidpunkt",
      "definition" : "Signeringstidpunkt",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "instant"
      }]
    },
    {
      "id" : "getimagingoutcome.imagingOutcome.imagingOutcomeHeader.legalAuthenticator.legalAuthenticatorHSAId",
      "path" : "getimagingoutcome.imagingOutcome.imagingOutcomeHeader.legalAuthenticator.legalAuthenticatorHSAId",
      "short" : "HSA-id",
      "definition" : "HSA-id",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "Identifier"
      }]
    },
    {
      "id" : "getimagingoutcome.imagingOutcome.imagingOutcomeHeader.legalAuthenticator.legalAuthenticatorName",
      "path" : "getimagingoutcome.imagingOutcome.imagingOutcomeHeader.legalAuthenticator.legalAuthenticatorName",
      "short" : "Namn",
      "definition" : "Namn",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "getimagingoutcome.imagingOutcome.imagingOutcomeHeader.approvedForPatient",
      "path" : "getimagingoutcome.imagingOutcome.imagingOutcomeHeader.approvedForPatient",
      "short" : "Godkänd för patientvisning",
      "definition" : "Godkänd för patientvisning",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "boolean"
      }]
    },
    {
      "id" : "getimagingoutcome.imagingOutcome.imagingOutcomeHeader.careContactId",
      "path" : "getimagingoutcome.imagingOutcome.imagingOutcomeHeader.careContactId",
      "short" : "Vårdkontaktid",
      "definition" : "Vårdkontaktid",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "getimagingoutcome.imagingOutcome.imagingOutcomeHeader.nullified",
      "path" : "getimagingoutcome.imagingOutcome.imagingOutcomeHeader.nullified",
      "short" : "Makulerad",
      "definition" : "Makulerad",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "boolean"
      }]
    },
    {
      "id" : "getimagingoutcome.imagingOutcome.imagingOutcomeHeader.nullifiedReason",
      "path" : "getimagingoutcome.imagingOutcome.imagingOutcomeHeader.nullifiedReason",
      "short" : "Makuleringsorsak",
      "definition" : "Makuleringsorsak",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "getimagingoutcome.imagingOutcome.imagingOutcomeBody",
      "path" : "getimagingoutcome.imagingOutcome.imagingOutcomeBody",
      "short" : "Bilddiagnostisk information",
      "definition" : "Bilddiagnostisk information",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "BackboneElement"
      }]
    },
    {
      "id" : "getimagingoutcome.imagingOutcome.imagingOutcomeBody.examinationSpeciality",
      "path" : "getimagingoutcome.imagingOutcome.imagingOutcomeBody.examinationSpeciality",
      "short" : "Undersökningsspecialitet",
      "definition" : "Undersökningsspecialitet",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "CodeableConcept"
      }]
    },
    {
      "id" : "getimagingoutcome.imagingOutcome.imagingOutcomeBody.typeOfResult",
      "path" : "getimagingoutcome.imagingOutcome.imagingOutcomeBody.typeOfResult",
      "short" : "Typ av resultat",
      "definition" : "Kodas enligt TypeOfResultCodeEnum. Se QUESTIONS.md ASSUME-003.",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "CodeableConcept"
      }]
    },
    {
      "id" : "getimagingoutcome.imagingOutcome.imagingOutcomeBody.resultTime",
      "path" : "getimagingoutcome.imagingOutcome.imagingOutcomeBody.resultTime",
      "short" : "Resultatets tidpunkt",
      "definition" : "Resultatets tidpunkt",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "instant"
      }]
    },
    {
      "id" : "getimagingoutcome.imagingOutcome.imagingOutcomeBody.resultReport",
      "path" : "getimagingoutcome.imagingOutcome.imagingOutcomeBody.resultReport",
      "short" : "Resultatrapport (fritext)",
      "definition" : "Resultatrapport (fritext)",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "getimagingoutcome.imagingOutcome.imagingOutcomeBody.resultComment",
      "path" : "getimagingoutcome.imagingOutcome.imagingOutcomeBody.resultComment",
      "short" : "Kommentar till resultatet",
      "definition" : "Kommentar till resultatet",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "getimagingoutcome.imagingOutcome.imagingOutcomeBody.radiationDose",
      "path" : "getimagingoutcome.imagingOutcome.imagingOutcomeBody.radiationDose",
      "short" : "Stråldos",
      "definition" : "Stråldos",
      "min" : 0,
      "max" : "*",
      "type" : [{
        "code" : "Quantity"
      }]
    },
    {
      "id" : "getimagingoutcome.imagingOutcome.imagingOutcomeBody.patientData",
      "path" : "getimagingoutcome.imagingOutcome.imagingOutcomeBody.patientData",
      "short" : "Patientdata vid undersökningstillfälle",
      "definition" : "Patientdata vid undersökningstillfälle",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "BackboneElement"
      }]
    },
    {
      "id" : "getimagingoutcome.imagingOutcome.imagingOutcomeBody.patientData.patientWeight",
      "path" : "getimagingoutcome.imagingOutcome.imagingOutcomeBody.patientData.patientWeight",
      "short" : "Patientens vikt",
      "definition" : "Patientens vikt",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "Quantity"
      }]
    },
    {
      "id" : "getimagingoutcome.imagingOutcome.imagingOutcomeBody.patientData.patientLength",
      "path" : "getimagingoutcome.imagingOutcome.imagingOutcomeBody.patientData.patientLength",
      "short" : "Patientens längd",
      "definition" : "Patientens längd",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "Quantity"
      }]
    },
    {
      "id" : "getimagingoutcome.imagingOutcome.imagingOutcomeBody.imageRecording",
      "path" : "getimagingoutcome.imagingOutcome.imagingOutcomeBody.imageRecording",
      "short" : "Bildtagning",
      "definition" : "Bildtagning",
      "min" : 0,
      "max" : "*",
      "type" : [{
        "code" : "BackboneElement"
      }]
    },
    {
      "id" : "getimagingoutcome.imagingOutcome.imagingOutcomeBody.imageRecording.recordingId",
      "path" : "getimagingoutcome.imagingOutcome.imagingOutcomeBody.imageRecording.recordingId",
      "short" : "Bildtagningens id",
      "definition" : "Bildtagningens id",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "Identifier"
      }]
    },
    {
      "id" : "getimagingoutcome.imagingOutcome.imagingOutcomeBody.imageRecording.examinationActivity",
      "path" : "getimagingoutcome.imagingOutcome.imagingOutcomeBody.imageRecording.examinationActivity",
      "short" : "Undersökningsaktivitet",
      "definition" : "Undersökningsaktivitet",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "CodeableConcept"
      }]
    },
    {
      "id" : "getimagingoutcome.imagingOutcome.imagingOutcomeBody.imageRecording.examinationTimePeriod",
      "path" : "getimagingoutcome.imagingOutcome.imagingOutcomeBody.imageRecording.examinationTimePeriod",
      "short" : "Undersökningsperiod",
      "definition" : "Undersökningsperiod",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "Period"
      }]
    },
    {
      "id" : "getimagingoutcome.imagingOutcome.imagingOutcomeBody.imageRecording.examinationStatus",
      "path" : "getimagingoutcome.imagingOutcome.imagingOutcomeBody.imageRecording.examinationStatus",
      "short" : "Undersökningsstatus",
      "definition" : "Undersökningsstatus",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "CodeableConcept"
      }]
    },
    {
      "id" : "getimagingoutcome.imagingOutcome.imagingOutcomeBody.imageRecording.examinationUnit",
      "path" : "getimagingoutcome.imagingOutcome.imagingOutcomeBody.imageRecording.examinationUnit",
      "short" : "Undersökningsenhet",
      "definition" : "Undersökningsenhet",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "getimagingoutcome.imagingOutcome.imagingOutcomeBody.imageRecording.accountableHealthcareProfessional",
      "path" : "getimagingoutcome.imagingOutcome.imagingOutcomeBody.imageRecording.accountableHealthcareProfessional",
      "short" : "Ansvarig personal",
      "definition" : "Ansvarig personal",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "BackboneElement"
      }]
    },
    {
      "id" : "getimagingoutcome.imagingOutcome.imagingOutcomeBody.imageRecording.accountableHealthcareProfessional.authorTime",
      "path" : "getimagingoutcome.imagingOutcome.imagingOutcomeBody.imageRecording.accountableHealthcareProfessional.authorTime",
      "short" : "Tidpunkt",
      "definition" : "Tidpunkt",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "instant"
      }]
    },
    {
      "id" : "getimagingoutcome.imagingOutcome.imagingOutcomeBody.imageRecording.accountableHealthcareProfessional.healthcareProfessionalHSAId",
      "path" : "getimagingoutcome.imagingOutcome.imagingOutcomeBody.imageRecording.accountableHealthcareProfessional.healthcareProfessionalHSAId",
      "short" : "HSA-id",
      "definition" : "HSA-id",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "Identifier"
      }]
    },
    {
      "id" : "getimagingoutcome.imagingOutcome.imagingOutcomeBody.imageRecording.accountableHealthcareProfessional.healthcareProfessionalName",
      "path" : "getimagingoutcome.imagingOutcome.imagingOutcomeBody.imageRecording.accountableHealthcareProfessional.healthcareProfessionalName",
      "short" : "Namn",
      "definition" : "Namn",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "getimagingoutcome.imagingOutcome.imagingOutcomeBody.imageRecording.accountableHealthcareProfessional.healthcareProfessionalRoleCode",
      "path" : "getimagingoutcome.imagingOutcome.imagingOutcomeBody.imageRecording.accountableHealthcareProfessional.healthcareProfessionalRoleCode",
      "short" : "Yrkesroll",
      "definition" : "Yrkesroll",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "CodeableConcept"
      }]
    },
    {
      "id" : "getimagingoutcome.imagingOutcome.imagingOutcomeBody.imageRecording.accountableHealthcareProfessional.healthcareProfessionalOrgUnit",
      "path" : "getimagingoutcome.imagingOutcome.imagingOutcomeBody.imageRecording.accountableHealthcareProfessional.healthcareProfessionalOrgUnit",
      "short" : "Org-enhet",
      "definition" : "Org-enhet",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "BackboneElement"
      }]
    },
    {
      "id" : "getimagingoutcome.imagingOutcome.imagingOutcomeBody.imageRecording.numberOfImages",
      "path" : "getimagingoutcome.imagingOutcome.imagingOutcomeBody.imageRecording.numberOfImages",
      "short" : "Antal bilder",
      "definition" : "Antal bilder",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "integer"
      }]
    },
    {
      "id" : "getimagingoutcome.imagingOutcome.imagingOutcomeBody.imageRecording.modalityData",
      "path" : "getimagingoutcome.imagingOutcome.imagingOutcomeBody.imageRecording.modalityData",
      "short" : "Modalitetsdata",
      "definition" : "Modalitetsdata",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "BackboneElement"
      }]
    },
    {
      "id" : "getimagingoutcome.imagingOutcome.imagingOutcomeBody.imageRecording.modalityData.typeOfModality",
      "path" : "getimagingoutcome.imagingOutcome.imagingOutcomeBody.imageRecording.modalityData.typeOfModality",
      "short" : "Modalitetstyp (t.ex. CT, MR)",
      "definition" : "Modalitetstyp (t.ex. CT, MR)",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "getimagingoutcome.imagingOutcome.imagingOutcomeBody.imageRecording.modalityData.manufacturer",
      "path" : "getimagingoutcome.imagingOutcome.imagingOutcomeBody.imageRecording.modalityData.manufacturer",
      "short" : "Tillverkare",
      "definition" : "Tillverkare",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "getimagingoutcome.imagingOutcome.imagingOutcomeBody.imageRecording.modalityData.modelName",
      "path" : "getimagingoutcome.imagingOutcome.imagingOutcomeBody.imageRecording.modalityData.modelName",
      "short" : "Modellnamn",
      "definition" : "Modellnamn",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "getimagingoutcome.imagingOutcome.imagingOutcomeBody.imageRecording.modalityData.equipmentId",
      "path" : "getimagingoutcome.imagingOutcome.imagingOutcomeBody.imageRecording.modalityData.equipmentId",
      "short" : "Utrustningens id",
      "definition" : "Utrustningens id",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "getimagingoutcome.imagingOutcome.imagingOutcomeBody.imageRecording.modalityData.softwareVersion",
      "path" : "getimagingoutcome.imagingOutcome.imagingOutcomeBody.imageRecording.modalityData.softwareVersion",
      "short" : "Programvaruversion",
      "definition" : "Programvaruversion",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "getimagingoutcome.imagingOutcome.imagingOutcomeBody.imageRecording.imageDicomData",
      "path" : "getimagingoutcome.imagingOutcome.imagingOutcomeBody.imageRecording.imageDicomData",
      "short" : "DICOM-bilddata",
      "definition" : "DICOM-bilddata",
      "min" : 0,
      "max" : "*",
      "type" : [{
        "code" : "BackboneElement"
      }]
    },
    {
      "id" : "getimagingoutcome.imagingOutcome.imagingOutcomeBody.imageRecording.imageDicomData.dicomSOP",
      "path" : "getimagingoutcome.imagingOutcome.imagingOutcomeBody.imageRecording.imageDicomData.dicomSOP",
      "short" : "DICOM SOP (UID)",
      "definition" : "DICOM SOP (UID)",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "Identifier"
      }]
    },
    {
      "id" : "getimagingoutcome.imagingOutcome.imagingOutcomeBody.imageRecording.imageDicomData.dicomValue",
      "path" : "getimagingoutcome.imagingOutcome.imagingOutcomeBody.imageRecording.imageDicomData.dicomValue",
      "short" : "DICOM binärdata",
      "definition" : "DICOM binärdata",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "base64Binary"
      }]
    },
    {
      "id" : "getimagingoutcome.imagingOutcome.imagingOutcomeBody.imageRecording.imageDicomData.dicomReference",
      "path" : "getimagingoutcome.imagingOutcome.imagingOutcomeBody.imageRecording.imageDicomData.dicomReference",
      "short" : "Referens till DICOM-bild",
      "definition" : "Referens till DICOM-bild",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "url"
      }]
    },
    {
      "id" : "getimagingoutcome.imagingOutcome.imagingOutcomeBody.imageRecording.imageStructuredData",
      "path" : "getimagingoutcome.imagingOutcome.imagingOutcomeBody.imageRecording.imageStructuredData",
      "short" : "Strukturerad bilddata",
      "definition" : "Strukturerad bilddata",
      "min" : 0,
      "max" : "*",
      "type" : [{
        "code" : "BackboneElement"
      }]
    },
    {
      "id" : "getimagingoutcome.imagingOutcome.imagingOutcomeBody.imageRecording.imageStructuredData.aperture",
      "path" : "getimagingoutcome.imagingOutcome.imagingOutcomeBody.imageRecording.imageStructuredData.aperture",
      "short" : "Bländare",
      "definition" : "Bländare",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "Quantity"
      }]
    },
    {
      "id" : "getimagingoutcome.imagingOutcome.imagingOutcomeBody.imageRecording.imageStructuredData.exposureTime",
      "path" : "getimagingoutcome.imagingOutcome.imagingOutcomeBody.imageRecording.imageStructuredData.exposureTime",
      "short" : "Exponeringstid",
      "definition" : "Exponeringstid",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "Quantity"
      }]
    },
    {
      "id" : "getimagingoutcome.imagingOutcome.imagingOutcomeBody.imageRecording.imageStructuredData.imageCreationTime",
      "path" : "getimagingoutcome.imagingOutcome.imagingOutcomeBody.imageRecording.imageStructuredData.imageCreationTime",
      "short" : "Bildskapningstidpunkt",
      "definition" : "Bildskapningstidpunkt",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "instant"
      }]
    },
    {
      "id" : "getimagingoutcome.imagingOutcome.imagingOutcomeBody.imageRecording.imageStructuredData.bodyPartExamined",
      "path" : "getimagingoutcome.imagingOutcome.imagingOutcomeBody.imageRecording.imageStructuredData.bodyPartExamined",
      "short" : "Undersökt kroppsdel",
      "definition" : "Undersökt kroppsdel",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "CodeableConcept"
      }]
    },
    {
      "id" : "getimagingoutcome.imagingOutcome.imagingOutcomeBody.imageRecording.imageStructuredData.contrastAgentUsed",
      "path" : "getimagingoutcome.imagingOutcome.imagingOutcomeBody.imageRecording.imageStructuredData.contrastAgentUsed",
      "short" : "Kontrastmedel",
      "definition" : "Kontrastmedel",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "getimagingoutcome.imagingOutcome.imagingOutcomeBody.imageRecording.imageStructuredData.magneticFieldStrength",
      "path" : "getimagingoutcome.imagingOutcome.imagingOutcomeBody.imageRecording.imageStructuredData.magneticFieldStrength",
      "short" : "Magnetfältstyrka",
      "definition" : "Magnetfältstyrka",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "Quantity"
      }]
    },
    {
      "id" : "getimagingoutcome.imagingOutcome.imagingOutcomeBody.imageRecording.imageStructuredData.copyright",
      "path" : "getimagingoutcome.imagingOutcome.imagingOutcomeBody.imageRecording.imageStructuredData.copyright",
      "short" : "Upphovsrätt",
      "definition" : "Upphovsrätt",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "getimagingoutcome.imagingOutcome.imagingOutcomeBody.imageRecording.imageStructuredData.imageData",
      "path" : "getimagingoutcome.imagingOutcome.imagingOutcomeBody.imageRecording.imageStructuredData.imageData",
      "short" : "Bilddata",
      "definition" : "Bilddata",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "BackboneElement"
      }]
    },
    {
      "id" : "getimagingoutcome.imagingOutcome.imagingOutcomeBody.imageRecording.imageStructuredData.imageData.mediaType",
      "path" : "getimagingoutcome.imagingOutcome.imagingOutcomeBody.imageRecording.imageStructuredData.imageData.mediaType",
      "short" : "Medietyp",
      "definition" : "Medietyp",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "CodeableConcept"
      }]
    },
    {
      "id" : "getimagingoutcome.imagingOutcome.imagingOutcomeBody.imageRecording.imageStructuredData.imageData.value",
      "path" : "getimagingoutcome.imagingOutcome.imagingOutcomeBody.imageRecording.imageStructuredData.imageData.value",
      "short" : "Binär bild",
      "definition" : "Binär bild",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "base64Binary"
      }]
    },
    {
      "id" : "getimagingoutcome.imagingOutcome.imagingOutcomeBody.imageRecording.imageStructuredData.imageData.reference",
      "path" : "getimagingoutcome.imagingOutcome.imagingOutcomeBody.imageRecording.imageStructuredData.imageData.reference",
      "short" : "Referens-URL",
      "definition" : "Referens-URL",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "url"
      }]
    },
    {
      "id" : "getimagingoutcome.imagingOutcome.imagingOutcomeBody.imageRecording.imageStructuredData.imageData.burnedInAnnotations",
      "path" : "getimagingoutcome.imagingOutcome.imagingOutcomeBody.imageRecording.imageStructuredData.imageData.burnedInAnnotations",
      "short" : "Inbrända annotationer",
      "definition" : "Inbrända annotationer",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "boolean"
      }]
    },
    {
      "id" : "getimagingoutcome.imagingOutcome.imagingOutcomeBody.referral",
      "path" : "getimagingoutcome.imagingOutcome.imagingOutcomeBody.referral",
      "short" : "Kopplad remiss",
      "definition" : "Kopplad remiss",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "BackboneElement"
      }]
    },
    {
      "id" : "getimagingoutcome.imagingOutcome.imagingOutcomeBody.referral.referralId",
      "path" : "getimagingoutcome.imagingOutcome.imagingOutcomeBody.referral.referralId",
      "short" : "Remissens id",
      "definition" : "Remissens id",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "getimagingoutcome.imagingOutcome.imagingOutcomeBody.referral.referralReason",
      "path" : "getimagingoutcome.imagingOutcome.imagingOutcomeBody.referral.referralReason",
      "short" : "Remissorsak",
      "definition" : "Remissorsak",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "getimagingoutcome.imagingOutcome.imagingOutcomeBody.referral.anamnesis",
      "path" : "getimagingoutcome.imagingOutcome.imagingOutcomeBody.referral.anamnesis",
      "short" : "Anamnes",
      "definition" : "Anamnes",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "getimagingoutcome.imagingOutcome.imagingOutcomeBody.referral.careContactId",
      "path" : "getimagingoutcome.imagingOutcome.imagingOutcomeBody.referral.careContactId",
      "short" : "Vårdkontaktid",
      "definition" : "Vårdkontaktid",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "getimagingoutcome.imagingOutcome.imagingOutcomeBody.referral.accountableHealthcareProfessional",
      "path" : "getimagingoutcome.imagingOutcome.imagingOutcomeBody.referral.accountableHealthcareProfessional",
      "short" : "Remittent",
      "definition" : "Remittent",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "BackboneElement"
      }]
    },
    {
      "id" : "getimagingoutcome.imagingOutcome.imagingOutcomeBody.referral.accountableHealthcareProfessional.authorTime",
      "path" : "getimagingoutcome.imagingOutcome.imagingOutcomeBody.referral.accountableHealthcareProfessional.authorTime",
      "short" : "Tidpunkt",
      "definition" : "Tidpunkt",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "instant"
      }]
    },
    {
      "id" : "getimagingoutcome.imagingOutcome.imagingOutcomeBody.referral.accountableHealthcareProfessional.healthcareProfessionalHSAid",
      "path" : "getimagingoutcome.imagingOutcome.imagingOutcomeBody.referral.accountableHealthcareProfessional.healthcareProfessionalHSAid",
      "short" : "HSA-id",
      "definition" : "HSA-id",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "Identifier"
      }]
    },
    {
      "id" : "getimagingoutcome.imagingOutcome.imagingOutcomeBody.referral.accountableHealthcareProfessional.healthcareProfessionalName",
      "path" : "getimagingoutcome.imagingOutcome.imagingOutcomeBody.referral.accountableHealthcareProfessional.healthcareProfessionalName",
      "short" : "Namn",
      "definition" : "Namn",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "getimagingoutcome.imagingOutcome.imagingOutcomeBody.referral.accountableHealthcareProfessional.healthcareProfessionalRoleCode",
      "path" : "getimagingoutcome.imagingOutcome.imagingOutcomeBody.referral.accountableHealthcareProfessional.healthcareProfessionalRoleCode",
      "short" : "Yrkesroll",
      "definition" : "Yrkesroll",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "CodeableConcept"
      }]
    },
    {
      "id" : "getimagingoutcome.imagingOutcome.imagingOutcomeBody.referral.accountableHealthcareProfessional.healthcareProfessionalOrgUnit",
      "path" : "getimagingoutcome.imagingOutcome.imagingOutcomeBody.referral.accountableHealthcareProfessional.healthcareProfessionalOrgUnit",
      "short" : "Org-enhet (obligatorisk i remissen)",
      "definition" : "Org-enhet (obligatorisk i remissen)",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "BackboneElement"
      }]
    },
    {
      "id" : "getimagingoutcome.imagingOutcome.imagingOutcomeBody.referral.accountableHealthcareProfessional.healthcareProfessionalOrgUnit.orgUnitHSAId",
      "path" : "getimagingoutcome.imagingOutcome.imagingOutcomeBody.referral.accountableHealthcareProfessional.healthcareProfessionalOrgUnit.orgUnitHSAId",
      "short" : "OrgUnit HSA-id",
      "definition" : "OrgUnit HSA-id",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "Identifier"
      }]
    },
    {
      "id" : "getimagingoutcome.imagingOutcome.imagingOutcomeBody.referral.accountableHealthcareProfessional.healthcareProfessionalOrgUnit.orgUnitName",
      "path" : "getimagingoutcome.imagingOutcome.imagingOutcomeBody.referral.accountableHealthcareProfessional.healthcareProfessionalOrgUnit.orgUnitName",
      "short" : "OrgUnit namn",
      "definition" : "OrgUnit namn",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "getimagingoutcome.imagingOutcome.imagingOutcomeBody.referral.accountableHealthcareProfessional.healthcareProfessionalOrgUnit.orgUnitTelecom",
      "path" : "getimagingoutcome.imagingOutcome.imagingOutcomeBody.referral.accountableHealthcareProfessional.healthcareProfessionalOrgUnit.orgUnitTelecom",
      "short" : "Telefon",
      "definition" : "Telefon",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "getimagingoutcome.imagingOutcome.imagingOutcomeBody.referral.accountableHealthcareProfessional.healthcareProfessionalOrgUnit.orgUnitEmail",
      "path" : "getimagingoutcome.imagingOutcome.imagingOutcomeBody.referral.accountableHealthcareProfessional.healthcareProfessionalOrgUnit.orgUnitEmail",
      "short" : "E-post",
      "definition" : "E-post",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "getimagingoutcome.imagingOutcome.imagingOutcomeBody.referral.accountableHealthcareProfessional.healthcareProfessionalOrgUnit.orgUnitAddress",
      "path" : "getimagingoutcome.imagingOutcome.imagingOutcomeBody.referral.accountableHealthcareProfessional.healthcareProfessionalOrgUnit.orgUnitAddress",
      "short" : "Adress",
      "definition" : "Adress",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "getimagingoutcome.imagingOutcome.imagingOutcomeBody.referral.accountableHealthcareProfessional.healthcareProfessionalOrgUnit.orgUnitLocation",
      "path" : "getimagingoutcome.imagingOutcome.imagingOutcomeBody.referral.accountableHealthcareProfessional.healthcareProfessionalOrgUnit.orgUnitLocation",
      "short" : "Plats",
      "definition" : "Plats",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "getimagingoutcome.imagingOutcome.imagingOutcomeBody.referral.attested",
      "path" : "getimagingoutcome.imagingOutcome.imagingOutcomeBody.referral.attested",
      "short" : "Attestering",
      "definition" : "Attestering",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "BackboneElement"
      }]
    },
    {
      "id" : "getimagingoutcome.imagingOutcome.imagingOutcomeBody.referral.attested.signatureTime",
      "path" : "getimagingoutcome.imagingOutcome.imagingOutcomeBody.referral.attested.signatureTime",
      "short" : "Attesttidpunkt",
      "definition" : "Attesttidpunkt",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "instant"
      }]
    },
    {
      "id" : "getimagingoutcome.imagingOutcome.imagingOutcomeBody.referral.attested.legalAuthenticatorHSAId",
      "path" : "getimagingoutcome.imagingOutcome.imagingOutcomeBody.referral.attested.legalAuthenticatorHSAId",
      "short" : "HSA-id",
      "definition" : "HSA-id",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "Identifier"
      }]
    },
    {
      "id" : "getimagingoutcome.imagingOutcome.imagingOutcomeBody.referral.attested.legalAuthenticatorName",
      "path" : "getimagingoutcome.imagingOutcome.imagingOutcomeBody.referral.attested.legalAuthenticatorName",
      "short" : "Namn",
      "definition" : "Namn",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    }]
  }
}

```
