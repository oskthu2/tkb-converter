# inera.clinicalprocess-healthcond-actoutcome#4.2.2: clinicalprocess: healthcond: actoutcome

## Pages

* [Hem](index.md)
* [5 Gemensamma informationskomponenter](5-gemensamma-informationskomponenter.md)
* [7 Tjänstekontrakt](7-tjanstekontrakt.md)
* [6 Tjänstedomänens meddelandemodeller](6-tjanstedomanens-meddelandemodeller.md)
* [Artifacts Summary](artifacts.md)
* [3 Tjänstedomänens arkitektur](3-tjanstedomanens-arkitektur.md)
* [4 Tjänstedomänens krav och regler](4-tjanstedomanens-krav-och-regler.md)
* [2 Versionsinformation](2-versionsinformation.md)
* [1 Inledning](1-inledning.md)

## Resources

### CodeSystems

* [DeliveryCode](CodeSystem-deliverycode-cs.md)
* [ExaminationStatusCode](CodeSystem-examinationstatuscode-cs.md)
* [FetalPositionCode](CodeSystem-fetalpositioncode-cs.md)
* [ReferralOutcomeTypeCode](CodeSystem-referraloutcometypecode-cs.md)
* [SexCode](CodeSystem-sexcode-cs.md)
* [TypeOfLeaveCode](CodeSystem-typeofleavecode-cs.md)
* [TypeOfResultCode](CodeSystem-typeofresultcode-cs.md)

### ValueSets

* [DeliveryCode — ValueSet](ValueSet-deliverycode-vs.md)
* [ExaminationStatusCode — ValueSet](ValueSet-examinationstatuscode-vs.md)
* [ReferralOutcomeTypeCode — ValueSet](ValueSet-referraloutcometypecode-vs.md)
* [SexCode — ValueSet](ValueSet-sexcode-vs.md)
* [TypeOfResultCode — ValueSet](ValueSet-typeofresultcode-vs.md)

### Logicals

* [GetImagingOutcome — Request](StructureDefinition-getimagingoutcome-request.md)
* [GetImagingOutcome](StructureDefinition-getimagingoutcome.md)
* [GetLaboratoryOrderOutcome — Request](StructureDefinition-getlaboratoryorderoutcome-request.md)
* [GetLaboratoryOrderOutcome](StructureDefinition-getlaboratoryorderoutcome.md)
* [GetMaternityMedicalHistory — Request](StructureDefinition-getmaternitymedicalhistory-request.md)
* [GetMaternityMedicalHistory](StructureDefinition-getmaternitymedicalhistory.md)
* [GetReferralOutcome — Request](StructureDefinition-getreferraloutcome-request.md)
* [GetReferralOutcome](StructureDefinition-getreferraloutcome.md)

### ImplementationGuides

* [clinicalprocess: healthcond: actoutcome](index.md)
