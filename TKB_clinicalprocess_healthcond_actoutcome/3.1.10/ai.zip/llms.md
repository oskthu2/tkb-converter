# inera.clinicalprocess-healthcond-actoutcome#3.1.10: clinicalprocess: healthcond: actoutcome 3.1.10

## Pages

* [Hem](index.md)
* [5 Gemensamma informationskomponenter](5-gemensamma-informationskomponenter.md)
* [7 Tjänstekontrakt](7-tjanstekontrakt.md)
* [6 Tjänstedomänens meddelandemodeller](6-tjanstedomanens-meddelandemodeller.md)
* [Artifacts Summary](artifacts.md)
* [3 Tjänstedomänens arkitektur](3-tjanstedomanens-arkitektur.md)
* [4 Tjänstedomänens krav och regler](4-tjanstedomanens-krav-och-regler.md)
* [2 Versionsinformation](2-versionsinformation.md)
* [1 Inledning](1-inledning.md)

## Resources

### CodeSystems

* [DeliveryCode](CodeSystem-deliverycode-cs.md)
* [ErrorCode](CodeSystem-errorcode-cs.md)
* [ExaminationStatusCode](CodeSystem-examinationstatuscode-cs.md)
* [FetalPositionCode](CodeSystem-fetalpositioncode-cs.md)
* [FetalPresentationCode](CodeSystem-fetalpresentationcode-cs.md)
* [MediaType](CodeSystem-mediatype-cs.md)
* [ReferralOutcomeTypeCode](CodeSystem-referraloutcometypecode-cs.md)
* [ResultCode](CodeSystem-resultcode-cs.md)
* [SexCode](CodeSystem-sexcode-cs.md)
* [TypeOfLeaveCode](CodeSystem-typeofleavecode-cs.md)
* [TypeOfResultCode](CodeSystem-typeofresultcode-cs.md)

### ValueSets

* [DeliveryCode — ValueSet](ValueSet-deliverycode-vs.md)
* [ErrorCode — ValueSet](ValueSet-errorcode-vs.md)
* [ExaminationStatusCode — ValueSet](ValueSet-examinationstatuscode-vs.md)
* [FetalPositionCode — ValueSet](ValueSet-fetalpositioncode-vs.md)
* [FetalPresentationCode — ValueSet](ValueSet-fetalpresentationcode-vs.md)
* [MediaType — ValueSet](ValueSet-mediatype-vs.md)
* [ReferralOutcomeTypeCode — ValueSet](ValueSet-referraloutcometypecode-vs.md)
* [ResultCode — ValueSet](ValueSet-resultcode-vs.md)
* [SexCode — ValueSet](ValueSet-sexcode-vs.md)
* [TypeOfLeaveCode — ValueSet](ValueSet-typeofleavecode-vs.md)
* [TypeOfResultCode — ValueSet](ValueSet-typeofresultcode-vs.md)

### Logicals

* [GetImagingOutcome — Begäran](StructureDefinition-getimagingoutcome-request.md)
* [GetImagingOutcome](StructureDefinition-getimagingoutcome.md)
* [GetLaboratoryOrderOutcome — Begäran](StructureDefinition-getlaboratoryorderoutcome-request.md)
* [GetLaboratoryOrderOutcome](StructureDefinition-getlaboratoryorderoutcome.md)
* [GetMaternityMedicalHistory — Begäran](StructureDefinition-getmaternitymedicalhistory-request.md)
* [GetMaternityMedicalHistory](StructureDefinition-getmaternitymedicalhistory.md)
* [GetReferralOutcome — Begäran](StructureDefinition-getreferraloutcome-request.md)
* [GetReferralOutcome](StructureDefinition-getreferraloutcome.md)

### ImplementationGuides

* [clinicalprocess: healthcond: actoutcome 3.1.10](index.md)
