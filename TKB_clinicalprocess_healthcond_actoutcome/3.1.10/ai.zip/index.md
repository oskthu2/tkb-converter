# Hem - clinicalprocess: healthcond: actoutcome 3.1.10 v3.1.10

* [**Table of Contents**](toc.md)
* **Hem**

## Hem

| | |
| :--- | :--- |
| *Official URL*:https://fhir.inera.se/ig/clinicalprocess-healthcond-actoutcome/ImplementationGuide/inera.clinicalprocess-healthcond-actoutcome | *Version*:3.1.10 |
| Active as of 2026-10-08 | *Computable Name*:clinicalprocesshealthcondactoutcome |
| **Copyright/Legal**: Copyright 2024 Inera AB. Licensieras under Creative Commons Attribution 4.0. | |

# clinicalprocess: healthcond: actoutcome 3.1.10

**TKB-version:** 3.1.10 · **IG-version:** 3.1.10 · **Källa:** Bitbucket-tagg `3.1.10` · **Andra huvudversioner:** [4.2.2](https://oskthu2.github.io/tkb-converter/TKB_clinicalprocess_healthcond_actoutcome/index.html) 

> **Äldre huvudversion.** Detta är TKB 3.1.10 (Bitbucket-tagg `3.1.10`). Den senaste huvudversionen, 4.2, finns på [clinicalprocess: healthcond: actoutcome](https://oskthu2.github.io/tkb-converter/TKB_clinicalprocess_healthcond_actoutcome/index.html).

## Översikt

Detta är en FHIR Implementation Guide genererad från Ineras tjänstekontraktsbeskrivning (TKB) för tjänstedomänen **clinicalprocess: healthcond: actoutcome** version 3.1.10, släppt 2026-06-03 (Bitbucket-tagg `3.1.10`, commit `7c07a857587fbf8e4484f586d045d2c366a9ace6`).

Domänen hanterar information gällande utfall av olika undersökningar och aktiviteter, till exempel laboratoriesvar och bilddiagnostik. Tjänstekontrakten är baserade på RIVTA 2.1 och reglerade genom arkitekturella beslut.

Namespace-bas: `urn:riv:clinicalprocess:healthcond:actoutcome`

Domänen innehåller följande tjänstekontrakt:

| | | |
| :--- | :--- | :--- |
| [GetReferralOutcome](7-tjanstekontrakt.md#getreferraloutcome) | 3.1 | Returnerar svar på en konsultationsremiss för en patient |
| [GetMaternityMedicalHistory](7-tjanstekontrakt.md#getmaternitymedicalhistory) | 2.0 | Returnerar mödravårdsjournal för en patient |
| [GetLaboratoryOrderOutcome](7-tjanstekontrakt.md#getlaboratoryorderoutcome) | 3.1 | Returnerar kemilaboratoriesvar för en patient |
| [GetImagingOutcome](7-tjanstekontrakt.md#getimagingoutcome) | 1.0 | Returnerar bilddiagnostiska resultat för en patient |

## Innehåll

* [1 Inledning](1-inledning.md)
* [2 Versionsinformation](2-versionsinformation.md)
* [3 Tjänstedomänens arkitektur](3-tjanstedomanens-arkitektur.md)
* [4 Tjänstedomänens krav och regler](4-tjanstedomanens-krav-och-regler.md)
* [5 Gemensamma informationskomponenter](5-gemensamma-informationskomponenter.md)
* [6 Tjänstedomänens meddelandemodeller](6-tjanstedomanens-meddelandemodeller.md)
* [7 Tjänstekontrakt](7-tjanstekontrakt.md)
* [Artefakter](artifacts.md)

