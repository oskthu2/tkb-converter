# GetImagingOutcome — Begäran - clinicalprocess: healthcond: actoutcome 3.1.10 v3.1.10

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **GetImagingOutcome — Begäran**

## Logical Model: GetImagingOutcome — Begäran 

| | |
| :--- | :--- |
| *Official URL*:https://fhir.inera.se/ig/clinicalprocess-healthcond-actoutcome/StructureDefinition/getimagingoutcome-request | *Version*:1.0 |
| Active as of 2026-10-08 | *Computable Name*:GetImagingOutcomeRequest |
| **Copyright/Legal**: Copyright 2024 Inera AB. Licensieras under Creative Commons Attribution 4.0. | |

 
Logisk modell för tjänstekontraktet GetImagingOutcome 1.0 (RIV-TA urn:riv:clinicalprocess:healthcond:actoutcome:GetImagingOutcomeResponder:1). Representerar begärans (request) parametrar enligt fältreglerna i TKB 3.1.10, avsnitt 7.4. 

**Usages:**

* This Logical Model is not used by any profiles in this Specification

You can also check for [usages in the FHIR IG Statistics](https://packages2.fhir.org/xig/resource/inera.clinicalprocess-healthcond-actoutcome|current/StructureDefinition/StructureDefinition-getimagingoutcome-request.json)

### Formal Views of Profile Content

 [Description of Profiles, Differentials, Snapshots and how the different presentations work](http://build.fhir.org/ig/FHIR/ig-guidance/readingIgs.html#structure-definitions). 

 

Other representations of profile: [CSV](StructureDefinition-getimagingoutcome-request.csv), [Excel](StructureDefinition-getimagingoutcome-request.xlsx) 



## Resource Content

```json
{
  "resourceType" : "StructureDefinition",
  "id" : "getimagingoutcome-request",
  "extension" : [{
    "url" : "http://hl7.org/fhir/StructureDefinition/structuredefinition-type-characteristics",
    "valueCode" : "can-be-target"
  }],
  "url" : "https://fhir.inera.se/ig/clinicalprocess-healthcond-actoutcome/StructureDefinition/getimagingoutcome-request",
  "version" : "1.0",
  "name" : "GetImagingOutcomeRequest",
  "title" : "GetImagingOutcome — Begäran",
  "status" : "active",
  "date" : "2026-10-08T18:06:18+00:00",
  "contact" : [{
    "name" : "Inera Arkitektur",
    "telecom" : [{
      "system" : "url",
      "value" : "https://www.inera.se"
    }]
  }],
  "description" : "Logisk modell för tjänstekontraktet GetImagingOutcome 1.0\n(RIV-TA urn:riv:clinicalprocess:healthcond:actoutcome:GetImagingOutcomeResponder:1).\nRepresenterar begärans (request) parametrar enligt fältreglerna i TKB 3.1.10, avsnitt 7.4.",
  "copyright" : "Copyright 2024 Inera AB. Licensieras under Creative Commons Attribution 4.0.",
  "fhirVersion" : "4.0.1",
  "kind" : "logical",
  "abstract" : false,
  "type" : "https://fhir.inera.se/ig/clinicalprocess-healthcond-actoutcome/StructureDefinition/getimagingoutcome-request",
  "baseDefinition" : "http://hl7.org/fhir/StructureDefinition/Base",
  "derivation" : "specialization",
  "differential" : {
    "element" : [{
      "id" : "getimagingoutcome-request",
      "path" : "getimagingoutcome-request",
      "short" : "GetImagingOutcome — Begäran",
      "definition" : "Logisk modell för tjänstekontraktet GetImagingOutcome 1.0\n(RIV-TA urn:riv:clinicalprocess:healthcond:actoutcome:GetImagingOutcomeResponder:1).\nRepresenterar begärans (request) parametrar enligt fältreglerna i TKB 3.1.10, avsnitt 7.4.",
      "constraint" : [{
        "key" : "getimagingoutcome-request-sourcesystem-if-carecontact",
        "severity" : "error",
        "human" : "sourceSystemHSAId ska anges om careContactId angivits.",
        "expression" : "careContactId.exists() implies sourceSystemHSAId.exists()",
        "source" : "https://fhir.inera.se/ig/clinicalprocess-healthcond-actoutcome/StructureDefinition/getimagingoutcome-request"
      }]
    },
    {
      "id" : "getimagingoutcome-request.careUnitHSAId",
      "path" : "getimagingoutcome-request.careUnitHSAId",
      "short" : "Filtrering på PDL-enhet vilket motsvarar careUnitHSAId i healthcareProfessionalType.",
      "definition" : "Filtrering på PDL-enhet vilket motsvarar careUnitHSAId i healthcareProfessionalType.\nRIV-TA-typ: HSAIdType. Kardinalitet i TKB: 0..*.",
      "min" : 0,
      "max" : "*",
      "type" : [{
        "code" : "Identifier"
      }]
    },
    {
      "id" : "getimagingoutcome-request.patientId",
      "path" : "getimagingoutcome-request.patientId",
      "short" : "Id för patienten",
      "definition" : "Id för patienten. / id sätts till patientens identifierare. Anges med 12 tecken utan avskiljare. / Type sätts till OID för typ av identifierare. / För personnummer ska Skatteverkets personnummer (1.2.752.129.2.1.3.1). / För samordningsnummer ska Skatteverkets samordningsnummer (1.2.752.129.2.1.3.3). / För reservnummer används lokalt definierade reservnummet, exempelvis SLL reservnummer (1.2.752.97.3.1.3)\nRIV-TA-typ: PersonIdType. Kardinalitet i TKB: 1..1.",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "Identifier"
      }]
    },
    {
      "id" : "getimagingoutcome-request.datePeriod",
      "path" : "getimagingoutcome-request.datePeriod",
      "short" : "Begränsar sökningen till det angivna intervallet",
      "definition" : "Begränsar sökningen till det angivna intervallet. Begränsningen innebär att endast poster returneras där datumintervallet, som bildas av tidpunkterna authorTime, resultTime samt remissens authorTime i svaret, helt eller delvis överlappar med det angivna sökintervallet, dvs. / det bildade intervallets startdatum ligger inom sökintervallets start- och slutdatum / det bildade intervallets slutdatum ligger inom sökintervallets start- och slutdatum / det bildade intervallets startdatum ligger före sökintervallets startdatum och slutdatum ligger efter sökintervallets slutdatum / Notera att sökintervallet beskrivs som ett datumintervall. Vid jämförelse konverteras datapostens tidpunkter till datum.\nRIV-TA-typ: DatePeriodType. Kardinalitet i TKB: 0..1.\nDelelement enligt TKB:\n- start (string, 1..1): Startdatum. Format ÅÅÅÅMMDD.\n- end (string, 1..1): Slutdatum. Format ÅÅÅÅMMDD.",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "Period"
      }]
    },
    {
      "id" : "getimagingoutcome-request.sourceSystemHSAId",
      "path" : "getimagingoutcome-request.sourceSystemHSAId",
      "short" : "Begränsar sökningen till dokument som är skapad i det angivna källsystemet",
      "definition" : "Begränsar sökningen till dokument som är skapad i det angivna källsystemet. Tjänsteproducenten förväntas enbart returnera poster som tillhör efterfrågat källsystem. / Värdet på detta fält måste överensstämma med värdet på logicalAddress i anropets tekniska kuvertering (ex. SOAP-header). / Det innebär i praktiken att aggregerande tjänster inte används när detta fält anges. / Ska anges om careContactId angivits. / Ska anges vid begäran på reservnummer. / Om sourceSystemHSAId och logicalAddress är olika ska ett svar endast innehålla en resultType med result.resultCode satt till ERROR samt result.errorCode satt till INVALID_REQUEST / Om careContactId är satt och sourceSystemHSAId är tomt ska ett svar endast innehålla en resultType med  result.resultCode satt till ERROR samt result.errorCode satt till INVALID_REQUEST.\nRIV-TA-typ: HSAIdType. Kardinalitet i TKB: 0..1.",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "Identifier"
      }]
    },
    {
      "id" : "getimagingoutcome-request.careContactId",
      "path" : "getimagingoutcome-request.careContactId",
      "short" : "Begränsar sökningen till den hälso-och sjukvårdskontakt som föranlett den information som omfattas av dokument",
      "definition" : "Begränsar sökningen till den hälso-och sjukvårdskontakt som föranlett den information som omfattas av dokumentet. Identiteten är unik inom källsystemet.\nRIV-TA-typ: string. Kardinalitet i TKB: 0..*.",
      "min" : 0,
      "max" : "*",
      "type" : [{
        "code" : "string"
      }]
    }]
  }
}

```
