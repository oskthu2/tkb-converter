# inera.ehr-log#1.2.3: ehr: log

## Pages

* [Hem](index.md)
* [7 Tjänstekontrakt](7-tjanstekontrakt.md)
* [1 Inledning](1-inledning.md)
* [2 Generella regler](2-generella-regler.md)
* [8 Datatyper](8-datatyper.md)
* [Artifacts Summary](artifacts.md)

## Resources

### CodeSystems

* [ActivityType](CodeSystem-activitytype-cs.md)
* [ResultCode](CodeSystem-resultcode-cs.md)

### ValueSets

* [ActivityType — ValueSet](ValueSet-activitytype-vs.md)
* [ResultCode — ValueSet](ValueSet-resultcode-vs.md)

### Logicals

* [GetAccessLogsForPatient — Request](StructureDefinition-getaccesslogsforpatient-request.md)
* [GetAccessLogsForPatient](StructureDefinition-getaccesslogsforpatient.md)
* [GetInfoLogsForCareProvider — Request](StructureDefinition-getinfologsforcareprovider-request.md)
* [GetInfoLogsForCareProvider](StructureDefinition-getinfologsforcareprovider.md)
* [GetInfoLogsForPatient — Request](StructureDefinition-getinfologsforpatient-request.md)
* [GetInfoLogsForPatient](StructureDefinition-getinfologsforpatient.md)
* [GetLogsForCareProvider — Request](StructureDefinition-getlogsforcareprovider-request.md)
* [GetLogsForCareProvider](StructureDefinition-getlogsforcareprovider.md)
* [GetLogsForPatient — Request](StructureDefinition-getlogsforpatient-request.md)
* [GetLogsForPatient](StructureDefinition-getlogsforpatient.md)
* [GetLogsForUser — Request](StructureDefinition-getlogsforuser-request.md)
* [GetLogsForUser](StructureDefinition-getlogsforuser.md)
* [StoreLog — Request](StructureDefinition-storelog-request.md)
* [StoreLog](StructureDefinition-storelog.md)

### ImplementationGuides

* [ehr: log](index.md)
