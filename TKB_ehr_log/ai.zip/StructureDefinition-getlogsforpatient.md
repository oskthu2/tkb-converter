# GetLogsForPatient - ehr: log v1.2.3

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **GetLogsForPatient**

## Logical Model: GetLogsForPatient 

| | |
| :--- | :--- |
| *Official URL*:https://fhir.inera.se/ig/ehr-log/StructureDefinition/getlogsforpatient | *Version*:1.2.3 |
| Draft as of 2026-09-17 | *Computable Name*:GetLogsForPatient |
| **Copyright/Legal**: Copyright 2024 Inera AB. Licensieras under Creative Commons Attribution 4.0. | |

 
Logisk modell för tjänstekontraktet GetLogsForPatient (RIV-TA urn:riv:ehr:log:querying:GetLogsForPatientResponder:1). Representerar responsens informationsstruktur (log.querying:LogsResult). Returnerar loggposter för angiven vårdgivare och patient. 

**Usages:**

* This Logical Model is not used by any profiles in this Specification

You can also check for [usages in the FHIR IG Statistics](https://packages2.fhir.org/xig/resource/inera.ehr-log|current/StructureDefinition/StructureDefinition-getlogsforpatient.json)

### Formal Views of Profile Content

 [Description of Profiles, Differentials, Snapshots and how the different presentations work](http://build.fhir.org/ig/FHIR/ig-guidance/readingIgs.html#structure-definitions). 

 

Other representations of profile: [CSV](StructureDefinition-getlogsforpatient.csv), [Excel](StructureDefinition-getlogsforpatient.xlsx) 



## Resource Content

```json
{
  "resourceType" : "StructureDefinition",
  "id" : "getlogsforpatient",
  "extension" : [{
    "url" : "http://hl7.org/fhir/StructureDefinition/structuredefinition-type-characteristics",
    "valueCode" : "can-be-target"
  }],
  "url" : "https://fhir.inera.se/ig/ehr-log/StructureDefinition/getlogsforpatient",
  "version" : "1.2.3",
  "name" : "GetLogsForPatient",
  "title" : "GetLogsForPatient",
  "status" : "draft",
  "date" : "2026-09-17T11:09:43+00:00",
  "contact" : [{
    "name" : "Inera Arkitektur",
    "telecom" : [{
      "system" : "url",
      "value" : "https://www.inera.se"
    }]
  }],
  "description" : "Logisk modell för tjänstekontraktet GetLogsForPatient\n(RIV-TA urn:riv:ehr:log:querying:GetLogsForPatientResponder:1).\nRepresenterar responsens informationsstruktur (log.querying:LogsResult).\nReturnerar loggposter för angiven vårdgivare och patient.",
  "copyright" : "Copyright 2024 Inera AB. Licensieras under Creative Commons Attribution 4.0.",
  "fhirVersion" : "4.0.1",
  "kind" : "logical",
  "abstract" : false,
  "type" : "https://fhir.inera.se/ig/ehr-log/StructureDefinition/getlogsforpatient",
  "baseDefinition" : "http://hl7.org/fhir/StructureDefinition/Base",
  "derivation" : "specialization",
  "differential" : {
    "element" : [{
      "id" : "getlogsforpatient",
      "path" : "getlogsforpatient",
      "short" : "GetLogsForPatient",
      "definition" : "Logisk modell för tjänstekontraktet GetLogsForPatient\n(RIV-TA urn:riv:ehr:log:querying:GetLogsForPatientResponder:1).\nRepresenterar responsens informationsstruktur (log.querying:LogsResult).\nReturnerar loggposter för angiven vårdgivare och patient."
    },
    {
      "id" : "getlogsforpatient.result",
      "path" : "getlogsforpatient.result",
      "short" : "Resultatkontainer",
      "definition" : "Resultatkontainer",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "BackboneElement"
      }]
    },
    {
      "id" : "getlogsforpatient.result.resultCode",
      "path" : "getlogsforpatient.result.resultCode",
      "short" : "Statuskod",
      "definition" : "Statuskod",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "code"
      }],
      "binding" : {
        "strength" : "required",
        "valueSet" : "https://fhir.inera.se/ig/ehr-log/ValueSet/resultcode-vs"
      }
    },
    {
      "id" : "getlogsforpatient.result.resultText",
      "path" : "getlogsforpatient.result.resultText",
      "short" : "Beskrivande text",
      "definition" : "Beskrivande text",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "getlogsforpatient.result.startInterval",
      "path" : "getlogsforpatient.result.startInterval",
      "short" : "Start på tillgängligt datumintervall",
      "definition" : "Start på tillgängligt datumintervall",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "dateTime"
      }]
    },
    {
      "id" : "getlogsforpatient.result.endInterval",
      "path" : "getlogsforpatient.result.endInterval",
      "short" : "Slut på tillgängligt datumintervall",
      "definition" : "Slut på tillgängligt datumintervall",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "dateTime"
      }]
    },
    {
      "id" : "getlogsforpatient.result.queuedReportId",
      "path" : "getlogsforpatient.result.queuedReportId",
      "short" : "Id för pågående rapport (UUID)",
      "definition" : "Id för pågående rapport (UUID)",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "getlogsforpatient.result.queueTime",
      "path" : "getlogsforpatient.result.queueTime",
      "short" : "Uppskattad väntetid i sekunder",
      "definition" : "Uppskattad väntetid i sekunder",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "integer"
      }]
    },
    {
      "id" : "getlogsforpatient.logs",
      "path" : "getlogsforpatient.logs",
      "short" : "Samling av loggposter",
      "definition" : "Samling av loggposter",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "BackboneElement"
      }]
    },
    {
      "id" : "getlogsforpatient.logs.log",
      "path" : "getlogsforpatient.logs.log",
      "short" : "En loggpost",
      "definition" : "En loggpost",
      "min" : 0,
      "max" : "*",
      "type" : [{
        "code" : "BackboneElement"
      }]
    },
    {
      "id" : "getlogsforpatient.logs.log.logId",
      "path" : "getlogsforpatient.logs.log.logId",
      "short" : "Loggpostens UUID-identifierare",
      "definition" : "Loggpostens UUID-identifierare",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "getlogsforpatient.logs.log.system",
      "path" : "getlogsforpatient.logs.log.system",
      "short" : "Loggande system",
      "definition" : "Loggande system",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "BackboneElement"
      }]
    },
    {
      "id" : "getlogsforpatient.logs.log.system.systemId",
      "path" : "getlogsforpatient.logs.log.system.systemId",
      "short" : "Systemets HSA-id",
      "definition" : "Systemets HSA-id",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "Identifier"
      }]
    },
    {
      "id" : "getlogsforpatient.logs.log.system.systemName",
      "path" : "getlogsforpatient.logs.log.system.systemName",
      "short" : "Systemets namn",
      "definition" : "Systemets namn",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "getlogsforpatient.logs.log.activity",
      "path" : "getlogsforpatient.logs.log.activity",
      "short" : "Aktivitetsinformation",
      "definition" : "Aktivitetsinformation",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "BackboneElement"
      }]
    },
    {
      "id" : "getlogsforpatient.logs.log.activity.activityType",
      "path" : "getlogsforpatient.logs.log.activity.activityType",
      "short" : "Typ av aktivitet",
      "definition" : "Typ av aktivitet",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "code"
      }],
      "binding" : {
        "strength" : "required",
        "valueSet" : "https://fhir.inera.se/ig/ehr-log/ValueSet/activitytype-vs"
      }
    },
    {
      "id" : "getlogsforpatient.logs.log.activity.activityLevel",
      "path" : "getlogsforpatient.logs.log.activity.activityLevel",
      "short" : "Aktivitetsnivå",
      "definition" : "Aktivitetsnivå",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "getlogsforpatient.logs.log.activity.activityArgs",
      "path" : "getlogsforpatient.logs.log.activity.activityArgs",
      "short" : "Övriga aktivitetsparametrar",
      "definition" : "Övriga aktivitetsparametrar",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "getlogsforpatient.logs.log.activity.startDate",
      "path" : "getlogsforpatient.logs.log.activity.startDate",
      "short" : "Tidpunkt för aktiviteten",
      "definition" : "Tidpunkt för aktiviteten",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "dateTime"
      }]
    },
    {
      "id" : "getlogsforpatient.logs.log.activity.purpose",
      "path" : "getlogsforpatient.logs.log.activity.purpose",
      "short" : "Syfte med aktiviteten",
      "definition" : "Syfte med aktiviteten",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "getlogsforpatient.logs.log.user",
      "path" : "getlogsforpatient.logs.log.user",
      "short" : "Medarbetaren som utförde aktiviteten",
      "definition" : "Medarbetaren som utförde aktiviteten",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "BackboneElement"
      }]
    },
    {
      "id" : "getlogsforpatient.logs.log.user.userId",
      "path" : "getlogsforpatient.logs.log.user.userId",
      "short" : "Medarbetarens HSA-id",
      "definition" : "Medarbetarens HSA-id",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "Identifier"
      }]
    },
    {
      "id" : "getlogsforpatient.logs.log.user.employeeName",
      "path" : "getlogsforpatient.logs.log.user.employeeName",
      "short" : "Medarbetarens namn",
      "definition" : "Medarbetarens namn",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "getlogsforpatient.logs.log.user.personId",
      "path" : "getlogsforpatient.logs.log.user.personId",
      "short" : "Medarbetarens personnummer",
      "definition" : "Medarbetarens personnummer",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "Identifier"
      }]
    },
    {
      "id" : "getlogsforpatient.logs.log.user.assignment",
      "path" : "getlogsforpatient.logs.log.user.assignment",
      "short" : "Uppdragsnamn",
      "definition" : "Uppdragsnamn",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "getlogsforpatient.logs.log.user.title",
      "path" : "getlogsforpatient.logs.log.user.title",
      "short" : "Yrkestitel",
      "definition" : "Yrkestitel",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "getlogsforpatient.logs.log.user.careProvider",
      "path" : "getlogsforpatient.logs.log.user.careProvider",
      "short" : "Medarbetarens vårdgivare",
      "definition" : "Medarbetarens vårdgivare",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "BackboneElement"
      }]
    },
    {
      "id" : "getlogsforpatient.logs.log.user.careProvider.careProviderId",
      "path" : "getlogsforpatient.logs.log.user.careProvider.careProviderId",
      "short" : "Vårdgivarens HSA-id",
      "definition" : "Vårdgivarens HSA-id",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "Identifier"
      }]
    },
    {
      "id" : "getlogsforpatient.logs.log.user.careProvider.careProviderName",
      "path" : "getlogsforpatient.logs.log.user.careProvider.careProviderName",
      "short" : "Vårdgivarens namn",
      "definition" : "Vårdgivarens namn",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "getlogsforpatient.logs.log.user.careUnit",
      "path" : "getlogsforpatient.logs.log.user.careUnit",
      "short" : "Medarbetarens vårdenhet",
      "definition" : "Medarbetarens vårdenhet",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "BackboneElement"
      }]
    },
    {
      "id" : "getlogsforpatient.logs.log.user.careUnit.careUnitId",
      "path" : "getlogsforpatient.logs.log.user.careUnit.careUnitId",
      "short" : "Vårdenhetens HSA-id",
      "definition" : "Vårdenhetens HSA-id",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "Identifier"
      }]
    },
    {
      "id" : "getlogsforpatient.logs.log.user.careUnit.careUnitName",
      "path" : "getlogsforpatient.logs.log.user.careUnit.careUnitName",
      "short" : "Vårdenhetens namn",
      "definition" : "Vårdenhetens namn",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "getlogsforpatient.logs.log.resources",
      "path" : "getlogsforpatient.logs.log.resources",
      "short" : "Resurser som aktiviteten avsåg",
      "definition" : "Resurser som aktiviteten avsåg",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "BackboneElement"
      }]
    },
    {
      "id" : "getlogsforpatient.logs.log.resources.resource",
      "path" : "getlogsforpatient.logs.log.resources.resource",
      "short" : "En resurs",
      "definition" : "En resurs",
      "min" : 1,
      "max" : "*",
      "type" : [{
        "code" : "BackboneElement"
      }]
    },
    {
      "id" : "getlogsforpatient.logs.log.resources.resource.resourceType",
      "path" : "getlogsforpatient.logs.log.resources.resource.resourceType",
      "short" : "Resurstyp",
      "definition" : "Resurstyp",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "getlogsforpatient.logs.log.resources.resource.patient",
      "path" : "getlogsforpatient.logs.log.resources.resource.patient",
      "short" : "Patient",
      "definition" : "Patient",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "BackboneElement"
      }]
    },
    {
      "id" : "getlogsforpatient.logs.log.resources.resource.patient.patientId",
      "path" : "getlogsforpatient.logs.log.resources.resource.patient.patientId",
      "short" : "Patientidentifierare",
      "definition" : "Patientidentifierare",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "Identifier"
      }]
    },
    {
      "id" : "getlogsforpatient.logs.log.resources.resource.patient.patientName",
      "path" : "getlogsforpatient.logs.log.resources.resource.patient.patientName",
      "short" : "Patientens namn",
      "definition" : "Patientens namn",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "getlogsforpatient.logs.log.resources.resource.careProvider",
      "path" : "getlogsforpatient.logs.log.resources.resource.careProvider",
      "short" : "Resursens ägande vårdgivare",
      "definition" : "Resursens ägande vårdgivare",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "BackboneElement"
      }]
    },
    {
      "id" : "getlogsforpatient.logs.log.resources.resource.careProvider.careProviderId",
      "path" : "getlogsforpatient.logs.log.resources.resource.careProvider.careProviderId",
      "short" : "Vårdgivarens HSA-id",
      "definition" : "Vårdgivarens HSA-id",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "Identifier"
      }]
    },
    {
      "id" : "getlogsforpatient.logs.log.resources.resource.careProvider.careProviderName",
      "path" : "getlogsforpatient.logs.log.resources.resource.careProvider.careProviderName",
      "short" : "Vårdgivarens namn",
      "definition" : "Vårdgivarens namn",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "getlogsforpatient.logs.log.resources.resource.careUnit",
      "path" : "getlogsforpatient.logs.log.resources.resource.careUnit",
      "short" : "Resursens vårdenhet",
      "definition" : "Resursens vårdenhet",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "BackboneElement"
      }]
    },
    {
      "id" : "getlogsforpatient.logs.log.resources.resource.careUnit.careUnitId",
      "path" : "getlogsforpatient.logs.log.resources.resource.careUnit.careUnitId",
      "short" : "Vårdenhetens HSA-id",
      "definition" : "Vårdenhetens HSA-id",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "Identifier"
      }]
    },
    {
      "id" : "getlogsforpatient.logs.log.resources.resource.careUnit.careUnitName",
      "path" : "getlogsforpatient.logs.log.resources.resource.careUnit.careUnitName",
      "short" : "Vårdenhetens namn",
      "definition" : "Vårdenhetens namn",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    }]
  }
}

```
