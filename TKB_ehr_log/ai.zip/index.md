# Hem - ehr: log v1.2.4

* [**Table of Contents**](toc.md)
* **Hem**

## Hem

| | |
| :--- | :--- |
| *Official URL*:https://fhir.inera.se/ig/ehr-log/ImplementationGuide/inera.ehr-log | *Version*:1.2.4 |
| Active as of 2026-10-12 | *Computable Name*:ehrlog |
| **Copyright/Legal**: Copyright 2024 Inera AB. Licensieras under Creative Commons Attribution 4.0. | |

# ehr: log

**TKB-version:** 1.2.4 · **IG-version:** 1.2.4 · **Källa:** Bitbucket-tagg `1.2.4` 

## Översikt

* Beskrivning: Svenskt kortnamn
  * OBSERVERA: Denna domän utvecklas inte längre, för nyutveckling, support och buggrättningar hänvisas till den nya domänen: loggtjänst - informationsecurity:auditing:log Logghantering lagrar information om åtkomstrelaterade händelser från olika system på ett strukturerat sätt, och används av system och tjänster som till exempel NPÖ och Pascal. Syftet är att man i efterhand ska kunna se vem som tagit del av vilken patientinformation. Tjänstekontrakten för Logghantering säkerställer att uppföljning av åtkomst till journaluppgifter sker på ett enhetligt sätt, och enligt de lagar och förordningar som gäller. Tjänstekontrakten gör det också möjligt för patienten/medborgaren att själv ta del av åtkomstloggar via till exempel Mina vårdkontakter. Detta är dock ännu inte realiserat i Mina vårdkontakter (MVK).: logghantering
* Beskrivning: Svenskt namn
  * OBSERVERA: Denna domän utvecklas inte längre, för nyutveckling, support och buggrättningar hänvisas till den nya domänen: loggtjänst - informationsecurity:auditing:log Logghantering lagrar information om åtkomstrelaterade händelser från olika system på ett strukturerat sätt, och används av system och tjänster som till exempel NPÖ och Pascal. Syftet är att man i efterhand ska kunna se vem som tagit del av vilken patientinformation. Tjänstekontrakten för Logghantering säkerställer att uppföljning av åtkomst till journaluppgifter sker på ett enhetligt sätt, och enligt de lagar och förordningar som gäller. Tjänstekontrakten gör det också möjligt för patienten/medborgaren att själv ta del av åtkomstloggar via till exempel Mina vårdkontakter. Detta är dock ännu inte realiserat i Mina vårdkontakter (MVK).: infrastruktur:säkerhetstjänster:logghantering
* Beskrivning: Typ
  * OBSERVERA: Denna domän utvecklas inte längre, för nyutveckling, support och buggrättningar hänvisas till den nya domänen: loggtjänst - informationsecurity:auditing:log Logghantering lagrar information om åtkomstrelaterade händelser från olika system på ett strukturerat sätt, och används av system och tjänster som till exempel NPÖ och Pascal. Syftet är att man i efterhand ska kunna se vem som tagit del av vilken patientinformation. Tjänstekontrakten för Logghantering säkerställer att uppföljning av åtkomst till journaluppgifter sker på ett enhetligt sätt, och enligt de lagar och förordningar som gäller. Tjänstekontrakten gör det också möjligt för patienten/medborgaren att själv ta del av åtkomstloggar via till exempel Mina vårdkontakter. Detta är dock ännu inte realiserat i Mina vårdkontakter (MVK).: Nationell tjänstedomän
* Beskrivning: Källkod
  * OBSERVERA: Denna domän utvecklas inte längre, för nyutveckling, support och buggrättningar hänvisas till den nya domänen: loggtjänst - informationsecurity:auditing:log Logghantering lagrar information om åtkomstrelaterade händelser från olika system på ett strukturerat sätt, och används av system och tjänster som till exempel NPÖ och Pascal. Syftet är att man i efterhand ska kunna se vem som tagit del av vilken patientinformation. Tjänstekontrakten för Logghantering säkerställer att uppföljning av åtkomst till journaluppgifter sker på ett enhetligt sätt, och enligt de lagar och förordningar som gäller. Tjänstekontrakten gör det också möjligt för patienten/medborgaren att själv ta del av åtkomstloggar via till exempel Mina vårdkontakter. Detta är dock ännu inte realiserat i Mina vårdkontakter (MVK).: [Bitbucket](https://bitbucket.org/rivta-domains/riv.ehr.log/src)
* Beskrivning: Ärenden
  * OBSERVERA: Denna domän utvecklas inte längre, för nyutveckling, support och buggrättningar hänvisas till den nya domänen: loggtjänst - informationsecurity:auditing:log Logghantering lagrar information om åtkomstrelaterade händelser från olika system på ett strukturerat sätt, och används av system och tjänster som till exempel NPÖ och Pascal. Syftet är att man i efterhand ska kunna se vem som tagit del av vilken patientinformation. Tjänstekontrakten för Logghantering säkerställer att uppföljning av åtkomst till journaluppgifter sker på ett enhetligt sätt, och enligt de lagar och förordningar som gäller. Tjänstekontrakten gör det också möjligt för patienten/medborgaren att själv ta del av åtkomstloggar via till exempel Mina vårdkontakter. Detta är dock ännu inte realiserat i Mina vårdkontakter (MVK).: [Bitbucket issues](https://bitbucket.org/rivta-domains/riv.ehr.log/issues)
* Beskrivning: Underlag för denna IG
  * OBSERVERA: Denna domän utvecklas inte längre, för nyutveckling, support och buggrättningar hänvisas till den nya domänen: loggtjänst - informationsecurity:auditing:log Logghantering lagrar information om åtkomstrelaterade händelser från olika system på ett strukturerat sätt, och används av system och tjänster som till exempel NPÖ och Pascal. Syftet är att man i efterhand ska kunna se vem som tagit del av vilken patientinformation. Tjänstekontrakten för Logghantering säkerställer att uppföljning av åtkomst till journaluppgifter sker på ett enhetligt sätt, och enligt de lagar och förordningar som gäller. Tjänstekontrakten gör det också möjligt för patienten/medborgaren att själv ta del av åtkomstloggar via till exempel Mina vårdkontakter. Detta är dock ännu inte realiserat i Mina vårdkontakter (MVK).: Version 1.2.4 ·[tagg 1.2.4](https://bitbucket.org/rivta-domains/riv.ehr.log/src/1.2.4)
* Beskrivning: RIV-TA-portalen
  * OBSERVERA: Denna domän utvecklas inte längre, för nyutveckling, support och buggrättningar hänvisas till den nya domänen: loggtjänst - informationsecurity:auditing:log Logghantering lagrar information om åtkomstrelaterade händelser från olika system på ett strukturerat sätt, och används av system och tjänster som till exempel NPÖ och Pascal. Syftet är att man i efterhand ska kunna se vem som tagit del av vilken patientinformation. Tjänstekontrakten för Logghantering säkerställer att uppföljning av åtkomst till journaluppgifter sker på ett enhetligt sätt, och enligt de lagar och förordningar som gäller. Tjänstekontrakten gör det också möjligt för patienten/medborgaren att själv ta del av åtkomstloggar via till exempel Mina vårdkontakter. Detta är dock ännu inte realiserat i Mina vårdkontakter (MVK).: [Alla tjänstedomäner](https://oskthu2.github.io/tkb-converter/rivta-portal/tjanstedomaner.html)·[Alla tjänstekontrakt](https://oskthu2.github.io/tkb-converter/rivta-portal/tjanstekontrakt.html)

FHIR Implementation Guide för tjänstedomänen **ehr: log** version 1.2.4. Genererad från Ineras Tjänstekontraktsbeskrivning (TKB).

Domänen **urn:riv:ehr:log** hanterar loggning och uppföljning av åtkomst till patientjournal enligt Patientdatalagen (PDL) och Socialstyrelsens föreskrifter (SOSFS 2008:14). Den är indelad i två underdomäner:

* **urn:riv:ehr:log:store** — registrerande tjänst
* **urn:riv:ehr:log:querying** — läsande tjänster

Domänen innehåller följande tjänstekontrakt:

| | | | |
| :--- | :--- | :--- | :--- |
| [StoreLog](7-tjanstekontrakt.md#storelog) | 1.0 | store | Sparar en eller flera loggposter i loggtjänsten |
| [GetLogsForCareProvider](7-tjanstekontrakt.md#getlogsforcareprovider) | 1.1 | querying | Returnerar loggposter för angiven vårdgivare |
| [GetLogsForUser](7-tjanstekontrakt.md#getlogsforuser) | 1.1 | querying | Returnerar loggposter för angiven medarbetare |
| [GetLogsForPatient](7-tjanstekontrakt.md#getlogsforpatient) | 1.0 | querying | Returnerar loggposter för angiven patient |
| [GetAccessLogsForPatient](7-tjanstekontrakt.md#getaccesslogsforpatient) | 1.1 | querying | Returnerar åtkomstloggar för angiven patient |
| [GetInfoLogsForCareProvider](7-tjanstekontrakt.md#getinfologsforcareprovider) | 1.0 | querying | Returnerar informationsloggar per informationsägande vårdgivare |
| [GetInfoLogsForPatient](7-tjanstekontrakt.md#getinfologsforpatient) | 1.0 | querying | Returnerar informationsloggar per patient och informationsägare |

### Versioner och granskningar

| | | | |
| :--- | :--- | :--- | :--- |
| 1.2.3 | TKB, AB | Äldre granskningsprocess: Teknik: Godkänd | [zip](http://rivta.se/downloads//ehr_log/1.2.3/ServiceContracts_ehr_log_1.2.3.zip)·[källkod](https://bitbucket.org/rivta-domains/riv.ehr.log/src/1.2.3) |
| trunk | TKB, AB |  | [källkod](https://bitbucket.org/rivta-domains/riv.ehr.log/src/master) |

*Källa: ögonblicksbild av DOMDB från 2021-08-24, via RIV-TA-portalen.*

## Innehåll

* [1 Inledning](1-inledning.md)
* [2 Generella regler](2-generella-regler.md)
* [7 Tjänstekontrakt](7-tjanstekontrakt.md)
* [8 Datatyper](8-datatyper.md)
* [Artefakter](artifacts.md)

