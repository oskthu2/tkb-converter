# Hem - ehr: log v1.2.3

* [**Table of Contents**](toc.md)
* **Hem**

## Hem

| | |
| :--- | :--- |
| *Official URL*:https://fhir.inera.se/ig/ehr-log/ImplementationGuide/inera.ehr-log | *Version*:1.2.3 |
| Draft as of 2026-09-17 | *Computable Name*:ehrlog |
| **Copyright/Legal**: Copyright 2024 Inera AB. Licensieras under Creative Commons Attribution 4.0. | |

# ehr: log

## Översikt

FHIR Implementation Guide för tjänstedomänen **ehr: log** version 1.2.3. Genererad från Ineras Tjänstekontraktsbeskrivning (TKB).

Domänen **urn:riv:ehr:log** hanterar loggning och uppföljning av åtkomst till patientjournal enligt Patientdatalagen (PDL) och Socialstyrelsens föreskrifter (SOSFS 2008:14). Den är indelad i två underdomäner:

* **urn:riv:ehr:log:store** — registrerande tjänst
* **urn:riv:ehr:log:querying** — läsande tjänster

Domänen innehåller följande tjänstekontrakt:

| | | | |
| :--- | :--- | :--- | :--- |
| [StoreLog](7-tjanstekontrakt.md#storelog) | 1.0 | store | Sparar en eller flera loggposter i loggtjänsten |
| [GetLogsForCareProvider](7-tjanstekontrakt.md#getlogsforcareprovider) | 1.1 | querying | Returnerar loggposter för angiven vårdgivare |
| [GetLogsForUser](7-tjanstekontrakt.md#getlogsforuser) | 1.1 | querying | Returnerar loggposter för angiven medarbetare |
| [GetLogsForPatient](7-tjanstekontrakt.md#getlogsforpatient) | 1.0 | querying | Returnerar loggposter för angiven patient |
| [GetAccessLogsForPatient](7-tjanstekontrakt.md#getaccesslogsforpatient) | 1.1 | querying | Returnerar åtkomstloggar för angiven patient |
| [GetInfoLogsForCareProvider](7-tjanstekontrakt.md#getinfologsforcareprovider) | 1.0 | querying | Returnerar informationsloggar per informationsägande vårdgivare |
| [GetInfoLogsForPatient](7-tjanstekontrakt.md#getinfologsforpatient) | 1.0 | querying | Returnerar informationsloggar per patient och informationsägare |

## Innehåll

* [1 Inledning](1-inledning.md)
* [2 Generella regler](2-generella-regler.md)
* [7 Tjänstekontrakt](7-tjanstekontrakt.md)
* [8 Datatyper](8-datatyper.md)
* [Artefakter](artifacts.md)

