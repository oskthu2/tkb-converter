# GetAccessLogsForPatient — Request - ehr: log v1.2.4

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **GetAccessLogsForPatient — Request**

## Logical Model: GetAccessLogsForPatient — Request 

| | |
| :--- | :--- |
| *Official URL*:https://fhir.inera.se/ig/ehr-log/StructureDefinition/getaccesslogsforpatient-request | *Version*:1.1 |
| Active as of 2026-11-09 | *Computable Name*:GetAccessLogsForPatientRequest |
| **Copyright/Legal**: Copyright 2024 Inera AB. Licensieras under Creative Commons Attribution 4.0. | |

 
Logisk modell för requestparametrar i GetAccessLogsForPatient. Obs: queuedReportId ska INTE användas när aggregerande tjänst anropas. 

**Usages:**

* This Logical Model is not used by any profiles in this Specification

You can also check for [usages in the FHIR IG Statistics](https://packages2.fhir.org/xig/resource/inera.ehr-log|current/StructureDefinition/StructureDefinition-getaccesslogsforpatient-request.json)

### Formal Views of Profile Content

 [Description of Profiles, Differentials, Snapshots and how the different presentations work](http://build.fhir.org/ig/FHIR/ig-guidance/readingIgs.html#structure-definitions). 

 

Other representations of profile: [CSV](StructureDefinition-getaccesslogsforpatient-request.csv), [Excel](StructureDefinition-getaccesslogsforpatient-request.xlsx) 



## Resource Content

```json
{
  "resourceType" : "StructureDefinition",
  "id" : "getaccesslogsforpatient-request",
  "extension" : [{
    "url" : "http://hl7.org/fhir/StructureDefinition/structuredefinition-type-characteristics",
    "valueCode" : "can-be-target"
  }],
  "url" : "https://fhir.inera.se/ig/ehr-log/StructureDefinition/getaccesslogsforpatient-request",
  "version" : "1.1",
  "name" : "GetAccessLogsForPatientRequest",
  "title" : "GetAccessLogsForPatient — Request",
  "status" : "active",
  "date" : "2026-11-09T03:29:30+00:00",
  "contact" : [{
    "name" : "Inera Arkitektur",
    "telecom" : [{
      "system" : "url",
      "value" : "https://www.inera.se"
    }]
  }],
  "description" : "Logisk modell för requestparametrar i GetAccessLogsForPatient.\nObs: queuedReportId ska INTE användas när aggregerande tjänst anropas.",
  "copyright" : "Copyright 2024 Inera AB. Licensieras under Creative Commons Attribution 4.0.",
  "fhirVersion" : "4.0.1",
  "kind" : "logical",
  "abstract" : false,
  "type" : "https://fhir.inera.se/ig/ehr-log/StructureDefinition/getaccesslogsforpatient-request",
  "baseDefinition" : "http://hl7.org/fhir/StructureDefinition/Base",
  "derivation" : "specialization",
  "differential" : {
    "element" : [{
      "id" : "getaccesslogsforpatient-request",
      "path" : "getaccesslogsforpatient-request",
      "short" : "GetAccessLogsForPatient — Request",
      "definition" : "Logisk modell för requestparametrar i GetAccessLogsForPatient.\nObs: queuedReportId ska INTE användas när aggregerande tjänst anropas."
    },
    {
      "id" : "getaccesslogsforpatient-request.patientId",
      "path" : "getaccesslogsforpatient-request.patientId",
      "short" : "Patientens personnummer, samordningsnummer eller reservnummer",
      "definition" : "Patientens personnummer, samordningsnummer, alternativt reservnummer som någon vårdgivare haft åtkomst till.",
      "comment" : "TKB-fält: `PatientId` (`log:PersonId`, kardinalitet 1..1).",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "Identifier"
      }]
    },
    {
      "id" : "getaccesslogsforpatient-request.fromDate",
      "path" : "getaccesslogsforpatient-request.fromDate",
      "short" : "Obligatoriskt startdatum för rapportuttaget",
      "definition" : "Obligatoriskt startdatum för att begränsa rapportuttaget.",
      "comment" : "TKB-fält: `FromDate` (`xs:dateTime`, kardinalitet 1..1).",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "dateTime"
      }]
    },
    {
      "id" : "getaccesslogsforpatient-request.toDate",
      "path" : "getaccesslogsforpatient-request.toDate",
      "short" : "Obligatoriskt slutdatum för rapportuttaget",
      "definition" : "Obligatoriskt slutdatum för att begränsa rapportuttaget.",
      "comment" : "TKB-fält: `ToDate` (`xs:dateTime`, kardinalitet 1..1).",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "dateTime"
      }]
    },
    {
      "id" : "getaccesslogsforpatient-request.queuedReportId",
      "path" : "getaccesslogsforpatient-request.queuedReportId",
      "short" : "Id på en pågående rapport (UUID) — ej vid aggregerande anrop",
      "definition" : "Id på en pågående rapport. Id som returnerats från ett tidigare anrop och hänvisar till rapport som ej färdigstälts.\n\nSkall inte användas när aggregerande tjänst anropas.",
      "comment" : "TKB-fält: `QueuedReportId` (`log:Id`, kardinalitet 0..1).",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    }]
  }
}

```
