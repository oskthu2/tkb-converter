# GetInfoLogsForCareProvider - ehr: log v1.2.4

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **GetInfoLogsForCareProvider**

## Logical Model: GetInfoLogsForCareProvider 

| | |
| :--- | :--- |
| *Official URL*:https://fhir.inera.se/ig/ehr-log/StructureDefinition/getinfologsforcareprovider | *Version*:1.0 |
| Active as of 2026-11-09 | *Computable Name*:GetInfoLogsForCareProvider |
| **Copyright/Legal**: Copyright 2024 Inera AB. Licensieras under Creative Commons Attribution 4.0. | |

 
Logisk modell för tjänstekontraktet GetInfoLogsForCareProvider (RIV-TA urn:riv:ehr:log:querying:GetInfoLogsForCareProviderResponder:1). Representerar responsens informationsstruktur (log.querying:InfoLogsResult). Returnerar lista för angiven informationsägande vårdgivare med vilka externa vårdgivare som har haft åtkomst till vårdgivarens information. 

**Usages:**

* This Logical Model is not used by any profiles in this Specification

You can also check for [usages in the FHIR IG Statistics](https://packages2.fhir.org/xig/resource/inera.ehr-log|current/StructureDefinition/StructureDefinition-getinfologsforcareprovider.json)

### Formal Views of Profile Content

 [Description of Profiles, Differentials, Snapshots and how the different presentations work](http://build.fhir.org/ig/FHIR/ig-guidance/readingIgs.html#structure-definitions). 

 

Other representations of profile: [CSV](StructureDefinition-getinfologsforcareprovider.csv), [Excel](StructureDefinition-getinfologsforcareprovider.xlsx) 



## Resource Content

```json
{
  "resourceType" : "StructureDefinition",
  "id" : "getinfologsforcareprovider",
  "extension" : [{
    "url" : "http://hl7.org/fhir/StructureDefinition/structuredefinition-type-characteristics",
    "valueCode" : "can-be-target"
  }],
  "url" : "https://fhir.inera.se/ig/ehr-log/StructureDefinition/getinfologsforcareprovider",
  "version" : "1.0",
  "name" : "GetInfoLogsForCareProvider",
  "title" : "GetInfoLogsForCareProvider",
  "status" : "active",
  "date" : "2026-11-09T03:29:30+00:00",
  "contact" : [{
    "name" : "Inera Arkitektur",
    "telecom" : [{
      "system" : "url",
      "value" : "https://www.inera.se"
    }]
  }],
  "description" : "Logisk modell för tjänstekontraktet GetInfoLogsForCareProvider\n(RIV-TA urn:riv:ehr:log:querying:GetInfoLogsForCareProviderResponder:1).\nRepresenterar responsens informationsstruktur (log.querying:InfoLogsResult).\nReturnerar lista för angiven informationsägande vårdgivare med vilka externa\nvårdgivare som har haft åtkomst till vårdgivarens information.",
  "copyright" : "Copyright 2024 Inera AB. Licensieras under Creative Commons Attribution 4.0.",
  "fhirVersion" : "4.0.1",
  "kind" : "logical",
  "abstract" : false,
  "type" : "https://fhir.inera.se/ig/ehr-log/StructureDefinition/getinfologsforcareprovider",
  "baseDefinition" : "http://hl7.org/fhir/StructureDefinition/Base",
  "derivation" : "specialization",
  "differential" : {
    "element" : [{
      "id" : "getinfologsforcareprovider",
      "path" : "getinfologsforcareprovider",
      "short" : "GetInfoLogsForCareProvider",
      "definition" : "Logisk modell för tjänstekontraktet GetInfoLogsForCareProvider\n(RIV-TA urn:riv:ehr:log:querying:GetInfoLogsForCareProviderResponder:1).\nRepresenterar responsens informationsstruktur (log.querying:InfoLogsResult).\nReturnerar lista för angiven informationsägande vårdgivare med vilka externa\nvårdgivare som har haft åtkomst till vårdgivarens information."
    },
    {
      "id" : "getinfologsforcareprovider.InfoLogsResultType",
      "path" : "getinfologsforcareprovider.InfoLogsResultType",
      "short" : "InfoLogsResultType",
      "definition" : "InfoLogsResultType",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "Base"
      }]
    },
    {
      "id" : "getinfologsforcareprovider.InfoLogsResultType.Result",
      "path" : "getinfologsforcareprovider.InfoLogsResultType.Result",
      "short" : "ResultType",
      "definition" : "Result",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "Base"
      }]
    },
    {
      "id" : "getinfologsforcareprovider.InfoLogsResultType.Result.ResultCode",
      "path" : "getinfologsforcareprovider.InfoLogsResultType.Result.ResultCode",
      "short" : "ResultCode",
      "definition" : "ResultCode Tillåtna värden: OK, INFO, ERROR, VALIDATION_ERROR, ACCESSDENIED, REPORT_ON_QUEUE, REPORT_IN_PROCESS, REPORT_NOT_FOUND, MAX_QUERY_RESULT_EXCEEDED.",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "code"
      }],
      "binding" : {
        "strength" : "required",
        "valueSet" : "https://fhir.inera.se/ig/ehr-log/ValueSet/resultcode-vs"
      }
    },
    {
      "id" : "getinfologsforcareprovider.InfoLogsResultType.Result.ResultText",
      "path" : "getinfologsforcareprovider.InfoLogsResultType.Result.ResultText",
      "short" : "ResultText",
      "definition" : "ResultText",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "getinfologsforcareprovider.InfoLogsResultType.Result.StartInterval",
      "path" : "getinfologsforcareprovider.InfoLogsResultType.Result.StartInterval",
      "short" : "StartInterval",
      "definition" : "StartInterval",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "dateTime"
      }]
    },
    {
      "id" : "getinfologsforcareprovider.InfoLogsResultType.Result.EndInterval",
      "path" : "getinfologsforcareprovider.InfoLogsResultType.Result.EndInterval",
      "short" : "EndInterval",
      "definition" : "EndInterval",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "dateTime"
      }]
    },
    {
      "id" : "getinfologsforcareprovider.InfoLogsResultType.Result.QueuedReportId",
      "path" : "getinfologsforcareprovider.InfoLogsResultType.Result.QueuedReportId",
      "short" : "QueuedReportId",
      "definition" : "QueuedReportId",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "getinfologsforcareprovider.InfoLogsResultType.Result.QueueTime",
      "path" : "getinfologsforcareprovider.InfoLogsResultType.Result.QueueTime",
      "short" : "QueueTime",
      "definition" : "QueueTime",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "integer"
      }]
    },
    {
      "id" : "getinfologsforcareprovider.InfoLogsResultType.CareProviders",
      "path" : "getinfologsforcareprovider.InfoLogsResultType.CareProviders",
      "short" : "CareProvidersType",
      "definition" : "CareProviders",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "Base"
      }]
    },
    {
      "id" : "getinfologsforcareprovider.InfoLogsResultType.CareProviders.CareProvider",
      "path" : "getinfologsforcareprovider.InfoLogsResultType.CareProviders.CareProvider",
      "short" : "CareProviderType",
      "definition" : "CareProvider",
      "min" : 0,
      "max" : "*",
      "type" : [{
        "code" : "Base"
      }]
    },
    {
      "id" : "getinfologsforcareprovider.InfoLogsResultType.CareProviders.CareProvider.CareProviderId",
      "path" : "getinfologsforcareprovider.InfoLogsResultType.CareProviders.CareProvider.CareProviderId",
      "short" : "CareProviderId",
      "definition" : "CareProviderId",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "getinfologsforcareprovider.InfoLogsResultType.CareProviders.CareProvider.CareProviderName",
      "path" : "getinfologsforcareprovider.InfoLogsResultType.CareProviders.CareProvider.CareProviderName",
      "short" : "CareProviderName",
      "definition" : "CareProviderName",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    }]
  }
}

```
