# GetInfoLogsForPatient - ehr: log v1.2.3

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **GetInfoLogsForPatient**

## Logical Model: GetInfoLogsForPatient 

| | |
| :--- | :--- |
| *Official URL*:https://fhir.inera.se/ig/ehr-log/StructureDefinition/getinfologsforpatient | *Version*:1.2.3 |
| Draft as of 2026-09-17 | *Computable Name*:GetInfoLogsForPatient |
| **Copyright/Legal**: Copyright 2024 Inera AB. Licensieras under Creative Commons Attribution 4.0. | |

 
Logisk modell för tjänstekontraktet GetInfoLogsForPatient (RIV-TA urn:riv:ehr:log:querying:GetInfoLogsForPatientResponder:1). Representerar responsens informationsstruktur (log.querying:InfoLogsResult). Returnerar lista för angiven informationsägande vårdgivare och patient med vilka externa vårdgivare som haft åtkomst till information. 

**Usages:**

* This Logical Model is not used by any profiles in this Specification

You can also check for [usages in the FHIR IG Statistics](https://packages2.fhir.org/xig/resource/inera.ehr-log|current/StructureDefinition/StructureDefinition-getinfologsforpatient.json)

### Formal Views of Profile Content

 [Description of Profiles, Differentials, Snapshots and how the different presentations work](http://build.fhir.org/ig/FHIR/ig-guidance/readingIgs.html#structure-definitions). 

 

Other representations of profile: [CSV](StructureDefinition-getinfologsforpatient.csv), [Excel](StructureDefinition-getinfologsforpatient.xlsx) 



## Resource Content

```json
{
  "resourceType" : "StructureDefinition",
  "id" : "getinfologsforpatient",
  "extension" : [{
    "url" : "http://hl7.org/fhir/StructureDefinition/structuredefinition-type-characteristics",
    "valueCode" : "can-be-target"
  }],
  "url" : "https://fhir.inera.se/ig/ehr-log/StructureDefinition/getinfologsforpatient",
  "version" : "1.2.3",
  "name" : "GetInfoLogsForPatient",
  "title" : "GetInfoLogsForPatient",
  "status" : "draft",
  "date" : "2026-09-17T11:09:43+00:00",
  "contact" : [{
    "name" : "Inera Arkitektur",
    "telecom" : [{
      "system" : "url",
      "value" : "https://www.inera.se"
    }]
  }],
  "description" : "Logisk modell för tjänstekontraktet GetInfoLogsForPatient\n(RIV-TA urn:riv:ehr:log:querying:GetInfoLogsForPatientResponder:1).\nRepresenterar responsens informationsstruktur (log.querying:InfoLogsResult).\nReturnerar lista för angiven informationsägande vårdgivare och patient med\nvilka externa vårdgivare som haft åtkomst till information.",
  "copyright" : "Copyright 2024 Inera AB. Licensieras under Creative Commons Attribution 4.0.",
  "fhirVersion" : "4.0.1",
  "kind" : "logical",
  "abstract" : false,
  "type" : "https://fhir.inera.se/ig/ehr-log/StructureDefinition/getinfologsforpatient",
  "baseDefinition" : "http://hl7.org/fhir/StructureDefinition/Base",
  "derivation" : "specialization",
  "differential" : {
    "element" : [{
      "id" : "getinfologsforpatient",
      "path" : "getinfologsforpatient",
      "short" : "GetInfoLogsForPatient",
      "definition" : "Logisk modell för tjänstekontraktet GetInfoLogsForPatient\n(RIV-TA urn:riv:ehr:log:querying:GetInfoLogsForPatientResponder:1).\nRepresenterar responsens informationsstruktur (log.querying:InfoLogsResult).\nReturnerar lista för angiven informationsägande vårdgivare och patient med\nvilka externa vårdgivare som haft åtkomst till information."
    },
    {
      "id" : "getinfologsforpatient.result",
      "path" : "getinfologsforpatient.result",
      "short" : "Resultatkontainer",
      "definition" : "Resultatkontainer",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "BackboneElement"
      }]
    },
    {
      "id" : "getinfologsforpatient.result.resultCode",
      "path" : "getinfologsforpatient.result.resultCode",
      "short" : "Statuskod",
      "definition" : "Statuskod",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "code"
      }],
      "binding" : {
        "strength" : "required",
        "valueSet" : "https://fhir.inera.se/ig/ehr-log/ValueSet/resultcode-vs"
      }
    },
    {
      "id" : "getinfologsforpatient.result.resultText",
      "path" : "getinfologsforpatient.result.resultText",
      "short" : "Beskrivande text",
      "definition" : "Beskrivande text",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "getinfologsforpatient.result.startInterval",
      "path" : "getinfologsforpatient.result.startInterval",
      "short" : "Start på tillgängligt datumintervall",
      "definition" : "Start på tillgängligt datumintervall",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "dateTime"
      }]
    },
    {
      "id" : "getinfologsforpatient.result.endInterval",
      "path" : "getinfologsforpatient.result.endInterval",
      "short" : "Slut på tillgängligt datumintervall",
      "definition" : "Slut på tillgängligt datumintervall",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "dateTime"
      }]
    },
    {
      "id" : "getinfologsforpatient.result.queuedReportId",
      "path" : "getinfologsforpatient.result.queuedReportId",
      "short" : "Id för pågående rapport (UUID)",
      "definition" : "Id för pågående rapport (UUID)",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "getinfologsforpatient.result.queueTime",
      "path" : "getinfologsforpatient.result.queueTime",
      "short" : "Uppskattad väntetid i sekunder",
      "definition" : "Uppskattad väntetid i sekunder",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "integer"
      }]
    },
    {
      "id" : "getinfologsforpatient.careProviders",
      "path" : "getinfologsforpatient.careProviders",
      "short" : "Samling av externa vårdgivare med åtkomst",
      "definition" : "Samling av externa vårdgivare med åtkomst",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "BackboneElement"
      }]
    },
    {
      "id" : "getinfologsforpatient.careProviders.careProvider",
      "path" : "getinfologsforpatient.careProviders.careProvider",
      "short" : "En extern vårdgivare",
      "definition" : "En extern vårdgivare",
      "min" : 0,
      "max" : "*",
      "type" : [{
        "code" : "BackboneElement"
      }]
    },
    {
      "id" : "getinfologsforpatient.careProviders.careProvider.careProviderId",
      "path" : "getinfologsforpatient.careProviders.careProvider.careProviderId",
      "short" : "HSA-id för den externa vårdgivaren",
      "definition" : "HSA-id för den externa vårdgivaren",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "Identifier"
      }]
    },
    {
      "id" : "getinfologsforpatient.careProviders.careProvider.careProviderName",
      "path" : "getinfologsforpatient.careProviders.careProvider.careProviderName",
      "short" : "Den externa vårdgivarens namn",
      "definition" : "Den externa vårdgivarens namn",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    }]
  }
}

```
