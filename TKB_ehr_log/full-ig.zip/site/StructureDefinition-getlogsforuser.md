# GetLogsForUser - ehr: log v1.2.3

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **GetLogsForUser**

## Logical Model: GetLogsForUser 

| | |
| :--- | :--- |
| *Official URL*:https://fhir.inera.se/ig/ehr-log/StructureDefinition/getlogsforuser | *Version*:1.2.3 |
| Draft as of 2026-09-14 | *Computable Name*:GetLogsForUser |
| **Copyright/Legal**: Copyright 2024 Inera AB. Licensieras under Creative Commons Attribution 4.0. | |

 
Logisk modell för tjänstekontraktet GetLogsForUser (RIV-TA urn:riv:ehr:log:querying:GetLogsForUserResponder:1). Representerar responsens informationsstruktur (log.querying:LogsResult). Returnerar loggposter för angiven vårdgivare och medarbetare. 

**Usages:**

* This Logical Model is not used by any profiles in this Specification

You can also check for [usages in the FHIR IG Statistics](https://packages2.fhir.org/xig/resource/inera.ehr-log|current/StructureDefinition/StructureDefinition-getlogsforuser.json)

### Formal Views of Profile Content

 [Description of Profiles, Differentials, Snapshots and how the different presentations work](http://build.fhir.org/ig/FHIR/ig-guidance/readingIgs.html#structure-definitions). 

 

Other representations of profile: [CSV](StructureDefinition-getlogsforuser.csv), [Excel](StructureDefinition-getlogsforuser.xlsx) 



## Resource Content

```json
{
  "resourceType" : "StructureDefinition",
  "id" : "getlogsforuser",
  "extension" : [{
    "url" : "http://hl7.org/fhir/StructureDefinition/structuredefinition-type-characteristics",
    "valueCode" : "can-be-target"
  }],
  "url" : "https://fhir.inera.se/ig/ehr-log/StructureDefinition/getlogsforuser",
  "version" : "1.2.3",
  "name" : "GetLogsForUser",
  "title" : "GetLogsForUser",
  "status" : "draft",
  "date" : "2026-09-14T12:44:07+00:00",
  "contact" : [{
    "name" : "Inera Arkitektur",
    "telecom" : [{
      "system" : "url",
      "value" : "https://www.inera.se"
    }]
  }],
  "description" : "Logisk modell för tjänstekontraktet GetLogsForUser\n(RIV-TA urn:riv:ehr:log:querying:GetLogsForUserResponder:1).\nRepresenterar responsens informationsstruktur (log.querying:LogsResult).\nReturnerar loggposter för angiven vårdgivare och medarbetare.",
  "copyright" : "Copyright 2024 Inera AB. Licensieras under Creative Commons Attribution 4.0.",
  "fhirVersion" : "4.0.1",
  "kind" : "logical",
  "abstract" : false,
  "type" : "https://fhir.inera.se/ig/ehr-log/StructureDefinition/getlogsforuser",
  "baseDefinition" : "http://hl7.org/fhir/StructureDefinition/Base",
  "derivation" : "specialization",
  "differential" : {
    "element" : [{
      "id" : "getlogsforuser",
      "path" : "getlogsforuser",
      "short" : "GetLogsForUser",
      "definition" : "Logisk modell för tjänstekontraktet GetLogsForUser\n(RIV-TA urn:riv:ehr:log:querying:GetLogsForUserResponder:1).\nRepresenterar responsens informationsstruktur (log.querying:LogsResult).\nReturnerar loggposter för angiven vårdgivare och medarbetare."
    },
    {
      "id" : "getlogsforuser.result",
      "path" : "getlogsforuser.result",
      "short" : "Resultatkontainer",
      "definition" : "Resultatkontainer",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "BackboneElement"
      }]
    },
    {
      "id" : "getlogsforuser.result.resultCode",
      "path" : "getlogsforuser.result.resultCode",
      "short" : "Statuskod",
      "definition" : "Statuskod",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "code"
      }],
      "binding" : {
        "strength" : "required",
        "valueSet" : "https://fhir.inera.se/ig/ehr-log/ValueSet/resultcode-vs"
      }
    },
    {
      "id" : "getlogsforuser.result.resultText",
      "path" : "getlogsforuser.result.resultText",
      "short" : "Beskrivande text",
      "definition" : "Beskrivande text",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "getlogsforuser.result.startInterval",
      "path" : "getlogsforuser.result.startInterval",
      "short" : "Start på tillgängligt datumintervall",
      "definition" : "Start på tillgängligt datumintervall",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "dateTime"
      }]
    },
    {
      "id" : "getlogsforuser.result.endInterval",
      "path" : "getlogsforuser.result.endInterval",
      "short" : "Slut på tillgängligt datumintervall",
      "definition" : "Slut på tillgängligt datumintervall",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "dateTime"
      }]
    },
    {
      "id" : "getlogsforuser.result.queuedReportId",
      "path" : "getlogsforuser.result.queuedReportId",
      "short" : "Id för pågående rapport (UUID)",
      "definition" : "Id för pågående rapport (UUID)",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "getlogsforuser.result.queueTime",
      "path" : "getlogsforuser.result.queueTime",
      "short" : "Uppskattad väntetid i sekunder",
      "definition" : "Uppskattad väntetid i sekunder",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "integer"
      }]
    },
    {
      "id" : "getlogsforuser.logs",
      "path" : "getlogsforuser.logs",
      "short" : "Samling av loggposter",
      "definition" : "Samling av loggposter",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "BackboneElement"
      }]
    },
    {
      "id" : "getlogsforuser.logs.log",
      "path" : "getlogsforuser.logs.log",
      "short" : "En loggpost",
      "definition" : "En loggpost",
      "min" : 0,
      "max" : "*",
      "type" : [{
        "code" : "BackboneElement"
      }]
    },
    {
      "id" : "getlogsforuser.logs.log.logId",
      "path" : "getlogsforuser.logs.log.logId",
      "short" : "Loggpostens UUID-identifierare",
      "definition" : "Loggpostens UUID-identifierare",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "getlogsforuser.logs.log.system",
      "path" : "getlogsforuser.logs.log.system",
      "short" : "Loggande system",
      "definition" : "Loggande system",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "BackboneElement"
      }]
    },
    {
      "id" : "getlogsforuser.logs.log.system.systemId",
      "path" : "getlogsforuser.logs.log.system.systemId",
      "short" : "Systemets HSA-id",
      "definition" : "Systemets HSA-id",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "Identifier"
      }]
    },
    {
      "id" : "getlogsforuser.logs.log.system.systemName",
      "path" : "getlogsforuser.logs.log.system.systemName",
      "short" : "Systemets namn",
      "definition" : "Systemets namn",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "getlogsforuser.logs.log.activity",
      "path" : "getlogsforuser.logs.log.activity",
      "short" : "Aktivitetsinformation",
      "definition" : "Aktivitetsinformation",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "BackboneElement"
      }]
    },
    {
      "id" : "getlogsforuser.logs.log.activity.activityType",
      "path" : "getlogsforuser.logs.log.activity.activityType",
      "short" : "Typ av aktivitet",
      "definition" : "Typ av aktivitet",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "code"
      }],
      "binding" : {
        "strength" : "required",
        "valueSet" : "https://fhir.inera.se/ig/ehr-log/ValueSet/activitytype-vs"
      }
    },
    {
      "id" : "getlogsforuser.logs.log.activity.activityLevel",
      "path" : "getlogsforuser.logs.log.activity.activityLevel",
      "short" : "Aktivitetsnivå",
      "definition" : "Aktivitetsnivå",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "getlogsforuser.logs.log.activity.activityArgs",
      "path" : "getlogsforuser.logs.log.activity.activityArgs",
      "short" : "Övriga aktivitetsparametrar",
      "definition" : "Övriga aktivitetsparametrar",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "getlogsforuser.logs.log.activity.startDate",
      "path" : "getlogsforuser.logs.log.activity.startDate",
      "short" : "Tidpunkt för aktiviteten",
      "definition" : "Tidpunkt för aktiviteten",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "dateTime"
      }]
    },
    {
      "id" : "getlogsforuser.logs.log.activity.purpose",
      "path" : "getlogsforuser.logs.log.activity.purpose",
      "short" : "Syfte med aktiviteten",
      "definition" : "Syfte med aktiviteten",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "getlogsforuser.logs.log.user",
      "path" : "getlogsforuser.logs.log.user",
      "short" : "Medarbetaren som utförde aktiviteten",
      "definition" : "Medarbetaren som utförde aktiviteten",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "BackboneElement"
      }]
    },
    {
      "id" : "getlogsforuser.logs.log.user.userId",
      "path" : "getlogsforuser.logs.log.user.userId",
      "short" : "Medarbetarens HSA-id",
      "definition" : "Medarbetarens HSA-id",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "Identifier"
      }]
    },
    {
      "id" : "getlogsforuser.logs.log.user.employeeName",
      "path" : "getlogsforuser.logs.log.user.employeeName",
      "short" : "Medarbetarens namn",
      "definition" : "Medarbetarens namn",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "getlogsforuser.logs.log.user.personId",
      "path" : "getlogsforuser.logs.log.user.personId",
      "short" : "Medarbetarens personnummer",
      "definition" : "Medarbetarens personnummer",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "Identifier"
      }]
    },
    {
      "id" : "getlogsforuser.logs.log.user.assignment",
      "path" : "getlogsforuser.logs.log.user.assignment",
      "short" : "Uppdragsnamn",
      "definition" : "Uppdragsnamn",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "getlogsforuser.logs.log.user.title",
      "path" : "getlogsforuser.logs.log.user.title",
      "short" : "Yrkestitel",
      "definition" : "Yrkestitel",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "getlogsforuser.logs.log.user.careProvider",
      "path" : "getlogsforuser.logs.log.user.careProvider",
      "short" : "Medarbetarens vårdgivare",
      "definition" : "Medarbetarens vårdgivare",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "BackboneElement"
      }]
    },
    {
      "id" : "getlogsforuser.logs.log.user.careProvider.careProviderId",
      "path" : "getlogsforuser.logs.log.user.careProvider.careProviderId",
      "short" : "Vårdgivarens HSA-id",
      "definition" : "Vårdgivarens HSA-id",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "Identifier"
      }]
    },
    {
      "id" : "getlogsforuser.logs.log.user.careProvider.careProviderName",
      "path" : "getlogsforuser.logs.log.user.careProvider.careProviderName",
      "short" : "Vårdgivarens namn",
      "definition" : "Vårdgivarens namn",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "getlogsforuser.logs.log.user.careUnit",
      "path" : "getlogsforuser.logs.log.user.careUnit",
      "short" : "Medarbetarens vårdenhet",
      "definition" : "Medarbetarens vårdenhet",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "BackboneElement"
      }]
    },
    {
      "id" : "getlogsforuser.logs.log.user.careUnit.careUnitId",
      "path" : "getlogsforuser.logs.log.user.careUnit.careUnitId",
      "short" : "Vårdenhetens HSA-id",
      "definition" : "Vårdenhetens HSA-id",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "Identifier"
      }]
    },
    {
      "id" : "getlogsforuser.logs.log.user.careUnit.careUnitName",
      "path" : "getlogsforuser.logs.log.user.careUnit.careUnitName",
      "short" : "Vårdenhetens namn",
      "definition" : "Vårdenhetens namn",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "getlogsforuser.logs.log.resources",
      "path" : "getlogsforuser.logs.log.resources",
      "short" : "Resurser som aktiviteten avsåg",
      "definition" : "Resurser som aktiviteten avsåg",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "BackboneElement"
      }]
    },
    {
      "id" : "getlogsforuser.logs.log.resources.resource",
      "path" : "getlogsforuser.logs.log.resources.resource",
      "short" : "En resurs",
      "definition" : "En resurs",
      "min" : 1,
      "max" : "*",
      "type" : [{
        "code" : "BackboneElement"
      }]
    },
    {
      "id" : "getlogsforuser.logs.log.resources.resource.resourceType",
      "path" : "getlogsforuser.logs.log.resources.resource.resourceType",
      "short" : "Resurstyp",
      "definition" : "Resurstyp",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "getlogsforuser.logs.log.resources.resource.patient",
      "path" : "getlogsforuser.logs.log.resources.resource.patient",
      "short" : "Patient",
      "definition" : "Patient",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "BackboneElement"
      }]
    },
    {
      "id" : "getlogsforuser.logs.log.resources.resource.patient.patientId",
      "path" : "getlogsforuser.logs.log.resources.resource.patient.patientId",
      "short" : "Patientidentifierare",
      "definition" : "Patientidentifierare",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "Identifier"
      }]
    },
    {
      "id" : "getlogsforuser.logs.log.resources.resource.patient.patientName",
      "path" : "getlogsforuser.logs.log.resources.resource.patient.patientName",
      "short" : "Patientens namn",
      "definition" : "Patientens namn",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "getlogsforuser.logs.log.resources.resource.careProvider",
      "path" : "getlogsforuser.logs.log.resources.resource.careProvider",
      "short" : "Resursens ägande vårdgivare",
      "definition" : "Resursens ägande vårdgivare",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "BackboneElement"
      }]
    },
    {
      "id" : "getlogsforuser.logs.log.resources.resource.careProvider.careProviderId",
      "path" : "getlogsforuser.logs.log.resources.resource.careProvider.careProviderId",
      "short" : "Vårdgivarens HSA-id",
      "definition" : "Vårdgivarens HSA-id",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "Identifier"
      }]
    },
    {
      "id" : "getlogsforuser.logs.log.resources.resource.careProvider.careProviderName",
      "path" : "getlogsforuser.logs.log.resources.resource.careProvider.careProviderName",
      "short" : "Vårdgivarens namn",
      "definition" : "Vårdgivarens namn",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "getlogsforuser.logs.log.resources.resource.careUnit",
      "path" : "getlogsforuser.logs.log.resources.resource.careUnit",
      "short" : "Resursens vårdenhet",
      "definition" : "Resursens vårdenhet",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "BackboneElement"
      }]
    },
    {
      "id" : "getlogsforuser.logs.log.resources.resource.careUnit.careUnitId",
      "path" : "getlogsforuser.logs.log.resources.resource.careUnit.careUnitId",
      "short" : "Vårdenhetens HSA-id",
      "definition" : "Vårdenhetens HSA-id",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "Identifier"
      }]
    },
    {
      "id" : "getlogsforuser.logs.log.resources.resource.careUnit.careUnitName",
      "path" : "getlogsforuser.logs.log.resources.resource.careUnit.careUnitName",
      "short" : "Vårdenhetens namn",
      "definition" : "Vårdenhetens namn",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    }]
  }
}

```
