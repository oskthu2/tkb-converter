# Hem - itintegration: monitoring v1.0.0

* [**Table of Contents**](toc.md)
* **Hem**

## Hem

| | |
| :--- | :--- |
| *Official URL*:https://fhir.inera.se/ig/itintegration-monitoring/ImplementationGuide/inera.itintegration-monitoring | *Version*:1.0.0 |
| Active as of 2026-10-26 | *Computable Name*:ItintegrationMonitoring |
| **Copyright/Legal**: Copyright 2024 Inera AB. Licensieras under Creative Commons Attribution 4.0. | |

# itintegration: monitoring

**TKB-version:** 1.0.0 · **IG-version:** 1.0.0 · **Källa:** Bitbucket-tagg `TD_MONITORING_1_0_0_R` 

## Översikt

* Beskrivning: Svenskt kortnamn
  * OBSERVERA: Kravet på övervakningstjänst baserad på kontraktet pingforconfiguration är borttaget och supporten för kontraktet är avslutad. Lokal användning är tillåten men nationellt stöd och support avvecklas under Q1 2018: tjänsteövervakning
* Beskrivning: Svenskt namn
  * OBSERVERA: Kravet på övervakningstjänst baserad på kontraktet pingforconfiguration är borttaget och supporten för kontraktet är avslutad. Lokal användning är tillåten men nationellt stöd och support avvecklas under Q1 2018: infrastruktur:tjänsteförmedlingstjänster:tjänsteövervakning
* Beskrivning: Typ
  * OBSERVERA: Kravet på övervakningstjänst baserad på kontraktet pingforconfiguration är borttaget och supporten för kontraktet är avslutad. Lokal användning är tillåten men nationellt stöd och support avvecklas under Q1 2018: Nationell tjänstedomän
* Beskrivning: Anmärkning
  * OBSERVERA: Kravet på övervakningstjänst baserad på kontraktet pingforconfiguration är borttaget och supporten för kontraktet är avslutad. Lokal användning är tillåten men nationellt stöd och support avvecklas under Q1 2018: dold på rivta.se
* Beskrivning: Källkod
  * OBSERVERA: Kravet på övervakningstjänst baserad på kontraktet pingforconfiguration är borttaget och supporten för kontraktet är avslutad. Lokal användning är tillåten men nationellt stöd och support avvecklas under Q1 2018: [Bitbucket](https://bitbucket.org/rivta-domains/riv.itintegration.monitoring/src)
* Beskrivning: Ärenden
  * OBSERVERA: Kravet på övervakningstjänst baserad på kontraktet pingforconfiguration är borttaget och supporten för kontraktet är avslutad. Lokal användning är tillåten men nationellt stöd och support avvecklas under Q1 2018: [Bitbucket issues](https://bitbucket.org/rivta-domains/riv.itintegration.monitoring/issues)
* Beskrivning: Underlag för denna IG
  * OBSERVERA: Kravet på övervakningstjänst baserad på kontraktet pingforconfiguration är borttaget och supporten för kontraktet är avslutad. Lokal användning är tillåten men nationellt stöd och support avvecklas under Q1 2018: Version 1.0.0 ·[tagg TD_MONITORING_1_0_0_R](https://bitbucket.org/rivta-domains/riv.itintegration.monitoring/src/TD_MONITORING_1_0_0_R)·[zip](https://bitbucket.org/rivta-domains/riv.itintegration.monitoring/get/TD_MONITORING_1_0_0_R.zip)
* Beskrivning: RIV-TA-portalen
  * OBSERVERA: Kravet på övervakningstjänst baserad på kontraktet pingforconfiguration är borttaget och supporten för kontraktet är avslutad. Lokal användning är tillåten men nationellt stöd och support avvecklas under Q1 2018: [Alla tjänstedomäner](https://oskthu2.github.io/tkb-converter/rivta-portal/tjanstedomaner.html)·[Alla tjänstekontrakt](https://oskthu2.github.io/tkb-converter/rivta-portal/tjanstekontrakt.html)

FHIR Implementation Guide för tjänstedomänen **itintegration: monitoring** version 1.0.0 ("Övervakning av SOA-tjänster"). Genererad från Ineras Tjänstekontraktsbeskrivning (TKB).

Tjänstedomänens omfattning är övervakning av tillgänglighet hos en tjänsteproducent. Ping-kontraktet ska exponeras av varje driftsatt modul som är tjänsteproducent för ett eller flera tjänstekontrakt, så att alla tjänstedomäner kan övervakas och felsökas genom ett enhetligt gränssnitt.

Domänen innehåller följande tjänstekontrakt:

| | | |
| :--- | :--- | :--- |
| [PingForConfiguration](7-tjanstekontrakt.md#pingforconfiguration) | 1.0 | Generisk "ping"-tjänst för övervakning och felsökning av en tjänstekomponents tillgänglighet och konfiguration. |

### Versioner och granskningar

| | | | |
| :--- | :--- | :--- | :--- |
| 1.0.0 |  | Äldre granskningsprocess: Teknik: Godkänd | [zip](http://rivta.se/downloads/itintegration_monitoring/1.0.0/ServiceContracts_itintegration_monitoring-1.0.0.zip)·[källkod](https://bitbucket.org/rivta-domains/riv.itintegration.monitoring/src/TD_MONITORING_1_0_0_R) |
| trunk | TKB |  | [källkod](https://bitbucket.org/rivta-domains/riv.itintegration.monitoring/src/master) |

*Källa: ögonblicksbild av DOMDB från 2021-08-24, via RIV-TA-portalen.*

## Innehåll

* [1 Inledning](1-inledning.md)
* [2 Versionsinformation](2-versionsinformation.md)
* [3 Tjänstedomänens arkitektur](3-tjanstedomanens-arkitektur.md)
* [4 Tjänstedomänens krav och regler](4-tjanstedomanens-krav-och-regler.md)
* [5 Tjänstedomänens meddelandemodeller](5-tjanstedomanens-meddelandemodeller.md)
* [6 Gemensamma informationskomponenter](6-gemensamma-informationskomponenter.md)
* [7 Tjänstekontrakt](7-tjanstekontrakt.md)
* [Artefakter](artifacts.md)

