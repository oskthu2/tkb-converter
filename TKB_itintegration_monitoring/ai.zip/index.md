# Hem - itintegration: monitoring v1

* [**Table of Contents**](toc.md)
* **Hem**

## Hem

| | |
| :--- | :--- |
| *Official URL*:https://fhir.inera.se/ig/itintegration-monitoring/ImplementationGuide/inera.itintegration-monitoring | *Version*:1 |
| Draft as of 2026-09-17 | *Computable Name*:ItintegrationMonitoring |
| **Copyright/Legal**: Copyright 2024 Inera AB. Licensieras under Creative Commons Attribution 4.0. | |

# itintegration: monitoring

## Översikt

FHIR Implementation Guide för tjänstedomänen **itintegration: monitoring** version 1.0 ("Övervakning av SOA-tjänster"). Genererad från Ineras Tjänstekontraktsbeskrivning (TKB).

Tjänstedomänens omfattning är övervakning av tillgänglighet hos en tjänsteproducent. Ping-kontraktet ska exponeras av varje driftsatt modul som är tjänsteproducent för ett eller flera tjänstekontrakt, så att alla tjänstedomäner kan övervakas och felsökas genom ett enhetligt gränssnitt.

Domänen innehåller följande tjänstekontrakt:

| | | |
| :--- | :--- | :--- |
| [PingForConfiguration](7-tjanstekontrakt.md#pingforconfiguration) | 1.0 | Generisk "ping"-tjänst för övervakning och felsökning av en tjänstekomponents tillgänglighet och konfiguration. |

## Innehåll

* [1 Inledning](1-inledning.md)
* [2 Versionsinformation](2-versionsinformation.md)
* [3 Tjänstedomänens arkitektur](3-tjanstedomanens-arkitektur.md)
* [4 Tjänstedomänens krav och regler](4-tjanstedomanens-krav-och-regler.md)
* [5 Tjänstedomänens meddelandemodeller](5-tjanstedomanens-meddelandemodeller.md)
* [6 Gemensamma informationskomponenter](6-gemensamma-informationskomponenter.md)
* [7 Tjänstekontrakt](7-tjanstekontrakt.md)
* [Artefakter](artifacts.md)

