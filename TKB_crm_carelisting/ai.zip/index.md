# Hem - crm: carelisting v1.0.0

* [**Table of Contents**](toc.md)
* **Hem**

## Hem

| | |
| :--- | :--- |
| *Official URL*:https://fhir.inera.se/ig/crm-carelisting/ImplementationGuide/inera.crm-carelisting | *Version*:1.0.0 |
| Active as of 2026-10-08 | *Computable Name*:crmcarelisting |
| **Copyright/Legal**: Copyright 2024 Inera AB. Licensieras under Creative Commons Attribution 4.0. | |

# crm: carelisting

**TKB-version:** 1.0 · **IG-version:** 1.0.0 · **Källa:** Bitbucket-tagg `TD_CARELISTING_1_0_R` 

## Översikt

FHIR Implementation Guide för tjänstedomänen **crm: carelisting** version 1.0. Genererad från Ineras Nationell Listningstjänst informationsspecifikation (RIV-TA).

Domänen hanterar information om lokalt valbara primärvårdstjänster och lokalt gjorda invånarval av primärvårdstjänster. Konsumenter av informationen är exempelvis Mina Vårdkontakter (MVK), Nationell Patientöversikt (NPÖ) samt övriga intressenter.

Domänen innehåller följande tjänstekontrakt:

| | | |
| :--- | :--- | :--- |
| [GetListing](7-tjanstekontrakt.md#getlisting) | 1.0 | Hämtar information om en persons aktiva listning (tjänsteval) |
| [GetAvailableFacilities](7-tjanstekontrakt.md#getavailablefacilities) | 1.0 | Hämtar lista med tillgängliga vårdenheter inom en region |
| [CreateListing](7-tjanstekontrakt.md#createlisting) | 1.0 | Skapar en ny listning (göra tjänsteval) |
| [GetListingTypes](7-tjanstekontrakt.md#getlistingtypes) | 1.0 | Hämtar möjliga listningstyper för en person |
| [GetPersonQueueStatus](7-tjanstekontrakt.md#getpersonqueuestatus) | 1.0 | Hämtar köstatus för en person |

## Innehåll

* [1 Inledning](1-inledning.md)
* [2 Versionsinformation](2-versionsinformation.md)
* [3 Tjänstedomänens arkitektur](3-tjanstedomanens-arkitektur.md)
* [4 Tjänstedomänens krav och regler](4-tjanstedomanens-krav-och-regler.md)
* [5 Tjänstedomänens meddelandemodeller](5-tjanstedomanens-meddelandemodeller.md)
* [6 Gemensamma informationskomponenter](6-gemensamma-informationskomponenter.md)
* [7 Tjänstekontrakt](7-tjanstekontrakt.md)
* [Artefakter](artifacts.md)

