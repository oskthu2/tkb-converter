# inera.crm-carelisting#1.0.0: crm: carelisting

## Pages

* [Hem](index.md)
* [7 Tjänstekontrakt](7-tjanstekontrakt.md)
* [5 Tjänstedomänens meddelandemodeller](5-tjanstedomanens-meddelandemodeller.md)
* [Artifacts Summary](artifacts.md)
* [6 Gemensamma informationskomponenter](6-gemensamma-informationskomponenter.md)
* [3 Tjänstedomänens arkitektur](3-tjanstedomanens-arkitektur.md)
* [4 Tjänstedomänens krav och regler](4-tjanstedomanens-krav-och-regler.md)
* [2 Versionsinformation](2-versionsinformation.md)
* [1 Inledning](1-inledning.md)

## Resources

### CodeSystems

* [PersonQueueStatus](CodeSystem-personqueuestatus-cs.md)

### ValueSets

* [PersonQueueStatus — ValueSet](ValueSet-personqueuestatus-vs.md)

### Logicals

* [CreateListing — Request](StructureDefinition-createlisting-request.md)
* [CreateListing](StructureDefinition-createlisting.md)
* [GetAvailableFacilities — Request](StructureDefinition-getavailablefacilities-request.md)
* [GetAvailableFacilities](StructureDefinition-getavailablefacilities.md)
* [GetListing — Request](StructureDefinition-getlisting-request.md)
* [GetListing](StructureDefinition-getlisting.md)
* [GetListingTypes — Request](StructureDefinition-getlistingtypes-request.md)
* [GetListingTypes](StructureDefinition-getlistingtypes.md)
* [GetPersonQueueStatus — Request](StructureDefinition-getpersonqueuestatus-request.md)
* [GetPersonQueueStatus](StructureDefinition-getpersonqueuestatus.md)

### ImplementationGuides

* [crm: carelisting](index.md)
