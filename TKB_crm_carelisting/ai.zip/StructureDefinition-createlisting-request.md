# CreateListing — Request - crm: carelisting v1.0.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **CreateListing — Request**

## Logical Model: CreateListing — Request 

| | |
| :--- | :--- |
| *Official URL*:https://fhir.inera.se/ig/crm-carelisting/StructureDefinition/createlisting-request | *Version*:1.0.0 |
| Draft as of 2026-09-26 | *Computable Name*:CreateListingRequest |
| **Copyright/Legal**: Copyright 2024 Inera AB. Licensieras under Creative Commons Attribution 4.0. | |

 
Logisk modell för requestparametrar i tjänstekontraktet CreateListing (Göra tjänsteval). (RIV-TA urn:riv:crm:carelisting:CreateListingResponder:1). 

**Usages:**

* This Logical Model is not used by any profiles in this Specification

You can also check for [usages in the FHIR IG Statistics](https://packages2.fhir.org/xig/resource/inera.crm-carelisting|current/StructureDefinition/StructureDefinition-createlisting-request.json)

### Formal Views of Profile Content

 [Description of Profiles, Differentials, Snapshots and how the different presentations work](http://build.fhir.org/ig/FHIR/ig-guidance/readingIgs.html#structure-definitions). 

 

Other representations of profile: [CSV](StructureDefinition-createlisting-request.csv), [Excel](StructureDefinition-createlisting-request.xlsx) 



## Resource Content

```json
{
  "resourceType" : "StructureDefinition",
  "id" : "createlisting-request",
  "extension" : [{
    "url" : "http://hl7.org/fhir/StructureDefinition/structuredefinition-type-characteristics",
    "valueCode" : "can-be-target"
  }],
  "url" : "https://fhir.inera.se/ig/crm-carelisting/StructureDefinition/createlisting-request",
  "version" : "1.0.0",
  "name" : "CreateListingRequest",
  "title" : "CreateListing — Request",
  "status" : "draft",
  "date" : "2026-09-26T19:20:23+00:00",
  "contact" : [{
    "name" : "Inera Arkitektur",
    "telecom" : [{
      "system" : "url",
      "value" : "https://www.inera.se"
    }]
  }],
  "description" : "Logisk modell för requestparametrar i tjänstekontraktet CreateListing (Göra tjänsteval).\n(RIV-TA urn:riv:crm:carelisting:CreateListingResponder:1).",
  "copyright" : "Copyright 2024 Inera AB. Licensieras under Creative Commons Attribution 4.0.",
  "fhirVersion" : "4.0.1",
  "kind" : "logical",
  "abstract" : false,
  "type" : "https://fhir.inera.se/ig/crm-carelisting/StructureDefinition/createlisting-request",
  "baseDefinition" : "http://hl7.org/fhir/StructureDefinition/Base",
  "derivation" : "specialization",
  "differential" : {
    "element" : [{
      "id" : "createlisting-request",
      "path" : "createlisting-request",
      "short" : "CreateListing — Request",
      "definition" : "Logisk modell för requestparametrar i tjänstekontraktet CreateListing (Göra tjänsteval).\n(RIV-TA urn:riv:crm:carelisting:CreateListingResponder:1)."
    },
    {
      "id" : "createlisting-request.personId",
      "path" : "createlisting-request.personId",
      "short" : "Personnummer för den person som önskar göra ett tjänsteval",
      "definition" : "Identitetsbeteckning för vård- och omsorgstagaren.\nPattern: (([1-9]\\d{7})|(\\d{6}))[\\-]?\\d{4}\nKardinalitet: Obligatorisk.",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "createlisting-request.listingType",
      "path" : "createlisting-request.listingType",
      "short" : "Typ av listning som önskas",
      "definition" : "Typ av listning som man önskar göra, t.ex. BVC.\nKardinalitet: Obligatorisk.",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "createlisting-request.healthcareFacility",
      "path" : "createlisting-request.healthcareFacility",
      "short" : "HSA-ID för den vårdenhet personen önskar lista sig på",
      "definition" : "HSA-ID för den vårdenhet som personen önskar lista sig på.\nSystem: urn:oid:1.2.752.129.2.1.4.1 (HSA-id).\nKardinalitet: Obligatorisk.",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "Identifier"
      }]
    },
    {
      "id" : "createlisting-request.healthcareProfessional",
      "path" : "createlisting-request.healthcareProfessional",
      "short" : "HSA-ID för specifik resurs att lista sig på",
      "definition" : "HSA-ID för specifik resurs (läkare/husläkarteam) att lista sig på.\nSystem: urn:oid:1.2.752.129.2.1.4.1 (HSA-id).\nKardinalitet: Valfri.",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "Identifier"
      }]
    },
    {
      "id" : "createlisting-request.addToQueue",
      "path" : "createlisting-request.addToQueue",
      "short" : "Om personen vill ställa sig i kö",
      "definition" : "Anger om personen vill ställa sig i kö om det är kö på vårdenheten/resursen.\nKardinalitet: Obligatorisk.",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "boolean"
      }]
    }]
  }
}

```
