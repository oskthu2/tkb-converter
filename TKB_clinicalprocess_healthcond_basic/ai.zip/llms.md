# inera.clinicalprocess-healthcond-basic#1.2.3: clinicalprocess: healthcond: basic

## Pages

* [Hem](index.md)
* [7 Tjänstekontrakt](7-tjanstekontrakt.md)
* [5 Tjänstedomänens meddelandemodeller](5-tjanstedomanens-meddelandemodeller.md)
* [Artifacts Summary](artifacts.md)
* [3 Tjänstedomänens arkitektur](3-tjanstedomanens-arkitektur.md)
* [4 Tjänstedomänens krav och regler](4-tjanstedomanens-krav-och-regler.md)
* [2 Versionsinformation](2-versionsinformation.md)
* [1 Inledning](1-inledning.md)

## Resources

### CodeSystems

* [AddressPartTypeEnum](CodeSystem-addressparttype-cs.md)
* [PostalAddressUseEnum](CodeSystem-postaladdressuse-cs.md)
* [TelTypeEnum](CodeSystem-teltype-cs.md)
* [TimeStampTypeFormatEnum](CodeSystem-timestamptypeformat-cs.md)

### ValueSets

* [AddressPartTypeEnum — ValueSet](ValueSet-addressparttype-vs.md)
* [PostalAddressUseEnum — ValueSet](ValueSet-postaladdressuse-vs.md)
* [TelTypeEnum — ValueSet](ValueSet-teltype-vs.md)
* [TimeStampTypeFormatEnum — ValueSet](ValueSet-timestamptypeformat-vs.md)

### Logicals

* [GetObservations — Request](StructureDefinition-getobservations-request.md)
* [GetObservations](StructureDefinition-getobservations.md)

### ImplementationGuides

* [clinicalprocess: healthcond: basic](index.md)
