# inera.clinicalprocess-healthcond-basic#2.0.0: clinicalprocess: healthcond: basic

## Pages

* [Hem](index.md)
* [7 Tjänstekontrakt](7-tjanstekontrakt.md)
* [1 Inledning](1-inledning.md)
* [4 Tjänstedomänens krav och regler](4-tjanstedomanens-krav-och-regler.md)
* [3 Tjänstedomänens arkitektur](3-tjanstedomanens-arkitektur.md)
* [Artifacts Summary](artifacts.md)
* [2 Versionsinformation](2-versionsinformation.md)
* [5 Tjänstedomänens meddelandemodeller](5-tjanstedomanens-meddelandemodeller.md)

## Resources

### Logicals

* [GetObservations — Request](StructureDefinition-getobservations-request.md)
* [GetObservations](StructureDefinition-getobservations.md)

### ImplementationGuides

* [clinicalprocess: healthcond: basic](index.md)
