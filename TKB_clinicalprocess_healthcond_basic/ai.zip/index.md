# Hem - clinicalprocess: healthcond: basic v2.0.0

* [**Table of Contents**](toc.md)
* **Hem**

## Hem

| | |
| :--- | :--- |
| *Official URL*:https://fhir.inera.se/ig/clinicalprocess-healthcond-basic/ImplementationGuide/inera.clinicalprocess-healthcond-basic | *Version*:2.0.0 |
| Draft as of 2026-09-09 | *Computable Name*:clinicalprocesshealthcondbasic |
| **Copyright/Legal**: Copyright 2024 Inera AB. Licensieras under Creative Commons Attribution 4.0. | |

# clinicalprocess: healthcond: basic

## Översikt

FHIR Implementation Guide för tjänstedomänen **clinicalprocess: healthcond: basic** version 2.0. Genererad från Ineras Tjänstekontraktsbeskrivning (TKB).

Domänen innehåller följande tjänstekontrakt:

| | | |
| :--- | :--- | :--- |
| [GetObservations](7-tjanstekontrakt.md#getobservations) | 2.0 | Hämtar strukturerade observationer rörande en patient. Kontraktet är abstrakt — godtyckliga observationstyper kan hämtas. |

## Innehåll

* [1 Inledning](1-inledning.md)
* [2 Versionsinformation](2-versionsinformation.md)
* [3 Tjänstedomänens arkitektur](3-tjanstedomanens-arkitektur.md)
* [4 Tjänstedomänens krav och regler](4-tjanstedomanens-krav-och-regler.md)
* [5 Tjänstedomänens meddelandemodeller](5-tjanstedomanens-meddelandemodeller.md)
* [7 Tjänstekontrakt](7-tjanstekontrakt.md)
* [Artefakter](artifacts.md)

