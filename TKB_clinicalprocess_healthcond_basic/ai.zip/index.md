# Hem - clinicalprocess: healthcond: basic v1.2.3

* [**Table of Contents**](toc.md)
* **Hem**

## Hem

| | |
| :--- | :--- |
| *Official URL*:https://fhir.inera.se/ig/clinicalprocess-healthcond-basic/ImplementationGuide/inera.clinicalprocess-healthcond-basic | *Version*:1.2.3 |
| Active as of 2026-11-06 | *Computable Name*:clinicalprocesshealthcondbasic |
| **Copyright/Legal**: Copyright 2024 Inera AB. Licensieras under Creative Commons Attribution 4.0. | |

# clinicalprocess: healthcond: basic

**TKB-version:** 1.2.3 · **IG-version:** 1.2.3 · **Källa:** Bitbucket-tagg `1.2.3` 

## Översikt

* Beskrivning: Svenskt kortnamn
  * Denna domän hanterar information gällande observationer och mätvärden.: basuppgifter tillstånd
* Beskrivning: Svenskt namn
  * Denna domän hanterar information gällande observationer och mätvärden.: Vård- och omsorg kärnprocess:hantera hälsorelaterade tillstånd:basuppgifter
* Beskrivning: Typ
  * Denna domän hanterar information gällande observationer och mätvärden.: Nationell tjänstedomän
* Beskrivning: Förvaltare
  * Denna domän hanterar information gällande observationer och mätvärden.: Tjänstekontraktsförvaltningen, TK-forvaltningen@inera.se
* Beskrivning: Källkod
  * Denna domän hanterar information gällande observationer och mätvärden.: [Bitbucket](https://bitbucket.org/rivta-domains/riv.clinicalprocess.healthcond.basic/src)
* Beskrivning: Ärenden
  * Denna domän hanterar information gällande observationer och mätvärden.: [Bitbucket issues](https://bitbucket.org/rivta-domains/riv.clinicalprocess.healthcond.basic/issues)
* Beskrivning: Informationssida
  * Denna domän hanterar information gällande observationer och mätvärden.: [Confluence](https://inera.atlassian.net/wiki/spaces/OITOF/pages/81396444/clinicalprocess+healthcond+basic+basuppgifter+tillst+nd)
* Beskrivning: Underlag för denna IG
  * Denna domän hanterar information gällande observationer och mätvärden.: Version 1.2.3 ·[tagg 1.2.3](https://bitbucket.org/rivta-domains/riv.clinicalprocess.healthcond.basic/src/1.2.3)·[zip](https://bitbucket.org/rivta-domains/riv.clinicalprocess.healthcond.basic/get/1.2.3.zip)
* Beskrivning: RIV-TA-portalen
  * Denna domän hanterar information gällande observationer och mätvärden.: [Alla tjänstedomäner](https://oskthu2.github.io/tkb-converter/rivta-portal/tjanstedomaner.html)·[Alla tjänstekontrakt](https://oskthu2.github.io/tkb-converter/rivta-portal/tjanstekontrakt.html)

FHIR Implementation Guide för tjänstedomänen **clinicalprocess: healthcond: basic** (Vård- och omsorg kärnprocess: hantera hälsorelaterade tillstånd: basuppgifter), version 1.2.3. Genererad från Ineras Tjänstekontraktsbeskrivning (TKB) och schemafilerna i Bitbucket-taggen `1.2.3` (commit `55a953227545`, 2026-05-12). TKB-dokumentet i taggen har dokumentversion 1.2.1 (2025-07-07).

Domänen hanterar information om observationer och mätvärden. Syftet är att tillgängliggöra journalförd, strukturerad och kodad information om observationer från vårdverksamheter för återanvändning, till exempel i kvalitetsregister, uppföljningssystem, system för den enskildes direktåtkomst och sammanhållen journalföring.

Domänen innehåller följande tjänstekontrakt:

| | | |
| :--- | :--- | :--- |
| [GetObservations](7-tjanstekontrakt.md#getobservations) | 1.2 | Returnerar strukturerade observationer för en patient. Den praktiska tillämpningen beskrivs i interaktionsöverenskommelser. |

### Versioner och granskningar

| | | | |
| :--- | :--- | :--- | :--- |
| 1.0.10 | AB, TKB | Arkitektur & Regelverk: Säkerhet: GodkändArkitektur & Regelverk: Teknik: GodkändArkitektur & Regelverk: Informatik: Godkänd | [zip](https://bitbucket.org/rivta-domains/riv.clinicalprocess.healthcond.basic/get/1.0.10.zip)·[källkod](https://bitbucket.org/rivta-domains/riv.clinicalprocess.healthcond.basic/src/1.0.10) |
| trunk | TKB, IS, AB |  | [källkod](https://bitbucket.org/rivta-domains/riv.clinicalprocess.healthcond.basic/src/master) |

*Zip-arkiven hämtas från taggarna på Bitbucket. Granskningsprotokollen publicerades på rivta.se och länkas inte härifrån.*

*Källa: ögonblicksbild av DOMDB från 2021-08-24, via RIV-TA-portalen.*

## Innehåll

* [1 Inledning](1-inledning.md)
* [2 Versionsinformation](2-versionsinformation.md)
* [3 Tjänstedomänens arkitektur](3-tjanstedomanens-arkitektur.md)
* [4 Tjänstedomänens krav och regler](4-tjanstedomanens-krav-och-regler.md)
* [5 Tjänstedomänens meddelandemodeller](5-tjanstedomanens-meddelandemodeller.md)
* [7 Tjänstekontrakt](7-tjanstekontrakt.md)
* [Artefakter](artifacts.md)

TKB-dokumentet saknar ett kapitel för gemensamma informationskomponenter; tjänstekontraktet är kapitel 6 i dokumentet och kapitel 7 i denna IG.

