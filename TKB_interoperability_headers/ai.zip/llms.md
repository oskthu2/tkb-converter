# inera.interoperability-headers#1.1: interoperability: headers — Gemensamma huvudelement

## Pages

* [Hem](index.md)
* [7 Tjänstekontrakt](7-tjanstekontrakt.md)
* [Artifacts Summary](artifacts.md)
* [6 Gemensamma informationskomponenter](6-gemensamma-informationskomponenter.md)
* [2 Versionsinformation](2-versionsinformation.md)
* [1 Inledning](1-inledning.md)

## Resources

### CodeSystems

* [ActorType](CodeSystem-actortype-cs.md)
* [CausingAgent](CodeSystem-causingagent-cs.md)
* [ProcessingStatusCode](CodeSystem-processingstatuscode-cs.md)

### ValueSets

* [ActorType — ValueSet](ValueSet-actortype-vs.md)
* [CausingAgent — ValueSet](ValueSet-causingagent-vs.md)
* [ProcessingStatusCode — ValueSet](ValueSet-processingstatuscode-vs.md)

### Logicals

* [Actor](StructureDefinition-actor.md)
* [ProcessingStatus](StructureDefinition-processingstatus.md)

### ImplementationGuides

* [interoperability: headers — Gemensamma huvudelement](index.md)
