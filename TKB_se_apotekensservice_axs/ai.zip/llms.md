# inera.se-apotekensservice-axs#7.0.0: se.apotekensservice: axs — Hämta patientinformation

## Pages

* [Hem](index.md)
* [7 Tjänstekontrakt](7-tjanstekontrakt.md)
* [5 Tjänstedomänens meddelandemodeller](5-tjanstedomanens-meddelandemodeller.md)
* [Artifacts Summary](artifacts.md)
* [6 Gemensamma informationskomponenter](6-gemensamma-informationskomponenter.md)
* [3 Tjänstedomänens arkitektur](3-tjanstedomanens-arkitektur.md)
* [4 Tjänstedomänens krav och regler](4-tjanstedomanens-krav-och-regler.md)
* [2 Versionsinformation](2-versionsinformation.md)
* [1 Inledning](1-inledning.md)

## Resources

### CodeSystems

* [Dosunderlagets status](CodeSystem-axs-dosunderlagstatus-cs.md)
* [Statuskod för person i FOLK](CodeSystem-axs-folkstatuskod-cs.md)

### ValueSets

* [Dosunderlagets status](ValueSet-axs-dosunderlagstatus-vs.md)
* [Statuskod för person i FOLK](ValueSet-axs-folkstatuskod-vs.md)

### Logicals

* [HamtaPatientInfo — Request](StructureDefinition-hamtapatientinfo-request.md)
* [HamtaPatientInfo — Response](StructureDefinition-hamtapatientinfo.md)

### ImplementationGuides

* [se.apotekensservice: axs — Hämta patientinformation](index.md)
