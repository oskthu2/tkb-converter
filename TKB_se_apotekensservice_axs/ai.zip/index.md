# Hem - se.apotekensservice: axs — Hämta patientinformation v7.0.0

* [**Table of Contents**](toc.md)
* **Hem**

## Hem

| | |
| :--- | :--- |
| *Official URL*:https://fhir.inera.se/ig/se-apotekensservice-axs/ImplementationGuide/inera.se-apotekensservice-axs | *Version*:7.0.0 |
| Active as of 2026-10-12 | *Computable Name*:seapotekensserviceaxs |
| **Copyright/Legal**: Copyright 2024 Inera AB. Licensieras under Creative Commons Attribution 4.0. | |

# se.apotekensservice: axs — Hämta patientinformation

**TKB-version:** 7.0 · **IG-version:** 7.0.0 · **Källa:** Bitbucket-tagg `7.0` 

## Översikt

* Typ: Förvaltare
  * Extern tjänstedomän: E-hälsomyndigheten
* Typ: Källkod
  * Extern tjänstedomän: [Bitbucket](https://bitbucket.org/rivta-domains/riv.se.apotekensservice.axs/src)
* Typ: Ärenden
  * Extern tjänstedomän: [Bitbucket issues](https://bitbucket.org/rivta-domains/riv.se.apotekensservice.axs/issues)
* Typ: Underlag för denna IG
  * Extern tjänstedomän: Version 7.0 ·[tagg 7.0](https://bitbucket.org/rivta-domains/riv.se.apotekensservice.axs/src/7.0)·[zip](https://bitbucket.org/rivta-domains/riv.se.apotekensservice.axs/get/7.0.zip)
* Typ: RIV-TA-portalen
  * Extern tjänstedomän: [Alla tjänstedomäner](https://oskthu2.github.io/tkb-converter/rivta-portal/tjanstedomaner.html)·[Alla tjänstekontrakt](https://oskthu2.github.io/tkb-converter/rivta-portal/tjanstekontrakt.html)

FHIR Implementation Guide för tjänstedomänen **se.apotekensservice: axs** version 7.0. Domänen förvaltas av eHälsomyndigheten (tidigare Apotekens Service AB) och tjänsteväxlas i NTjP.

**Observera:** källan innehåller ingen tjänstekontraktsbeskrivning (TKB). Denna IG är därför uppbyggd från domänens scheman (XSD/WSDL) och dess dokument med arkitekturella beslut. Avsnitt som i andra IG:er hämtas ur TKB:n är markerade med **SAKNAS I KÄLLDOKUMENT**. Beskrivningar av fält och koder är hämtade ur schemaannoteringarna.

RIV-TA namnrymd: `urn:riv:se.apotekensservice:axs`

Domänen innehåller följande tjänstekontrakt:

| | | |
| :--- | :--- | :--- |
| [HamtaPatientInfo](7-tjanstekontrakt.md#hamtapatientinfo) | 6.0 | Hämtar patientinformation: eventuellt dosapotek, dosproducent, dosunderlagets status, om det finns aktuella recept samt folkbokförings- och samtyckesinformation |

**Källa:** Bitbucket `rivta-domains/riv.se.apotekensservice.axs`, tagg `7.0` (commit `a8817d521c66`, 2019-12-05).

### Versioner och granskningar

| | | | |
| :--- | :--- | :--- | :--- |
| 6.0 | AB |  | [zip](http://rivta.se/downloads//se_apotekensservice_axs/6.0/ServiceContracts_se_apotekensservice_axs_6.0.zip)·[källkod](https://bitbucket.org/rivta-domains/riv.se.apotekensservice.axs/src/6.0) |
| 5.0 |  |  | [zip](http://rivta.se/downloads//se_apotekensservice_axs/5.0/ServiceContracts_se.apotekensservice_axs_5.0.zip)·[källkod](https://bitbucket.org/rivta-domains/riv.se.apotekensservice.axs/src/5.0) |
| 4.0_RC1 |  |  | [zip](http://rivta.se/downloads/se_apotekensservice_axs/4.0_RC1/ServiceContracts_se_apotekensservice_axs_4.0_RC1.zip)·[källkod](https://bitbucket.org/rivta-domains/riv.se.apotekensservice.axs/src/TD_SE_APOTEKENSSERVICE_AXS_4_0_RC1) |
| trunk |  |  | [källkod](https://bitbucket.org/rivta-domains/riv.se.apotekensservice.axs/src/master) |

*Källa: ögonblicksbild av DOMDB från 2021-08-24, via RIV-TA-portalen.*

## Innehåll

* [1 Inledning](1-inledning.md)
* [2 Versionsinformation](2-versionsinformation.md)
* [3 Tjänstedomänens arkitektur](3-tjanstedomanens-arkitektur.md)
* [4 Tjänstedomänens krav och regler](4-tjanstedomanens-krav-och-regler.md)
* [5 Tjänstedomänens meddelandemodeller](5-tjanstedomanens-meddelandemodeller.md)
* [6 Gemensamma informationskomponenter](6-gemensamma-informationskomponenter.md)
* [7 Tjänstekontrakt](7-tjanstekontrakt.md)
* [Artefakter](artifacts.md)

