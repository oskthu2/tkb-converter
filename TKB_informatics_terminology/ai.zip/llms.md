# inera.informatics-terminology#1.0.1: informatics: terminology

## Pages

* [Hem](index.md)
* [2 Generella regler](2-generella-regler.md)
* [1 Inledning](1-inledning.md)
* [Artifacts Summary](artifacts.md)
* [5 Tillgängliga urval](5-tillgangliga-urval.md)
* [3 SLA-krav/support](3-sla-krav-support.md)
* [4 Tjänstekontrakt](4-tjanstekontrakt.md)

## Resources

### Logicals

* [GetTerminologySubset — Request](StructureDefinition-getterminologysubset-request.md)
* [GetTerminologySubset](StructureDefinition-getterminologysubset.md)

### ImplementationGuides

* [informatics: terminology](index.md)
