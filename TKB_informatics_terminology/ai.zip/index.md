# Hem - informatics: terminology v1.0.1

* [**Table of Contents**](toc.md)
* **Hem**

## Hem

| | |
| :--- | :--- |
| *Official URL*:https://fhir.inera.se/ig/informatics-terminology/ImplementationGuide/inera.informatics-terminology | *Version*:1.0.1 |
| Active as of 2026-10-26 | *Computable Name*:informaticsterminology |
| **Copyright/Legal**: Copyright 2024 Inera AB. Licensieras under Creative Commons Attribution 4.0. | |

# informatics: terminology

**TKB-version:** 1.0.1 · **IG-version:** 1.0.1 · **Källa:** Bitbucket-tagg `1.0.1` 

## Översikt

* Svenskt kortnamn: Svenskt namn
  * terminologi: infrastruktur:informations-strukturtjänster:terminologi
* Svenskt kortnamn: Typ
  * terminologi: Applikationsspecifik tjänstedomän
* Svenskt kortnamn: Källkod
  * terminologi: [Bitbucket](https://bitbucket.org/rivta-domains/riv.informatics.terminology/src)
* Svenskt kortnamn: Ärenden
  * terminologi: [Bitbucket issues](https://bitbucket.org/rivta-domains/riv.informatics.terminology/issues)
* Svenskt kortnamn: Underlag för denna IG
  * terminologi: Version 1.0.1 ·[tagg 1.0.1](https://bitbucket.org/rivta-domains/riv.informatics.terminology/src/1.0.1)
* Svenskt kortnamn: RIV-TA-portalen
  * terminologi: [Alla tjänstedomäner](https://oskthu2.github.io/tkb-converter/rivta-portal/tjanstedomaner.html)·[Alla tjänstekontrakt](https://oskthu2.github.io/tkb-converter/rivta-portal/tjanstekontrakt.html)

FHIR Implementation Guide för tjänstedomänen **informatics: terminology** version 1.0.1. Genererad från Ineras Tjänstekontraktsbeskrivning (TKB) för Terminologitjänsten.

Tjänsten är en generisk terminologiurvalstjänst som tillhandahåller delmängder (subset) av terminologier (exempelvis SNOMED CT, ICD-10, ATC-kodverket) för användning i vårdinformationssystem. Den stöder bl.a. det dynamiska urvalet av orsaker till antibiotikainsättning som rapporteras till Infektionsregistret.

Domänen innehåller följande tjänstekontrakt:

| | | |
| :--- | :--- | :--- |
| [GetTerminologySubset](4-tjanstekontrakt.md#getterminologysubset) | 1.0 | Hämtar en delmängd (subset) av en terminologi |

### Versioner och granskningar

| | | | |
| :--- | :--- | :--- | :--- |
| 1.0.1 |  | Äldre granskningsprocess: Teknik: Godkänd | [zip](http://rivta.se/downloads//informatics_terminology/1.0.1/ServiceContracts_informatics_terminology_1.0.1.zip)·[källkod](https://bitbucket.org/rivta-domains/riv.informatics.terminology/src/1.0.1) |
| trunk |  |  | [källkod](https://bitbucket.org/rivta-domains/riv.informatics.terminology/src/master) |

*Källa: ögonblicksbild av DOMDB från 2021-08-24, via RIV-TA-portalen.*

## Innehåll

* [1 Inledning](1-inledning.md)
* [2 Generella regler](2-generella-regler.md)
* [3 SLA-krav/support](3-sla-krav-support.md)
* [4 Tjänstekontrakt](4-tjanstekontrakt.md)
* [5 Tillgängliga urval](5-tillgangliga-urval.md)
* [Artefakter](artifacts.md)

