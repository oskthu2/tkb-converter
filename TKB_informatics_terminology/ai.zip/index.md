# Hem - informatics: terminology v1.4

* [**Table of Contents**](toc.md)
* **Hem**

## Hem

| | |
| :--- | :--- |
| *Official URL*:https://fhir.inera.se/ig/informatics-terminology/ImplementationGuide/inera.informatics-terminology | *Version*:1.4 |
| Draft as of 2026-09-17 | *Computable Name*:informaticsterminology |
| **Copyright/Legal**: Copyright 2024 Inera AB. Licensieras under Creative Commons Attribution 4.0. | |

# informatics: terminology

## Översikt

FHIR Implementation Guide för tjänstedomänen **informatics: terminology** version 1.4. Genererad från Ineras Tjänstekontraktsbeskrivning (TKB) för Terminologitjänsten.

Tjänsten är en generisk terminologiurvalstjänst som tillhandahåller delmängder (subset) av terminologier (exempelvis SNOMED CT, ICD-10, ATC-kodverket) för användning i vårdinformationssystem. Den stöder bl.a. det dynamiska urvalet av orsaker till antibiotikainsättning som rapporteras till Infektionsregistret.

Domänen innehåller följande tjänstekontrakt:

| | | |
| :--- | :--- | :--- |
| [GetTerminologySubset](4-tjanstekontrakt.md#getterminologysubset) | 1.0 | Hämtar en delmängd (subset) av en terminologi |

## Innehåll

* [1 Inledning](1-inledning.md)
* [2 Generella regler](2-generella-regler.md)
* [3 SLA-krav/support](3-sla-krav-support.md)
* [4 Tjänstekontrakt](4-tjanstekontrakt.md)
* [5 Tillgängliga urval](5-tillgangliga-urval.md)
* [Artefakter](artifacts.md)

