# GetCredentialsForPerson - infrastructure: directory: authorizationmanagement v2.4.4

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **GetCredentialsForPerson**

## Logical Model: GetCredentialsForPerson 

| | |
| :--- | :--- |
| *Official URL*:https://fhir.inera.se/ig/infrastructure-directory-authorizationmanagement/StructureDefinition/getcredentialsforperson | *Version*:2.4.4 |
| Draft as of 2026-09-14 | *Computable Name*:GetCredentialsForPerson |
| **Copyright/Legal**: Copyright 2024 Inera AB. Licensieras under Creative Commons Attribution 4.0. | |

 
Logisk modell för tjänstekontraktet GetCredentialsForPerson (RIV-TA urn:riv:infrastructure:directory:authorizationmanagement:GetCredentialsForPerson:2). Identisk med GetCredentialsForPersonIncludingProtectedPerson förutom att information om skyddade personer aldrig returneras (fältet protectedPerson returneras aldrig). 

**Usages:**

* This Logical Model is not used by any profiles in this Specification

You can also check for [usages in the FHIR IG Statistics](https://packages2.fhir.org/xig/resource/inera.infrastructure-directory-authorizationmanagement|current/StructureDefinition/StructureDefinition-getcredentialsforperson.json)

### Formal Views of Profile Content

 [Description of Profiles, Differentials, Snapshots and how the different presentations work](http://build.fhir.org/ig/FHIR/ig-guidance/readingIgs.html#structure-definitions). 

 

Other representations of profile: [CSV](StructureDefinition-getcredentialsforperson.csv), [Excel](StructureDefinition-getcredentialsforperson.xlsx) 



## Resource Content

```json
{
  "resourceType" : "StructureDefinition",
  "id" : "getcredentialsforperson",
  "extension" : [{
    "url" : "http://hl7.org/fhir/StructureDefinition/structuredefinition-type-characteristics",
    "valueCode" : "can-be-target"
  }],
  "url" : "https://fhir.inera.se/ig/infrastructure-directory-authorizationmanagement/StructureDefinition/getcredentialsforperson",
  "version" : "2.4.4",
  "name" : "GetCredentialsForPerson",
  "title" : "GetCredentialsForPerson",
  "status" : "draft",
  "date" : "2026-09-14T12:48:16+00:00",
  "contact" : [{
    "name" : "Inera Arkitektur",
    "telecom" : [{
      "system" : "url",
      "value" : "https://www.inera.se"
    }]
  }],
  "description" : "Logisk modell för tjänstekontraktet GetCredentialsForPerson\n(RIV-TA urn:riv:infrastructure:directory:authorizationmanagement:GetCredentialsForPerson:2).\nIdentisk med GetCredentialsForPersonIncludingProtectedPerson förutom att information om\nskyddade personer aldrig returneras (fältet protectedPerson returneras aldrig).",
  "copyright" : "Copyright 2024 Inera AB. Licensieras under Creative Commons Attribution 4.0.",
  "fhirVersion" : "4.0.1",
  "kind" : "logical",
  "abstract" : false,
  "type" : "https://fhir.inera.se/ig/infrastructure-directory-authorizationmanagement/StructureDefinition/getcredentialsforperson",
  "baseDefinition" : "http://hl7.org/fhir/StructureDefinition/Base",
  "derivation" : "specialization",
  "differential" : {
    "element" : [{
      "id" : "getcredentialsforperson",
      "path" : "getcredentialsforperson",
      "short" : "GetCredentialsForPerson",
      "definition" : "Logisk modell för tjänstekontraktet GetCredentialsForPerson\n(RIV-TA urn:riv:infrastructure:directory:authorizationmanagement:GetCredentialsForPerson:2).\nIdentisk med GetCredentialsForPersonIncludingProtectedPerson förutom att information om\nskyddade personer aldrig returneras (fältet protectedPerson returneras aldrig)."
    },
    {
      "id" : "getcredentialsforperson.credentialInformation",
      "path" : "getcredentialsforperson.credentialInformation",
      "short" : "Behörighetsegenskaper för sökt person",
      "definition" : "Behörighetsegenskaper för sökt person",
      "min" : 0,
      "max" : "*",
      "type" : [{
        "code" : "BackboneElement"
      }]
    },
    {
      "id" : "getcredentialsforperson.credentialInformation.givenName",
      "path" : "getcredentialsforperson.credentialInformation.givenName",
      "short" : "Tilltalsnamn",
      "definition" : "Tilltalsnamn",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "getcredentialsforperson.credentialInformation.middleAndSurName",
      "path" : "getcredentialsforperson.credentialInformation.middleAndSurName",
      "short" : "Personens mellannamn och efternamn",
      "definition" : "Personens mellannamn och efternamn",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "getcredentialsforperson.credentialInformation.personHsaId",
      "path" : "getcredentialsforperson.credentialInformation.personHsaId",
      "short" : "Personens HSA-id",
      "definition" : "Personens HSA-id",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "getcredentialsforperson.credentialInformation.healthCareProfessionalLicence",
      "path" : "getcredentialsforperson.credentialInformation.healthCareProfessionalLicence",
      "short" : "Legitimerad yrkestitel i klartext",
      "definition" : "Legitimerad yrkestitel i klartext",
      "min" : 0,
      "max" : "*",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "getcredentialsforperson.credentialInformation.healthCareProfessionalLicenceCode",
      "path" : "getcredentialsforperson.credentialInformation.healthCareProfessionalLicenceCode",
      "short" : "Kod för legitimerad yrkestitel",
      "definition" : "Kod för legitimerad yrkestitel",
      "min" : 0,
      "max" : "*",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "getcredentialsforperson.credentialInformation.healthCareProfessionalLicenceSpeciality",
      "path" : "getcredentialsforperson.credentialInformation.healthCareProfessionalLicenceSpeciality",
      "short" : "Specialistkoder kopplat till legitimerad yrkesgrupp",
      "definition" : "Specialistkoder kopplat till legitimerad yrkesgrupp",
      "min" : 0,
      "max" : "*",
      "type" : [{
        "code" : "BackboneElement"
      }]
    },
    {
      "id" : "getcredentialsforperson.credentialInformation.healthCareProfessionalLicenceSpeciality.healthCareProfessionalLicenceCode",
      "path" : "getcredentialsforperson.credentialInformation.healthCareProfessionalLicenceSpeciality.healthCareProfessionalLicenceCode",
      "short" : "Kod för legitimerad yrkestitel specialistkoden hör till",
      "definition" : "Kod för legitimerad yrkestitel specialistkoden hör till",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "getcredentialsforperson.credentialInformation.healthCareProfessionalLicenceSpeciality.specialityCode",
      "path" : "getcredentialsforperson.credentialInformation.healthCareProfessionalLicenceSpeciality.specialityCode",
      "short" : "Specialistkod",
      "definition" : "Specialistkod",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "getcredentialsforperson.credentialInformation.healthCareProfessionalLicenceSpeciality.specialityName",
      "path" : "getcredentialsforperson.credentialInformation.healthCareProfessionalLicenceSpeciality.specialityName",
      "short" : "Specialitet i klartext",
      "definition" : "Specialitet i klartext",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "getcredentialsforperson.credentialInformation.occupationalCode",
      "path" : "getcredentialsforperson.credentialInformation.occupationalCode",
      "short" : "Utökad yrkeskod",
      "definition" : "Utökad yrkeskod",
      "min" : 0,
      "max" : "*",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "getcredentialsforperson.credentialInformation.personalIdentity",
      "path" : "getcredentialsforperson.credentialInformation.personalIdentity",
      "short" : "Personens person- eller samordningsnummer (extended1)",
      "definition" : "Personens person- eller samordningsnummer (extended1)",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "BackboneElement"
      }]
    },
    {
      "id" : "getcredentialsforperson.credentialInformation.personalIdentity.root",
      "path" : "getcredentialsforperson.credentialInformation.personalIdentity.root",
      "short" : "Typ av personnummer (OID)",
      "definition" : "Typ av personnummer (OID)",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "getcredentialsforperson.credentialInformation.personalIdentity.personNumber",
      "path" : "getcredentialsforperson.credentialInformation.personalIdentity.personNumber",
      "short" : "Person- eller samordningsnummer",
      "definition" : "Person- eller samordningsnummer",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "getcredentialsforperson.credentialInformation.healthcareProfessionalLicenseIdentityNumber",
      "path" : "getcredentialsforperson.credentialInformation.healthcareProfessionalLicenseIdentityNumber",
      "short" : "Personens HOSP-id",
      "definition" : "Personens HOSP-id",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "getcredentialsforperson.credentialInformation.personalPrescriptionCode",
      "path" : "getcredentialsforperson.credentialInformation.personalPrescriptionCode",
      "short" : "Personens förskrivarkod",
      "definition" : "Personens förskrivarkod",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "getcredentialsforperson.credentialInformation.groupPrescriptionCode",
      "path" : "getcredentialsforperson.credentialInformation.groupPrescriptionCode",
      "short" : "Gruppförskrivarkod",
      "definition" : "Gruppförskrivarkod",
      "min" : 0,
      "max" : "*",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "getcredentialsforperson.credentialInformation.nursePrescriptionRight",
      "path" : "getcredentialsforperson.credentialInformation.nursePrescriptionRight",
      "short" : "Förskrivningsrätt för barnmorska/sjuksköterska",
      "definition" : "Förskrivningsrätt för barnmorska/sjuksköterska",
      "min" : 0,
      "max" : "*",
      "type" : [{
        "code" : "BackboneElement"
      }]
    },
    {
      "id" : "getcredentialsforperson.credentialInformation.nursePrescriptionRight.healthCareProfessionalLicence",
      "path" : "getcredentialsforperson.credentialInformation.nursePrescriptionRight.healthCareProfessionalLicence",
      "short" : "Legitimerad yrkestitel (BM eller SJ)",
      "definition" : "Legitimerad yrkestitel (BM eller SJ)",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "getcredentialsforperson.credentialInformation.nursePrescriptionRight.prescriptionRight",
      "path" : "getcredentialsforperson.credentialInformation.nursePrescriptionRight.prescriptionRight",
      "short" : "Personen har förskrivningsrätt",
      "definition" : "Personen har förskrivningsrätt",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "boolean"
      }]
    },
    {
      "id" : "getcredentialsforperson.credentialInformation.hsaSystemRole",
      "path" : "getcredentialsforperson.credentialInformation.hsaSystemRole",
      "short" : "Individuella egenskaper för it-tjänster",
      "definition" : "Individuella egenskaper för it-tjänster",
      "min" : 0,
      "max" : "*",
      "type" : [{
        "code" : "BackboneElement"
      }]
    },
    {
      "id" : "getcredentialsforperson.credentialInformation.hsaSystemRole.systemId",
      "path" : "getcredentialsforperson.credentialInformation.hsaSystemRole.systemId",
      "short" : "IT-tjänstens SystemId",
      "definition" : "IT-tjänstens SystemId",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "getcredentialsforperson.credentialInformation.hsaSystemRole.role",
      "path" : "getcredentialsforperson.credentialInformation.hsaSystemRole.role",
      "short" : "Personens roll inom IT-tjänsten",
      "definition" : "Personens roll inom IT-tjänsten",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "getcredentialsforperson.credentialInformation.paTitleCode",
      "path" : "getcredentialsforperson.credentialInformation.paTitleCode",
      "short" : "Befattningskod",
      "definition" : "Befattningskod",
      "min" : 0,
      "max" : "*",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "getcredentialsforperson.credentialInformation.feignedPerson",
      "path" : "getcredentialsforperson.credentialInformation.feignedPerson",
      "short" : "Personen är ett fingerat objekt",
      "definition" : "Personen är ett fingerat objekt",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "boolean"
      }]
    },
    {
      "id" : "getcredentialsforperson.credentialInformation.commission",
      "path" : "getcredentialsforperson.credentialInformation.commission",
      "short" : "Vårdmedarbetaruppdrag personen är kopplad till",
      "definition" : "Vårdmedarbetaruppdrag personen är kopplad till",
      "min" : 0,
      "max" : "*",
      "type" : [{
        "code" : "BackboneElement"
      }]
    },
    {
      "id" : "getcredentialsforperson.credentialInformation.commission.commissionName",
      "path" : "getcredentialsforperson.credentialInformation.commission.commissionName",
      "short" : "Vårdmedarbetaruppdragets namn",
      "definition" : "Vårdmedarbetaruppdragets namn",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "getcredentialsforperson.credentialInformation.commission.commissionHsaId",
      "path" : "getcredentialsforperson.credentialInformation.commission.commissionHsaId",
      "short" : "Vårdmedarbetaruppdragets HSA-id",
      "definition" : "Vårdmedarbetaruppdragets HSA-id",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "getcredentialsforperson.credentialInformation.commission.commissionPurpose",
      "path" : "getcredentialsforperson.credentialInformation.commission.commissionPurpose",
      "short" : "Vårdmedarbetaruppdragets ändamål",
      "definition" : "Vårdmedarbetaruppdragets ändamål",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "getcredentialsforperson.credentialInformation.commission.commissionRight",
      "path" : "getcredentialsforperson.credentialInformation.commission.commissionRight",
      "short" : "Vårdmedarbetaruppdragets rättigheter",
      "definition" : "Vårdmedarbetaruppdragets rättigheter",
      "min" : 0,
      "max" : "*",
      "type" : [{
        "code" : "BackboneElement"
      }]
    },
    {
      "id" : "getcredentialsforperson.credentialInformation.commission.commissionRight.activity",
      "path" : "getcredentialsforperson.credentialInformation.commission.commissionRight.activity",
      "short" : "Rättighet aktivitet",
      "definition" : "Rättighet aktivitet",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "getcredentialsforperson.credentialInformation.commission.commissionRight.informationClass",
      "path" : "getcredentialsforperson.credentialInformation.commission.commissionRight.informationClass",
      "short" : "Rättighet informationstyp",
      "definition" : "Rättighet informationstyp",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "getcredentialsforperson.credentialInformation.commission.commissionRight.scope",
      "path" : "getcredentialsforperson.credentialInformation.commission.commissionRight.scope",
      "short" : "Rättighet omfång",
      "definition" : "Rättighet omfång",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "getcredentialsforperson.credentialInformation.commission.pharmacyIdentifier",
      "path" : "getcredentialsforperson.credentialInformation.commission.pharmacyIdentifier",
      "short" : "Unikt id för apotek",
      "definition" : "Unikt id för apotek",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "getcredentialsforperson.credentialInformation.commission.feignedCommission",
      "path" : "getcredentialsforperson.credentialInformation.commission.feignedCommission",
      "short" : "Vårdmedarbetaruppdraget är ett fingerat objekt",
      "definition" : "Vårdmedarbetaruppdraget är ett fingerat objekt",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "boolean"
      }]
    },
    {
      "id" : "getcredentialsforperson.credentialInformation.commission.healthCareUnitHsaId",
      "path" : "getcredentialsforperson.credentialInformation.commission.healthCareUnitHsaId",
      "short" : "HSA-id för vårdenhet enligt PDL",
      "definition" : "HSA-id för vårdenhet enligt PDL",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "getcredentialsforperson.credentialInformation.commission.healthCareUnitName",
      "path" : "getcredentialsforperson.credentialInformation.commission.healthCareUnitName",
      "short" : "Vårdenhetens namn",
      "definition" : "Vårdenhetens namn",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "getcredentialsforperson.credentialInformation.commission.healthCareUnitStartDate",
      "path" : "getcredentialsforperson.credentialInformation.commission.healthCareUnitStartDate",
      "short" : "Startdatum för vårdenhetens verksamhet",
      "definition" : "Startdatum för vårdenhetens verksamhet",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "dateTime"
      }]
    },
    {
      "id" : "getcredentialsforperson.credentialInformation.commission.healthCareUnitEndDate",
      "path" : "getcredentialsforperson.credentialInformation.commission.healthCareUnitEndDate",
      "short" : "Slutdatum för vårdenhetens verksamhet",
      "definition" : "Slutdatum för vårdenhetens verksamhet",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "dateTime"
      }]
    },
    {
      "id" : "getcredentialsforperson.credentialInformation.commission.feignedHealthCareUnit",
      "path" : "getcredentialsforperson.credentialInformation.commission.feignedHealthCareUnit",
      "short" : "Vårdenheten är ett fingerat objekt",
      "definition" : "Vårdenheten är ett fingerat objekt",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "boolean"
      }]
    },
    {
      "id" : "getcredentialsforperson.credentialInformation.commission.archivedHealthCareUnit",
      "path" : "getcredentialsforperson.credentialInformation.commission.archivedHealthCareUnit",
      "short" : "Vårdenheten är ett arkiverat objekt",
      "definition" : "Vårdenheten är ett arkiverat objekt",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "boolean"
      }]
    },
    {
      "id" : "getcredentialsforperson.credentialInformation.commission.healthCareProviderHsaId",
      "path" : "getcredentialsforperson.credentialInformation.commission.healthCareProviderHsaId",
      "short" : "Vårdgivarens HSA-id",
      "definition" : "Vårdgivarens HSA-id",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "getcredentialsforperson.credentialInformation.commission.healthCareProviderName",
      "path" : "getcredentialsforperson.credentialInformation.commission.healthCareProviderName",
      "short" : "Vårdgivarens namn",
      "definition" : "Vårdgivarens namn",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "getcredentialsforperson.credentialInformation.commission.healthCareProviderOrgNo",
      "path" : "getcredentialsforperson.credentialInformation.commission.healthCareProviderOrgNo",
      "short" : "Vårdgivarens organisationsnummer",
      "definition" : "Vårdgivarens organisationsnummer",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "getcredentialsforperson.credentialInformation.commission.healthCareProviderStartDate",
      "path" : "getcredentialsforperson.credentialInformation.commission.healthCareProviderStartDate",
      "short" : "Startdatum för vårdgivarens verksamhet",
      "definition" : "Startdatum för vårdgivarens verksamhet",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "dateTime"
      }]
    },
    {
      "id" : "getcredentialsforperson.credentialInformation.commission.healthCareProviderEndDate",
      "path" : "getcredentialsforperson.credentialInformation.commission.healthCareProviderEndDate",
      "short" : "Slutdatum för vårdgivarens verksamhet",
      "definition" : "Slutdatum för vårdgivarens verksamhet",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "dateTime"
      }]
    },
    {
      "id" : "getcredentialsforperson.credentialInformation.commission.feignedHealthCareProvider",
      "path" : "getcredentialsforperson.credentialInformation.commission.feignedHealthCareProvider",
      "short" : "Vårdgivaren är ett fingerat objekt",
      "definition" : "Vårdgivaren är ett fingerat objekt",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "boolean"
      }]
    },
    {
      "id" : "getcredentialsforperson.credentialInformation.commission.archivedHealthCareProvider",
      "path" : "getcredentialsforperson.credentialInformation.commission.archivedHealthCareProvider",
      "short" : "Vårdgivaren är ett arkiverat objekt",
      "definition" : "Vårdgivaren är ett arkiverat objekt",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "boolean"
      }]
    }]
  }
}

```
