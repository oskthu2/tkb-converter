# inera.infrastructure-directory-authorizationmanagement#2.4.4: infrastructure: directory: authorizationmanagement

## Pages

* [Hem](index.md)
* [7 Tjänstekontrakt](7-tjanstekontrakt.md)
* [1 Inledning](1-inledning.md)
* [4 Tjänstedomänens krav och regler](4-tjanstedomanens-krav-och-regler.md)
* [6 Gemensamma informationskomponenter](6-gemensamma-informationskomponenter.md)
* [3 Tjänstedomänens arkitektur](3-tjanstedomanens-arkitektur.md)
* [Artifacts Summary](artifacts.md)
* [2 Versionsinformation](2-versionsinformation.md)
* [5 Tjänstedomänens meddelandemodeller](5-tjanstedomanens-meddelandemodeller.md)

## Resources

### CodeSystems

* [HOSP Operation](CodeSystem-hosp-operation-cs.md)

### ValueSets

* [HOSP Operation — ValueSet](ValueSet-hosp-operation-vs.md)

### Logicals

* [GetAdminCredentialsForPerson — Request](StructureDefinition-getadmincredentialsforperson-request.md)
* [GetAdminCredentialsForPerson](StructureDefinition-getadmincredentialsforperson.md)
* [GetAdminCredentialsForPersonIncludingProtectedPerson — Request](StructureDefinition-getadmincredentialsforpersonincludingprotectedperson-request.md)
* [GetAdminCredentialsForPersonIncludingProtectedPerson](StructureDefinition-getadmincredentialsforpersonincludingprotectedperson.md)
* [GetCredentialsForPerson — Request](StructureDefinition-getcredentialsforperson-request.md)
* [GetCredentialsForPerson](StructureDefinition-getcredentialsforperson.md)
* [GetCredentialsForPersonIncludingProtectedPerson — Request](StructureDefinition-getcredentialsforpersonincludingprotectedperson-request.md)
* [GetCredentialsForPersonIncludingProtectedPerson](StructureDefinition-getcredentialsforpersonincludingprotectedperson.md)
* [GetHospCredentialsForPerson — Request](StructureDefinition-gethospcredentialsforperson-request.md)
* [GetHospCredentialsForPerson](StructureDefinition-gethospcredentialsforperson.md)
* [GetHospLastUpdate](StructureDefinition-gethosplastupdate.md)
* [HandleHospCertificationPerson — Request](StructureDefinition-handlehospcertificationperson-request.md)
* [HandleHospCertificationPerson](StructureDefinition-handlehospcertificationperson.md)

### ImplementationGuides

* [infrastructure: directory: authorizationmanagement](index.md)
