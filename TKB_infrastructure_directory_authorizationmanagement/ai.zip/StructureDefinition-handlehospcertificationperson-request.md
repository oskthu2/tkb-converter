# HandleHospCertificationPerson — Request - infrastructure: directory: authorizationmanagement v2.4.5

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **HandleHospCertificationPerson — Request**

## Logical Model: HandleHospCertificationPerson — Request 

| | |
| :--- | :--- |
| *Official URL*:https://fhir.inera.se/ig/infrastructure-directory-authorizationmanagement/StructureDefinition/handlehospcertificationperson-request | *Version*:1.0 |
| Active as of 2026-11-09 | *Computable Name*:HandleHospCertificationPersonRequest |
| **Copyright/Legal**: Copyright 2024 Inera AB. Licensieras under Creative Commons Attribution 4.0. | |

 
Logisk modell för requestparametrar i HandleHospCertificationPerson. 

**Usages:**

* This Logical Model is not used by any profiles in this Specification

You can also check for [usages in the FHIR IG Statistics](https://packages2.fhir.org/xig/resource/inera.infrastructure-directory-authorizationmanagement|current/StructureDefinition/StructureDefinition-handlehospcertificationperson-request.json)

### Formal Views of Profile Content

 [Description of Profiles, Differentials, Snapshots and how the different presentations work](http://build.fhir.org/ig/FHIR/ig-guidance/readingIgs.html#structure-definitions). 

 

Other representations of profile: [CSV](StructureDefinition-handlehospcertificationperson-request.csv), [Excel](StructureDefinition-handlehospcertificationperson-request.xlsx) 



## Resource Content

```json
{
  "resourceType" : "StructureDefinition",
  "id" : "handlehospcertificationperson-request",
  "extension" : [{
    "url" : "http://hl7.org/fhir/StructureDefinition/structuredefinition-type-characteristics",
    "valueCode" : "can-be-target"
  }],
  "url" : "https://fhir.inera.se/ig/infrastructure-directory-authorizationmanagement/StructureDefinition/handlehospcertificationperson-request",
  "version" : "1.0",
  "name" : "HandleHospCertificationPersonRequest",
  "title" : "HandleHospCertificationPerson — Request",
  "status" : "active",
  "date" : "2026-11-09T03:36:43+00:00",
  "contact" : [{
    "name" : "Inera Arkitektur",
    "telecom" : [{
      "system" : "url",
      "value" : "https://www.inera.se"
    }]
  }],
  "description" : "Logisk modell för requestparametrar i HandleHospCertificationPerson.",
  "copyright" : "Copyright 2024 Inera AB. Licensieras under Creative Commons Attribution 4.0.",
  "fhirVersion" : "4.0.1",
  "kind" : "logical",
  "abstract" : false,
  "type" : "https://fhir.inera.se/ig/infrastructure-directory-authorizationmanagement/StructureDefinition/handlehospcertificationperson-request",
  "baseDefinition" : "http://hl7.org/fhir/StructureDefinition/Base",
  "derivation" : "specialization",
  "differential" : {
    "element" : [{
      "id" : "handlehospcertificationperson-request",
      "path" : "handlehospcertificationperson-request",
      "short" : "HandleHospCertificationPerson — Request",
      "definition" : "Logisk modell för requestparametrar i HandleHospCertificationPerson."
    },
    {
      "id" : "handlehospcertificationperson-request.personalIdentityNumber",
      "path" : "handlehospcertificationperson-request.personalIdentityNumber",
      "short" : "personalIdentityNumber",
      "definition" : "Person-id för den person vars HoSp-uppgifter ska begäras utlämnade från Socialstyrelsen. Ref. person-id (personalIdentityNumber) [R5]",
      "comment" : "TKB-fält: `personalIdentityNumber` (`String`, kardinalitet 1..1).",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "handlehospcertificationperson-request.operation",
      "path" : "handlehospcertificationperson-request.operation",
      "short" : "operation",
      "definition" : "\"add\" för att lägga till personen, \"remove\" för att ta bort personen från utlämningsförfrågningar.",
      "comment" : "TKB-fält: `operation` (`String`, kardinalitet 1..1).\n\n**Modellanteckning:** operation Tillåtna värden: add, remove.",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "code"
      }]
    },
    {
      "id" : "handlehospcertificationperson-request.certificationId",
      "path" : "handlehospcertificationperson-request.certificationId",
      "short" : "certificationId",
      "definition" : "Frivillig uppgift. Alternativ id för personposten",
      "comment" : "TKB-fält: `certificationId` (`String`, kardinalitet 0..1).",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "handlehospcertificationperson-request.reason",
      "path" : "handlehospcertificationperson-request.reason",
      "short" : "reason",
      "definition" : "Frivillig uppgift om anledning till avregistrering. Uppgiften sparas inte utan kommer bara loggas i tjänstekontraktets logg.",
      "comment" : "TKB-fält: `reason` (`String`, kardinalitet 0..1).",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    }]
  }
}

```
