# Hem - infrastructure: directory: authorizationmanagement v2.4.5

* [**Table of Contents**](toc.md)
* **Hem**

## Hem

| | |
| :--- | :--- |
| *Official URL*:https://fhir.inera.se/ig/infrastructure-directory-authorizationmanagement/ImplementationGuide/inera.infrastructure-directory-authorizationmanagement | *Version*:2.4.5 |
| Active as of 2026-10-26 | *Computable Name*:infrastructuredirectoryauthorizationmanagement |
| **Copyright/Legal**: Copyright 2024 Inera AB. Licensieras under Creative Commons Attribution 4.0. | |

# infrastructure: directory: authorizationmanagement

**TKB-version:** 2.4.5 · **IG-version:** 2.4.5 · **Källa:** Bitbucket-commit `041301035a1a`, efter taggen `2.4.5` 

## Översikt

* Beskrivning: Svenskt kortnamn
  * Tjänstedomänens ändamål är att förse övriga tjänster med kvalitetssäkrad och aktuell behörighetsgrundande information. Användningsområden utgörs främst av sökningar efter behörighetsgrundande egenskaper i form av information om personers uppdrag kopplade till organisation samt anställningsrelaterade och personliga egenskaper av betydelse för åtkomst till information, vilket ofta, men inte alltid, är relaterat till Patientdatalagen, PDL.: behörighetshantering
* Beskrivning: Svenskt namn
  * Tjänstedomänens ändamål är att förse övriga tjänster med kvalitetssäkrad och aktuell behörighetsgrundande information. Användningsområden utgörs främst av sökningar efter behörighetsgrundande egenskaper i form av information om personers uppdrag kopplade till organisation samt anställningsrelaterade och personliga egenskaper av betydelse för åtkomst till information, vilket ofta, men inte alltid, är relaterat till Patientdatalagen, PDL.: infrastruktur:katalogtjänster:behörighetshantering
* Beskrivning: Typ
  * Tjänstedomänens ändamål är att förse övriga tjänster med kvalitetssäkrad och aktuell behörighetsgrundande information. Användningsområden utgörs främst av sökningar efter behörighetsgrundande egenskaper i form av information om personers uppdrag kopplade till organisation samt anställningsrelaterade och personliga egenskaper av betydelse för åtkomst till information, vilket ofta, men inte alltid, är relaterat till Patientdatalagen, PDL.: Nationell tjänstedomän
* Beskrivning: Källkod
  * Tjänstedomänens ändamål är att förse övriga tjänster med kvalitetssäkrad och aktuell behörighetsgrundande information. Användningsområden utgörs främst av sökningar efter behörighetsgrundande egenskaper i form av information om personers uppdrag kopplade till organisation samt anställningsrelaterade och personliga egenskaper av betydelse för åtkomst till information, vilket ofta, men inte alltid, är relaterat till Patientdatalagen, PDL.: [Bitbucket](https://bitbucket.org/rivta-domains/riv.infrastructure.directory.authorizationmanagement/src)
* Beskrivning: Ärenden
  * Tjänstedomänens ändamål är att förse övriga tjänster med kvalitetssäkrad och aktuell behörighetsgrundande information. Användningsområden utgörs främst av sökningar efter behörighetsgrundande egenskaper i form av information om personers uppdrag kopplade till organisation samt anställningsrelaterade och personliga egenskaper av betydelse för åtkomst till information, vilket ofta, men inte alltid, är relaterat till Patientdatalagen, PDL.: [Bitbucket issues](https://bitbucket.org/rivta-domains/riv.infrastructure.directory.authorizationmanagement/issues)
* Beskrivning: Underlag för denna IG
  * Tjänstedomänens ändamål är att förse övriga tjänster med kvalitetssäkrad och aktuell behörighetsgrundande information. Användningsområden utgörs främst av sökningar efter behörighetsgrundande egenskaper i form av information om personers uppdrag kopplade till organisation samt anställningsrelaterade och personliga egenskaper av betydelse för åtkomst till information, vilket ofta, men inte alltid, är relaterat till Patientdatalagen, PDL.: Version 2.4.5 ·[tagg 2.4.5](https://bitbucket.org/rivta-domains/riv.infrastructure.directory.authorizationmanagement/src/2.4.5)
* Beskrivning: RIV-TA-portalen
  * Tjänstedomänens ändamål är att förse övriga tjänster med kvalitetssäkrad och aktuell behörighetsgrundande information. Användningsområden utgörs främst av sökningar efter behörighetsgrundande egenskaper i form av information om personers uppdrag kopplade till organisation samt anställningsrelaterade och personliga egenskaper av betydelse för åtkomst till information, vilket ofta, men inte alltid, är relaterat till Patientdatalagen, PDL.: [Alla tjänstedomäner](https://oskthu2.github.io/tkb-converter/rivta-portal/tjanstedomaner.html)·[Alla tjänstekontrakt](https://oskthu2.github.io/tkb-converter/rivta-portal/tjanstekontrakt.html)

FHIR Implementation Guide för tjänstedomänen **infrastructure: directory: authorizationmanagement** version 2.4.5. Genererad från Ineras Tjänstekontraktsbeskrivning (TKB).

Domänen innehåller följande tjänstekontrakt:

| | | |
| :--- | :--- | :--- |
| [GetCredentialsForPersonIncludingProtectedPerson](7-tjanstekontrakt.md#getcredentialsforpersonincludingprotectedperson) | 2.2 | Hämta PDL-behörighetsegenskaper (inkl. skyddade personer) |
| [GetCredentialsForPerson](7-tjanstekontrakt.md#getcredentialsforperson) | 2.2 | Hämta PDL-behörighetsegenskaper |
| [GetAdminCredentialsForPersonIncludingProtectedPerson](7-tjanstekontrakt.md#getadmincredentialsforpersonincludingprotectedperson) | 2.0 | Hämta administrativa behörighetsegenskaper (inkl. skyddade personer) |
| [GetAdminCredentialsForPerson](7-tjanstekontrakt.md#getadmincredentialsforperson) | 2.0 | Hämta administrativa behörighetsegenskaper |
| [GetHospLastUpdate](7-tjanstekontrakt.md#gethosplastupdate) | 1.0 | Hämta senaste HOSP-uppdateringstidpunkt |
| [GetHospCredentialsForPerson](7-tjanstekontrakt.md#gethospcredentialsforperson) | 1.0 | Hämta HOSP-behörighetsuppgifter |
| [HandleHospCertificationPerson](7-tjanstekontrakt.md#handlehospcertificationperson) | 1.0 | Hantera HOSP-certifieringsperson |

### Versioner och granskningar

| | | | |
| :--- | :--- | :--- | :--- |
| 2.4 | AB, TKB | [Arkitektur & Regelverk: Säkerhet: Godkänd](http://rivta.se/downloads//infrastructure_directory_authorizationmanagement/2.4/VIS_granskning%20-%20infrastructure_directory_authorizationmanagement_2.4.docx)[Arkitektur & Regelverk: Teknik: Godkänd](http://rivta.se/downloads//infrastructure_directory_authorizationmanagement/2.4/T-granskning%20-%20%20%20infrastructure_directory_authorizationmanagement_2.4.docx)[Arkitektur & Regelverk: Informatik: Godkänd](http://rivta.se/downloads//infrastructure_directory_authorizationmanagement/2.4/VIS_granskning%20-%20infrastructure_directory_authorizationmanagement_2.4.docx) | [zip](http://rivta.se/downloads//infrastructure_directory_authorizationmanagement/2.4/ServiceContracts_infrastructure_directory_authorizationmanagement_2.4.zip)·[källkod](https://bitbucket.org/rivta-domains/riv.infrastructure.directory.authorizationmanagement/src/2.4) |
| 2.3 | TKB, AB | [Arkitektur & Regelverk: Teknik: Godkänd](http://rivta.se/downloads//infrastructure_directory_authorizationmanagement/2.3/T-granskning%20infrastructure_directory_authorizationmanagement_2.3.docx) | [zip](http://rivta.se/downloads//infrastructure_directory_authorizationmanagement/2.3/ServiceContracts_infrastructure_directory_authorizationmanagement_2.3.zip)·[källkod](https://bitbucket.org/rivta-domains/riv.infrastructure.directory.authorizationmanagement/src/2.3) |
| 2.2 | AB, TKB | [Arkitektur & Regelverk: Säkerhet: Godkänd](http://rivta.se/downloads//infrastructure_directory_authorizationmanagement/2.2/VIS_granskning%20infrastructure_directory_authorizationmanagement_2.2.docx)[Arkitektur & Regelverk: Teknik: Godkänd](http://rivta.se/downloads//infrastructure_directory_authorizationmanagement/2.2/T-granskning%20infrastructure_directory_authorizationmanagement_2.2.docx)[Arkitektur & Regelverk: Informatik: Godkänd](http://rivta.se/downloads//infrastructure_directory_authorizationmanagement/2.2/VIS_granskning%20infrastructure_directory_authorizationmanagement_2.2.docx) | [zip](http://rivta.se/downloads//infrastructure_directory_authorizationmanagement/2.2/ServiceContracts_infrastructure_directory_authorizationmanagement_2.2.zip)·[källkod](https://bitbucket.org/rivta-domains/riv.infrastructure.directory.authorizationmanagement/src/2.2) |
| trunk | AB, TKB |  | [källkod](https://bitbucket.org/rivta-domains/riv.infrastructure.directory.authorizationmanagement/src/master) |

*Källa: ögonblicksbild av DOMDB från 2021-08-24, via RIV-TA-portalen.*

## Innehåll

* [1 Inledning](1-inledning.md)
* [2 Versionsinformation](2-versionsinformation.md)
* [3 Tjänstedomänens arkitektur](3-tjanstedomanens-arkitektur.md)
* [4 Tjänstedomänens krav och regler](4-tjanstedomanens-krav-och-regler.md)
* [5 Tjänstedomänens meddelandemodeller](5-tjanstedomanens-meddelandemodeller.md)
* [6 Gemensamma informationskomponenter](6-gemensamma-informationskomponenter.md)
* [7 Tjänstekontrakt](7-tjanstekontrakt.md)
* [Artefakter](artifacts.md)

