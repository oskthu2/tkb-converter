# Hem - infrastructure: directory: authorizationmanagement v2.4.4

* [**Table of Contents**](toc.md)
* **Hem**

## Hem

| | |
| :--- | :--- |
| *Official URL*:https://fhir.inera.se/ig/infrastructure-directory-authorizationmanagement/ImplementationGuide/inera.infrastructure-directory-authorizationmanagement | *Version*:2.4.4 |
| Draft as of 2026-09-26 | *Computable Name*:infrastructuredirectoryauthorizationmanagement |
| **Copyright/Legal**: Copyright 2024 Inera AB. Licensieras under Creative Commons Attribution 4.0. | |

# infrastructure: directory: authorizationmanagement

## Översikt

FHIR Implementation Guide för tjänstedomänen **infrastructure: directory: authorizationmanagement** version 2.4.4. Genererad från Ineras Tjänstekontraktsbeskrivning (TKB).

Domänen innehåller följande tjänstekontrakt:

| | | |
| :--- | :--- | :--- |
| [GetCredentialsForPersonIncludingProtectedPerson](7-tjanstekontrakt.md#getcredentialsforpersonincludingprotectedperson) | 2.2 | Hämta PDL-behörighetsegenskaper (inkl. skyddade personer) |
| [GetCredentialsForPerson](7-tjanstekontrakt.md#getcredentialsforperson) | 2.2 | Hämta PDL-behörighetsegenskaper |
| [GetAdminCredentialsForPersonIncludingProtectedPerson](7-tjanstekontrakt.md#getadmincredentialsforpersonincludingprotectedperson) | 2.0 | Hämta administrativa behörighetsegenskaper (inkl. skyddade personer) |
| [GetAdminCredentialsForPerson](7-tjanstekontrakt.md#getadmincredentialsforperson) | 2.0 | Hämta administrativa behörighetsegenskaper |
| [GetHospLastUpdate](7-tjanstekontrakt.md#gethosplastupdate) | 1.0 | Hämta senaste HOSP-uppdateringstidpunkt |
| [GetHospCredentialsForPerson](7-tjanstekontrakt.md#gethospcredentialsforperson) | 1.0 | Hämta HOSP-behörighetsuppgifter |
| [HandleHospCertificationPerson](7-tjanstekontrakt.md#handlehospcertificationperson) | 1.0 | Hantera HOSP-certifieringsperson |

## Innehåll

* [1 Inledning](1-inledning.md)
* [2 Versionsinformation](2-versionsinformation.md)
* [3 Tjänstedomänens arkitektur](3-tjanstedomanens-arkitektur.md)
* [4 Tjänstedomänens krav och regler](4-tjanstedomanens-krav-och-regler.md)
* [5 Tjänstedomänens meddelandemodeller](5-tjanstedomanens-meddelandemodeller.md)
* [6 Gemensamma informationskomponenter](6-gemensamma-informationskomponenter.md)
* [7 Tjänstekontrakt](7-tjanstekontrakt.md)
* [Artefakter](artifacts.md)

