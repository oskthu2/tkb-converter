# inera.infrastructure-itintegration-messagebox#1.0.0: infrastructure: itintegration: messagebox

## Pages

* [Hem](index.md)
* [7 Tjänstekontrakt](7-tjanstekontrakt.md)
* [5 Tjänstedomänens meddelandemodeller](5-tjanstedomanens-meddelandemodeller.md)
* [Artifacts Summary](artifacts.md)
* [3 Tjänstedomänens arkitektur](3-tjanstedomanens-arkitektur.md)
* [4 Tjänstedomänens krav och regler](4-tjanstedomanens-krav-och-regler.md)
* [2 Versionsinformation](2-versionsinformation.md)
* [1 Inledning](1-inledning.md)

## Resources

### CodeSystems

* [Meddelandestatus](CodeSystem-messagebox-messagestatus-cs.md)
* [Resultatkod](CodeSystem-messagebox-resultcode-cs.md)

### ValueSets

* [Meddelandestatus](ValueSet-messagebox-messagestatus-vs.md)
* [Resultatkod](ValueSet-messagebox-resultcode-vs.md)

### Logicals

* [DeleteMessages — Request](StructureDefinition-deletemessages-request.md)
* [DeleteMessages — Response](StructureDefinition-deletemessages.md)
* [GetMessages — Request](StructureDefinition-getmessages-request.md)
* [GetMessages — Response](StructureDefinition-getmessages.md)
* [ListMessages — Request](StructureDefinition-listmessages-request.md)
* [ListMessages — Response](StructureDefinition-listmessages.md)

### ImplementationGuides

* [infrastructure: itintegration: messagebox](index.md)
