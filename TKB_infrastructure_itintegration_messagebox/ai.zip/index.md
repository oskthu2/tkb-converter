# Hem - infrastructure: itintegration: messagebox v1.0.0

* [**Table of Contents**](toc.md)
* **Hem**

## Hem

| | |
| :--- | :--- |
| *Official URL*:https://fhir.inera.se/ig/infrastructure-itintegration-messagebox/ImplementationGuide/inera.infrastructure-itintegration-messagebox | *Version*:1.0.0 |
| Active as of 2026-10-26 | *Computable Name*:infrastructureitintegrationmessagebox |
| **Copyright/Legal**: Copyright 2024 Inera AB. Licensieras under Creative Commons Attribution 4.0. | |

# infrastructure: itintegration: messagebox

**TKB-version:** 1.0 · **IG-version:** 1.0.0 · **Källa:** Bitbucket-tagg `infrastructure_itintegration_messagebox_1.0` 

## Översikt

* Beskrivning: Svenskt kortnamn
  * Gammal domänen: meddelandetjänst
* Beskrivning: Svenskt namn
  * Gammal domänen: infrastruktur:tjänsteförmedlingstjänster:meddelandetjänst
* Beskrivning: Typ
  * Gammal domänen: Nationell tjänstedomän
* Beskrivning: Anmärkning
  * Gammal domänen: dold på rivta.se
* Beskrivning: Källkod
  * Gammal domänen: [Bitbucket](https://bitbucket.org/rivta-domains/riv.infrastructure.itintegration.messagebox/src)
* Beskrivning: Ärenden
  * Gammal domänen: [Bitbucket issues](https://bitbucket.org/rivta-domains/riv.infrastructure.itintegration.messagebox/issues)
* Beskrivning: Underlag för denna IG
  * Gammal domänen: Version 1.0 ·[tagg infrastructure_itintegration_messagebox_1.0](https://bitbucket.org/rivta-domains/riv.infrastructure.itintegration.messagebox/src/infrastructure_itintegration_messagebox_1.0)·[zip](https://bitbucket.org/rivta-domains/riv.infrastructure.itintegration.messagebox/get/infrastructure_itintegration_messagebox_1.0.zip)
* Beskrivning: RIV-TA-portalen
  * Gammal domänen: [Alla tjänstedomäner](https://oskthu2.github.io/tkb-converter/rivta-portal/tjanstedomaner.html)·[Alla tjänstekontrakt](https://oskthu2.github.io/tkb-converter/rivta-portal/tjanstekontrakt.html)

FHIR Implementation Guide för tjänstedomänen **infrastructure: itintegration: messagebox** (Meddelandetjänst) version 1.0.0. Genererad från Ineras Tjänstekontraktsbeskrivning (TKB), version 1.0.0 (2013-12-04), och domänens WSDL- och XSD-filer.

Meddelandetjänsten mellanlagrar meddelanden adresserade till verksamheter. Ett journalsystem listar, hämtar och tar bort meddelanden som adresserats till de verksamheter det hanterar.

Domänen innehåller följande tjänstekontrakt:

| | | |
| :--- | :--- | :--- |
| [ListMessages](7-tjanstekontrakt.md#listmessages) | 1.0 | Listar meddelanden i Meddelandetjänsten |
| [GetMessages](7-tjanstekontrakt.md#getmessages) | 1.0 | Hämtar meddelanden utifrån meddelandeidentiteter |
| [DeleteMessages](7-tjanstekontrakt.md#deletemessages) | 1.0 | Tar bort meddelanden som tidigare hämtats |

### Versioner och granskningar

| | | | |
| :--- | :--- | :--- | :--- |
| 1.0 | TKB | Äldre granskningsprocess: Informatik: GodkändÄldre granskningsprocess: Säkerhet: GodkändÄldre granskningsprocess: Teknik: Godkänd | [zip](http://rivta.se/downloads/infrastructure_itintegration_messagebox/1.0/ServiceContracts_infrastructure_itintegration_messagebox_1.0.zip)·[källkod](https://bitbucket.org/rivta-domains/riv.infrastructure.itintegration.messagebox/src/infrastructure_itintegration_messagebox_1.0) |
| trunk | TKB |  | [källkod](https://bitbucket.org/rivta-domains/riv.infrastructure.itintegration.messagebox/src/master) |

*Källa: ögonblicksbild av DOMDB från 2021-08-24, via RIV-TA-portalen.*

## Innehåll

* [1 Inledning](1-inledning.md)
* [2 Versionsinformation](2-versionsinformation.md)
* [3 Tjänstedomänens arkitektur](3-tjanstedomanens-arkitektur.md)
* [4 Tjänstedomänens krav och regler](4-tjanstedomanens-krav-och-regler.md)
* [5 Tjänstedomänens meddelandemodeller](5-tjanstedomanens-meddelandemodeller.md)
* [7 Tjänstekontrakt](7-tjanstekontrakt.md)
* [Artefakter](artifacts.md)

