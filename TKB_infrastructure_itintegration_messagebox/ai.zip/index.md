# Hem - infrastructure: itintegration: messagebox v1.0.0

* [**Table of Contents**](toc.md)
* **Hem**

## Hem

| | |
| :--- | :--- |
| *Official URL*:https://fhir.inera.se/ig/infrastructure-itintegration-messagebox/ImplementationGuide/inera.infrastructure-itintegration-messagebox | *Version*:1.0.0 |
| Draft as of 2026-09-26 | *Computable Name*:infrastructureitintegrationmessagebox |
| **Copyright/Legal**: Copyright 2024 Inera AB. Licensieras under Creative Commons Attribution 4.0. | |

# infrastructure: itintegration: messagebox

## Översikt

FHIR Implementation Guide för tjänstedomänen **infrastructure: itintegration: messagebox** (Meddelandetjänst) version 1.0.0. Genererad från Ineras Tjänstekontraktsbeskrivning (TKB), version 1.0.0 (2013-12-04), och domänens WSDL- och XSD-filer.

Meddelandetjänsten mellanlagrar meddelanden adresserade till verksamheter. Ett journalsystem listar, hämtar och tar bort meddelanden som adresserats till de verksamheter det hanterar.

Domänen innehåller följande tjänstekontrakt:

| | | |
| :--- | :--- | :--- |
| [ListMessages](7-tjanstekontrakt.md#listmessages) | 1.0 | Listar meddelanden i Meddelandetjänsten |
| [GetMessages](7-tjanstekontrakt.md#getmessages) | 1.0 | Hämtar meddelanden utifrån meddelandeidentiteter |
| [DeleteMessages](7-tjanstekontrakt.md#deletemessages) | 1.0 | Tar bort meddelanden som tidigare hämtats |

## Innehåll

* [1 Inledning](1-inledning.md)
* [2 Versionsinformation](2-versionsinformation.md)
* [3 Tjänstedomänens arkitektur](3-tjanstedomanens-arkitektur.md)
* [4 Tjänstedomänens krav och regler](4-tjanstedomanens-krav-och-regler.md)
* [5 Tjänstedomänens meddelandemodeller](5-tjanstedomanens-meddelandemodeller.md)
* [7 Tjänstekontrakt](7-tjanstekontrakt.md)
* [Artefakter](artifacts.md)

