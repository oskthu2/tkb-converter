# inera.population-residentmaster#1.2: population: residentmaster

## Pages

* [Hem](index.md)
* [7 Tjänstekontrakt](7-tjanstekontrakt.md)
* [1 Inledning](1-inledning.md)
* [4 Tjänstedomänens krav och regler](4-tjanstedomanens-krav-och-regler.md)
* [6 Gemensamma informationskomponenter](6-gemensamma-informationskomponenter.md)
* [3 Tjänstedomänens arkitektur](3-tjanstedomanens-arkitektur.md)
* [Artifacts Summary](artifacts.md)
* [2 Versionsinformation](2-versionsinformation.md)
* [5 Tjänstedomänens meddelandemodeller](5-tjanstedomanens-meddelandemodeller.md)

## Resources

### CodeSystems

* [Avregistreringsorsak](CodeSystem-avregistreringsorsak-cs.md)
* [Avregistreringsorsak (komplett)](CodeSystem-avregistreringsorsakkomplett-cs.md)
* [Civilståndskod](CodeSystem-civilstandkod-cs.md)
* [Kön](CodeSystem-kon-cs.md)
* [Relationsstatus](CodeSystem-relationstatus-cs.md)
* [Relationstyp](CodeSystem-relationstyp-cs.md)

### ValueSets

* [Avregistreringsorsak — ValueSet](ValueSet-avregistreringsorsak-vs.md)
* [Avregistreringsorsak (komplett) — ValueSet](ValueSet-avregistreringsorsakkomplett-vs.md)
* [Civilståndskod — ValueSet](ValueSet-civilstandkod-vs.md)
* [Kön — ValueSet](ValueSet-kon-vs.md)
* [Relationsstatus — ValueSet](ValueSet-relationstatus-vs.md)
* [Relationstyp — ValueSet](ValueSet-relationstyp-vs.md)

### Logicals

* [LookupResidentForFullProfile — Request](StructureDefinition-lookupresidentforfullprofile-request.md)
* [LookupResidentForFullProfile](StructureDefinition-lookupresidentforfullprofile.md)

### ImplementationGuides

* [population: residentmaster](index.md)
