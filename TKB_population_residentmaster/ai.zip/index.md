# Hem - population: residentmaster v1.2.0

* [**Table of Contents**](toc.md)
* **Hem**

## Hem

| | |
| :--- | :--- |
| *Official URL*:https://fhir.inera.se/ig/population-residentmaster/ImplementationGuide/inera.population-residentmaster | *Version*:1.2.0 |
| Active as of 2026-11-06 | *Computable Name*:populationresidentmaster |
| **Copyright/Legal**: Copyright 2024 Inera AB. Licensieras under Creative Commons Attribution 4.0. | |

# population: residentmaster

**TKB-version:** 1.2 · **IG-version:** 1.2.0 · **Källa:** Bitbucket-tagg `population_residentmaster_1.2` 

## Översikt

* Beskrivning: Svenskt kortnamn
  * Denna tjänstedomän tillgängliggör personuppgifter för invånare bosatta i Sverige. Domänen kommer att avvecklas och ersättas av masterdata:citizen:citizen.: personuppgiftshantering
* Beskrivning: Svenskt namn
  * Denna tjänstedomän tillgängliggör personuppgifter för invånare bosatta i Sverige. Domänen kommer att avvecklas och ersättas av masterdata:citizen:citizen.: infrastruktur:katalogtjänster:personuppgiftshantering
* Beskrivning: Typ
  * Denna tjänstedomän tillgängliggör personuppgifter för invånare bosatta i Sverige. Domänen kommer att avvecklas och ersättas av masterdata:citizen:citizen.: Nationell tjänstedomän
* Beskrivning: Källkod
  * Denna tjänstedomän tillgängliggör personuppgifter för invånare bosatta i Sverige. Domänen kommer att avvecklas och ersättas av masterdata:citizen:citizen.: [Bitbucket](https://bitbucket.org/rivta-domains/riv.population.residentmaster/src)
* Beskrivning: Ärenden
  * Denna tjänstedomän tillgängliggör personuppgifter för invånare bosatta i Sverige. Domänen kommer att avvecklas och ersättas av masterdata:citizen:citizen.: [Bitbucket issues](https://bitbucket.org/rivta-domains/riv.population.residentmaster/issues)
* Beskrivning: Underlag för denna IG
  * Denna tjänstedomän tillgängliggör personuppgifter för invånare bosatta i Sverige. Domänen kommer att avvecklas och ersättas av masterdata:citizen:citizen.: Version 1.2 ·[tagg population_residentmaster_1.2](https://bitbucket.org/rivta-domains/riv.population.residentmaster/src/population_residentmaster_1.2)·[zip](https://bitbucket.org/rivta-domains/riv.population.residentmaster/get/population_residentmaster_1.2.zip)
* Beskrivning: RIV-TA-portalen
  * Denna tjänstedomän tillgängliggör personuppgifter för invånare bosatta i Sverige. Domänen kommer att avvecklas och ersättas av masterdata:citizen:citizen.: [Alla tjänstedomäner](https://oskthu2.github.io/tkb-converter/rivta-portal/tjanstedomaner.html)·[Alla tjänstekontrakt](https://oskthu2.github.io/tkb-converter/rivta-portal/tjanstekontrakt.html)

FHIR Implementation Guide för tjänstedomänen **population: residentmaster** version 1.2. Genererad från Ineras Tjänstekontraktsbeskrivning (TKB).

Domänen tillhandahåller uppslagning av personuppgifter (demografiska uppgifter från Skatteverkets folkbokföring) baserat på personnummer, i form av en familj av tjänstekontrakt `LookupResidentFor<Profile>` — ett per publicerad delmängd (profil) av fält. För närvarande finns endast en publicerad profil, **Full**.

Domänen innehåller följande tjänstekontrakt:

| | | |
| :--- | :--- | :--- |
| [LookupResidentForFullProfile](7-tjanstekontrakt.md#lookupresidentforfullprofile) | 1.2 | Slår upp personuppgifter (fullständig profil) för en eller flera personer baserat på personnummer. |

### Versioner och granskningar

| | | | |
| :--- | :--- | :--- | :--- |
| 1.2 | TKB, AB | Arkitektur & Regelverk: Teknik: GodkändArkitektur & Regelverk: Informatik: UnderkändArkitektur & Regelverk: Säkerhet: Delvis Godkänd | [zip](https://bitbucket.org/rivta-domains/riv.population.residentmaster/get/population_residentmaster_1.2.zip)·[källkod](https://bitbucket.org/rivta-domains/riv.population.residentmaster/src/population_residentmaster_1.2) |
| 1.0.0 | TKB | Äldre granskningsprocess: Teknik: Godkänd | [zip](https://bitbucket.org/rivta-domains/riv.population.residentmaster/get/TD_RESIDENTMASTER_1_0_0_R.zip)·[källkod](https://bitbucket.org/rivta-domains/riv.population.residentmaster/src/TD_RESIDENTMASTER_1_0_0_R) |
| trunk | TKB, AB |  | [källkod](https://bitbucket.org/rivta-domains/riv.population.residentmaster/src/master) |

*Zip-arkiven hämtas från taggarna på Bitbucket. Granskningsprotokollen publicerades på rivta.se och länkas inte härifrån.*

*Källa: ögonblicksbild av DOMDB från 2021-08-24, via RIV-TA-portalen.*

## Innehåll

* [1 Inledning](1-inledning.md)
* [2 Versionsinformation](2-versionsinformation.md)
* [3 Tjänstedomänens arkitektur](3-tjanstedomanens-arkitektur.md)
* [4 Tjänstedomänens krav och regler](4-tjanstedomanens-krav-och-regler.md)
* [5 Tjänstedomänens meddelandemodeller](5-tjanstedomanens-meddelandemodeller.md)
* [6 Gemensamma informationskomponenter](6-gemensamma-informationskomponenter.md)
* [7 Tjänstekontrakt](7-tjanstekontrakt.md)
* [Artefakter](artifacts.md)

