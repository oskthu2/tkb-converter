# Hem - population: residentmaster v1.2

* [**Table of Contents**](toc.md)
* **Hem**

## Hem

| | |
| :--- | :--- |
| *Official URL*:https://fhir.inera.se/ig/population-residentmaster/ImplementationGuide/inera.population-residentmaster | *Version*:1.2 |
| Draft as of 2026-09-26 | *Computable Name*:populationresidentmaster |
| **Copyright/Legal**: Copyright 2024 Inera AB. Licensieras under Creative Commons Attribution 4.0. | |

# population: residentmaster

## Översikt

FHIR Implementation Guide för tjänstedomänen **population: residentmaster** version 1.2. Genererad från Ineras Tjänstekontraktsbeskrivning (TKB).

Domänen tillhandahåller uppslagning av personuppgifter (demografiska uppgifter från Skatteverkets folkbokföring) baserat på personnummer, i form av en familj av tjänstekontrakt `LookupResidentFor<Profile>` — ett per publicerad delmängd (profil) av fält. För närvarande finns endast en publicerad profil, **Full**.

Domänen innehåller följande tjänstekontrakt:

| | | |
| :--- | :--- | :--- |
| [LookupResidentForFullProfile](7-tjanstekontrakt.md#lookupresidentforfullprofile) | 1.2 | Slår upp personuppgifter (fullständig profil) för en eller flera personer baserat på personnummer. |

## Innehåll

* [1 Inledning](1-inledning.md)
* [2 Versionsinformation](2-versionsinformation.md)
* [3 Tjänstedomänens arkitektur](3-tjanstedomanens-arkitektur.md)
* [4 Tjänstedomänens krav och regler](4-tjanstedomanens-krav-och-regler.md)
* [5 Tjänstedomänens meddelandemodeller](5-tjanstedomanens-meddelandemodeller.md)
* [6 Gemensamma informationskomponenter](6-gemensamma-informationskomponenter.md)
* [7 Tjänstekontrakt](7-tjanstekontrakt.md)
* [Artefakter](artifacts.md)

