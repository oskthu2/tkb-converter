# inera.financial-billing-claim#1.1.0: financial: billing: claim

## Pages

* [Hem](index.md)
* [7 Tjänstekontrakt](7-tjanstekontrakt.md)
* [5 Tjänstedomänens meddelandemodeller](5-tjanstedomanens-meddelandemodeller.md)
* [Artifacts Summary](artifacts.md)
* [6 Gemensamma informationskomponenter](6-gemensamma-informationskomponenter.md)
* [3 Tjänstedomänens arkitektur](3-tjanstedomanens-arkitektur.md)
* [4 Tjänstedomänens krav och regler](4-tjanstedomanens-krav-och-regler.md)
* [2 Versionsinformation](2-versionsinformation.md)
* [1 Inledning](1-inledning.md)

## Resources

### CodeSystems

* [Resultatkod](CodeSystem-financial-billing-claim-resultcode-cs.md)

### ValueSets

* [Resultatkod](ValueSet-financial-billing-claim-resultcode-vs.md)

### Logicals

* [ProcessClaimSpecification — Request](StructureDefinition-processclaimspecification-request.md)
* [ProcessClaimSpecification — Response](StructureDefinition-processclaimspecification.md)

### ImplementationGuides

* [financial: billing: claim](index.md)
