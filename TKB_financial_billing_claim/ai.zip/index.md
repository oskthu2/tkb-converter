# Hem - financial: billing: claim v1.1.0

* [**Table of Contents**](toc.md)
* **Hem**

## Hem

| | |
| :--- | :--- |
| *Official URL*:https://fhir.inera.se/ig/financial-billing-claim/ImplementationGuide/inera.financial-billing-claim | *Version*:1.1.0 |
| Active as of 2026-11-09 | *Computable Name*:financialbillingclaim |
| **Copyright/Legal**: Copyright 2024 Inera AB. Licensieras under Creative Commons Attribution 4.0. | |

# financial: billing: claim

**TKB-version:** 1.1 · **IG-version:** 1.1.0 · **Källa:** Bitbucket-tagg `1.1` 

## Översikt

* Beskrivning: Svenskt kortnamn
  * Syftet med tjänstedomänen Utomlänsfakturering är att göra det möjligt för landsting/regioner att skicka fakturaunderlag till andra landsting/regioner på ett enhetligt och standardiserat sätt. Tjänstekontraktet i tjänstedomänen gör det möjligt för en vårdgivare att skicka fakturaunderlag till en patients hemlandsting vid fakturering och eventuell kreditering av patientens vård. Fakturaunderlaget innehåller patientuppgifter och uppgifter kring den vård patienten fått.: utomlänsfakturering
* Beskrivning: Svenskt namn
  * Syftet med tjänstedomänen Utomlänsfakturering är att göra det möjligt för landsting/regioner att skicka fakturaunderlag till andra landsting/regioner på ett enhetligt och standardiserat sätt. Tjänstekontraktet i tjänstedomänen gör det möjligt för en vårdgivare att skicka fakturaunderlag till en patients hemlandsting vid fakturering och eventuell kreditering av patientens vård. Fakturaunderlaget innehåller patientuppgifter och uppgifter kring den vård patienten fått.: operativt processtöd: samordna resurser över verksamhetsstrukturer
* Beskrivning: Typ
  * Syftet med tjänstedomänen Utomlänsfakturering är att göra det möjligt för landsting/regioner att skicka fakturaunderlag till andra landsting/regioner på ett enhetligt och standardiserat sätt. Tjänstekontraktet i tjänstedomänen gör det möjligt för en vårdgivare att skicka fakturaunderlag till en patients hemlandsting vid fakturering och eventuell kreditering av patientens vård. Fakturaunderlaget innehåller patientuppgifter och uppgifter kring den vård patienten fått.: Nationell tjänstedomän
* Beskrivning: Källkod
  * Syftet med tjänstedomänen Utomlänsfakturering är att göra det möjligt för landsting/regioner att skicka fakturaunderlag till andra landsting/regioner på ett enhetligt och standardiserat sätt. Tjänstekontraktet i tjänstedomänen gör det möjligt för en vårdgivare att skicka fakturaunderlag till en patients hemlandsting vid fakturering och eventuell kreditering av patientens vård. Fakturaunderlaget innehåller patientuppgifter och uppgifter kring den vård patienten fått.: [Bitbucket](https://bitbucket.org/rivta-domains/riv.financial.billing.claim/src)
* Beskrivning: Ärenden
  * Syftet med tjänstedomänen Utomlänsfakturering är att göra det möjligt för landsting/regioner att skicka fakturaunderlag till andra landsting/regioner på ett enhetligt och standardiserat sätt. Tjänstekontraktet i tjänstedomänen gör det möjligt för en vårdgivare att skicka fakturaunderlag till en patients hemlandsting vid fakturering och eventuell kreditering av patientens vård. Fakturaunderlaget innehåller patientuppgifter och uppgifter kring den vård patienten fått.: [Bitbucket issues](https://bitbucket.org/rivta-domains/riv.financial.billing.claim/issues)
* Beskrivning: Underlag för denna IG
  * Syftet med tjänstedomänen Utomlänsfakturering är att göra det möjligt för landsting/regioner att skicka fakturaunderlag till andra landsting/regioner på ett enhetligt och standardiserat sätt. Tjänstekontraktet i tjänstedomänen gör det möjligt för en vårdgivare att skicka fakturaunderlag till en patients hemlandsting vid fakturering och eventuell kreditering av patientens vård. Fakturaunderlaget innehåller patientuppgifter och uppgifter kring den vård patienten fått.: Version 1.1 ·[tagg 1.1](https://bitbucket.org/rivta-domains/riv.financial.billing.claim/src/1.1)·[zip](https://bitbucket.org/rivta-domains/riv.financial.billing.claim/get/1.1.zip)
* Beskrivning: RIV-TA-portalen
  * Syftet med tjänstedomänen Utomlänsfakturering är att göra det möjligt för landsting/regioner att skicka fakturaunderlag till andra landsting/regioner på ett enhetligt och standardiserat sätt. Tjänstekontraktet i tjänstedomänen gör det möjligt för en vårdgivare att skicka fakturaunderlag till en patients hemlandsting vid fakturering och eventuell kreditering av patientens vård. Fakturaunderlaget innehåller patientuppgifter och uppgifter kring den vård patienten fått.: [Alla tjänstedomäner](https://oskthu2.github.io/tkb-converter/rivta-portal/tjanstedomaner.html)·[Alla tjänstekontrakt](https://oskthu2.github.io/tkb-converter/rivta-portal/tjanstekontrakt.html)

FHIR Implementation Guide för tjänstedomänen **financial: billing: claim** (Utomlänsfakturering) version 1.1. Genererad från Ineras Tjänstekontraktsbeskrivning (TKB), version 1.1 (2025-10-13), och domänens WSDL-, XSD- och schematronfiler (tagg 1.1).

Tjänstedomänen används för att skicka digitala fakturaunderlag när en patient har fått vård utanför sin hemregion och vårdregionen fakturerar hemregionen enligt Riksavtalet för utomlänsvård.

Domänen innehåller följande tjänstekontrakt:

| | | |
| :--- | :--- | :--- |
| [ProcessClaimSpecification](7-tjanstekontrakt.md#processclaimspecification) | 1.1 | Tjänstekontraktet ProcessClaimSpecification används för att skicka fakturaunderlag då fakturering ska göras från en patients vårdregion till patientens hemregion. |

### Versioner och granskningar

| | | | |
| :--- | :--- | :--- | :--- |
| 1.0.4 | IS, TKB, AB | Arkitektur & Regelverk: Teknik: GodkändArkitektur & Regelverk: Informatik: GodkändArkitektur & Regelverk: Säkerhet: Godkänd | [zip](https://bitbucket.org/rivta-domains/riv.financial.billing.claim/get/1.0.4.zip)·[källkod](https://bitbucket.org/rivta-domains/riv.financial.billing.claim/src/1.0.4) |
| trunk | AB, IS, TKB |  | [källkod](https://bitbucket.org/rivta-domains/riv.financial.billing.claim/src/master) |

*Zip-arkiven hämtas från taggarna på Bitbucket. Granskningsprotokollen publicerades på rivta.se och länkas inte härifrån.*

*Källa: ögonblicksbild av DOMDB från 2021-08-24, via RIV-TA-portalen.*

## Innehåll

* [1 Inledning](1-inledning.md)
* [2 Versionsinformation](2-versionsinformation.md)
* [3 Tjänstedomänens arkitektur](3-tjanstedomanens-arkitektur.md)
* [4 Tjänstedomänens krav och regler](4-tjanstedomanens-krav-och-regler.md)
* [5 Tjänstedomänens meddelandemodeller](5-tjanstedomanens-meddelandemodeller.md)
* [6 Gemensamma informationskomponenter](6-gemensamma-informationskomponenter.md)
* [7 Tjänstekontrakt](7-tjanstekontrakt.md)
* [Artefakter](artifacts.md)

