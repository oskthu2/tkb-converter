# Hem - financial: billing: claim v1.1.0

* [**Table of Contents**](toc.md)
* **Hem**

## Hem

| | |
| :--- | :--- |
| *Official URL*:https://fhir.inera.se/ig/financial-billing-claim/ImplementationGuide/inera.financial-billing-claim | *Version*:1.1.0 |
| Active as of 2026-10-08 | *Computable Name*:financialbillingclaim |
| **Copyright/Legal**: Copyright 2024 Inera AB. Licensieras under Creative Commons Attribution 4.0. | |

# financial: billing: claim

**TKB-version:** 1.1 · **IG-version:** 1.1.0 · **Källa:** Bitbucket-tagg `1.1` 

## Översikt

FHIR Implementation Guide för tjänstedomänen **financial: billing: claim** (Utomlänsfakturering) version 1.1. Genererad från Ineras Tjänstekontraktsbeskrivning (TKB), version 1.1 (2025-10-13), och domänens WSDL-, XSD- och schematronfiler (tagg 1.1).

Tjänstedomänen används för att skicka digitala fakturaunderlag när en patient har fått vård utanför sin hemregion och vårdregionen fakturerar hemregionen enligt Riksavtalet för utomlänsvård.

Domänen innehåller följande tjänstekontrakt:

| | | |
| :--- | :--- | :--- |
| [ProcessClaimSpecification](7-tjanstekontrakt.md#processclaimspecification) | 1.1 | Tjänstekontraktet ProcessClaimSpecification används för att skicka fakturaunderlag då fakturering ska göras från en patients vårdregion till patientens hemregion. |

## Innehåll

* [1 Inledning](1-inledning.md)
* [2 Versionsinformation](2-versionsinformation.md)
* [3 Tjänstedomänens arkitektur](3-tjanstedomanens-arkitektur.md)
* [4 Tjänstedomänens krav och regler](4-tjanstedomanens-krav-och-regler.md)
* [5 Tjänstedomänens meddelandemodeller](5-tjanstedomanens-meddelandemodeller.md)
* [6 Gemensamma informationskomponenter](6-gemensamma-informationskomponenter.md)
* [7 Tjänstekontrakt](7-tjanstekontrakt.md)
* [Artefakter](artifacts.md)

