# SendMedicalCertificateAnswer — Request - insuranceprocess: healthreporting v3.1.1

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **SendMedicalCertificateAnswer — Request**

## Logical Model: SendMedicalCertificateAnswer — Request 

| | |
| :--- | :--- |
| *Official URL*:https://fhir.inera.se/ig/insuranceprocess-healthreporting/StructureDefinition/sendmedicalcertificateanswer-request | *Version*:1.0 |
| Active as of 2026-11-06 | *Computable Name*:SendMedicalCertificateAnswerRequest |
| **Copyright/Legal**: Copyright 2024 Inera AB. Licensieras under Creative Commons Attribution 4.0. | |

 
Logisk modell för requestparametrar i tjänstekontraktet SendMedicalCertificateAnswer (RIV-TA urn:riv:insuranceprocess:healthreporting:SendMedicalCertificateAnswer:1). Skickar ett svar till Försäkringskassan på en tidigare mottagen fråga. 

**Usages:**

* This Logical Model is not used by any profiles in this Specification

You can also check for [usages in the FHIR IG Statistics](https://packages2.fhir.org/xig/resource/inera.insuranceprocess-healthreporting|current/StructureDefinition/StructureDefinition-sendmedicalcertificateanswer-request.json)

### Formal Views of Profile Content

 [Description of Profiles, Differentials, Snapshots and how the different presentations work](http://build.fhir.org/ig/FHIR/ig-guidance/readingIgs.html#structure-definitions). 

 

Other representations of profile: [CSV](StructureDefinition-sendmedicalcertificateanswer-request.csv), [Excel](StructureDefinition-sendmedicalcertificateanswer-request.xlsx) 



## Resource Content

```json
{
  "resourceType" : "StructureDefinition",
  "id" : "sendmedicalcertificateanswer-request",
  "extension" : [{
    "url" : "http://hl7.org/fhir/StructureDefinition/structuredefinition-type-characteristics",
    "valueCode" : "can-be-target"
  }],
  "url" : "https://fhir.inera.se/ig/insuranceprocess-healthreporting/StructureDefinition/sendmedicalcertificateanswer-request",
  "version" : "1.0",
  "name" : "SendMedicalCertificateAnswerRequest",
  "title" : "SendMedicalCertificateAnswer — Request",
  "status" : "active",
  "date" : "2026-11-06T21:35:54+00:00",
  "contact" : [{
    "name" : "Inera Arkitektur",
    "telecom" : [{
      "system" : "url",
      "value" : "https://www.inera.se"
    }]
  }],
  "description" : "Logisk modell för requestparametrar i tjänstekontraktet SendMedicalCertificateAnswer\n(RIV-TA urn:riv:insuranceprocess:healthreporting:SendMedicalCertificateAnswer:1).\nSkickar ett svar till Försäkringskassan på en tidigare mottagen fråga.",
  "copyright" : "Copyright 2024 Inera AB. Licensieras under Creative Commons Attribution 4.0.",
  "fhirVersion" : "4.0.1",
  "kind" : "logical",
  "abstract" : false,
  "type" : "https://fhir.inera.se/ig/insuranceprocess-healthreporting/StructureDefinition/sendmedicalcertificateanswer-request",
  "baseDefinition" : "http://hl7.org/fhir/StructureDefinition/Base",
  "derivation" : "specialization",
  "differential" : {
    "element" : [{
      "id" : "sendmedicalcertificateanswer-request",
      "path" : "sendmedicalcertificateanswer-request",
      "short" : "SendMedicalCertificateAnswer — Request",
      "definition" : "Logisk modell för requestparametrar i tjänstekontraktet SendMedicalCertificateAnswer\n(RIV-TA urn:riv:insuranceprocess:healthreporting:SendMedicalCertificateAnswer:1).\nSkickar ett svar till Försäkringskassan på en tidigare mottagen fråga."
    },
    {
      "id" : "sendmedicalcertificateanswer-request.vardReferensId",
      "path" : "sendmedicalcertificateanswer-request.vardReferensId",
      "short" : "Identitet för detta svar från vården",
      "definition" : "Identitet för detta svar från vården *",
      "comment" : "TKB-fält: `vardReferens-id` (`string`, kardinalitet 1..1).",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "sendmedicalcertificateanswer-request.fkReferensId",
      "path" : "sendmedicalcertificateanswer-request.fkReferensId",
      "short" : "Försäkringskassans referens-id",
      "definition" : "Försäkringskassans referens-id *",
      "comment" : "TKB-fält: `fkReferens-id` (`string`, kardinalitet 1..1).",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "sendmedicalcertificateanswer-request.amne",
      "path" : "sendmedicalcertificateanswer-request.amne",
      "short" : "Ämne som fråga/svar gäller",
      "definition" : "Ämne som fråga/svar gäller.",
      "comment" : "TKB-fält: `amne` (`string`, kardinalitet 1..1).",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "CodeableConcept"
      }],
      "binding" : {
        "strength" : "required",
        "valueSet" : "https://fhir.inera.se/ig/insuranceprocess-healthreporting/ValueSet/amne-vs"
      }
    },
    {
      "id" : "sendmedicalcertificateanswer-request.fraga",
      "path" : "sendmedicalcertificateanswer-request.fraga",
      "short" : "Frågan",
      "definition" : "Frågan",
      "comment" : "TKB-fält: `fraga` (kardinalitet 1..1).",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "BackboneElement"
      }]
    },
    {
      "id" : "sendmedicalcertificateanswer-request.fraga.meddelandeText",
      "path" : "sendmedicalcertificateanswer-request.fraga.meddelandeText",
      "short" : "Själva frågan",
      "definition" : "Själva frågan",
      "comment" : "TKB-fält: `fraga.meddelandeText` (`string`, kardinalitet 1..1).",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "sendmedicalcertificateanswer-request.fraga.signeringsTidpunkt",
      "path" : "sendmedicalcertificateanswer-request.fraga.signeringsTidpunkt",
      "short" : "Signeringstidpunkt för frågan",
      "definition" : "Signeringstidpunkt för själva frågan",
      "comment" : "TKB-fält: `fraga.signeringsTidpunkt` (`datumtid`, kardinalitet 1..1).",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "dateTime"
      }]
    },
    {
      "id" : "sendmedicalcertificateanswer-request.svar",
      "path" : "sendmedicalcertificateanswer-request.svar",
      "short" : "Svaret",
      "definition" : "Svaret",
      "comment" : "TKB-fält: `svar` (kardinalitet 1..1).",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "BackboneElement"
      }]
    },
    {
      "id" : "sendmedicalcertificateanswer-request.svar.meddelandeText",
      "path" : "sendmedicalcertificateanswer-request.svar.meddelandeText",
      "short" : "Själva svaret på ställd fråga",
      "definition" : "Själva svaret på ställd fråga",
      "comment" : "TKB-fält: `svar.meddelandeText` (`string`, kardinalitet 1..1).",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "sendmedicalcertificateanswer-request.svar.signeringsTidpunkt",
      "path" : "sendmedicalcertificateanswer-request.svar.signeringsTidpunkt",
      "short" : "Signeringstidpunkt för svaret",
      "definition" : "Signeringstidpunkt för själva svaret",
      "comment" : "TKB-fält: `svar.signeringsTidpunkt` (`datumtid`, kardinalitet 1..1).",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "dateTime"
      }]
    },
    {
      "id" : "sendmedicalcertificateanswer-request.avsantTidpunkt",
      "path" : "sendmedicalcertificateanswer-request.avsantTidpunkt",
      "short" : "Tidpunkt då svaret skickades från vården",
      "definition" : "Tidpunkt då svaret skickades från vården",
      "comment" : "TKB-fält: `avsantTidpunkt` (`datumtid`, kardinalitet 1..1).",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "dateTime"
      }]
    },
    {
      "id" : "sendmedicalcertificateanswer-request.adressVard",
      "path" : "sendmedicalcertificateanswer-request.adressVard",
      "short" : "Vårdadress",
      "definition" : "Vårdadress",
      "comment" : "TKB-fält: `adressVard` (kardinalitet 1..1).",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "BackboneElement"
      }]
    },
    {
      "id" : "sendmedicalcertificateanswer-request.adressVard.hosPersonal",
      "path" : "sendmedicalcertificateanswer-request.adressVard.hosPersonal",
      "short" : "Vårdpersonal som svarar på frågan",
      "definition" : "Vårdpersonal",
      "comment" : "TKB-fält: `adressVard.hosPersonal` (kardinalitet 1..1).",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "BackboneElement"
      }]
    },
    {
      "id" : "sendmedicalcertificateanswer-request.adressVard.hosPersonal.personalId",
      "path" : "sendmedicalcertificateanswer-request.adressVard.hosPersonal.personalId",
      "short" : "HSA-Id för Hos-person som svarar",
      "definition" : "Hsa-Id för Hos-person som svarar på frågan.",
      "comment" : "TKB-fält: `..hosPersonal.personal-id` (`hsaId`, kardinalitet 1..1).",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "Identifier"
      }]
    },
    {
      "id" : "sendmedicalcertificateanswer-request.adressVard.hosPersonal.fullstandigtNamn",
      "path" : "sendmedicalcertificateanswer-request.adressVard.hosPersonal.fullstandigtNamn",
      "short" : "Namn för Hos-person som svarar",
      "definition" : "Namn för Hos-person som svarar på frågan.",
      "comment" : "TKB-fält: `..hosPersonal.fullstandigtNamn` (`string`, kardinalitet 1..1).",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "sendmedicalcertificateanswer-request.adressVard.hosPersonal.enhet",
      "path" : "sendmedicalcertificateanswer-request.adressVard.hosPersonal.enhet",
      "short" : "Vårdenhet",
      "definition" : "Vårdenhet",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "BackboneElement"
      }]
    },
    {
      "id" : "sendmedicalcertificateanswer-request.adressVard.hosPersonal.enhet.enhetsId",
      "path" : "sendmedicalcertificateanswer-request.adressVard.hosPersonal.enhet.enhetsId",
      "short" : "HSA-Id för Hos-vårdenhet",
      "definition" : "Hsa-Id för Hos-vårdenhet varifrån svaret skickas",
      "comment" : "TKB-fält: `..enhet.enhets-id` (`hsaId`, kardinalitet 1..1).",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "Identifier"
      }]
    },
    {
      "id" : "sendmedicalcertificateanswer-request.adressVard.hosPersonal.enhet.enhetsNamn",
      "path" : "sendmedicalcertificateanswer-request.adressVard.hosPersonal.enhet.enhetsNamn",
      "short" : "Namn på Hos-vårdenhet",
      "definition" : "Namn på Hos-vårdenhet varifrån svaret skickas",
      "comment" : "TKB-fält: `..enhet.enhets-namn` (`string`, kardinalitet 1..1).",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "sendmedicalcertificateanswer-request.adressVard.hosPersonal.enhet.postadress",
      "path" : "sendmedicalcertificateanswer-request.adressVard.hosPersonal.enhet.postadress",
      "short" : "Postadress",
      "definition" : "Postadress för Hos-vårdenhet varifrån svaret skickas",
      "comment" : "TKB-fält: `..enhet.postadress` (`string`, kardinalitet 0..1).",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "sendmedicalcertificateanswer-request.adressVard.hosPersonal.enhet.postnummer",
      "path" : "sendmedicalcertificateanswer-request.adressVard.hosPersonal.enhet.postnummer",
      "short" : "Postnummer",
      "definition" : "Postnummer för Hos-vårdenhet varifrån svaret skickas",
      "comment" : "TKB-fält: `..enhet.postnummer` (`string`, kardinalitet 0..1).",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "sendmedicalcertificateanswer-request.adressVard.hosPersonal.enhet.postort",
      "path" : "sendmedicalcertificateanswer-request.adressVard.hosPersonal.enhet.postort",
      "short" : "Postort",
      "definition" : "Postort för Hos-vårdenhet varifrån svaret skickas",
      "comment" : "TKB-fält: `..enhet.postort` (`string`, kardinalitet 0..1).",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "sendmedicalcertificateanswer-request.adressVard.hosPersonal.enhet.telefonnummer",
      "path" : "sendmedicalcertificateanswer-request.adressVard.hosPersonal.enhet.telefonnummer",
      "short" : "Telefonnummer",
      "definition" : "Telefonnummer till Hos-vårdenhet varifrån svaret skickas",
      "comment" : "TKB-fält: `..enhet.telefonnummer` (`string`, kardinalitet 0..1).",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "sendmedicalcertificateanswer-request.adressVard.hosPersonal.enhet.epost",
      "path" : "sendmedicalcertificateanswer-request.adressVard.hosPersonal.enhet.epost",
      "short" : "Epost",
      "definition" : "Epost adress för Hos-vårdenhet varifrån svaret skickas",
      "comment" : "TKB-fält: `..enhet.epost` (`string`, kardinalitet 0..1).",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "sendmedicalcertificateanswer-request.adressVard.hosPersonal.enhet.vardgivare",
      "path" : "sendmedicalcertificateanswer-request.adressVard.hosPersonal.enhet.vardgivare",
      "short" : "Vårdgivare",
      "definition" : "Vårdgivare",
      "comment" : "TKB-fält: `..enhet.vardgivare` (kardinalitet 1..1).",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "BackboneElement"
      }]
    },
    {
      "id" : "sendmedicalcertificateanswer-request.adressVard.hosPersonal.enhet.vardgivare.vardgivareId",
      "path" : "sendmedicalcertificateanswer-request.adressVard.hosPersonal.enhet.vardgivare.vardgivareId",
      "short" : "HSA-Id för Hos-vårdgivare",
      "definition" : "Hsa-Id för Hos-vårdgivare varifrån svaret skickas",
      "comment" : "TKB-fält: `vardgivare.vardgivare-id` (`hsaId`, kardinalitet 1..1).",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "Identifier"
      }]
    },
    {
      "id" : "sendmedicalcertificateanswer-request.adressVard.hosPersonal.enhet.vardgivare.vardgivareNamn",
      "path" : "sendmedicalcertificateanswer-request.adressVard.hosPersonal.enhet.vardgivare.vardgivareNamn",
      "short" : "Namn på Hos-vårdgivare",
      "definition" : "Namn på Hos-vårdgivare varifrån svaret skickas",
      "comment" : "TKB-fält: `vardgivare.vardgivare-namn` (`string`, kardinalitet 1..1).",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "sendmedicalcertificateanswer-request.lakarutlatande",
      "path" : "sendmedicalcertificateanswer-request.lakarutlatande",
      "short" : "Läkarintyget som fråga/svar gäller",
      "definition" : "Läkarintyget som fråga/svar gäller",
      "comment" : "TKB-fält: `lakarutlatande` (kardinalitet 1..1).",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "BackboneElement"
      }]
    },
    {
      "id" : "sendmedicalcertificateanswer-request.lakarutlatande.lakarutlatandeId",
      "path" : "sendmedicalcertificateanswer-request.lakarutlatande.lakarutlatandeId",
      "short" : "Unikt id för läkarintyget",
      "definition" : "Unikt id för läkarintyget som fråga/svar gäller",
      "comment" : "TKB-fält: `lakarutlatande.lakarutlatande-id` (`string`, kardinalitet 1..1).",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "sendmedicalcertificateanswer-request.lakarutlatande.signeringsTidpunkt",
      "path" : "sendmedicalcertificateanswer-request.lakarutlatande.signeringsTidpunkt",
      "short" : "Signeringstidpunkt för läkarintyget",
      "definition" : "Signeringstidpunkt för läkarintyget som fråga/svar gäller",
      "comment" : "TKB-fält: `lakarutlatande.signeringsTidpunkt` (`datumtid`, kardinalitet 1..1).",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "dateTime"
      }]
    },
    {
      "id" : "sendmedicalcertificateanswer-request.lakarutlatande.patient",
      "path" : "sendmedicalcertificateanswer-request.lakarutlatande.patient",
      "short" : "Patienten",
      "definition" : "Patienten",
      "comment" : "TKB-fält: `lakarutlatande.patient` (kardinalitet 1..1).",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "BackboneElement"
      }]
    },
    {
      "id" : "sendmedicalcertificateanswer-request.lakarutlatande.patient.personId",
      "path" : "sendmedicalcertificateanswer-request.lakarutlatande.patient.personId",
      "short" : "Patientens personnummer eller samordningsnummer",
      "definition" : "Patientens personnummer eller samordningnummer",
      "comment" : "TKB-fält: `..patient.person-id` (`string`, kardinalitet 1..1).",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "Identifier"
      }]
    },
    {
      "id" : "sendmedicalcertificateanswer-request.lakarutlatande.patient.fullstandigtNamn",
      "path" : "sendmedicalcertificateanswer-request.lakarutlatande.patient.fullstandigtNamn",
      "short" : "Patientens namn",
      "definition" : "Patientens namn",
      "comment" : "TKB-fält: `..patient.fullstandigtNamn` (`string`, kardinalitet 1..1).",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    }]
  }
}

```
