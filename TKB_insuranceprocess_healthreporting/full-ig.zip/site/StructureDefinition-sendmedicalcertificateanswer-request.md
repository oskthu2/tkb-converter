# SendMedicalCertificateAnswer — Request - insuranceprocess: healthreporting v3.1.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **SendMedicalCertificateAnswer — Request**

## Logical Model: SendMedicalCertificateAnswer — Request 

| | |
| :--- | :--- |
| *Official URL*:https://fhir.inera.se/ig/insuranceprocess-healthreporting/StructureDefinition/sendmedicalcertificateanswer-request | *Version*:3.1.0 |
| Draft as of 2026-09-09 | *Computable Name*:SendMedicalCertificateAnswerRequest |
| **Copyright/Legal**: Copyright 2024 Inera AB. Licensieras under Creative Commons Attribution 4.0. | |

 
Logisk modell för requestparametrar i tjänstekontraktet SendMedicalCertificateAnswer (RIV-TA urn:riv:insuranceprocess:healthreporting:SendMedicalCertificateAnswer:1). Skickar ett svar till Försäkringskassan på en tidigare mottagen fråga. 

**Usages:**

* This Logical Model is not used by any profiles in this Specification

You can also check for [usages in the FHIR IG Statistics](https://packages2.fhir.org/xig/resource/inera.insuranceprocess-healthreporting|current/StructureDefinition/StructureDefinition-sendmedicalcertificateanswer-request.json)

### Formal Views of Profile Content

 [Description of Profiles, Differentials, Snapshots and how the different presentations work](http://build.fhir.org/ig/FHIR/ig-guidance/readingIgs.html#structure-definitions). 

 

Other representations of profile: [CSV](StructureDefinition-sendmedicalcertificateanswer-request.csv), [Excel](StructureDefinition-sendmedicalcertificateanswer-request.xlsx) 



## Resource Content

```json
{
  "resourceType" : "StructureDefinition",
  "id" : "sendmedicalcertificateanswer-request",
  "extension" : [{
    "url" : "http://hl7.org/fhir/StructureDefinition/structuredefinition-type-characteristics",
    "valueCode" : "can-be-target"
  }],
  "url" : "https://fhir.inera.se/ig/insuranceprocess-healthreporting/StructureDefinition/sendmedicalcertificateanswer-request",
  "version" : "3.1.0",
  "name" : "SendMedicalCertificateAnswerRequest",
  "title" : "SendMedicalCertificateAnswer — Request",
  "status" : "draft",
  "date" : "2026-09-09T17:03:03+00:00",
  "contact" : [{
    "name" : "Inera Arkitektur",
    "telecom" : [{
      "system" : "url",
      "value" : "https://www.inera.se"
    }]
  }],
  "description" : "Logisk modell för requestparametrar i tjänstekontraktet SendMedicalCertificateAnswer\n(RIV-TA urn:riv:insuranceprocess:healthreporting:SendMedicalCertificateAnswer:1).\nSkickar ett svar till Försäkringskassan på en tidigare mottagen fråga.",
  "copyright" : "Copyright 2024 Inera AB. Licensieras under Creative Commons Attribution 4.0.",
  "fhirVersion" : "4.0.1",
  "kind" : "logical",
  "abstract" : false,
  "type" : "https://fhir.inera.se/ig/insuranceprocess-healthreporting/StructureDefinition/sendmedicalcertificateanswer-request",
  "baseDefinition" : "http://hl7.org/fhir/StructureDefinition/Base",
  "derivation" : "specialization",
  "differential" : {
    "element" : [{
      "id" : "sendmedicalcertificateanswer-request",
      "path" : "sendmedicalcertificateanswer-request",
      "short" : "SendMedicalCertificateAnswer — Request",
      "definition" : "Logisk modell för requestparametrar i tjänstekontraktet SendMedicalCertificateAnswer\n(RIV-TA urn:riv:insuranceprocess:healthreporting:SendMedicalCertificateAnswer:1).\nSkickar ett svar till Försäkringskassan på en tidigare mottagen fråga."
    },
    {
      "id" : "sendmedicalcertificateanswer-request.vardReferensId",
      "path" : "sendmedicalcertificateanswer-request.vardReferensId",
      "short" : "Identitet för detta svar från vården",
      "definition" : "Identitet för detta svar från vården",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "sendmedicalcertificateanswer-request.fkReferensId",
      "path" : "sendmedicalcertificateanswer-request.fkReferensId",
      "short" : "Försäkringskassans referens-id",
      "definition" : "Försäkringskassans referens-id",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "sendmedicalcertificateanswer-request.amne",
      "path" : "sendmedicalcertificateanswer-request.amne",
      "short" : "Ämne som fråga/svar gäller",
      "definition" : "Ämne som fråga/svar gäller",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "CodeableConcept"
      }],
      "binding" : {
        "strength" : "required",
        "valueSet" : "https://fhir.inera.se/ig/insuranceprocess-healthreporting/ValueSet/amne-vs"
      }
    },
    {
      "id" : "sendmedicalcertificateanswer-request.fraga",
      "path" : "sendmedicalcertificateanswer-request.fraga",
      "short" : "Frågan",
      "definition" : "Frågan",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "BackboneElement"
      }]
    },
    {
      "id" : "sendmedicalcertificateanswer-request.fraga.meddelandeText",
      "path" : "sendmedicalcertificateanswer-request.fraga.meddelandeText",
      "short" : "Själva frågan",
      "definition" : "Själva frågan",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "sendmedicalcertificateanswer-request.fraga.signeringsTidpunkt",
      "path" : "sendmedicalcertificateanswer-request.fraga.signeringsTidpunkt",
      "short" : "Signeringstidpunkt för frågan",
      "definition" : "Signeringstidpunkt för frågan",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "dateTime"
      }]
    },
    {
      "id" : "sendmedicalcertificateanswer-request.svar",
      "path" : "sendmedicalcertificateanswer-request.svar",
      "short" : "Svaret",
      "definition" : "Svaret",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "BackboneElement"
      }]
    },
    {
      "id" : "sendmedicalcertificateanswer-request.svar.meddelandeText",
      "path" : "sendmedicalcertificateanswer-request.svar.meddelandeText",
      "short" : "Själva svaret på ställd fråga",
      "definition" : "Själva svaret på ställd fråga",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "sendmedicalcertificateanswer-request.svar.signeringsTidpunkt",
      "path" : "sendmedicalcertificateanswer-request.svar.signeringsTidpunkt",
      "short" : "Signeringstidpunkt för svaret",
      "definition" : "Signeringstidpunkt för svaret",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "dateTime"
      }]
    },
    {
      "id" : "sendmedicalcertificateanswer-request.avsantTidpunkt",
      "path" : "sendmedicalcertificateanswer-request.avsantTidpunkt",
      "short" : "Tidpunkt då svaret skickades från vården",
      "definition" : "Tidpunkt då svaret skickades från vården",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "dateTime"
      }]
    },
    {
      "id" : "sendmedicalcertificateanswer-request.adressVard",
      "path" : "sendmedicalcertificateanswer-request.adressVard",
      "short" : "Vårdadress",
      "definition" : "Vårdadress",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "BackboneElement"
      }]
    },
    {
      "id" : "sendmedicalcertificateanswer-request.adressVard.hosPersonal",
      "path" : "sendmedicalcertificateanswer-request.adressVard.hosPersonal",
      "short" : "Vårdpersonal som svarar på frågan",
      "definition" : "Vårdpersonal som svarar på frågan",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "BackboneElement"
      }]
    },
    {
      "id" : "sendmedicalcertificateanswer-request.adressVard.hosPersonal.personalId",
      "path" : "sendmedicalcertificateanswer-request.adressVard.hosPersonal.personalId",
      "short" : "HSA-Id för Hos-person som svarar",
      "definition" : "HSA-Id för Hos-person som svarar",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "Identifier"
      }]
    },
    {
      "id" : "sendmedicalcertificateanswer-request.adressVard.hosPersonal.fullstandigtNamn",
      "path" : "sendmedicalcertificateanswer-request.adressVard.hosPersonal.fullstandigtNamn",
      "short" : "Namn för Hos-person som svarar",
      "definition" : "Namn för Hos-person som svarar",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "sendmedicalcertificateanswer-request.adressVard.hosPersonal.enhet",
      "path" : "sendmedicalcertificateanswer-request.adressVard.hosPersonal.enhet",
      "short" : "Vårdenhet",
      "definition" : "Vårdenhet",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "BackboneElement"
      }]
    },
    {
      "id" : "sendmedicalcertificateanswer-request.adressVard.hosPersonal.enhet.enhetsId",
      "path" : "sendmedicalcertificateanswer-request.adressVard.hosPersonal.enhet.enhetsId",
      "short" : "HSA-Id för Hos-vårdenhet",
      "definition" : "HSA-Id för Hos-vårdenhet",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "Identifier"
      }]
    },
    {
      "id" : "sendmedicalcertificateanswer-request.adressVard.hosPersonal.enhet.enhetsNamn",
      "path" : "sendmedicalcertificateanswer-request.adressVard.hosPersonal.enhet.enhetsNamn",
      "short" : "Namn på Hos-vårdenhet",
      "definition" : "Namn på Hos-vårdenhet",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "sendmedicalcertificateanswer-request.adressVard.hosPersonal.enhet.postadress",
      "path" : "sendmedicalcertificateanswer-request.adressVard.hosPersonal.enhet.postadress",
      "short" : "Postadress",
      "definition" : "Postadress",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "sendmedicalcertificateanswer-request.adressVard.hosPersonal.enhet.postnummer",
      "path" : "sendmedicalcertificateanswer-request.adressVard.hosPersonal.enhet.postnummer",
      "short" : "Postnummer",
      "definition" : "Postnummer",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "sendmedicalcertificateanswer-request.adressVard.hosPersonal.enhet.postort",
      "path" : "sendmedicalcertificateanswer-request.adressVard.hosPersonal.enhet.postort",
      "short" : "Postort",
      "definition" : "Postort",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "sendmedicalcertificateanswer-request.adressVard.hosPersonal.enhet.telefonnummer",
      "path" : "sendmedicalcertificateanswer-request.adressVard.hosPersonal.enhet.telefonnummer",
      "short" : "Telefonnummer",
      "definition" : "Telefonnummer",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "sendmedicalcertificateanswer-request.adressVard.hosPersonal.enhet.epost",
      "path" : "sendmedicalcertificateanswer-request.adressVard.hosPersonal.enhet.epost",
      "short" : "Epost",
      "definition" : "Epost",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "sendmedicalcertificateanswer-request.adressVard.hosPersonal.enhet.vardgivare",
      "path" : "sendmedicalcertificateanswer-request.adressVard.hosPersonal.enhet.vardgivare",
      "short" : "Vårdgivare",
      "definition" : "Vårdgivare",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "BackboneElement"
      }]
    },
    {
      "id" : "sendmedicalcertificateanswer-request.adressVard.hosPersonal.enhet.vardgivare.vardgivareId",
      "path" : "sendmedicalcertificateanswer-request.adressVard.hosPersonal.enhet.vardgivare.vardgivareId",
      "short" : "HSA-Id för Hos-vårdgivare",
      "definition" : "HSA-Id för Hos-vårdgivare",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "Identifier"
      }]
    },
    {
      "id" : "sendmedicalcertificateanswer-request.adressVard.hosPersonal.enhet.vardgivare.vardgivareNamn",
      "path" : "sendmedicalcertificateanswer-request.adressVard.hosPersonal.enhet.vardgivare.vardgivareNamn",
      "short" : "Namn på Hos-vårdgivare",
      "definition" : "Namn på Hos-vårdgivare",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "sendmedicalcertificateanswer-request.lakarutlatande",
      "path" : "sendmedicalcertificateanswer-request.lakarutlatande",
      "short" : "Läkarintyget som fråga/svar gäller",
      "definition" : "Läkarintyget som fråga/svar gäller",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "BackboneElement"
      }]
    },
    {
      "id" : "sendmedicalcertificateanswer-request.lakarutlatande.lakarutlatandeId",
      "path" : "sendmedicalcertificateanswer-request.lakarutlatande.lakarutlatandeId",
      "short" : "Unikt id för läkarintyget",
      "definition" : "Unikt id för läkarintyget",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "sendmedicalcertificateanswer-request.lakarutlatande.signeringsTidpunkt",
      "path" : "sendmedicalcertificateanswer-request.lakarutlatande.signeringsTidpunkt",
      "short" : "Signeringstidpunkt för läkarintyget",
      "definition" : "Signeringstidpunkt för läkarintyget",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "dateTime"
      }]
    },
    {
      "id" : "sendmedicalcertificateanswer-request.lakarutlatande.patient",
      "path" : "sendmedicalcertificateanswer-request.lakarutlatande.patient",
      "short" : "Patienten",
      "definition" : "Patienten",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "BackboneElement"
      }]
    },
    {
      "id" : "sendmedicalcertificateanswer-request.lakarutlatande.patient.personId",
      "path" : "sendmedicalcertificateanswer-request.lakarutlatande.patient.personId",
      "short" : "Patientens personnummer eller samordningsnummer",
      "definition" : "Patientens personnummer eller samordningsnummer",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "Identifier"
      }]
    },
    {
      "id" : "sendmedicalcertificateanswer-request.lakarutlatande.patient.fullstandigtNamn",
      "path" : "sendmedicalcertificateanswer-request.lakarutlatande.patient.fullstandigtNamn",
      "short" : "Patientens namn",
      "definition" : "Patientens namn",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    }]
  }
}

```
