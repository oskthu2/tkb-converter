# SendMedicalCertificateAnswer - insuranceprocess: healthreporting v3.1.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **SendMedicalCertificateAnswer**

## Logical Model: SendMedicalCertificateAnswer 

| | |
| :--- | :--- |
| *Official URL*:https://fhir.inera.se/ig/insuranceprocess-healthreporting/StructureDefinition/sendmedicalcertificateanswer | *Version*:3.1.0 |
| Draft as of 2026-09-17 | *Computable Name*:SendMedicalCertificateAnswer |
| **Copyright/Legal**: Copyright 2024 Inera AB. Licensieras under Creative Commons Attribution 4.0. | |

 
Logisk modell för responsens informationsstruktur i tjänstekontraktet SendMedicalCertificateAnswer (RIV-TA urn:riv:insuranceprocess:healthreporting:SendMedicalCertificateAnswer:1). 

**Usages:**

* This Logical Model is not used by any profiles in this Specification

You can also check for [usages in the FHIR IG Statistics](https://packages2.fhir.org/xig/resource/inera.insuranceprocess-healthreporting|current/StructureDefinition/StructureDefinition-sendmedicalcertificateanswer.json)

### Formal Views of Profile Content

 [Description of Profiles, Differentials, Snapshots and how the different presentations work](http://build.fhir.org/ig/FHIR/ig-guidance/readingIgs.html#structure-definitions). 

 

Other representations of profile: [CSV](StructureDefinition-sendmedicalcertificateanswer.csv), [Excel](StructureDefinition-sendmedicalcertificateanswer.xlsx) 



## Resource Content

```json
{
  "resourceType" : "StructureDefinition",
  "id" : "sendmedicalcertificateanswer",
  "extension" : [{
    "url" : "http://hl7.org/fhir/StructureDefinition/structuredefinition-type-characteristics",
    "valueCode" : "can-be-target"
  }],
  "url" : "https://fhir.inera.se/ig/insuranceprocess-healthreporting/StructureDefinition/sendmedicalcertificateanswer",
  "version" : "3.1.0",
  "name" : "SendMedicalCertificateAnswer",
  "title" : "SendMedicalCertificateAnswer",
  "status" : "draft",
  "date" : "2026-09-17T11:16:21+00:00",
  "contact" : [{
    "name" : "Inera Arkitektur",
    "telecom" : [{
      "system" : "url",
      "value" : "https://www.inera.se"
    }]
  }],
  "description" : "Logisk modell för responsens informationsstruktur i tjänstekontraktet SendMedicalCertificateAnswer\n(RIV-TA urn:riv:insuranceprocess:healthreporting:SendMedicalCertificateAnswer:1).",
  "copyright" : "Copyright 2024 Inera AB. Licensieras under Creative Commons Attribution 4.0.",
  "fhirVersion" : "4.0.1",
  "kind" : "logical",
  "abstract" : false,
  "type" : "https://fhir.inera.se/ig/insuranceprocess-healthreporting/StructureDefinition/sendmedicalcertificateanswer",
  "baseDefinition" : "http://hl7.org/fhir/StructureDefinition/Base",
  "derivation" : "specialization",
  "differential" : {
    "element" : [{
      "id" : "sendmedicalcertificateanswer",
      "path" : "sendmedicalcertificateanswer",
      "short" : "SendMedicalCertificateAnswer",
      "definition" : "Logisk modell för responsens informationsstruktur i tjänstekontraktet SendMedicalCertificateAnswer\n(RIV-TA urn:riv:insuranceprocess:healthreporting:SendMedicalCertificateAnswer:1)."
    },
    {
      "id" : "sendmedicalcertificateanswer.result",
      "path" : "sendmedicalcertificateanswer.result",
      "short" : "Resultatinformation",
      "definition" : "Resultatinformation",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "BackboneElement"
      }]
    },
    {
      "id" : "sendmedicalcertificateanswer.result.resultCode",
      "path" : "sendmedicalcertificateanswer.result.resultCode",
      "short" : "Resultatkod (OK, ERROR, INFO)",
      "definition" : "Resultatkod (OK, ERROR, INFO)",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "sendmedicalcertificateanswer.result.infoText",
      "path" : "sendmedicalcertificateanswer.result.infoText",
      "short" : "Extra information om anropets utgång",
      "definition" : "Extra information om anropets utgång",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "sendmedicalcertificateanswer.result.errorId",
      "path" : "sendmedicalcertificateanswer.result.errorId",
      "short" : "Felkategori",
      "definition" : "Felkategori",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "sendmedicalcertificateanswer.result.errorText",
      "path" : "sendmedicalcertificateanswer.result.errorText",
      "short" : "Beskrivande text för felet",
      "definition" : "Beskrivande text för felet",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    }]
  }
}

```
