# Hem - insuranceprocess: healthreporting v3.1.1

* [**Table of Contents**](toc.md)
* **Hem**

## Hem

| | |
| :--- | :--- |
| *Official URL*:https://fhir.inera.se/ig/insuranceprocess-healthreporting/ImplementationGuide/inera.insuranceprocess-healthreporting | *Version*:3.1.1 |
| Active as of 2026-10-12 | *Computable Name*:insuranceprocesshealthreporting |
| **Copyright/Legal**: Copyright 2024 Inera AB. Licensieras under Creative Commons Attribution 4.0. | |

# insuranceprocess: healthreporting

**TKB-version:** 3.1.1 · **IG-version:** 3.1.1 · **Källa:** Bitbucket-tagg `insuranceprocess_healthreporting_3.1.1` 

## Översikt

* Beskrivning: Svenskt kortnamn
  * Denna tjänstedomän syftar till att hantera vårdgivarperspektivet på sjukskrivningsprocessen för en individ. Tjänstekontrakten inom domänen hanterar vårdens, Försäkringskassans och invånarens behov av e-tjänster för hantering av läkarintyg (Blankett FK 7263). Dessutom hanteras stödprocesser för ärendehantering kring ett läkarintyg sk frågor och svar. Även processer för att hantera frågor i svar från Försäkringskassan till vårdens sk ärendelåda ingår.: intygshantering
* Beskrivning: Svenskt namn
  * Denna tjänstedomän syftar till att hantera vårdgivarperspektivet på sjukskrivningsprocessen för en individ. Tjänstekontrakten inom domänen hanterar vårdens, Försäkringskassans och invånarens behov av e-tjänster för hantering av läkarintyg (Blankett FK 7263). Dessutom hanteras stödprocesser för ärendehantering kring ett läkarintyg sk frågor och svar. Även processer för att hantera frågor i svar från Försäkringskassan till vårdens sk ärendelåda ingår.: vård- och omsorg kärnprocess:hälsorelaterade tillstånd:intygshantering
* Beskrivning: Typ
  * Denna tjänstedomän syftar till att hantera vårdgivarperspektivet på sjukskrivningsprocessen för en individ. Tjänstekontrakten inom domänen hanterar vårdens, Försäkringskassans och invånarens behov av e-tjänster för hantering av läkarintyg (Blankett FK 7263). Dessutom hanteras stödprocesser för ärendehantering kring ett läkarintyg sk frågor och svar. Även processer för att hantera frågor i svar från Försäkringskassan till vårdens sk ärendelåda ingår.: Nationell tjänstedomän
* Beskrivning: Källkod
  * Denna tjänstedomän syftar till att hantera vårdgivarperspektivet på sjukskrivningsprocessen för en individ. Tjänstekontrakten inom domänen hanterar vårdens, Försäkringskassans och invånarens behov av e-tjänster för hantering av läkarintyg (Blankett FK 7263). Dessutom hanteras stödprocesser för ärendehantering kring ett läkarintyg sk frågor och svar. Även processer för att hantera frågor i svar från Försäkringskassan till vårdens sk ärendelåda ingår.: [Bitbucket](https://bitbucket.org/rivta-domains/riv.insuranceprocess.healthreporting/src)
* Beskrivning: Ärenden
  * Denna tjänstedomän syftar till att hantera vårdgivarperspektivet på sjukskrivningsprocessen för en individ. Tjänstekontrakten inom domänen hanterar vårdens, Försäkringskassans och invånarens behov av e-tjänster för hantering av läkarintyg (Blankett FK 7263). Dessutom hanteras stödprocesser för ärendehantering kring ett läkarintyg sk frågor och svar. Även processer för att hantera frågor i svar från Försäkringskassan till vårdens sk ärendelåda ingår.: [Bitbucket issues](https://bitbucket.org/rivta-domains/riv.insuranceprocess.healthreporting/issues)
* Beskrivning: Underlag för denna IG
  * Denna tjänstedomän syftar till att hantera vårdgivarperspektivet på sjukskrivningsprocessen för en individ. Tjänstekontrakten inom domänen hanterar vårdens, Försäkringskassans och invånarens behov av e-tjänster för hantering av läkarintyg (Blankett FK 7263). Dessutom hanteras stödprocesser för ärendehantering kring ett läkarintyg sk frågor och svar. Även processer för att hantera frågor i svar från Försäkringskassan till vårdens sk ärendelåda ingår.: Version 3.1.1 ·[tagg insuranceprocess_healthreporting_3.1.1](https://bitbucket.org/rivta-domains/riv.insuranceprocess.healthreporting/src/insuranceprocess_healthreporting_3.1.1)
* Beskrivning: RIV-TA-portalen
  * Denna tjänstedomän syftar till att hantera vårdgivarperspektivet på sjukskrivningsprocessen för en individ. Tjänstekontrakten inom domänen hanterar vårdens, Försäkringskassans och invånarens behov av e-tjänster för hantering av läkarintyg (Blankett FK 7263). Dessutom hanteras stödprocesser för ärendehantering kring ett läkarintyg sk frågor och svar. Även processer för att hantera frågor i svar från Försäkringskassan till vårdens sk ärendelåda ingår.: [Alla tjänstedomäner](https://oskthu2.github.io/tkb-converter/rivta-portal/tjanstedomaner.html)·[Alla tjänstekontrakt](https://oskthu2.github.io/tkb-converter/rivta-portal/tjanstekontrakt.html)

FHIR Implementation Guide för tjänstedomänen **insuranceprocess: healthreporting** version 3.1.1. Genererad från Ineras Tjänstekontraktsbeskrivning (TKB).

Domänen innehåller följande tjänstekontrakt:

| | | |
| :--- | :--- | :--- |
| [RegisterMedicalCertificate](7-tjanstekontrakt.md#registermedicalcertificate) | 3.1 | Skicka ett komplett läkarintyg med informationsmängden enligt blankett FK7263 |
| [ReceiveMedicalCertificateQuestion](7-tjanstekontrakt.md#receivemedicalcertificatequestion) | 1.0 | Ta emot en fråga om ett läkarintyg |
| [ReceiveMedicalCertificateAnswer](7-tjanstekontrakt.md#receivemedicalcertificateanswer) | 1.0 | Ta emot ett svar på en fråga om ett läkarintyg |
| [SendMedicalCertificateQuestion](7-tjanstekontrakt.md#sendmedicalcertificatequestion) | 1.0 | Skicka en fråga om ett läkarintyg |
| [SendMedicalCertificateAnswer](7-tjanstekontrakt.md#sendmedicalcertificateanswer) | 1.0 | Skicka ett svar på en fråga om ett läkarintyg |
| [FindAllQuestions](7-tjanstekontrakt.md#findallquestions) | 1.0 | Söka bland frågor om läkarintyg |
| [FindAllAnswers](7-tjanstekontrakt.md#findallanswers) | 1.0 | Söka bland svar på frågor om läkarintyg |
| [DeleteQuestions](7-tjanstekontrakt.md#deletequestions) | 1.0 | Ta bort frågor om ett läkarintyg |
| [DeleteAnswers](7-tjanstekontrakt.md#deleteanswers) | 1.0 | Ta bort svar på frågor om ett läkarintyg |
| [RevokeMedicalCertificate](7-tjanstekontrakt.md#revokemedicalcertificate) | 1.0 | Makulera ett läkarintyg |
| [SendMedicalCertificate](7-tjanstekontrakt.md#sendmedicalcertificate) | 1.0 | Skicka ett läkarintyg |
| [ListCertificates](7-tjanstekontrakt.md#listcertificates) | 1.0 | Lista läkarintyg |
| [GetCertificate](7-tjanstekontrakt.md#getcertificate) | 1.0 | Hämta ett specifikt läkarintyg |
| [SetCertificateStatus](7-tjanstekontrakt.md#setcertificatestatus) | 1.0 | Sätta status på ett läkarintyg |

### Versioner och granskningar

| | | | |
| :--- | :--- | :--- | :--- |
| 3.1.1 | AB, TKB | [Arkitektur & Regelverk: Teknik: Godkänd](http://rivta.se/downloads/insuranceprocess_healthreporting/3.1.1/AL-T%20Granskning%20av%20insuranceprocess_healthreporting_3.1.1_RC2.docx) | [zip](http://rivta.se/downloads/insuranceprocess_healthreporting/3.1.1/ServiceContracts_insuranceprocess_healthreporting_3.1.1.zip)·[källkod](https://bitbucket.org/rivta-domains/riv.insuranceprocess.healthreporting/src/insuranceprocess_healthreporting_3.1.1) |
| 3.0.0 | TKB | Äldre granskningsprocess: Teknik: Godkänd | [zip](http://rivta.se/downloads/insuranceprocess_healthreporting/3.0.0/Servicecontracts_insuranceprocess_healthreporting_3.0.0.zip)·[källkod](https://bitbucket.org/rivta-domains/riv.insuranceprocess.healthreporting/src/TD_3_0_0_R) |
| trunk | TKB, AB |  | [källkod](https://bitbucket.org/rivta-domains/riv.insuranceprocess.healthreporting/src/master) |

*Källa: ögonblicksbild av DOMDB från 2021-08-24, via RIV-TA-portalen.*

## Innehåll

* [1 Inledning](1-inledning.md)
* [2 Versionsinformation](2-versionsinformation.md)
* [3 Tjänstedomänens arkitektur](3-tjanstedomanens-arkitektur.md)
* [4 Tjänstedomänens krav och regler](4-tjanstedomanens-krav-och-regler.md)
* [5 Tjänstedomänens meddelandemodeller](5-tjanstedomanens-meddelandemodeller.md)
* [6 Gemensamma informationskomponenter](6-gemensamma-informationskomponenter.md)
* [7 Tjänstekontrakt](7-tjanstekontrakt.md)
* [Artefakter](artifacts.md)

