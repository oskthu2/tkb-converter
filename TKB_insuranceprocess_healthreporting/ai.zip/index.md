# Hem - insuranceprocess: healthreporting v3.1.0

* [**Table of Contents**](toc.md)
* **Hem**

## Hem

| | |
| :--- | :--- |
| *Official URL*:https://fhir.inera.se/ig/insuranceprocess-healthreporting/ImplementationGuide/inera.insuranceprocess-healthreporting | *Version*:3.1.0 |
| Draft as of 2026-09-09 | *Computable Name*:insuranceprocesshealthreporting |
| **Copyright/Legal**: Copyright 2024 Inera AB. Licensieras under Creative Commons Attribution 4.0. | |

# insuranceprocess: healthreporting

## Översikt

FHIR Implementation Guide för tjänstedomänen **insuranceprocess: healthreporting** version 3.1.0. Genererad från Ineras Tjänstekontraktsbeskrivning (TKB).

Domänen innehåller följande tjänstekontrakt:

| | | |
| :--- | :--- | :--- |
| [RegisterMedicalCertificate](7-tjanstekontrakt.md#registermedicalcertificate) | 3.1 | Skicka ett komplett läkarintyg med informationsmängden enligt blankett FK7263 |
| [ReceiveMedicalCertificateQuestion](7-tjanstekontrakt.md#receivemedicalcertificatequestion) | 1.0 | Ta emot en fråga om ett läkarintyg |
| [ReceiveMedicalCertificateAnswer](7-tjanstekontrakt.md#receivemedicalcertificateanswer) | 1.0 | Ta emot ett svar på en fråga om ett läkarintyg |
| [SendMedicalCertificateQuestion](7-tjanstekontrakt.md#sendmedicalcertificatequestion) | 1.0 | Skicka en fråga om ett läkarintyg |
| [SendMedicalCertificateAnswer](7-tjanstekontrakt.md#sendmedicalcertificateanswer) | 1.0 | Skicka ett svar på en fråga om ett läkarintyg |
| [FindAllQuestions](7-tjanstekontrakt.md#findallquestions) | 1.0 | Söka bland frågor om läkarintyg |
| [FindAllAnswers](7-tjanstekontrakt.md#findallanswers) | 1.0 | Söka bland svar på frågor om läkarintyg |
| [DeleteQuestions](7-tjanstekontrakt.md#deletequestions) | 1.0 | Ta bort frågor om ett läkarintyg |
| [DeleteAnswers](7-tjanstekontrakt.md#deleteanswers) | 1.0 | Ta bort svar på frågor om ett läkarintyg |
| [RevokeMedicalCertificate](7-tjanstekontrakt.md#revokemedicalcertificate) | 1.0 | Makulera ett läkarintyg |
| [SendMedicalCertificate](7-tjanstekontrakt.md#sendmedicalcertificate) | 1.0 | Skicka ett läkarintyg |
| [ListCertificates](7-tjanstekontrakt.md#listcertificates) | 1.0 | Lista läkarintyg |
| [GetCertificate](7-tjanstekontrakt.md#getcertificate) | 1.0 | Hämta ett specifikt läkarintyg |
| [SetCertificateStatus](7-tjanstekontrakt.md#setcertificatestatus) | 1.0 | Sätta status på ett läkarintyg |

## Innehåll

* [1 Inledning](1-inledning.md)
* [2 Versionsinformation](2-versionsinformation.md)
* [3 Tjänstedomänens arkitektur](3-tjanstedomanens-arkitektur.md)
* [4 Tjänstedomänens krav och regler](4-tjanstedomanens-krav-och-regler.md)
* [5 Tjänstedomänens meddelandemodeller](5-tjanstedomanens-meddelandemodeller.md)
* [6 Gemensamma informationskomponenter](6-gemensamma-informationskomponenter.md)
* [7 Tjänstekontrakt](7-tjanstekontrakt.md)
* [Artefakter](artifacts.md)

