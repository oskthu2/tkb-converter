# inera.insuranceprocess-healthreporting#3.1.0: insuranceprocess: healthreporting

## Pages

* [Hem](index.md)
* [7 Tjänstekontrakt](7-tjanstekontrakt.md)
* [5 Tjänstedomänens meddelandemodeller](5-tjanstedomanens-meddelandemodeller.md)
* [Artifacts Summary](artifacts.md)
* [6 Gemensamma informationskomponenter](6-gemensamma-informationskomponenter.md)
* [3 Tjänstedomänens arkitektur](3-tjanstedomanens-arkitektur.md)
* [4 Tjänstedomänens krav och regler](4-tjanstedomanens-krav-och-regler.md)
* [2 Versionsinformation](2-versionsinformation.md)
* [1 Inledning](1-inledning.md)

## Resources

### CodeSystems

* [Aktivitetskod](CodeSystem-aktivitetskod-cs.md)
* [Amne](CodeSystem-amne-cs.md)
* [Nedsattningsgrad](CodeSystem-nedsattningsgrad-cs.md)
* [Referenstyp](CodeSystem-referenstyp-cs.md)
* [Status](CodeSystem-status-cs.md)
* [Vardkontakttyp](CodeSystem-vardkontakttyp-cs.md)

### ValueSets

* [Aktivitetskod — ValueSet](ValueSet-aktivitetskod-vs.md)
* [Amne — ValueSet](ValueSet-amne-vs.md)
* [Nedsattningsgrad — ValueSet](ValueSet-nedsattningsgrad-vs.md)
* [Referenstyp — ValueSet](ValueSet-referenstyp-vs.md)
* [Status — ValueSet](ValueSet-status-vs.md)
* [Vardkontakttyp — ValueSet](ValueSet-vardkontakttyp-vs.md)

### Logicals

* [DeleteAnswers — Request](StructureDefinition-deleteanswers-request.md)
* [DeleteAnswers](StructureDefinition-deleteanswers.md)
* [DeleteQuestions — Request](StructureDefinition-deletequestions-request.md)
* [DeleteQuestions](StructureDefinition-deletequestions.md)
* [FindAllAnswers — Request](StructureDefinition-findallanswers-request.md)
* [FindAllAnswers](StructureDefinition-findallanswers.md)
* [FindAllQuestions — Request](StructureDefinition-findallquestions-request.md)
* [FindAllQuestions](StructureDefinition-findallquestions.md)
* [GetCertificate — Request](StructureDefinition-getcertificate-request.md)
* [GetCertificate](StructureDefinition-getcertificate.md)
* [ListCertificates — Request](StructureDefinition-listcertificates-request.md)
* [ListCertificates](StructureDefinition-listcertificates.md)
* [ReceiveMedicalCertificateAnswer — Request](StructureDefinition-receivemedicalcertificateanswer-request.md)
* [ReceiveMedicalCertificateAnswer](StructureDefinition-receivemedicalcertificateanswer.md)
* [ReceiveMedicalCertificateQuestion — Request](StructureDefinition-receivemedicalcertificatequestion-request.md)
* [ReceiveMedicalCertificateQuestion](StructureDefinition-receivemedicalcertificatequestion.md)
* [RegisterMedicalCertificate — Request](StructureDefinition-registermedicalcertificate-request.md)
* [RegisterMedicalCertificate](StructureDefinition-registermedicalcertificate.md)
* [RevokeMedicalCertificate — Request](StructureDefinition-revokemedicalcertificate-request.md)
* [RevokeMedicalCertificate](StructureDefinition-revokemedicalcertificate.md)
* [SendMedicalCertificate — Request](StructureDefinition-sendmedicalcertificate-request.md)
* [SendMedicalCertificate](StructureDefinition-sendmedicalcertificate.md)
* [SendMedicalCertificateAnswer — Request](StructureDefinition-sendmedicalcertificateanswer-request.md)
* [SendMedicalCertificateAnswer](StructureDefinition-sendmedicalcertificateanswer.md)
* [SendMedicalCertificateQuestion — Request](StructureDefinition-sendmedicalcertificatequestion-request.md)
* [SendMedicalCertificateQuestion](StructureDefinition-sendmedicalcertificatequestion.md)
* [SetCertificateStatus — Request](StructureDefinition-setcertificatestatus-request.md)
* [SetCertificateStatus](StructureDefinition-setcertificatestatus.md)

### ImplementationGuides

* [insuranceprocess: healthreporting](index.md)
