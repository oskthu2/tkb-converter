# Hem - processdevelopment: infections v1.0.2

* [**Table of Contents**](toc.md)
* **Hem**

## Hem

| | |
| :--- | :--- |
| *Official URL*:https://fhir.inera.se/ig/processdevelopment-infections/ImplementationGuide/inera.processdevelopment-infections | *Version*:1.0.2 |
| Active as of 2026-11-09 | *Computable Name*:ProcessdevelopmentInfections |
| **Copyright/Legal**: Copyright 2024 Inera AB. Licensieras under Creative Commons Attribution 4.0. | |

# processdevelopment: infections

**TKB-version:** 1.0.2 · **IG-version:** 1.0.2 · **Källa:** Bitbucket-tagg `1.0.2` 

## Översikt

* Typ: Källkod
  * Applikationsspecifik tjänstedomän: [Bitbucket](https://bitbucket.org/rivta-domains/riv.processdevelopment.infections/src)
* Typ: Ärenden
  * Applikationsspecifik tjänstedomän: [Bitbucket issues](https://bitbucket.org/rivta-domains/riv.processdevelopment.infections/issues)
* Typ: Underlag för denna IG
  * Applikationsspecifik tjänstedomän: Version 1.0.2 ·[tagg 1.0.2](https://bitbucket.org/rivta-domains/riv.processdevelopment.infections/src/1.0.2)·[zip](https://bitbucket.org/rivta-domains/riv.processdevelopment.infections/get/1.0.2.zip)
* Typ: RIV-TA-portalen
  * Applikationsspecifik tjänstedomän: [Alla tjänstedomäner](https://oskthu2.github.io/tkb-converter/rivta-portal/tjanstedomaner.html)·[Alla tjänstekontrakt](https://oskthu2.github.io/tkb-converter/rivta-portal/tjanstekontrakt.html)

FHIR Implementation Guide för tjänstedomänen **processdevelopment: infections** version 1.0.2. Genererad från Ineras Tjänstekontraktsbeskrivning (TKB).

Domänen omfattar tjänstekontrakt för registrering och radering av tidigare registreringar av infektioner, antibiotikaanvändning, mikrobiologiska laboratoriesvar, åtgärder, tillstånd samt vårdtillfällen i det nationella Infektionsverktyget.

Domänen innehåller följande tjänstekontrakt:

| | | |
| :--- | :--- | :--- |
| [ProcessPrescriptionReason](7-tjanstekontrakt.md#processprescriptionreason) | 1.0 | Registrerar en ordinationsorsak. |
| [ProcessLaboratoryReport](7-tjanstekontrakt.md#processlaboratoryreport) | 1.0 | Registrerar ett laboratoriesvar. |
| [ProcessActivity](7-tjanstekontrakt.md#processactivity) | 1.0 | Registrerar en eller flera aktiviteter. |
| [ProcessCondition](7-tjanstekontrakt.md#processcondition) | 1.0 | Registrerar ett bedömt hälsorelaterat tillstånd. |
| [ProcessCareEncounter](7-tjanstekontrakt.md#processcareencounter) | 1.0 | Registrerar en patientplacering (vårdkontakt). |
| [DeletePrescriptionReason](7-tjanstekontrakt.md#deleteprescriptionreason) | 1.0 | Raderar en tidigare registrerad ordinationsorsak. |
| [DeletePrescription](7-tjanstekontrakt.md#deleteprescription) | 1.0 | Raderar en tidigare registrerad ordination. |
| [DeleteLaboratoryReport](7-tjanstekontrakt.md#deletelaboratoryreport) | 1.0 | Raderar ett tidigare registrerat laboratoriesvar. |
| [DeleteActivity](7-tjanstekontrakt.md#deleteactivity) | 1.0 | Raderar en tidigare registrerad aktivitet. |
| [DeleteCondition](7-tjanstekontrakt.md#deletecondition) | 1.0 | Raderar ett tidigare registrerat tillstånd. |
| [DeleteCareEncounter](7-tjanstekontrakt.md#deletecareencounter) | 1.0 | Raderar en tidigare registrerad vårdkontakt. |

### Versioner och granskningar

| | | | |
| :--- | :--- | :--- | :--- |
| 1.0.1 | TKB, TKB | Äldre granskningsprocess: Teknik: Godkänd | [zip](https://bitbucket.org/rivta-domains/riv.processdevelopment.infections/get/processdevelopment_infections_1.0.1.zip)·[källkod](https://bitbucket.org/rivta-domains/riv.processdevelopment.infections/src/processdevelopment_infections_1.0.1) |
| trunk |  |  | [källkod](https://bitbucket.org/rivta-domains/riv.processdevelopment.infections/src/master) |

*Zip-arkiven hämtas från taggarna på Bitbucket. Granskningsprotokollen publicerades på rivta.se och länkas inte härifrån.*

*Källa: ögonblicksbild av DOMDB från 2021-08-24, via RIV-TA-portalen.*

## Innehåll

* [1 Inledning](1-inledning.md)
* [2 Versionsinformation](2-versionsinformation.md)
* [3 Tjänstedomänens arkitektur](3-tjanstedomanens-arkitektur.md)
* [4 Tjänstedomänens krav och regler](4-tjanstedomanens-krav-och-regler.md)
* [5 Tjänstedomänens meddelandemodeller](5-tjanstedomanens-meddelandemodeller.md)
* [6 Gemensamma informationskomponenter](6-gemensamma-informationskomponenter.md)
* [7 Tjänstekontrakt](7-tjanstekontrakt.md)
* [Artefakter](artifacts.md)

