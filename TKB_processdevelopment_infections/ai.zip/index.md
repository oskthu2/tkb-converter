# Hem - processdevelopment: infections v1.0.2

* [**Table of Contents**](toc.md)
* **Hem**

## Hem

| | |
| :--- | :--- |
| *Official URL*:https://fhir.inera.se/ig/processdevelopment-infections/ImplementationGuide/inera.processdevelopment-infections | *Version*:1.0.2 |
| Draft as of 2026-09-17 | *Computable Name*:ProcessdevelopmentInfections |
| **Copyright/Legal**: Copyright 2024 Inera AB. Licensieras under Creative Commons Attribution 4.0. | |

# processdevelopment: infections

## Översikt

FHIR Implementation Guide för tjänstedomänen **processdevelopment: infections** version 1.0.2. Genererad från Ineras Tjänstekontraktsbeskrivning (TKB).

Domänen omfattar tjänstekontrakt för registrering och radering av tidigare registreringar av infektioner, antibiotikaanvändning, mikrobiologiska laboratoriesvar, åtgärder, tillstånd samt vårdtillfällen i det nationella Infektionsverktyget.

Domänen innehåller följande tjänstekontrakt:

| | | |
| :--- | :--- | :--- |
| [ProcessPrescriptionReason](7-tjanstekontrakt.md#processprescriptionreason) | 1.0 | Registrerar en ordinationsorsak. |
| [ProcessLaboratoryReport](7-tjanstekontrakt.md#processlaboratoryreport) | 1.0 | Registrerar ett laboratoriesvar. |
| [ProcessActivity](7-tjanstekontrakt.md#processactivity) | 1.0 | Registrerar en eller flera aktiviteter. |
| [ProcessCondition](7-tjanstekontrakt.md#processcondition) | 1.0 | Registrerar ett bedömt hälsorelaterat tillstånd. |
| [ProcessCareEncounter](7-tjanstekontrakt.md#processcareencounter) | 1.0 | Registrerar en patientplacering (vårdkontakt). |
| [DeletePrescriptionReason](7-tjanstekontrakt.md#deleteprescriptionreason) | 1.0 | Raderar en tidigare registrerad ordinationsorsak. |
| [DeletePrescription](7-tjanstekontrakt.md#deleteprescription) | 1.0 | Raderar en tidigare registrerad ordination. |
| [DeleteLaboratoryReport](7-tjanstekontrakt.md#deletelaboratoryreport) | 1.0 | Raderar ett tidigare registrerat laboratoriesvar. |
| [DeleteActivity](7-tjanstekontrakt.md#deleteactivity) | 1.0 | Raderar en tidigare registrerad aktivitet. |
| [DeleteCondition](7-tjanstekontrakt.md#deletecondition) | 1.0 | Raderar ett tidigare registrerat tillstånd. |
| [DeleteCareEncounter](7-tjanstekontrakt.md#deletecareencounter) | 1.0 | Raderar en tidigare registrerad vårdkontakt. |

## Innehåll

* [1 Inledning](1-inledning.md)
* [2 Versionsinformation](2-versionsinformation.md)
* [3 Tjänstedomänens arkitektur](3-tjanstedomanens-arkitektur.md)
* [4 Tjänstedomänens krav och regler](4-tjanstedomanens-krav-och-regler.md)
* [5 Tjänstedomänens meddelandemodeller](5-tjanstedomanens-meddelandemodeller.md)
* [6 Gemensamma informationskomponenter](6-gemensamma-informationskomponenter.md)
* [7 Tjänstekontrakt](7-tjanstekontrakt.md)
* [Artefakter](artifacts.md)

