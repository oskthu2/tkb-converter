# inera.supportprocess-personalresources-interpretation#1.0.0: supportprocess: personalresources: interpretation — Tolkförmedling

## Pages

* [Hem](index.md)
* [7 Tjänstekontrakt](7-tjanstekontrakt.md)
* [5 Tjänstedomänens meddelandemodeller](5-tjanstedomanens-meddelandemodeller.md)
* [Artifacts Summary](artifacts.md)
* [6 Gemensamma informationskomponenter](6-gemensamma-informationskomponenter.md)
* [3 Tjänstedomänens arkitektur](3-tjanstedomanens-arkitektur.md)
* [4 Tjänstedomänens krav och regler](4-tjanstedomanens-krav-och-regler.md)
* [2 Versionsinformation](2-versionsinformation.md)
* [1 Inledning](1-inledning.md)

## Resources

### CodeSystems

* [BookingStateEnum](CodeSystem-bookingstate-cs.md)
* [ErrorCodeEnum](CodeSystem-errorcode-cs.md)
* [InquiryResponseAnswerEnum](CodeSystem-inquiryresponseanswer-cs.md)
* [InquiryStateEnum](CodeSystem-inquirystate-cs.md)
* [RequirementLevelEnum](CodeSystem-requirementlevel-cs.md)
* [ResultCodeEnum](CodeSystem-resultcode-cs.md)

### ValueSets

* [BookingStateEnum](ValueSet-bookingstate-vs.md)
* [ErrorCodeEnum](ValueSet-errorcode-vs.md)
* [InquiryResponseAnswerEnum](ValueSet-inquiryresponseanswer-vs.md)
* [InquiryStateEnum](ValueSet-inquirystate-vs.md)
* [RequirementLevelEnum](ValueSet-requirementlevel-vs.md)
* [ResultCodeEnum](ValueSet-resultcode-vs.md)

### Logicals

* [AnswerInquiry — Begäran](StructureDefinition-answerinquiry.md)
* [CreateBooking — Svar](StructureDefinition-createbooking-response.md)
* [CreateBooking — Begäran](StructureDefinition-createbooking.md)
* [Resultat (ResultType)](StructureDefinition-interpretation-result.md)
* [ListBookings — Begäran](StructureDefinition-listbookings-request.md)
* [ListBookings — Svar](StructureDefinition-listbookings.md)
* [ListInquiries — Begäran](StructureDefinition-listinquiries-request.md)
* [ListInquiries — Svar](StructureDefinition-listinquiries.md)
* [UpdateBooking — Begäran](StructureDefinition-updatebooking.md)

### ImplementationGuides

* [supportprocess: personalresources: interpretation — Tolkförmedling](index.md)
