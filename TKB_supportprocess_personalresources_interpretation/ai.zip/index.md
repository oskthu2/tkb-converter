# Hem - supportprocess: personalresources: interpretation — Tolkförmedling v1.0.0

* [**Table of Contents**](toc.md)
* **Hem**

## Hem

| | |
| :--- | :--- |
| *Official URL*:https://fhir.inera.se/ig/supportprocess-personalresources-interpretation/ImplementationGuide/inera.supportprocess-personalresources-interpretation | *Version*:1.0.0 |
| Draft as of 2026-09-26 | *Computable Name*:supportprocesspersonalresourcesinterpretation |
| **Copyright/Legal**: Copyright 2024 Inera AB. Licensieras under Creative Commons Attribution 4.0. | |

# supportprocess: personalresources: interpretation — Tolkförmedling

## Översikt

FHIR Implementation Guide för tjänstedomänen **supportprocess: personalresources: interpretation** ("Operativt processtöd: personalresurser: tolkförmedling") version 1.0. Genererad från Ineras Tjänstekontraktsbeskrivning (TKB).

Domänen låter tolkförmedlingars system hämta och besvara förfrågningar om tolkuppdrag samt skapa, hämta och uppdatera beställningar i Tolkportalen (Stockholms läns landsting).

RIV-TA namnrymd: `urn:riv:supportprocess:personalresources:interpretation`

Domänen innehåller följande tjänstekontrakt:

| | | |
| :--- | :--- | :--- |
| [AnswerInquiry](7-tjanstekontrakt.md#answerinquiry) | 1.0 | Besvarar en förfrågan om tolkuppdrag |
| [ListBookings](7-tjanstekontrakt.md#listbookings) | 1.0 | Hämtar tolkförmedlingens beställningar från Tolkportalen |
| [ListInquiries](7-tjanstekontrakt.md#listinquiries) | 1.0 | Hämtar förfrågningar om tolkuppdrag från Tolkportalen |
| [UpdateBooking](7-tjanstekontrakt.md#updatebooking) | 1.0 | Uppdaterar beställningsinformation i Tolkportalen |
| [CreateBooking](7-tjanstekontrakt.md#createbooking) | 1.0 | Registrerar en inringd beställning i Tolkportalen |

**Källa:** TKB-dokumentet (`TKB_supportprocess_personalresources_interpretation.docx`, version 1.0_RC1, 2017-07-10) från Bitbucket `rivta-domains/riv.supportprocess.personalresources.interpretation`, commit `010d6f367f37` på `master` (repot har inga taggar).

## Innehåll

* [1 Inledning](1-inledning.md)
* [2 Versionsinformation](2-versionsinformation.md)
* [3 Tjänstedomänens arkitektur](3-tjanstedomanens-arkitektur.md)
* [4 Tjänstedomänens krav och regler](4-tjanstedomanens-krav-och-regler.md)
* [5 Tjänstedomänens meddelandemodeller](5-tjanstedomanens-meddelandemodeller.md)
* [6 Gemensamma informationskomponenter](6-gemensamma-informationskomponenter.md)
* [7 Tjänstekontrakt](7-tjanstekontrakt.md)
* [Artefakter](artifacts.md)

