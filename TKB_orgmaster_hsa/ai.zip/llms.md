# inera.orgmaster-hsa#1.0.0: orgmaster: hsa

## Pages

* [Hem](index.md)
* [2 Generella regler](2-generella-regler.md)
* [7 Tjänstekontrakt](7-tjanstekontrakt.md)
* [8 Datatyper](8-datatyper.md)
* [Artifacts Summary](artifacts.md)
* [1 Inledning](1-inledning.md)

## Resources

### Logicals

* [GetHsaPerson — Request](StructureDefinition-gethsaperson-request.md)
* [GetHsaPerson — Response](StructureDefinition-gethsaperson.md)
* [GetHsaUnit — Request](StructureDefinition-gethsaunit-request.md)
* [GetHsaUnit — Response](StructureDefinition-gethsaunit.md)
* [GetHsaUnitList — Request](StructureDefinition-gethsaunitlist-request.md)
* [GetHsaUnitList — Response](StructureDefinition-gethsaunitlist.md)
* [GetMiuForPerson — Request](StructureDefinition-getmiuforperson-request.md)
* [GetMiuForPerson — Response](StructureDefinition-getmiuforperson.md)
* [GetPersonsWithCommissionAtHealthCareUnit — Request](StructureDefinition-getpersonswithcommissionathealthcareunit-request.md)
* [GetPersonsWithCommissionAtHealthCareUnit — Response](StructureDefinition-getpersonswithcommissionathealthcareunit.md)

### ImplementationGuides

* [orgmaster: hsa](index.md)
