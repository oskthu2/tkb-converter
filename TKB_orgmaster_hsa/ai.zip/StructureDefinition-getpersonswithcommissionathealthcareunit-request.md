# GetPersonsWithCommissionAtHealthCareUnit — Request - orgmaster: hsa v1.0.0-snapshot

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **GetPersonsWithCommissionAtHealthCareUnit — Request**

## Logical Model: GetPersonsWithCommissionAtHealthCareUnit — Request 

| | |
| :--- | :--- |
| *Official URL*:https://fhir.inera.se/ig/orgmaster-hsa/StructureDefinition/getpersonswithcommissionathealthcareunit-request | *Version*:1.0 |
| Draft as of 2026-10-08 | *Computable Name*:GetPersonsWithCommissionAtHealthCareUnitRequest |
| **Copyright/Legal**: Copyright 2024 Inera AB. Licensieras under Creative Commons Attribution 4.0. | |

 
Logisk modell för begäran i GetPersonsWithCommissionAtHealthCareUnit (urn:riv:orgmaster:hsa:GetPersonsWithCommissionAtHealthCareUnitResponder:1, GetPersonsWithCommissionAtHealthCareUnitType), inklusive SOAP-huvuden enligt WSDL. 

**Usages:**

* This Logical Model is not used by any profiles in this Specification

You can also check for [usages in the FHIR IG Statistics](https://packages2.fhir.org/xig/resource/inera.orgmaster-hsa|current/StructureDefinition/StructureDefinition-getpersonswithcommissionathealthcareunit-request.json)

### Formal Views of Profile Content

 [Description of Profiles, Differentials, Snapshots and how the different presentations work](http://build.fhir.org/ig/FHIR/ig-guidance/readingIgs.html#structure-definitions). 

 

Other representations of profile: [CSV](StructureDefinition-getpersonswithcommissionathealthcareunit-request.csv), [Excel](StructureDefinition-getpersonswithcommissionathealthcareunit-request.xlsx) 



## Resource Content

```json
{
  "resourceType" : "StructureDefinition",
  "id" : "getpersonswithcommissionathealthcareunit-request",
  "extension" : [{
    "url" : "http://hl7.org/fhir/StructureDefinition/structuredefinition-type-characteristics",
    "valueCode" : "can-be-target"
  }],
  "url" : "https://fhir.inera.se/ig/orgmaster-hsa/StructureDefinition/getpersonswithcommissionathealthcareunit-request",
  "version" : "1.0",
  "name" : "GetPersonsWithCommissionAtHealthCareUnitRequest",
  "title" : "GetPersonsWithCommissionAtHealthCareUnit — Request",
  "status" : "draft",
  "date" : "2026-10-08T18:43:42+00:00",
  "contact" : [{
    "name" : "Inera Arkitektur",
    "telecom" : [{
      "system" : "url",
      "value" : "https://www.inera.se"
    }]
  }],
  "description" : "Logisk modell för begäran i GetPersonsWithCommissionAtHealthCareUnit\n(urn:riv:orgmaster:hsa:GetPersonsWithCommissionAtHealthCareUnitResponder:1, GetPersonsWithCommissionAtHealthCareUnitType), inklusive SOAP-huvuden enligt WSDL.",
  "copyright" : "Copyright 2024 Inera AB. Licensieras under Creative Commons Attribution 4.0.",
  "fhirVersion" : "4.0.1",
  "kind" : "logical",
  "abstract" : false,
  "type" : "https://fhir.inera.se/ig/orgmaster-hsa/StructureDefinition/getpersonswithcommissionathealthcareunit-request",
  "baseDefinition" : "http://hl7.org/fhir/StructureDefinition/Base",
  "derivation" : "specialization",
  "differential" : {
    "element" : [{
      "id" : "getpersonswithcommissionathealthcareunit-request",
      "path" : "getpersonswithcommissionathealthcareunit-request",
      "short" : "GetPersonsWithCommissionAtHealthCareUnit — Request",
      "definition" : "Logisk modell för begäran i GetPersonsWithCommissionAtHealthCareUnit\n(urn:riv:orgmaster:hsa:GetPersonsWithCommissionAtHealthCareUnitResponder:1, GetPersonsWithCommissionAtHealthCareUnitType), inklusive SOAP-huvuden enligt WSDL."
    },
    {
      "id" : "getpersonswithcommissionathealthcareunit-request.logicalAddress",
      "path" : "getpersonswithcommissionathealthcareunit-request.logicalAddress",
      "short" : "logicalAddress",
      "definition" : "SOAP-huvud LogicalAddress. Search base",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "getpersonswithcommissionathealthcareunit-request.hsaIdentity",
      "path" : "getpersonswithcommissionathealthcareunit-request.hsaIdentity",
      "short" : "hsaIdentity",
      "definition" : "hsaIdentity",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "getpersonswithcommissionathealthcareunit-request.searchBase",
      "path" : "getpersonswithcommissionathealthcareunit-request.searchBase",
      "short" : "searchBase",
      "definition" : "searchBase",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "getpersonswithcommissionathealthcareunit-request.paTitleCodes",
      "path" : "getpersonswithcommissionathealthcareunit-request.paTitleCodes",
      "short" : "paTitleCodes",
      "definition" : "paTitleCodes",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "BackboneElement"
      }]
    },
    {
      "id" : "getpersonswithcommissionathealthcareunit-request.paTitleCodes.paTitleCode",
      "path" : "getpersonswithcommissionathealthcareunit-request.paTitleCodes.paTitleCode",
      "short" : "paTitleCode",
      "definition" : "paTitleCode",
      "min" : 0,
      "max" : "*",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "getpersonswithcommissionathealthcareunit-request.hsaTitles",
      "path" : "getpersonswithcommissionathealthcareunit-request.hsaTitles",
      "short" : "hsaTitles",
      "definition" : "hsaTitles",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "BackboneElement"
      }]
    },
    {
      "id" : "getpersonswithcommissionathealthcareunit-request.hsaTitles.hsaTitle",
      "path" : "getpersonswithcommissionathealthcareunit-request.hsaTitles.hsaTitle",
      "short" : "hsaTitle",
      "definition" : "hsaTitle",
      "min" : 0,
      "max" : "*",
      "type" : [{
        "code" : "string"
      }]
    }]
  }
}

```
