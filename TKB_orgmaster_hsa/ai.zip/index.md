# Hem - orgmaster: hsa v1.0.0-snapshot

* [**Table of Contents**](toc.md)
* **Hem**

## Hem

| | |
| :--- | :--- |
| *Official URL*:https://fhir.inera.se/ig/orgmaster-hsa/ImplementationGuide/inera.orgmaster-hsa | *Version*:1.0.0-snapshot |
| Draft as of 2026-11-06 | *Computable Name*:orgmasterhsa |
| **Copyright/Legal**: Copyright 2024 Inera AB. Licensieras under Creative Commons Attribution 4.0. | |

# orgmaster: hsa

**TKB-version:** 1.0.0 · **IG-version:** 1.0.0-snapshot · **Källa:** Bitbucket-commit `f84df986cac4` (ingen tagg) 

## Översikt

* Beskrivning: Typ
  * Denna domän innehåller arbetsmaterial från ett lokalt e-remissprojekt. Kontrakten domänen har ersatts av infrastructure:directory:*: Nationell tjänstedomän
* Beskrivning: Anmärkning
  * Denna domän innehåller arbetsmaterial från ett lokalt e-remissprojekt. Kontrakten domänen har ersatts av infrastructure:directory:*: dold på rivta.se
* Beskrivning: Källkod
  * Denna domän innehåller arbetsmaterial från ett lokalt e-remissprojekt. Kontrakten domänen har ersatts av infrastructure:directory:*: [Bitbucket](https://bitbucket.org/rivta-domains/riv.orgmaster.hsa/src)
* Beskrivning: Ärenden
  * Denna domän innehåller arbetsmaterial från ett lokalt e-remissprojekt. Kontrakten domänen har ersatts av infrastructure:directory:*: [Bitbucket issues](https://bitbucket.org/rivta-domains/riv.orgmaster.hsa/issues)
* Beskrivning: Underlag för denna IG
  * Denna domän innehåller arbetsmaterial från ett lokalt e-remissprojekt. Kontrakten domänen har ersatts av infrastructure:directory:*: Version 1.0.0 ·[commit f84df986cac4](https://bitbucket.org/rivta-domains/riv.orgmaster.hsa/src/f84df986cac48d4caedfcfa414d99904b6d92978)·[zip](https://bitbucket.org/rivta-domains/riv.orgmaster.hsa/get/f84df986cac4.zip)
* Beskrivning: RIV-TA-portalen
  * Denna domän innehåller arbetsmaterial från ett lokalt e-remissprojekt. Kontrakten domänen har ersatts av infrastructure:directory:*: [Alla tjänstedomäner](https://oskthu2.github.io/tkb-converter/rivta-portal/tjanstedomaner.html)·[Alla tjänstekontrakt](https://oskthu2.github.io/tkb-converter/rivta-portal/tjanstekontrakt.html)

FHIR Implementation Guide för tjänstedomänen **orgmaster: hsa** (Organisationsinformation) version 1.0.0. Genererad från Ineras tjänstekontraktsbeskrivning, RevB (2012-11-27), och domänens WSDL- och XSD-filer.

Tjänstedomänen omfattar hämtning av organisationsinformation (enheter och personer) från en organisationskatalog, till exempel HSA.

Domänen innehåller följande tjänstekontrakt:

| | | |
| :--- | :--- | :--- |
| [GetHsaUnit](7-tjanstekontrakt.md#gethsaunit) | 1.0 | Hämtar information om en specifik enhet eller funktion |
| [GetHsaPerson](7-tjanstekontrakt.md#gethsaperson) | 1.0 | Hämtar information om en HSA-person |
| [GetMiuForPerson](7-tjanstekontrakt.md#getmiuforperson) | 1.0 | Hämtar medarbetaruppdrag för en person |
| [GetHsaUnitList](7-tjanstekontrakt.md#gethsaunitlist) | 1.0 | Hämtar en lista med enheter |
| [GetPersonsWithCommissionAtHealthCareUnit](7-tjanstekontrakt.md#getpersonswithcommissionathealthcareunit) | 1.0 | Hämtar personer med medarbetaruppdrag på en vårdenhet |

### Versioner och granskningar

| | | | |
| :--- | :--- | :--- | :--- |
| trunk | TKB |  | [källkod](https://bitbucket.org/rivta-domains/riv.orgmaster.hsa/src/master) |

*Zip-arkiven hämtas från taggarna på Bitbucket. Granskningsprotokollen publicerades på rivta.se och länkas inte härifrån.*

*Källa: ögonblicksbild av DOMDB från 2021-08-24, via RIV-TA-portalen.*

## Innehåll

* [1 Inledning](1-inledning.md)
* [2 Generella regler](2-generella-regler.md)
* [7 Tjänstekontrakt](7-tjanstekontrakt.md)
* [8 Datatyper](8-datatyper.md)
* [Artefakter](artifacts.md)

