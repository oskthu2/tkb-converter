# Hem - orgmaster: hsa v1.0.0-snapshot

* [**Table of Contents**](toc.md)
* **Hem**

## Hem

| | |
| :--- | :--- |
| *Official URL*:https://fhir.inera.se/ig/orgmaster-hsa/ImplementationGuide/inera.orgmaster-hsa | *Version*:1.0.0-snapshot |
| Draft as of 2026-10-08 | *Computable Name*:orgmasterhsa |
| **Copyright/Legal**: Copyright 2024 Inera AB. Licensieras under Creative Commons Attribution 4.0. | |

# orgmaster: hsa

**TKB-version:** 1.0.0 · **IG-version:** 1.0.0-snapshot · **Källa:** Bitbucket-commit `f84df986cac4` (ingen tagg) 

## Översikt

FHIR Implementation Guide för tjänstedomänen **orgmaster: hsa** (Organisationsinformation) version 1.0.0. Genererad från Ineras tjänstekontraktsbeskrivning, RevB (2012-11-27), och domänens WSDL- och XSD-filer.

Tjänstedomänen omfattar hämtning av organisationsinformation (enheter och personer) från en organisationskatalog, till exempel HSA.

Domänen innehåller följande tjänstekontrakt:

| | | |
| :--- | :--- | :--- |
| [GetHsaUnit](7-tjanstekontrakt.md#gethsaunit) | 1.0 | Hämtar information om en specifik enhet eller funktion |
| [GetHsaPerson](7-tjanstekontrakt.md#gethsaperson) | 1.0 | Hämtar information om en HSA-person |
| [GetMiuForPerson](7-tjanstekontrakt.md#getmiuforperson) | 1.0 | Hämtar medarbetaruppdrag för en person |
| [GetHsaUnitList](7-tjanstekontrakt.md#gethsaunitlist) | 1.0 | Hämtar en lista med enheter |
| [GetPersonsWithCommissionAtHealthCareUnit](7-tjanstekontrakt.md#getpersonswithcommissionathealthcareunit) | 1.0 | Hämtar personer med medarbetaruppdrag på en vårdenhet |

## Innehåll

* [1 Inledning](1-inledning.md)
* [2 Generella regler](2-generella-regler.md)
* [7 Tjänstekontrakt](7-tjanstekontrakt.md)
* [8 Datatyper](8-datatyper.md)
* [Artefakter](artifacts.md)

