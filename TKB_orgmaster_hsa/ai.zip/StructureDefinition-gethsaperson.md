# GetHsaPerson — Response - orgmaster: hsa v1.0.0-snapshot

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **GetHsaPerson — Response**

## Logical Model: GetHsaPerson — Response 

| | |
| :--- | :--- |
| *Official URL*:https://fhir.inera.se/ig/orgmaster-hsa/StructureDefinition/gethsaperson | *Version*:1.0 |
| Draft as of 2026-10-08 | *Computable Name*:GetHsaPerson |
| **Copyright/Legal**: Copyright 2024 Inera AB. Licensieras under Creative Commons Attribution 4.0. | |

 
Logisk modell för svaret i GetHsaPerson (urn:riv:orgmaster:hsa:GetHsaPersonResponder:1, GetHsaPersonResponseType). 

**Usages:**

* This Logical Model is not used by any profiles in this Specification

You can also check for [usages in the FHIR IG Statistics](https://packages2.fhir.org/xig/resource/inera.orgmaster-hsa|current/StructureDefinition/StructureDefinition-gethsaperson.json)

### Formal Views of Profile Content

 [Description of Profiles, Differentials, Snapshots and how the different presentations work](http://build.fhir.org/ig/FHIR/ig-guidance/readingIgs.html#structure-definitions). 

 

Other representations of profile: [CSV](StructureDefinition-gethsaperson.csv), [Excel](StructureDefinition-gethsaperson.xlsx) 



## Resource Content

```json
{
  "resourceType" : "StructureDefinition",
  "id" : "gethsaperson",
  "extension" : [{
    "url" : "http://hl7.org/fhir/StructureDefinition/structuredefinition-type-characteristics",
    "valueCode" : "can-be-target"
  }],
  "url" : "https://fhir.inera.se/ig/orgmaster-hsa/StructureDefinition/gethsaperson",
  "version" : "1.0",
  "name" : "GetHsaPerson",
  "title" : "GetHsaPerson — Response",
  "status" : "draft",
  "date" : "2026-10-08T18:43:42+00:00",
  "contact" : [{
    "name" : "Inera Arkitektur",
    "telecom" : [{
      "system" : "url",
      "value" : "https://www.inera.se"
    }]
  }],
  "description" : "Logisk modell för svaret i GetHsaPerson\n(urn:riv:orgmaster:hsa:GetHsaPersonResponder:1, GetHsaPersonResponseType).",
  "copyright" : "Copyright 2024 Inera AB. Licensieras under Creative Commons Attribution 4.0.",
  "fhirVersion" : "4.0.1",
  "kind" : "logical",
  "abstract" : false,
  "type" : "https://fhir.inera.se/ig/orgmaster-hsa/StructureDefinition/gethsaperson",
  "baseDefinition" : "http://hl7.org/fhir/StructureDefinition/Base",
  "derivation" : "specialization",
  "differential" : {
    "element" : [{
      "id" : "gethsaperson",
      "path" : "gethsaperson",
      "short" : "GetHsaPerson — Response",
      "definition" : "Logisk modell för svaret i GetHsaPerson\n(urn:riv:orgmaster:hsa:GetHsaPersonResponder:1, GetHsaPersonResponseType)."
    },
    {
      "id" : "gethsaperson.userInformations",
      "path" : "gethsaperson.userInformations",
      "short" : "userInformations",
      "definition" : "userInformations",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "BackboneElement"
      }]
    },
    {
      "id" : "gethsaperson.userInformations.userInformation",
      "path" : "gethsaperson.userInformations.userInformation",
      "short" : "userInformation",
      "definition" : "userInformation",
      "min" : 0,
      "max" : "*",
      "type" : [{
        "code" : "BackboneElement"
      }]
    },
    {
      "id" : "gethsaperson.userInformations.userInformation.personalPrescriptionCode",
      "path" : "gethsaperson.userInformations.userInformation.personalPrescriptionCode",
      "short" : "personalPrescriptionCode",
      "definition" : "personalPrescriptionCode",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "gethsaperson.userInformations.userInformation.description",
      "path" : "gethsaperson.userInformations.userInformation.description",
      "short" : "description",
      "definition" : "description",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "gethsaperson.userInformations.userInformation.paTitleCodes",
      "path" : "gethsaperson.userInformations.userInformation.paTitleCodes",
      "short" : "paTitleCodes",
      "definition" : "paTitleCodes",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "BackboneElement"
      }]
    },
    {
      "id" : "gethsaperson.userInformations.userInformation.paTitleCodes.paTitleCode",
      "path" : "gethsaperson.userInformations.userInformation.paTitleCodes.paTitleCode",
      "short" : "paTitleCode",
      "definition" : "paTitleCode",
      "min" : 0,
      "max" : "*",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "gethsaperson.userInformations.userInformation.paTitleNames",
      "path" : "gethsaperson.userInformations.userInformation.paTitleNames",
      "short" : "paTitleNames",
      "definition" : "paTitleNames",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "BackboneElement"
      }]
    },
    {
      "id" : "gethsaperson.userInformations.userInformation.paTitleNames.paTitleName",
      "path" : "gethsaperson.userInformations.userInformation.paTitleNames.paTitleName",
      "short" : "paTitleName",
      "definition" : "paTitleName",
      "min" : 0,
      "max" : "*",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "gethsaperson.userInformations.userInformation.mail",
      "path" : "gethsaperson.userInformations.userInformation.mail",
      "short" : "mail",
      "definition" : "mail",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "gethsaperson.userInformations.userInformation.givenName",
      "path" : "gethsaperson.userInformations.userInformation.givenName",
      "short" : "givenName",
      "definition" : "givenName",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "gethsaperson.userInformations.userInformation.hsaIdentity",
      "path" : "gethsaperson.userInformations.userInformation.hsaIdentity",
      "short" : "hsaIdentity",
      "definition" : "hsaIdentity",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "gethsaperson.userInformations.userInformation.hsaSwitchboardNumber",
      "path" : "gethsaperson.userInformations.userInformation.hsaSwitchboardNumber",
      "short" : "hsaSwitchboardNumber",
      "definition" : "hsaSwitchboardNumber",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "gethsaperson.userInformations.userInformation.hsaTelephoneNumbers",
      "path" : "gethsaperson.userInformations.userInformation.hsaTelephoneNumbers",
      "short" : "hsaTelephoneNumbers",
      "definition" : "hsaTelephoneNumbers",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "BackboneElement"
      }]
    },
    {
      "id" : "gethsaperson.userInformations.userInformation.hsaTelephoneNumbers.hsaTelephoneNumber",
      "path" : "gethsaperson.userInformations.userInformation.hsaTelephoneNumbers.hsaTelephoneNumber",
      "short" : "hsaTelephoneNumber",
      "definition" : "hsaTelephoneNumber",
      "min" : 0,
      "max" : "*",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "gethsaperson.userInformations.userInformation.labeledUri",
      "path" : "gethsaperson.userInformations.userInformation.labeledUri",
      "short" : "labeledUri",
      "definition" : "labeledUri",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "gethsaperson.userInformations.userInformation.languageKnowledgeCodes",
      "path" : "gethsaperson.userInformations.userInformation.languageKnowledgeCodes",
      "short" : "languageKnowledgeCodes",
      "definition" : "languageKnowledgeCodes",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "BackboneElement"
      }]
    },
    {
      "id" : "gethsaperson.userInformations.userInformation.languageKnowledgeCodes.languageKnowledgeCode",
      "path" : "gethsaperson.userInformations.userInformation.languageKnowledgeCodes.languageKnowledgeCode",
      "short" : "languageKnowledgeCode",
      "definition" : "languageKnowledgeCode",
      "min" : 0,
      "max" : "*",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "gethsaperson.userInformations.userInformation.mobileNumbers",
      "path" : "gethsaperson.userInformations.userInformation.mobileNumbers",
      "short" : "mobileNumbers",
      "definition" : "mobileNumbers",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "BackboneElement"
      }]
    },
    {
      "id" : "gethsaperson.userInformations.userInformation.mobileNumbers.mobileNumber",
      "path" : "gethsaperson.userInformations.userInformation.mobileNumbers.mobileNumber",
      "short" : "mobileNumber",
      "definition" : "mobileNumber",
      "min" : 0,
      "max" : "*",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "gethsaperson.userInformations.userInformation.facsimileTelephoneNumbers",
      "path" : "gethsaperson.userInformations.userInformation.facsimileTelephoneNumbers",
      "short" : "facsimileTelephoneNumbers",
      "definition" : "facsimileTelephoneNumbers",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "BackboneElement"
      }]
    },
    {
      "id" : "gethsaperson.userInformations.userInformation.facsimileTelephoneNumbers.facsimileTelephoneNumber",
      "path" : "gethsaperson.userInformations.userInformation.facsimileTelephoneNumbers.facsimileTelephoneNumber",
      "short" : "facsimileTelephoneNumber",
      "definition" : "facsimileTelephoneNumber",
      "min" : 0,
      "max" : "*",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "gethsaperson.userInformations.userInformation.nickName",
      "path" : "gethsaperson.userInformations.userInformation.nickName",
      "short" : "nickName",
      "definition" : "nickName",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "gethsaperson.userInformations.userInformation.smsTelephoneNumber",
      "path" : "gethsaperson.userInformations.userInformation.smsTelephoneNumber",
      "short" : "smsTelephoneNumber",
      "definition" : "smsTelephoneNumber",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "gethsaperson.userInformations.userInformation.specialityCodes",
      "path" : "gethsaperson.userInformations.userInformation.specialityCodes",
      "short" : "specialityCodes",
      "definition" : "specialityCodes",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "BackboneElement"
      }]
    },
    {
      "id" : "gethsaperson.userInformations.userInformation.specialityCodes.specialityCode",
      "path" : "gethsaperson.userInformations.userInformation.specialityCodes.specialityCode",
      "short" : "specialityCode",
      "definition" : "specialityCode",
      "min" : 0,
      "max" : "*",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "gethsaperson.userInformations.userInformation.specialityNames",
      "path" : "gethsaperson.userInformations.userInformation.specialityNames",
      "short" : "specialityNames",
      "definition" : "specialityNames",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "BackboneElement"
      }]
    },
    {
      "id" : "gethsaperson.userInformations.userInformation.specialityNames.specialityName",
      "path" : "gethsaperson.userInformations.userInformation.specialityNames.specialityName",
      "short" : "specialityName",
      "definition" : "specialityName",
      "min" : 0,
      "max" : "*",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "gethsaperson.userInformations.userInformation.sn",
      "path" : "gethsaperson.userInformations.userInformation.sn",
      "short" : "sn",
      "definition" : "sn",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "gethsaperson.userInformations.userInformation.telephoneHours",
      "path" : "gethsaperson.userInformations.userInformation.telephoneHours",
      "short" : "telephoneHours",
      "definition" : "telephoneHours",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "BackboneElement"
      }]
    },
    {
      "id" : "gethsaperson.userInformations.userInformation.telephoneHours.telephoneHour",
      "path" : "gethsaperson.userInformations.userInformation.telephoneHours.telephoneHour",
      "short" : "telephoneHour",
      "definition" : "telephoneHour",
      "min" : 0,
      "max" : "*",
      "type" : [{
        "code" : "BackboneElement"
      }]
    },
    {
      "id" : "gethsaperson.userInformations.userInformation.telephoneHours.telephoneHour.fromDay",
      "path" : "gethsaperson.userInformations.userInformation.telephoneHours.telephoneHour.fromDay",
      "short" : "fromDay",
      "definition" : "fromDay",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "integer"
      }]
    },
    {
      "id" : "gethsaperson.userInformations.userInformation.telephoneHours.telephoneHour.fromTime",
      "path" : "gethsaperson.userInformations.userInformation.telephoneHours.telephoneHour.fromTime",
      "short" : "fromTime",
      "definition" : "fromTime",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "time"
      }]
    },
    {
      "id" : "gethsaperson.userInformations.userInformation.telephoneHours.telephoneHour.fromTime2",
      "path" : "gethsaperson.userInformations.userInformation.telephoneHours.telephoneHour.fromTime2",
      "short" : "fromTime2",
      "definition" : "fromTime2",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "gethsaperson.userInformations.userInformation.telephoneHours.telephoneHour.toDay",
      "path" : "gethsaperson.userInformations.userInformation.telephoneHours.telephoneHour.toDay",
      "short" : "toDay",
      "definition" : "toDay",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "integer"
      }]
    },
    {
      "id" : "gethsaperson.userInformations.userInformation.telephoneHours.telephoneHour.toTime",
      "path" : "gethsaperson.userInformations.userInformation.telephoneHours.telephoneHour.toTime",
      "short" : "toTime",
      "definition" : "toTime",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "time"
      }]
    },
    {
      "id" : "gethsaperson.userInformations.userInformation.telephoneHours.telephoneHour.toTime2",
      "path" : "gethsaperson.userInformations.userInformation.telephoneHours.telephoneHour.toTime2",
      "short" : "toTime2",
      "definition" : "toTime2",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "gethsaperson.userInformations.userInformation.telephoneHours.telephoneHour.comment",
      "path" : "gethsaperson.userInformations.userInformation.telephoneHours.telephoneHour.comment",
      "short" : "comment",
      "definition" : "comment",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "gethsaperson.userInformations.userInformation.telephoneNumbers",
      "path" : "gethsaperson.userInformations.userInformation.telephoneNumbers",
      "short" : "telephoneNumbers",
      "definition" : "telephoneNumbers",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "BackboneElement"
      }]
    },
    {
      "id" : "gethsaperson.userInformations.userInformation.telephoneNumbers.telephoneNumber",
      "path" : "gethsaperson.userInformations.userInformation.telephoneNumbers.telephoneNumber",
      "short" : "telephoneNumber",
      "definition" : "telephoneNumber",
      "min" : 0,
      "max" : "*",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "gethsaperson.userInformations.userInformation.title",
      "path" : "gethsaperson.userInformations.userInformation.title",
      "short" : "title",
      "definition" : "title",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "gethsaperson.userInformations.userInformation.DN",
      "path" : "gethsaperson.userInformations.userInformation.DN",
      "short" : "DN",
      "definition" : "DN",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "gethsaperson.userInformations.userInformation.middleName",
      "path" : "gethsaperson.userInformations.userInformation.middleName",
      "short" : "middleName",
      "definition" : "middleName",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "gethsaperson.userInformations.userInformation.postalAddress",
      "path" : "gethsaperson.userInformations.userInformation.postalAddress",
      "short" : "postalAddress",
      "definition" : "postalAddress",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "BackboneElement"
      }]
    },
    {
      "id" : "gethsaperson.userInformations.userInformation.postalAddress.addressLine",
      "path" : "gethsaperson.userInformations.userInformation.postalAddress.addressLine",
      "short" : "addressLine",
      "definition" : "addressLine",
      "min" : 1,
      "max" : "*",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "gethsaperson.userInformations.userInformation.hsaTitles",
      "path" : "gethsaperson.userInformations.userInformation.hsaTitles",
      "short" : "hsaTitles",
      "definition" : "hsaTitles",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "BackboneElement"
      }]
    },
    {
      "id" : "gethsaperson.userInformations.userInformation.hsaTitles.hsaTitle",
      "path" : "gethsaperson.userInformations.userInformation.hsaTitles.hsaTitle",
      "short" : "hsaTitle",
      "definition" : "hsaTitle",
      "min" : 0,
      "max" : "*",
      "type" : [{
        "code" : "string"
      }]
    }]
  }
}

```
