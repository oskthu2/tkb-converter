# GetHsaUnit — Response - orgmaster: hsa v1.0.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **GetHsaUnit — Response**

## Logical Model: GetHsaUnit — Response 

| | |
| :--- | :--- |
| *Official URL*:https://fhir.inera.se/ig/orgmaster-hsa/StructureDefinition/gethsaunit | *Version*:1.0.0 |
| Draft as of 2026-09-28 | *Computable Name*:GetHsaUnit |
| **Copyright/Legal**: Copyright 2024 Inera AB. Licensieras under Creative Commons Attribution 4.0. | |

 
Logisk modell för svaret i GetHsaUnit (urn:riv:orgmaster:hsa:GetHsaUnitResponder:1, GetHsaUnitResponseType). 

**Usages:**

* This Logical Model is not used by any profiles in this Specification

You can also check for [usages in the FHIR IG Statistics](https://packages2.fhir.org/xig/resource/inera.orgmaster-hsa|current/StructureDefinition/StructureDefinition-gethsaunit.json)

### Formal Views of Profile Content

 [Description of Profiles, Differentials, Snapshots and how the different presentations work](http://build.fhir.org/ig/FHIR/ig-guidance/readingIgs.html#structure-definitions). 

 

Other representations of profile: [CSV](StructureDefinition-gethsaunit.csv), [Excel](StructureDefinition-gethsaunit.xlsx) 



## Resource Content

```json
{
  "resourceType" : "StructureDefinition",
  "id" : "gethsaunit",
  "extension" : [{
    "url" : "http://hl7.org/fhir/StructureDefinition/structuredefinition-type-characteristics",
    "valueCode" : "can-be-target"
  }],
  "url" : "https://fhir.inera.se/ig/orgmaster-hsa/StructureDefinition/gethsaunit",
  "version" : "1.0.0",
  "name" : "GetHsaUnit",
  "title" : "GetHsaUnit — Response",
  "status" : "draft",
  "date" : "2026-09-28T09:15:01+00:00",
  "contact" : [{
    "name" : "Inera Arkitektur",
    "telecom" : [{
      "system" : "url",
      "value" : "https://www.inera.se"
    }]
  }],
  "description" : "Logisk modell för svaret i GetHsaUnit\n(urn:riv:orgmaster:hsa:GetHsaUnitResponder:1, GetHsaUnitResponseType).",
  "copyright" : "Copyright 2024 Inera AB. Licensieras under Creative Commons Attribution 4.0.",
  "fhirVersion" : "4.0.1",
  "kind" : "logical",
  "abstract" : false,
  "type" : "https://fhir.inera.se/ig/orgmaster-hsa/StructureDefinition/gethsaunit",
  "baseDefinition" : "http://hl7.org/fhir/StructureDefinition/Base",
  "derivation" : "specialization",
  "differential" : {
    "element" : [{
      "id" : "gethsaunit",
      "path" : "gethsaunit",
      "short" : "GetHsaUnit — Response",
      "definition" : "Logisk modell för svaret i GetHsaUnit\n(urn:riv:orgmaster:hsa:GetHsaUnitResponder:1, GetHsaUnitResponseType)."
    },
    {
      "id" : "gethsaunit.careGiver",
      "path" : "gethsaunit.careGiver",
      "short" : "careGiver",
      "definition" : "careGiver",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "gethsaunit.parentHsaIdentity",
      "path" : "gethsaunit.parentHsaIdentity",
      "short" : "parentHsaIdentity",
      "definition" : "parentHsaIdentity",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "gethsaunit.unitPrescriptionCodes",
      "path" : "gethsaunit.unitPrescriptionCodes",
      "short" : "unitPrescriptionCodes",
      "definition" : "unitPrescriptionCodes",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "gethsaunit.alternateNames",
      "path" : "gethsaunit.alternateNames",
      "short" : "alternateNames",
      "definition" : "alternateNames",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "BackboneElement"
      }]
    },
    {
      "id" : "gethsaunit.alternateNames.alternateName",
      "path" : "gethsaunit.alternateNames.alternateName",
      "short" : "alternateName",
      "definition" : "alternateName",
      "min" : 0,
      "max" : "*",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "gethsaunit.alternateText",
      "path" : "gethsaunit.alternateText",
      "short" : "alternateText",
      "definition" : "alternateText",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "gethsaunit.businessClassifications",
      "path" : "gethsaunit.businessClassifications",
      "short" : "businessClassifications",
      "definition" : "businessClassifications",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "BackboneElement"
      }]
    },
    {
      "id" : "gethsaunit.businessClassifications.businessClassification",
      "path" : "gethsaunit.businessClassifications.businessClassification",
      "short" : "businessClassification",
      "definition" : "businessClassification",
      "min" : 0,
      "max" : "*",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "gethsaunit.businessClassificationCodes",
      "path" : "gethsaunit.businessClassificationCodes",
      "short" : "businessClassificationCodes",
      "definition" : "businessClassificationCodes",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "BackboneElement"
      }]
    },
    {
      "id" : "gethsaunit.businessClassificationCodes.businessClassificationCode",
      "path" : "gethsaunit.businessClassificationCodes.businessClassificationCode",
      "short" : "businessClassificationCode",
      "definition" : "businessClassificationCode",
      "min" : 0,
      "max" : "*",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "gethsaunit.businessTypes",
      "path" : "gethsaunit.businessTypes",
      "short" : "businessTypes",
      "definition" : "businessTypes",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "BackboneElement"
      }]
    },
    {
      "id" : "gethsaunit.businessTypes.businessType",
      "path" : "gethsaunit.businessTypes.businessType",
      "short" : "businessType",
      "definition" : "businessType",
      "min" : 0,
      "max" : "*",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "gethsaunit.careTypes",
      "path" : "gethsaunit.careTypes",
      "short" : "careTypes",
      "definition" : "careTypes",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "BackboneElement"
      }]
    },
    {
      "id" : "gethsaunit.careTypes.careType",
      "path" : "gethsaunit.careTypes.careType",
      "short" : "careType",
      "definition" : "careType",
      "min" : 0,
      "max" : "*",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "gethsaunit.county",
      "path" : "gethsaunit.county",
      "short" : "county",
      "definition" : "county",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "gethsaunit.countyCode",
      "path" : "gethsaunit.countyCode",
      "short" : "countyCode",
      "definition" : "countyCode",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "gethsaunit.description",
      "path" : "gethsaunit.description",
      "short" : "description",
      "definition" : "description",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "gethsaunit.directoryContact",
      "path" : "gethsaunit.directoryContact",
      "short" : "directoryContact",
      "definition" : "directoryContact",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "gethsaunit.displayOption",
      "path" : "gethsaunit.displayOption",
      "short" : "displayOption",
      "definition" : "displayOption",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "gethsaunit.dropInHours",
      "path" : "gethsaunit.dropInHours",
      "short" : "dropInHours",
      "definition" : "dropInHours",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "BackboneElement"
      }]
    },
    {
      "id" : "gethsaunit.dropInHours.dropInHour",
      "path" : "gethsaunit.dropInHours.dropInHour",
      "short" : "dropInHour",
      "definition" : "dropInHour",
      "min" : 0,
      "max" : "*",
      "type" : [{
        "code" : "BackboneElement"
      }]
    },
    {
      "id" : "gethsaunit.dropInHours.dropInHour.fromDay",
      "path" : "gethsaunit.dropInHours.dropInHour.fromDay",
      "short" : "fromDay",
      "definition" : "fromDay",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "integer"
      }]
    },
    {
      "id" : "gethsaunit.dropInHours.dropInHour.fromTime",
      "path" : "gethsaunit.dropInHours.dropInHour.fromTime",
      "short" : "fromTime",
      "definition" : "fromTime",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "time"
      }]
    },
    {
      "id" : "gethsaunit.dropInHours.dropInHour.fromTime2",
      "path" : "gethsaunit.dropInHours.dropInHour.fromTime2",
      "short" : "fromTime2",
      "definition" : "fromTime2",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "gethsaunit.dropInHours.dropInHour.toDay",
      "path" : "gethsaunit.dropInHours.dropInHour.toDay",
      "short" : "toDay",
      "definition" : "toDay",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "integer"
      }]
    },
    {
      "id" : "gethsaunit.dropInHours.dropInHour.toTime",
      "path" : "gethsaunit.dropInHours.dropInHour.toTime",
      "short" : "toTime",
      "definition" : "toTime",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "time"
      }]
    },
    {
      "id" : "gethsaunit.dropInHours.dropInHour.toTime2",
      "path" : "gethsaunit.dropInHours.dropInHour.toTime2",
      "short" : "toTime2",
      "definition" : "toTime2",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "gethsaunit.dropInHours.dropInHour.comment",
      "path" : "gethsaunit.dropInHours.dropInHour.comment",
      "short" : "comment",
      "definition" : "comment",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "gethsaunit.email",
      "path" : "gethsaunit.email",
      "short" : "email",
      "definition" : "email",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "gethsaunit.faxNumbers",
      "path" : "gethsaunit.faxNumbers",
      "short" : "faxNumbers",
      "definition" : "faxNumbers",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "BackboneElement"
      }]
    },
    {
      "id" : "gethsaunit.faxNumbers.faxNumber",
      "path" : "gethsaunit.faxNumbers.faxNumber",
      "short" : "faxNumber",
      "definition" : "faxNumber",
      "min" : 0,
      "max" : "*",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "gethsaunit.geographicalCoordinatesRt90",
      "path" : "gethsaunit.geographicalCoordinatesRt90",
      "short" : "geographicalCoordinatesRt90",
      "definition" : "geographicalCoordinatesRt90",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "BackboneElement"
      }]
    },
    {
      "id" : "gethsaunit.geographicalCoordinatesRt90.coordinatesType",
      "path" : "gethsaunit.geographicalCoordinatesRt90.coordinatesType",
      "short" : "coordinatesType",
      "definition" : "coordinatesType Heter type i schemat.",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "gethsaunit.geographicalCoordinatesRt90.x",
      "path" : "gethsaunit.geographicalCoordinatesRt90.x",
      "short" : "x",
      "definition" : "x",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "gethsaunit.geographicalCoordinatesRt90.y",
      "path" : "gethsaunit.geographicalCoordinatesRt90.y",
      "short" : "y",
      "definition" : "y",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "gethsaunit.healthCareArea",
      "path" : "gethsaunit.healthCareArea",
      "short" : "healthCareArea",
      "definition" : "healthCareArea",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "gethsaunit.hsaDestinationIndicators",
      "path" : "gethsaunit.hsaDestinationIndicators",
      "short" : "hsaDestinationIndicators",
      "definition" : "hsaDestinationIndicators",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "BackboneElement"
      }]
    },
    {
      "id" : "gethsaunit.hsaDestinationIndicators.hsaDestinationIndicator",
      "path" : "gethsaunit.hsaDestinationIndicators.hsaDestinationIndicator",
      "short" : "hsaDestinationIndicator",
      "definition" : "hsaDestinationIndicator",
      "min" : 0,
      "max" : "*",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "gethsaunit.hsaIdentity",
      "path" : "gethsaunit.hsaIdentity",
      "short" : "hsaIdentity",
      "definition" : "hsaIdentity",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "gethsaunit.hsaJpegLogotype",
      "path" : "gethsaunit.hsaJpegLogotype",
      "short" : "hsaJpegLogotype",
      "definition" : "hsaJpegLogotype",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "gethsaunit.invoiceAddress",
      "path" : "gethsaunit.invoiceAddress",
      "short" : "invoiceAddress",
      "definition" : "invoiceAddress",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "BackboneElement"
      }]
    },
    {
      "id" : "gethsaunit.invoiceAddress.addressLine",
      "path" : "gethsaunit.invoiceAddress.addressLine",
      "short" : "addressLine",
      "definition" : "addressLine",
      "min" : 1,
      "max" : "*",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "gethsaunit.jpegPhoto",
      "path" : "gethsaunit.jpegPhoto",
      "short" : "jpegPhoto",
      "definition" : "jpegPhoto",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "gethsaunit.labeledUri",
      "path" : "gethsaunit.labeledUri",
      "short" : "labeledUri",
      "definition" : "labeledUri",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "gethsaunit.location",
      "path" : "gethsaunit.location",
      "short" : "location",
      "definition" : "location",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "gethsaunit.webPage1177",
      "path" : "gethsaunit.webPage1177",
      "short" : "webPage1177",
      "definition" : "webPage1177",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "gethsaunit.managements",
      "path" : "gethsaunit.managements",
      "short" : "managements",
      "definition" : "managements",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "BackboneElement"
      }]
    },
    {
      "id" : "gethsaunit.managements.management",
      "path" : "gethsaunit.managements.management",
      "short" : "management",
      "definition" : "management",
      "min" : 0,
      "max" : "*",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "gethsaunit.municipality",
      "path" : "gethsaunit.municipality",
      "short" : "municipality",
      "definition" : "municipality",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "gethsaunit.municipalityCode",
      "path" : "gethsaunit.municipalityCode",
      "short" : "municipalityCode",
      "definition" : "municipalityCode",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "gethsaunit.municipalitySection",
      "path" : "gethsaunit.municipalitySection",
      "short" : "municipalitySection",
      "definition" : "municipalitySection",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "gethsaunit.getHsaUnitName",
      "path" : "gethsaunit.getHsaUnitName",
      "short" : "getHsaUnitName",
      "definition" : "getHsaUnitName Heter name i schemat.",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "gethsaunit.patientInformation",
      "path" : "gethsaunit.patientInformation",
      "short" : "patientInformation",
      "definition" : "patientInformation",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "gethsaunit.postalAddress",
      "path" : "gethsaunit.postalAddress",
      "short" : "postalAddress",
      "definition" : "postalAddress",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "BackboneElement"
      }]
    },
    {
      "id" : "gethsaunit.postalAddress.addressLine",
      "path" : "gethsaunit.postalAddress.addressLine",
      "short" : "addressLine",
      "definition" : "addressLine",
      "min" : 1,
      "max" : "*",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "gethsaunit.postalCode",
      "path" : "gethsaunit.postalCode",
      "short" : "postalCode",
      "definition" : "postalCode",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "gethsaunit.priceInformation",
      "path" : "gethsaunit.priceInformation",
      "short" : "priceInformation",
      "definition" : "priceInformation",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "gethsaunit.publicName",
      "path" : "gethsaunit.publicName",
      "short" : "publicName",
      "definition" : "publicName",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "gethsaunit.relatedUnits",
      "path" : "gethsaunit.relatedUnits",
      "short" : "relatedUnits",
      "definition" : "relatedUnits",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "BackboneElement"
      }]
    },
    {
      "id" : "gethsaunit.relatedUnits.relatedUnit",
      "path" : "gethsaunit.relatedUnits.relatedUnit",
      "short" : "relatedUnit",
      "definition" : "relatedUnit",
      "min" : 0,
      "max" : "*",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "gethsaunit.route",
      "path" : "gethsaunit.route",
      "short" : "route",
      "definition" : "route",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "gethsaunit.street",
      "path" : "gethsaunit.street",
      "short" : "street",
      "definition" : "street",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "gethsaunit.surgeryHours",
      "path" : "gethsaunit.surgeryHours",
      "short" : "surgeryHours",
      "definition" : "surgeryHours",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "BackboneElement"
      }]
    },
    {
      "id" : "gethsaunit.surgeryHours.surgeryHour",
      "path" : "gethsaunit.surgeryHours.surgeryHour",
      "short" : "surgeryHour",
      "definition" : "surgeryHour",
      "min" : 0,
      "max" : "*",
      "type" : [{
        "code" : "BackboneElement"
      }]
    },
    {
      "id" : "gethsaunit.surgeryHours.surgeryHour.fromDay",
      "path" : "gethsaunit.surgeryHours.surgeryHour.fromDay",
      "short" : "fromDay",
      "definition" : "fromDay",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "integer"
      }]
    },
    {
      "id" : "gethsaunit.surgeryHours.surgeryHour.fromTime",
      "path" : "gethsaunit.surgeryHours.surgeryHour.fromTime",
      "short" : "fromTime",
      "definition" : "fromTime",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "time"
      }]
    },
    {
      "id" : "gethsaunit.surgeryHours.surgeryHour.fromTime2",
      "path" : "gethsaunit.surgeryHours.surgeryHour.fromTime2",
      "short" : "fromTime2",
      "definition" : "fromTime2",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "gethsaunit.surgeryHours.surgeryHour.toDay",
      "path" : "gethsaunit.surgeryHours.surgeryHour.toDay",
      "short" : "toDay",
      "definition" : "toDay",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "integer"
      }]
    },
    {
      "id" : "gethsaunit.surgeryHours.surgeryHour.toTime",
      "path" : "gethsaunit.surgeryHours.surgeryHour.toTime",
      "short" : "toTime",
      "definition" : "toTime",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "time"
      }]
    },
    {
      "id" : "gethsaunit.surgeryHours.surgeryHour.toTime2",
      "path" : "gethsaunit.surgeryHours.surgeryHour.toTime2",
      "short" : "toTime2",
      "definition" : "toTime2",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "gethsaunit.surgeryHours.surgeryHour.comment",
      "path" : "gethsaunit.surgeryHours.surgeryHour.comment",
      "short" : "comment",
      "definition" : "comment",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "gethsaunit.switchboardNumber",
      "path" : "gethsaunit.switchboardNumber",
      "short" : "switchboardNumber",
      "definition" : "switchboardNumber",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "gethsaunit.telephoneHours",
      "path" : "gethsaunit.telephoneHours",
      "short" : "telephoneHours",
      "definition" : "telephoneHours",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "BackboneElement"
      }]
    },
    {
      "id" : "gethsaunit.telephoneHours.telephoneHour",
      "path" : "gethsaunit.telephoneHours.telephoneHour",
      "short" : "telephoneHour",
      "definition" : "telephoneHour",
      "min" : 0,
      "max" : "*",
      "type" : [{
        "code" : "BackboneElement"
      }]
    },
    {
      "id" : "gethsaunit.telephoneHours.telephoneHour.fromDay",
      "path" : "gethsaunit.telephoneHours.telephoneHour.fromDay",
      "short" : "fromDay",
      "definition" : "fromDay",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "integer"
      }]
    },
    {
      "id" : "gethsaunit.telephoneHours.telephoneHour.fromTime",
      "path" : "gethsaunit.telephoneHours.telephoneHour.fromTime",
      "short" : "fromTime",
      "definition" : "fromTime",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "time"
      }]
    },
    {
      "id" : "gethsaunit.telephoneHours.telephoneHour.fromTime2",
      "path" : "gethsaunit.telephoneHours.telephoneHour.fromTime2",
      "short" : "fromTime2",
      "definition" : "fromTime2",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "gethsaunit.telephoneHours.telephoneHour.toDay",
      "path" : "gethsaunit.telephoneHours.telephoneHour.toDay",
      "short" : "toDay",
      "definition" : "toDay",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "integer"
      }]
    },
    {
      "id" : "gethsaunit.telephoneHours.telephoneHour.toTime",
      "path" : "gethsaunit.telephoneHours.telephoneHour.toTime",
      "short" : "toTime",
      "definition" : "toTime",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "time"
      }]
    },
    {
      "id" : "gethsaunit.telephoneHours.telephoneHour.toTime2",
      "path" : "gethsaunit.telephoneHours.telephoneHour.toTime2",
      "short" : "toTime2",
      "definition" : "toTime2",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "gethsaunit.telephoneHours.telephoneHour.comment",
      "path" : "gethsaunit.telephoneHours.telephoneHour.comment",
      "short" : "comment",
      "definition" : "comment",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "gethsaunit.telephoneNumbers",
      "path" : "gethsaunit.telephoneNumbers",
      "short" : "telephoneNumbers",
      "definition" : "telephoneNumbers",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "BackboneElement"
      }]
    },
    {
      "id" : "gethsaunit.telephoneNumbers.telephoneNumber",
      "path" : "gethsaunit.telephoneNumbers.telephoneNumber",
      "short" : "telephoneNumber",
      "definition" : "telephoneNumber",
      "min" : 0,
      "max" : "*",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "gethsaunit.textTelephoneNumbers",
      "path" : "gethsaunit.textTelephoneNumbers",
      "short" : "textTelephoneNumbers",
      "definition" : "textTelephoneNumbers",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "BackboneElement"
      }]
    },
    {
      "id" : "gethsaunit.textTelephoneNumbers.textTelephoneNumber",
      "path" : "gethsaunit.textTelephoneNumbers.textTelephoneNumber",
      "short" : "textTelephoneNumber",
      "definition" : "textTelephoneNumber",
      "min" : 0,
      "max" : "*",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "gethsaunit.unitExtraInformation",
      "path" : "gethsaunit.unitExtraInformation",
      "short" : "unitExtraInformation",
      "definition" : "unitExtraInformation",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "gethsaunit.unitFunctions",
      "path" : "gethsaunit.unitFunctions",
      "short" : "unitFunctions",
      "definition" : "unitFunctions",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "BackboneElement"
      }]
    },
    {
      "id" : "gethsaunit.unitFunctions.unitFunction",
      "path" : "gethsaunit.unitFunctions.unitFunction",
      "short" : "unitFunction",
      "definition" : "unitFunction",
      "min" : 0,
      "max" : "*",
      "type" : [{
        "code" : "BackboneElement"
      }]
    },
    {
      "id" : "gethsaunit.unitFunctions.unitFunction.hsaUnitFunctionName",
      "path" : "gethsaunit.unitFunctions.unitFunction.hsaUnitFunctionName",
      "short" : "hsaUnitFunctionName",
      "definition" : "hsaUnitFunctionName Heter name i schemat.",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "gethsaunit.unitFunctions.unitFunction.telephoneHours",
      "path" : "gethsaunit.unitFunctions.unitFunction.telephoneHours",
      "short" : "telephoneHours",
      "definition" : "telephoneHours",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "BackboneElement"
      }]
    },
    {
      "id" : "gethsaunit.unitFunctions.unitFunction.telephoneHours.telephoneHour",
      "path" : "gethsaunit.unitFunctions.unitFunction.telephoneHours.telephoneHour",
      "short" : "telephoneHour",
      "definition" : "telephoneHour",
      "min" : 0,
      "max" : "*",
      "type" : [{
        "code" : "BackboneElement"
      }]
    },
    {
      "id" : "gethsaunit.unitFunctions.unitFunction.telephoneHours.telephoneHour.fromDay",
      "path" : "gethsaunit.unitFunctions.unitFunction.telephoneHours.telephoneHour.fromDay",
      "short" : "fromDay",
      "definition" : "fromDay",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "integer"
      }]
    },
    {
      "id" : "gethsaunit.unitFunctions.unitFunction.telephoneHours.telephoneHour.fromTime",
      "path" : "gethsaunit.unitFunctions.unitFunction.telephoneHours.telephoneHour.fromTime",
      "short" : "fromTime",
      "definition" : "fromTime",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "time"
      }]
    },
    {
      "id" : "gethsaunit.unitFunctions.unitFunction.telephoneHours.telephoneHour.fromTime2",
      "path" : "gethsaunit.unitFunctions.unitFunction.telephoneHours.telephoneHour.fromTime2",
      "short" : "fromTime2",
      "definition" : "fromTime2",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "gethsaunit.unitFunctions.unitFunction.telephoneHours.telephoneHour.toDay",
      "path" : "gethsaunit.unitFunctions.unitFunction.telephoneHours.telephoneHour.toDay",
      "short" : "toDay",
      "definition" : "toDay",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "integer"
      }]
    },
    {
      "id" : "gethsaunit.unitFunctions.unitFunction.telephoneHours.telephoneHour.toTime",
      "path" : "gethsaunit.unitFunctions.unitFunction.telephoneHours.telephoneHour.toTime",
      "short" : "toTime",
      "definition" : "toTime",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "time"
      }]
    },
    {
      "id" : "gethsaunit.unitFunctions.unitFunction.telephoneHours.telephoneHour.toTime2",
      "path" : "gethsaunit.unitFunctions.unitFunction.telephoneHours.telephoneHour.toTime2",
      "short" : "toTime2",
      "definition" : "toTime2",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "gethsaunit.unitFunctions.unitFunction.telephoneHours.telephoneHour.comment",
      "path" : "gethsaunit.unitFunctions.unitFunction.telephoneHours.telephoneHour.comment",
      "short" : "comment",
      "definition" : "comment",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "gethsaunit.unitFunctions.unitFunction.telephoneNumbers",
      "path" : "gethsaunit.unitFunctions.unitFunction.telephoneNumbers",
      "short" : "telephoneNumbers",
      "definition" : "telephoneNumbers",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "BackboneElement"
      }]
    },
    {
      "id" : "gethsaunit.unitFunctions.unitFunction.telephoneNumbers.telephoneNumber",
      "path" : "gethsaunit.unitFunctions.unitFunction.telephoneNumbers.telephoneNumber",
      "short" : "telephoneNumber",
      "definition" : "telephoneNumber",
      "min" : 0,
      "max" : "*",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "gethsaunit.unitTemporaryInformation",
      "path" : "gethsaunit.unitTemporaryInformation",
      "short" : "unitTemporaryInformation",
      "definition" : "unitTemporaryInformation",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "BackboneElement"
      }]
    },
    {
      "id" : "gethsaunit.unitTemporaryInformation.fromDate",
      "path" : "gethsaunit.unitTemporaryInformation.fromDate",
      "short" : "fromDate",
      "definition" : "fromDate",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "gethsaunit.unitTemporaryInformation.toDate",
      "path" : "gethsaunit.unitTemporaryInformation.toDate",
      "short" : "toDate",
      "definition" : "toDate",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "gethsaunit.unitTemporaryInformation.comment",
      "path" : "gethsaunit.unitTemporaryInformation.comment",
      "short" : "comment",
      "definition" : "comment",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "gethsaunit.visitingHours",
      "path" : "gethsaunit.visitingHours",
      "short" : "visitingHours",
      "definition" : "visitingHours",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "BackboneElement"
      }]
    },
    {
      "id" : "gethsaunit.visitingHours.visitingHour",
      "path" : "gethsaunit.visitingHours.visitingHour",
      "short" : "visitingHour",
      "definition" : "visitingHour",
      "min" : 0,
      "max" : "*",
      "type" : [{
        "code" : "BackboneElement"
      }]
    },
    {
      "id" : "gethsaunit.visitingHours.visitingHour.fromDay",
      "path" : "gethsaunit.visitingHours.visitingHour.fromDay",
      "short" : "fromDay",
      "definition" : "fromDay",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "integer"
      }]
    },
    {
      "id" : "gethsaunit.visitingHours.visitingHour.fromTime",
      "path" : "gethsaunit.visitingHours.visitingHour.fromTime",
      "short" : "fromTime",
      "definition" : "fromTime",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "time"
      }]
    },
    {
      "id" : "gethsaunit.visitingHours.visitingHour.fromTime2",
      "path" : "gethsaunit.visitingHours.visitingHour.fromTime2",
      "short" : "fromTime2",
      "definition" : "fromTime2",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "gethsaunit.visitingHours.visitingHour.toDay",
      "path" : "gethsaunit.visitingHours.visitingHour.toDay",
      "short" : "toDay",
      "definition" : "toDay",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "integer"
      }]
    },
    {
      "id" : "gethsaunit.visitingHours.visitingHour.toTime",
      "path" : "gethsaunit.visitingHours.visitingHour.toTime",
      "short" : "toTime",
      "definition" : "toTime",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "time"
      }]
    },
    {
      "id" : "gethsaunit.visitingHours.visitingHour.toTime2",
      "path" : "gethsaunit.visitingHours.visitingHour.toTime2",
      "short" : "toTime2",
      "definition" : "toTime2",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "gethsaunit.visitingHours.visitingHour.comment",
      "path" : "gethsaunit.visitingHours.visitingHour.comment",
      "short" : "comment",
      "definition" : "comment",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "gethsaunit.visitingRuleAge",
      "path" : "gethsaunit.visitingRuleAge",
      "short" : "visitingRuleAge",
      "definition" : "visitingRuleAge",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "BackboneElement"
      }]
    },
    {
      "id" : "gethsaunit.visitingRuleAge.from",
      "path" : "gethsaunit.visitingRuleAge.from",
      "short" : "from",
      "definition" : "from",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "integer"
      }]
    },
    {
      "id" : "gethsaunit.visitingRuleAge.to",
      "path" : "gethsaunit.visitingRuleAge.to",
      "short" : "to",
      "definition" : "to",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "integer"
      }]
    },
    {
      "id" : "gethsaunit.visitingRuleReferral",
      "path" : "gethsaunit.visitingRuleReferral",
      "short" : "visitingRuleReferral",
      "definition" : "visitingRuleReferral",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "gethsaunit.visitingRules",
      "path" : "gethsaunit.visitingRules",
      "short" : "visitingRules",
      "definition" : "visitingRules",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "gethsaunit.referralReceiver",
      "path" : "gethsaunit.referralReceiver",
      "short" : "referralReceiver",
      "definition" : "referralReceiver",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "boolean"
      }]
    },
    {
      "id" : "gethsaunit.referralTypes",
      "path" : "gethsaunit.referralTypes",
      "short" : "referralTypes",
      "definition" : "referralTypes",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "BackboneElement"
      }]
    },
    {
      "id" : "gethsaunit.referralTypes.referralType",
      "path" : "gethsaunit.referralTypes.referralType",
      "short" : "referralType",
      "definition" : "referralType",
      "min" : 0,
      "max" : "*",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "gethsaunit.DN",
      "path" : "gethsaunit.DN",
      "short" : "DN",
      "definition" : "DN",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    }]
  }
}

```
