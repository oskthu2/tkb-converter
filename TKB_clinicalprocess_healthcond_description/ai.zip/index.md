# Hem - clinicalprocess: healthcond: description v3.0.5

* [**Table of Contents**](toc.md)
* **Hem**

## Hem

| | |
| :--- | :--- |
| *Official URL*:https://fhir.inera.se/ig/clinicalprocess-healthcond-description/ImplementationGuide/inera.clinicalprocess-healthcond-description | *Version*:3.0.5 |
| Draft as of 2026-09-17 | *Computable Name*:clinicalprocesshealthconddescription |
| **Copyright/Legal**: Copyright 2024 Inera AB. Licensieras under Creative Commons Attribution 4.0. | |

# clinicalprocess: healthcond: description

## Översikt

Detta är en FHIR Implementation Guide genererad från TKB-dokumentation för tjänstedomänen **clinicalprocess: healthcond: description** version 3.0.5.

Tjänstekontrakten är baserade på RIVTA 2.1 och reglerade genom arkitekturella beslut. Tjänstekontraktsbeskrivningen är en kravspecifikation som fungerar som ett teknikneutralt, formellt regelverk som reglerar integrationskrav.

## Tjänstekontrakt i denna domän

| | | |
| :--- | :--- | :--- |
| [GetCareDocumentation](7-tjanstekontrakt.md#getcaredocumentation) | 3.0 | Returnerar journalanteckningar för en patient |
| [GetDiagnosis](7-tjanstekontrakt.md#getdiagnosis) | 2.0 | Returnerar registrerade diagnoser för en patient |
| [GetAlertInformation](7-tjanstekontrakt.md#getalertinformation) | 2.0 | Returnerar uppmärksamhetsinformation för en patient |
| [GetFunctionalStatus](7-tjanstekontrakt.md#getfunctionalstatus) | 2.0 | Returnerar dokumenterade bedömningar av funktionsnedsättningar |

## Innehåll

* [1 Inledning](1-inledning.md)
* [2 Versionsinformation](2-versionsinformation.md)
* [3 Tjänstedomänens arkitektur](3-tjanstedomanens-arkitektur.md)
* [4 Tjänstedomänens krav och regler](4-tjanstedomanens-krav-och-regler.md)
* [5 Tjänstedomänens meddelandemodeller](5-tjanstedomanens-meddelandemodeller.md)
* [6 Gemensamma informationskomponenter](6-gemensamma-informationskomponenter.md)
* [7 Tjänstekontrakt](7-tjanstekontrakt.md)

