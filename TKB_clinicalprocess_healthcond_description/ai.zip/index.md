# Hem - clinicalprocess: healthcond: description v3.0.6

* [**Table of Contents**](toc.md)
* **Hem**

## Hem

| | |
| :--- | :--- |
| *Official URL*:https://fhir.inera.se/ig/clinicalprocess-healthcond-description/ImplementationGuide/inera.clinicalprocess-healthcond-description | *Version*:3.0.6 |
| Active as of 2026-11-06 | *Computable Name*:clinicalprocesshealthconddescription |
| **Copyright/Legal**: Copyright 2024 Inera AB. Licensieras under Creative Commons Attribution 4.0. | |

# clinicalprocess: healthcond: description

**TKB-version:** 3.0.6 · **IG-version:** 3.0.6 · **Källa:** Bitbucket-tagg `3.0.6` · **Andra huvudversioner:** [2.1.19](https://oskthu2.github.io/tkb-converter/TKB_clinicalprocess_healthcond_description/2.1.19/index.html) 

## Översikt

* Beskrivning: Svenskt kortnamn
  * Denna domän hantera information som beskriver patientens hälsotillstånd, till exempel vårdanteckningar, diagnoser, uppmärksamhetsinformation och funktionsstatus.: tillståndsbeskrivning
* Beskrivning: Svenskt namn
  * Denna domän hantera information som beskriver patientens hälsotillstånd, till exempel vårdanteckningar, diagnoser, uppmärksamhetsinformation och funktionsstatus.: vård och omsorg kärnprocess:hantera hälsorelaterade tillstånd:tillståndsbeskrivning
* Beskrivning: Typ
  * Denna domän hantera information som beskriver patientens hälsotillstånd, till exempel vårdanteckningar, diagnoser, uppmärksamhetsinformation och funktionsstatus.: Nationell tjänstedomän
* Beskrivning: Förvaltare
  * Denna domän hantera information som beskriver patientens hälsotillstånd, till exempel vårdanteckningar, diagnoser, uppmärksamhetsinformation och funktionsstatus.: Tjänstekontraktsförvaltningen, TK-forvaltningen@inera.se
* Beskrivning: Källkod
  * Denna domän hantera information som beskriver patientens hälsotillstånd, till exempel vårdanteckningar, diagnoser, uppmärksamhetsinformation och funktionsstatus.: [Bitbucket](https://bitbucket.org/rivta-domains/riv.clinicalprocess.healthcond.description/src)
* Beskrivning: Ärenden
  * Denna domän hantera information som beskriver patientens hälsotillstånd, till exempel vårdanteckningar, diagnoser, uppmärksamhetsinformation och funktionsstatus.: [Bitbucket issues](https://bitbucket.org/rivta-domains/riv.clinicalprocess.healthcond.description/issues)
* Beskrivning: Informationssida
  * Denna domän hantera information som beskriver patientens hälsotillstånd, till exempel vårdanteckningar, diagnoser, uppmärksamhetsinformation och funktionsstatus.: [Confluence](https://inera.atlassian.net/wiki/spaces/OITOF/pages/268174569/clinicalprocess+healthcond+description+tillst+ndsbeskrivning)
* Beskrivning: Underlag för denna IG
  * Denna domän hantera information som beskriver patientens hälsotillstånd, till exempel vårdanteckningar, diagnoser, uppmärksamhetsinformation och funktionsstatus.: Version 3.0.6 ·[tagg 3.0.6](https://bitbucket.org/rivta-domains/riv.clinicalprocess.healthcond.description/src/3.0.6)·[zip](https://bitbucket.org/rivta-domains/riv.clinicalprocess.healthcond.description/get/3.0.6.zip)
* Beskrivning: RIV-TA-portalen
  * Denna domän hantera information som beskriver patientens hälsotillstånd, till exempel vårdanteckningar, diagnoser, uppmärksamhetsinformation och funktionsstatus.: [Alla tjänstedomäner](https://oskthu2.github.io/tkb-converter/rivta-portal/tjanstedomaner.html)·[Alla tjänstekontrakt](https://oskthu2.github.io/tkb-converter/rivta-portal/tjanstekontrakt.html)

Detta är en FHIR Implementation Guide genererad från TKB-dokumentation för tjänstedomänen **clinicalprocess: healthcond: description** version 3.0.6.

Tjänstekontrakten är baserade på RIVTA 2.1 och reglerade genom arkitekturella beslut. Tjänstekontraktsbeskrivningen är en kravspecifikation som fungerar som ett teknikneutralt, formellt regelverk som reglerar integrationskrav.

## Tjänstekontrakt i denna domän

| | | |
| :--- | :--- | :--- |
| [GetCareDocumentation](7-tjanstekontrakt.md#getcaredocumentation) | 3.0 | Returnerar journalanteckningar för en patient |
| [GetDiagnosis](7-tjanstekontrakt.md#getdiagnosis) | 2.0 | Returnerar registrerade diagnoser för en patient |
| [GetAlertInformation](7-tjanstekontrakt.md#getalertinformation) | 2.0 | Returnerar uppmärksamhetsinformation för en patient |
| [GetFunctionalStatus](7-tjanstekontrakt.md#getfunctionalstatus) | 2.0 | Returnerar dokumenterade bedömningar av funktionsnedsättningar |

### Versioner och granskningar

| | | | |
| :--- | :--- | :--- | :--- |
| 2.1.16 | AB, TKB | Arkitektur & Regelverk: Säkerhet: GodkändArkitektur & Regelverk: Teknik: GodkändArkitektur & Regelverk: Informatik: Godkänd | [zip](https://bitbucket.org/rivta-domains/riv.clinicalprocess.healthcond.description/get/2.1.16.zip)·[källkod](https://bitbucket.org/rivta-domains/riv.clinicalprocess.healthcond.description/src/2.1.16) |
| trunk | TKB, AB |  | [källkod](https://bitbucket.org/rivta-domains/riv.clinicalprocess.healthcond.description/src/master) |

*Zip-arkiven hämtas från taggarna på Bitbucket. Granskningsprotokollen publicerades på rivta.se och länkas inte härifrån.*

*Källa: ögonblicksbild av DOMDB från 2021-08-24, via RIV-TA-portalen.*

## Innehåll

* [1 Inledning](1-inledning.md)
* [2 Versionsinformation](2-versionsinformation.md)
* [3 Tjänstedomänens arkitektur](3-tjanstedomanens-arkitektur.md)
* [4 Tjänstedomänens krav och regler](4-tjanstedomanens-krav-och-regler.md)
* [5 Tjänstedomänens meddelandemodeller](5-tjanstedomanens-meddelandemodeller.md)
* [6 Gemensamma informationskomponenter](6-gemensamma-informationskomponenter.md)
* [7 Tjänstekontrakt](7-tjanstekontrakt.md)

