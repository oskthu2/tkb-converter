# inera.clinicalprocess-healthcond-description#3.0.5: clinicalprocess: healthcond: description

## Pages

* [Hem](index.md)
* [7 Tjänstekontrakt](7-tjanstekontrakt.md)
* [5 Tjänstedomänens meddelandemodeller](5-tjanstedomanens-meddelandemodeller.md)
* [Artifacts Summary](artifacts.md)
* [6 Gemensamma informationskomponenter](6-gemensamma-informationskomponenter.md)
* [3 Tjänstedomänens arkitektur](3-tjanstedomanens-arkitektur.md)
* [4 Tjänstedomänens krav och regler](4-tjanstedomanens-krav-och-regler.md)
* [2 Versionsinformation](2-versionsinformation.md)
* [1 Inledning](1-inledning.md)

## Resources

### CodeSystems

* [AssessmentCategory](CodeSystem-assessmentcategory-cs.md)
* [KV Anteckningstyp](CodeSystem-clinicaldocumentnotecode-cs.md)
* [DiagnosisType](CodeSystem-diagnosistype-cs.md)

### ValueSets

* [AssessmentCategory — ValueSet](ValueSet-assessmentcategory-vs.md)
* [KV Anteckningstyp — ValueSet](ValueSet-clinicaldocumentnotecode-vs.md)
* [DiagnosisType — ValueSet](ValueSet-diagnosistype-vs.md)

### Logicals

* [GetAlertInformation — Request](StructureDefinition-getalertinformation-request.md)
* [GetAlertInformation](StructureDefinition-getalertinformation.md)
* [GetCareDocumentation — Request](StructureDefinition-getcaredocumentation-request.md)
* [GetCareDocumentation](StructureDefinition-getcaredocumentation.md)
* [GetDiagnosis — Request](StructureDefinition-getdiagnosis-request.md)
* [GetDiagnosis](StructureDefinition-getdiagnosis.md)
* [GetFunctionalStatus — Request](StructureDefinition-getfunctionalstatus-request.md)
* [GetFunctionalStatus](StructureDefinition-getfunctionalstatus.md)

### ImplementationGuides

* [clinicalprocess: healthcond: description](index.md)
