# 6 Tjänstedomänens meddelandemodeller - clinicalprocess: healthcond: description 2.1 v2.1.19

* [**Table of Contents**](toc.md)
* **6 Tjänstedomänens meddelandemodeller**

## 6 Tjänstedomänens meddelandemodeller

## Tjänstedomänens meddelandemodeller

Här beskrivs de meddelandemodeller som tjänstekontrakten bygger på. För varje meddelandemodell beskrivs hur mappning ser ut delvis mot V-TIM, här version 2.2 samt mot schema (XSD) för tjänstekontrakt.

### MIM Hälso- och sjukvårds dokument

![](img_008.png)

| | |
| :--- | :--- |
| CareDocumentationType |   |
| CareDocumentationHeaderType.documentId | careDocumentation/careDocumentationHeader/documentId |
| CareDocumentationHeaderType.sourceSystemHSAId | careDocumentation/careDocumentationHeader/sourceSystemHSAId |
| CareDocumentationHeaderType.patientId | careDocumentation/careDocumentationHeader/patientId |
| CareDocumentationHeaderType.accountableHealthcareProfessional | careDocumentation/careDocumentationHeader/accountableHealthcareProfessional |
| AccountableHealthcareProfessionalType.authorTime | careDocumentation/careDocumentationHeader/ accountableHealthcareProfessional /authorTime |
| AccountableHealthcareProfessionalType.healthcareProfessionalHSAId | careDocumentation/careDocumentationHeader/accountableHealthcareProfessional/healthcareProfessionalHSAId |
| AccountableHealthcareProfessionalType.healthcareProfessionalName | careDocumentation/careDocumentationHeader/accountableHealthcareProfessional/healthcareProfessionalName |
| AccountableHealthcareProfessionalType.healthcareProfessionalRoleCode | careDocumentation/careDocumentationHeader/accountableHealthcareProfessional/healthcareProfessionalRoleCode |
| HealthcareProfessionalOrgUnitType.orgUnitHSAId | careDocumentation/careDocumentationHeader/accountableHealthcareProfessional/healthcareProfessionalOrgUnit/orgUnitHSAId |
| HealthcareProfessionalOrgUnitType.orgUnitname | careDocumentation/careDocumentationHeader/accountableHealthcareProfessional/healthcareProfessionalOrgUnit/orgUnitname |
| HealthcareProfessionalOrgUnitType.orgUnitTelecom | careDocumentation/careDocumentationHeader/accountableHealthcareProfessional/healthcareProfessionalOrgUnit/orgUnitTelecom |
| HealthcareProfessionalOrgUnitType.orgUnitEmail | careDocumentation/careDocumentationHeader/accountableHealthcareProfessional/healthcareProfessionalOrgUnit/orgUnitEmail |
| HealthcareProfessionalOrgUnitType.orgUnitAddress | careDocumentation/careDocumentationHeader/accountableHealthcareProfessional/healthcareProfessionalOrgUnit/orgUnitAddress |
| HealthcareProfessionalOrgUnitType.orgUnitLocation | careDocumentation/careDocumentationHeader/accountableHealthcareProfessional/healthcareProfessionalOrgUnit/orgUnitLocation |
| AccountableHealthcareProfessionalType.healthcareProfessionalCareUnitHSAId | careDocumentation/careDocumentationHeader/accountableHealthcareProfessional/healthcareProfessionalCareUnitHSAId |
| AccountableHealthcareProfessionalType.healthcareProfessionalCareGiverHSAId | careDocumentation/careDocumentationHeader/accountableHealthcareProfessional/healthcareProfessionalCareGiverHSAId |
| LegalAuthenticatorType.legalAuthenticatorTime | careDocumentation/careDocumentationHeader/legalAuthenticator/legalAuthenticatorTime |
| LegalAuthenticatorType.legalAuthenticatorHSAId | careDocumentation/careDocumentationHeader/legalAuthenticator/legalAuthenticatorHSAId |
| LegalAuthenticatorType.legalAuthenticatorName | careDocumentation/careDocumentationHeader/legalAuthenticator/legalAuthenticatorName |
| CareDocumentationHeaderType.approvedForPatient | careDocumentation/careDocumentationHeader/approvedForPatient |
| CareDocumentationHeaderType.careContactId | careDocumentation/CareDocumentationHeader/careContactId |
| CareDocumentationBodyType |   |
| ClinicalDocumentNoteType.clinicalDocumentNoteCode | careDocumentation/careDocumentationBody/clinicalDocument/clinicalDocumentNoteCode |
| ClinicalDocumentNoteType.clinicalDocumentTypeCode | careDocumentation/careDocumentationBody/clinicalDocument/clinicalDocumentTypeCode |
| ClinicalDocumentNoteType.clinicalDocumentNoteTitle | careDocumentation/careDocumentationBody/clinicalDocument/clinicalDocumentNoteTitle |
| ClinicalDocumentNoteType.clinicalDocumentNoteText | careDocumentation/careDocumentationBody/clinicalDocument/clinicalDocumentNoteText |
| MultimediaEntryType.mediaType | careDocumentation/careDocumentationBody/clinicalDocument/multimediaEntry/mediaType |
| MultimediaEntryType.value | careDocumentation/careDocumentationBody/clinicalDocument/multimediaEntry/value |
| MultimediaEntryType.reference | careDocumentation/careDocumentationBody/clinicalDocument/multimediaEntry/reerence |
| DissentingOpinionType.opinionId | careDocumentation/careDocumentationBody/clinicalDocument/dissentingOpinion/opinionId |
| DissentingOpinionType.authorTime | careDocumentation/careDocumentationBody/clinicalDocument/dissentingOpinion/authorTime |
| DissentingOpinionType.opinion | careDocumentation/careDocumentationBody/clinicalDocument/dissentingOpinion/opinion |
| DissentingOpinionType.personId | careDocumentation/careDocumentationBody/clinicalDocument/dissentingOpinion/personId |
| DissentingOpinionType.personName | careDocumentation/careDocumentationBody/clinicalDocument/dissentingOpinion/personName |

### MIM Diagnos

![](img_001.png)

| | |
| :--- | :--- |
| diagnosis |   |
| DiagnosisHeaderType.documentId | diagnosis/diagnosisHeader/documentId |
| DiagnosisHeaderType.sourceSystemHSAId | diagnosis/diagnosisHeader/sourceSystemHSAId |
| DiagnosisHeaderType.patientId | diagnosis/diagnosisHeader/patientId |
| DiagnosisHeaderType.accountableHealthcareProfessional | diagnosis/diagnosisHeader/accountableHealthcareProfessional |
| AccountableHealthcareProfessionalType.authorTime | diagnosis/diagnosisHeader/ accountableHealthcareProfessional /authorTime |
| AccountableHealthcareProfessionalType.healthcareProfessionalHSAId | diagnosis/diagnosisHeader/accountableHealthcareProfessional/healthcareProfessionalHSAId |
| AccountableHealthcareProfessionalType.healthcareProfessionalName | diagnosis/diagnosisHeader/accountableHealthcareProfessional/healthcareProfessionalName |
| AccountableHealthcareProfessionalType.healthcareProfessionalRoleCode | diagnosis/diagnosisHeader/accountableHealthcareProfessional/healthcareProfessionalRoleCode |
| HealthcareProfessionalOrgUnitType.orgUnitHSAId | diagnosis/diagnosisHeader/accountableHealthcareProfessional/healthcareProfessionalOrgUnit/orgUnitHSAId |
| HealthcareProfessionalOrgUnitType.orgUnitname | diagnosis/diagnosisHeader/accountableHealthcareProfessional/healthcareProfessionalOrgUnit/orgUnitname |
| HealthcareProfessionalOrgUnitType.orgUnitTelecom | diagnosis/diagnosisHeader/accountableHealthcareProfessional/healthcareProfessionalOrgUnit/orgUnitTelecom |
| HealthcareProfessionalOrgUnitType.orgUnitEmail | diagnosis/diagnosisHeader/accountableHealthcareProfessional/healthcareProfessionalOrgUnit/orgUnitEmail |
| HealthcareProfessionalOrgUnitType.orgUnitAddress | diagnosis/diagnosisHeader/accountableHealthcareProfessional/healthcareProfessionalOrgUnit/orgUnitAddress |
| HealthcareProfessionalOrgUnitType.orgUnitLocation | diagnosis/diagnosisHeader/accountableHealthcareProfessional/healthcareProfessionalOrgUnit/orgUnitLocation |
| AccountableHealthcareProfessionalType.healthcareProfessionalCareUnitHSAId | diagnosis/diagnosisHeader/accountableHealthcareProfessional/healthcareProfessionalCareUnitHSAId |
| AccountableHealthcareProfessionalType.healthcareProfessionalCareGiverHSAId | diagnosis/diagnosisHeader/accountableHealthcareProfessional/healthcareProfessionalCareGiverHSAId |
| LegalAuthenticatorType.legalAuthenticatorTime | diagnosis/diagnosisHeader/legalAuthenticator/legalAuthenticatorTime |
| LegalAuthenticatorType.legalAuthenticatorHSAId | diagnosis/diagnosisHeader/legalAuthenticator/legalAuthenticatorHSAId |
| LegalAuthenticatorType.legalAuthenticatorName | diagnosis/diagnosisHeader/legalAuthenticator/legalAuthenticatorName |
| DiagnosisHeaderType.approvedForPatient | diagnosis/diagnosisHeader/approvedForPatient |
| DiagnosisHeaderType.careContactId | diagnosis/diagnosisHeader/careContactId |
| DiagnosisBodyType |   |
| DiagnosisBodyType.typeOfDiagnosis | diagnosis/diagnosisBody/typeOfDiagnosis |
| DiagnosisBodyType.chronicDiagnosis | diagnosis/diagnosisBody/chronicDiagnosis |
| DiagnosisBodyType.diagnosisTime | diagnosis/diagnosisBody/diagnosisTime |
| DiagnosisBodyType.diagnosisCode | diagnosis/diagnosisBody/diagnosisCode |
| RelatedDiagnosisType.documentId | diagnosis/diagnosisBody/relatedDiagnosis/documentId |

### MIM Uppmärksamhetsinformation

![](img_004.png)

| | |
| :--- | :--- |
| AlertInformationType |   |
| AlertInformationHeaderType.documentId | alertInformation/alertInformationHeader/documentId |
| AlertInformationHeaderType.sourceSystemHSAId | alertInformation/alertInformationHeader/sourceSystemHSAId |
| AlertInformationHeaderType.patientId | alertInformation/alertInformationHeader/patientId |
| AlertInformationHeaderType.accountableHealthcareProfessional | alertInformation/alertInformationHeader/accountableHealthcareProfessional |
| AccountableHealthcareProfessionalType.authorTime | alertInformation/alertInformationHeader/ accountableHealthcareProfessional /authorTime |
| AccountableHealthcareProfessionalType.healthcareProfessionalHSAId | alertInformation/alertInformationHeader/accountableHealthcareProfessional/healthcareProfessionalHSAId |
| AccountableHealthcareProfessionalType.healthcareProfessionalName | alertInformation/alertInformationHeader/accountableHealthcareProfessional/healthcareProfessionalName |
| AccountableHealthcareProfessionalType.healthcareProfessionalRoleCode | alertInformation/alertInformationHeader/accountableHealthcareProfessional/healthcareProfessionalRoleCode |
| HealthcareProfessionalOrgUnitType.orgUnitHSAId | alertInformation/alertInformationHeader/accountableHealthcareProfessional/healthcareProfessionalOrgUnit/orgUnitHSAId |
| HealthcareProfessionalOrgUnitType.orgUnitname | alertInformation/alertInformationHeader/accountableHealthcareProfessional/healthcareProfessionalOrgUnit/orgUnitname |
| HealthcareProfessionalOrgUnitType.orgUnitTelecom | alertInformation/alertInformationHeader/accountableHealthcareProfessional/healthcareProfessionalOrgUnit/orgUnitTelecom |
| HealthcareProfessionalOrgUnitType.orgUnitEmail | alertInformation/alertInformationHeader/accountableHealthcareProfessional/healthcareProfessionalOrgUnit/orgUnitEmail |
| HealthcareProfessionalOrgUnitType.orgUnitAddress | alertInformation/alertInformationHeader/accountableHealthcareProfessional/healthcareProfessionalOrgUnit/orgUnitAddress |
| HealthcareProfessionalOrgUnitType.orgUnitLocation | alertInformation/alertInformationHeader/accountableHealthcareProfessional/healthcareProfessionalOrgUnit/orgUnitLocation |
| AccountableHealthcareProfessionalType.healthcareProfessionalCareUnitHSAId | alertInformation/alertInformationHeader/accountableHealthcareProfessional/healthcareProfessionalCareUnitHSAId |
| AccountableHealthcareProfessionalType.healthcareProfessionalCareGiverHSAId | alertInformation/alertInformationHeader/accountableHealthcareProfessional/healthcareProfessionalCareGiverHSAId |
| LegalAuthenticatorType.legalAuthenticatorTime | alertInformation/alertInformationHeader/legalAuthenticator/legalAuthenticatorTime |
| LegalAuthenticatorType.legalAuthenticatorHSAId | alertInformation/alertInformationHeader/legalAuthenticator/legalAuthenticatorHSAId |
| LegalAuthenticatorType.legalAuthenticatorName | alertInformation/alertInformationHeader/legalAuthenticator/legalAuthenticatorName |
| AlertInformationHeaderType.approvedForPatient | alertInformation/alertInformationHeader/approvedForPatient |
| AlertInformationHeaderType.careContactId | alertInformation/alertInformationHeader/careContactId |
| AlertInformationBodyType |   |
| AlertInformationBodyType.typeOfAlertInformation | alertInformation/alertInformationBody/typeOfAlertInformation |
| AlertInformationBodyType.ascertainedDate | alertInformation/alertInformationBody/ascertainedDate |
| AlertInformationBodyType.verifiedTime | alertInformation/alertInformationBody/verifiedTime |
| AlertInformationBodyType.validityTimePeriod | alertInformation/alertInformationBody/validityTimePeriod |
| AlertInformationBodyType.alertInformationComment | alertInformation/alertInformationBody/alertInformationComment |
| AlertInformationBodyType.obsoleteTime | alertInformation/alertInformationBody/obsoleteTime |
| AlertInformationBodyType.obsoleteComment | alertInformation/alertInformationBody/obsoleteComment |
| HypersensitivityType.typeOfSensitivity | alertInformation/alertInformationBody/hyperSensitivity/typeOfSensitvity |
| HypersensitivityType.degreeOfSeverity | alertInformation/alertInformationBody/hyperSensitivity/degreeOfSeverity |
| HypersensitivityType.degreeOfCertainty | alertInformation/alertInformationBody/hyperSensitivity/degreeOfCertainty |
| PharmaceuticalHypersensitivityType.atcSubstance | alertInformation/alertInformationBody/hyperSensitivity/pharmaceuticalHypersensitivity/atcSubstance |
| PharmaceuticalHypersensitivityType.nonATCSubstance | alertInformation/alertInformationBody/hyperSensitivity/pharmaceuticalHypersensitivity/nonATCSubstance |
| PharmaceuticalHypersensitivityType.nonATCSubstanceComment | alertInformation/alertInformationBody/hyperSensitivity/pharmaceuticalHypersensitivity/nonATCSubstanceComment |
| PharmaceuticalHypersensitivityType.pharmaceuticalProductId | alertInformation/alertInformationBody/hyperSensitivity/pharmaceuticalHypersensitivity/pharmaceuticalProductId |
| OtherHypersensitivityType.hypersensitivityAgent | alertInformation/alertInformationBody/hyperSensitivity/otherHypersensitivity/hypersensitivityAgent |
| OtherHypersensitivityType.hypersensitivityAgentCode | alertInformation/alertInformationBody/hyperSensitivity/otherHypersensitivity/hypersensitivityAgentCode |
| SeriousDiseaseType.disease | alertInformation/alertInformationBody/seriousDisease/disease |
| TreatmentType.treatmentDescription | alertInformation/alertInformationBody/treatment/treatmentDescription |
| TreatmentType.treatmentCode | alertInformation/alertInformationBody/treatment/treatmentCode |
| TreatmentType.pharmaceuticalTreatment | alertInformation/alertInformationBody/treatment/pharmaceuticalTreatment |
| RestrictionOfCareType.restrictionOfCareComment | alertInformation/alertInformationBody/restrictionOfCare/restrictionOfCareComment |
| CommunicableDiseaseType.communicableDiseaseCode | alertInformation/alertInformationBody/communicableDisease/communicableDiseaseCode |
| CommunicableDiseaseType.routeOfTransmission | alertInformation/alertInformationBody/communicableDisease/routeOfTransmission |
| UnstructuredAlertInformationType.unstructuredAlertInformationHeading | alertInformation/alertInformationBody/unstructuredAlertInformation/unstructuredAlertInformationHeading |
| UnstructuredAlertInformationType.unstructuredAlertInformationContent | alertInformation/alertInformationBody/unstructuredAlertInformation/unstructuredAlertInformationContent |
| AlertInformationRelationshipType.typeOfAlertInformationRelationship | alertInformation/alertInformationBody/alertInformationRelationship/typeOfAlertInfomationRelationship |
| AlertInformationRelationshipType.relationComment | alertInformation/alertInformationBody/alertInformationRelationship/relationComment |
| RelatedAlertInformationType.documentId | alertInformation/alertInformationBody/alertInformationRelationship/relatedAlertInformation/documentId |

### MIM Funktionsstatus

![](img_009.png)

| | |
| :--- | :--- |
| FunctionalStatusAssessmentType |   |
| PatientSummaryHeaderType.documentId | functionalStatusAssessment/functionalStatusAssessmentHeader/documentId |
| PatientSummaryHeaderType.sourceSystemHSAId | functionalStatusAssessment/functionalStatusAssessmentHeader/sourceSystemHSAId |
| PatientSummaryHeaderType.documentTime | functionalStatusAssessment/functionalStatusAssessmentHeader/documentTime |
| PatientSummaryHeaderType.patientId | functionalStatusAssessment/functionalStatusAssessmentHeader/patientId |
| PatientSummaryHeaderType.accountableHealthcareProfessional | functionalStatusAssessment/functionalStatusAssessmentHeader/accountableHealthcareProfessional |
| HealthcareProfessionalType.authorTime | functionalStatusAssessment/functionalStatusAssessmentHeader/accountableHealthcareProfessional /authorTime |
| HealthcareProfessionalType.healthcareProfessionalHSAId | functionalStatusAssessment/functionalStatusAssessmentHeader/accountableHealthcareProfessional/healthcareProfessionalHSAId |
| HealthcareProfessionalType.healthcareProfessionalName | functionalStatusAssessment/functionalStatusAssessmentHeader/accountableHealthcareProfessional/healthcareProfessionalName |
| HealthcareProfessionalType.healthcareProfessionalRoleCode | functionalStatusAssessment/functionalStatusAssessmentHeader/accountableHealthcareProfessional/healthcareProfessionalRoleCode |
| HealthcareProfessionalOrgUnitType.orgUnitHSAId | functionalStatusAssessment/functionalStatusAssessmentHeader/accountableHealthcareProfessional/healthcareProfessionalOrgUnit/orgUnitHSAId |
| HealthcareProfessionalOrgUnitType.orgUnitname | functionalStatusAssessment/functionalStatusAssessmentHeader/accountableHealthcareProfessional/healthcareProfessionalOrgUnit/orgUnitname |
| HealthcareProfessionalOrgUnitType.orgUnitTelecom | functionalStatusAssessment/functionalStatusAssessmentHeader/accountableHealthcareProfessional/healthcareProfessionalOrgUnit/orgUnitTelecom |
| HealthcareProfessionalOrgUnitType.orgUnitEmail | functionalStatusAssessment/functionalStatusAssessmentHeader/accountableHealthcareProfessional/healthcareProfessionalOrgUnit/orgUnitEmail |
| HealthcareProfessionalOrgUnitType.orgUnitAddress | functionalStatusAssessment/functionalStatusAssessmentHeader/accountableHealthcareProfessional/healthcareProfessionalOrgUnit/orgUnitAddress |
| HealthcareProfessionalOrgUnitType.orgUnitLocation | functionalStatusAssessment/functionalStatusAssessmentHeader/accountableHealthcareProfessional/healthcareProfessionalOrgUnit/orgUnitLocation |
| HealthcareProfessionalType.healthcareProfessionalCareUnitHSAId | functionalStatusAssessment/functionalStatusAssessmentHeader/accountableHealthcareProfessional/healthcareProfessionalCareUnitHSAId |
| HealthcareProfessionalType.healthcareProfessionalCareGiverHSAId | functionalStatusAssessment/functionalStatusAssessmentHeader/accountableHealthcareProfessional/healthcareProfessionalCareGiverHSAId |
| LegalAuthenticatorType.legalAuthenticatorTime | functionalStatusAssessment/functionalStatusAssessmentHeader/legalAuthenticator/legalAuthenticatorTime |
| LegalAuthenticatorType.legalAuthenticatorHSAId | functionalStatusAssessment/functionalStatusAssessmentHeader/legalAuthenticator/legalAuthenticatorHSAId |
| LegalAuthenticatorType.legalAuthenticatorName | functionalStatusAssessment/functionalStatusAssessmentHeader/legalAuthenticator/legalAuthenticatorName |
| LegalAuthenticatorType.legalAuthenticatorRoleCode | functionalStatusAssessment/functionalStatusAssessmentHeader/legalAuthenticator/legalAuthenticator RoleCode |
| PatientSummaryHeaderType.approvedForPatient | functionalStatusAssessment/functionalStatusAssessmentHeader/approvedForPatient |
| PatientSummaryHeaderType.careContactId | functionalStatusAssessment/functionalStatusAssessmentHeader/careContactId |
| FunctionalStatusAssessmentBodyType |   |
| FunctionalStatusAssessmentBodyType.assessmentCategory | functionalStatusAssessment/functionalStatusAssessmentBody/assessmentCategory |
| FunctionalStatusAssessmentBodyType.comment | functionalStatusAssessment/functionalStatusAssessmentBody/comment |
| PADLType.typeOfAssessment | functionalStatusAssessment/functionalStatusAssessmentBody/padl/typeOfAssessment |
| PADLType.assessment | functionalStatusAssessment/functionalStatusAssessmentBody/padl/assessment |
| DisabilityType.disabilityAssessment | functionalStatusAssessment/functionalStatusAssessmentBody/disability/disabilityAssessment |
| DisabilityType.comment | functionalStatusAssessment/functionalStatusAssessmentBody/disability/comment |
| ResultType | result |
| ResultType.resultCode | result/resultCode |
| ResultType.errorCode | result/errorCode |
| ResultType.subcode | result/subcode |
| ResultType.logId | result/logId |
| ResultType.message | result/message |

