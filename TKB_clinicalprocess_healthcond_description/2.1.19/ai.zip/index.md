# Hem - clinicalprocess: healthcond: description 2.1 v2.1.19

* [**Table of Contents**](toc.md)
* **Hem**

## Hem

| | |
| :--- | :--- |
| *Official URL*:https://fhir.inera.se/ig/clinicalprocess-healthcond-description/ImplementationGuide/inera.clinicalprocess-healthcond-description | *Version*:2.1.19 |
| Active as of 2026-10-08 | *Computable Name*:clinicalprocesshealthconddescription |
| **Copyright/Legal**: Copyright 2024 Inera AB. Licensieras under Creative Commons Attribution 4.0. | |

# clinicalprocess: healthcond: description 2.1

**TKB-version:** 2.1.19 · **IG-version:** 2.1.19 · **Källa:** Bitbucket-tagg `2.1.19` · **Andra huvudversioner:** [3.0.6](https://oskthu2.github.io/tkb-converter/TKB_clinicalprocess_healthcond_description/index.html) 

**Äldre huvudversion.** Detta är TKB 2.1 (Bitbucket-taggen 2.1.19, dokumentversion 2.1.18). Den senaste huvudversionen, 3.0, finns på [clinicalprocess: healthcond: description](https://oskthu2.github.io/tkb-converter/TKB_clinicalprocess_healthcond_description/index.html).

## Översikt

FHIR Implementation Guide för tjänstedomänen **clinicalprocess: healthcond: description** version 2.1.19. Genererad från Ineras tjänstekontraktsbeskrivning (TKB) i Bitbucket-taggen `2.1.19`. Själva TKB-dokumentet i taggen är märkt version 2.1.18 (ARK_0015, 2023-02-03): taggen 2.1.19 skiljer sig från taggen 2.1.18 bara i testsviterna och i självdeklarationerna SjD_TP för GetAlertInformation och GetCareDocumentation, så TKB-texten och scheman är desamma som i 2.1.18.

Domänen hanterar information som beskriver patientens hälsotillstånd, till exempel vårdanteckningar, diagnoser, uppmärksamhetsinformation och funktionsstatus. Tjänstekontrakten är baserade på RIVTA 2.1 och reglerade genom arkitekturella beslut. Tjänstekontraktsbeskrivningen är en kravspecifikation som fungerar som ett teknikneutralt, formellt regelverk för tjänstekonsumenter och tjänsteproducenter.

Domänen innehåller följande tjänstekontrakt:

| | | | |
| :--- | :--- | :--- | :--- |
| [GetCareDocumentation](7-tjanstekontrakt.md#getcaredocumentation) | 2.1 | Returnerar hälso- och sjukvårdsdokument (journalanteckningar) för en patient | [Svar](StructureDefinition-getcaredocumentation.md),[begäran](StructureDefinition-getcaredocumentation-request.md) |
| [GetDiagnosis](7-tjanstekontrakt.md#getdiagnosis) | 2.0 | Returnerar registrerade diagnoser för en patient | [Svar](StructureDefinition-getdiagnosis.md),[begäran](StructureDefinition-getdiagnosis-request.md) |
| [GetAlertInformation](7-tjanstekontrakt.md#getalertinformation) | 2.0 | Returnerar uppmärksamhetsinformation för en patient | [Svar](StructureDefinition-getalertinformation.md),[begäran](StructureDefinition-getalertinformation-request.md) |
| [GetFunctionalStatus](7-tjanstekontrakt.md#getfunctionalstatus) | 2.0 | Returnerar dokumenterade bedömningar av funktionsnedsättningar och/eller aktivitetsförmåga | [Svar](StructureDefinition-getfunctionalstatus.md),[begäran](StructureDefinition-getfunctionalstatus-request.md) |

## Innehåll

* [1 Inledning](1-inledning.md)
* [2 Versionsinformation](2-versionsinformation.md)
* [3 Tjänstedomänens arkitektur](3-tjanstedomanens-arkitektur.md)
* [4 Tjänstedomänens krav och regler](4-tjanstedomanens-krav-och-regler.md)
* [5 Gemensamma informationskomponenter](5-gemensamma-informationskomponenter.md)
* [6 Tjänstedomänens meddelandemodeller](6-tjanstedomanens-meddelandemodeller.md)
* [7 Tjänstekontrakt](7-tjanstekontrakt.md)
* [8 Bilaga Mappningar](8-bilaga-mappningar.md)
* [Artefakter](artifacts.md)

