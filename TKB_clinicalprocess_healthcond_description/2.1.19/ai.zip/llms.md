# inera.clinicalprocess-healthcond-description#2.1.19: clinicalprocess: healthcond: description 2.1

## Pages

* [Hem](index.md)
* [5 Gemensamma informationskomponenter](5-gemensamma-informationskomponenter.md)
* [7 Tjänstekontrakt](7-tjanstekontrakt.md)
* [6 Tjänstedomänens meddelandemodeller](6-tjanstedomanens-meddelandemodeller.md)
* [Artifacts Summary](artifacts.md)
* [3 Tjänstedomänens arkitektur](3-tjanstedomanens-arkitektur.md)
* [4 Tjänstedomänens krav och regler](4-tjanstedomanens-krav-och-regler.md)
* [2 Versionsinformation](2-versionsinformation.md)
* [1 Inledning](1-inledning.md)
* [8 Bilaga Mappningar](8-bilaga-mappningar.md)

## Resources

### CodeSystems

* [AssessmentCategory](CodeSystem-assessmentcategory-cs.md)
* [KV Anteckningstyp](CodeSystem-clinicaldocumentnotecode-cs.md)
* [DiagnosisType](CodeSystem-diagnosistype-cs.md)

### ValueSets

* [AssessmentCategory — ValueSet](ValueSet-assessmentcategory-vs.md)
* [KV Anteckningstyp — ValueSet](ValueSet-clinicaldocumentnotecode-vs.md)
* [DiagnosisType — ValueSet](ValueSet-diagnosistype-vs.md)

### Logicals

* [GetAlertInformation — Request](StructureDefinition-getalertinformation-request.md)
* [GetAlertInformation](StructureDefinition-getalertinformation.md)
* [GetCareDocumentation — Request](StructureDefinition-getcaredocumentation-request.md)
* [GetCareDocumentation](StructureDefinition-getcaredocumentation.md)
* [GetDiagnosis — Request](StructureDefinition-getdiagnosis-request.md)
* [GetDiagnosis](StructureDefinition-getdiagnosis.md)
* [GetFunctionalStatus — Request](StructureDefinition-getfunctionalstatus-request.md)
* [GetFunctionalStatus](StructureDefinition-getfunctionalstatus.md)

### ImplementationGuides

* [clinicalprocess: healthcond: description 2.1](index.md)
