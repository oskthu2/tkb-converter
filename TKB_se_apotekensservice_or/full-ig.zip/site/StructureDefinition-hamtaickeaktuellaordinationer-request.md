# HamtaIckeAktuellaOrdinationer — Request - se.apotekensservice: or — Ordinationer v7.0.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **HamtaIckeAktuellaOrdinationer — Request**

## Logical Model: HamtaIckeAktuellaOrdinationer — Request 

| | |
| :--- | :--- |
| *Official URL*:https://fhir.inera.se/ig/se-apotekensservice-or/StructureDefinition/hamtaickeaktuellaordinationer-request | *Version*:7.0.0 |
| Draft as of 2026-09-26 | *Computable Name*:HamtaIckeAktuellaOrdinationerRequest |
| **Copyright/Legal**: Copyright 2024 Inera AB. Licensieras under Creative Commons Attribution 4.0. | |

 
Logisk modell för begäran i HamtaIckeAktuellaOrdinationer (urn:riv:se.apotekensservice:or:HamtaIckeAktuellaOrdinationerResponder:6, HamtaIckeAktuellaOrdinationerRequestType), inklusive SOAP-huvuden enligt WSDL. 

**Usages:**

* This Logical Model is not used by any profiles in this Specification

You can also check for [usages in the FHIR IG Statistics](https://packages2.fhir.org/xig/resource/inera.se-apotekensservice-or|current/StructureDefinition/StructureDefinition-hamtaickeaktuellaordinationer-request.json)

### Formal Views of Profile Content

 [Description of Profiles, Differentials, Snapshots and how the different presentations work](http://build.fhir.org/ig/FHIR/ig-guidance/readingIgs.html#structure-definitions). 

 

Other representations of profile: [CSV](StructureDefinition-hamtaickeaktuellaordinationer-request.csv), [Excel](StructureDefinition-hamtaickeaktuellaordinationer-request.xlsx) 



## Resource Content

```json
{
  "resourceType" : "StructureDefinition",
  "id" : "hamtaickeaktuellaordinationer-request",
  "extension" : [{
    "url" : "http://hl7.org/fhir/StructureDefinition/structuredefinition-type-characteristics",
    "valueCode" : "can-be-target"
  }],
  "url" : "https://fhir.inera.se/ig/se-apotekensservice-or/StructureDefinition/hamtaickeaktuellaordinationer-request",
  "version" : "7.0.0",
  "name" : "HamtaIckeAktuellaOrdinationerRequest",
  "title" : "HamtaIckeAktuellaOrdinationer — Request",
  "status" : "draft",
  "date" : "2026-09-26T19:44:49+00:00",
  "contact" : [{
    "name" : "Inera Arkitektur",
    "telecom" : [{
      "system" : "url",
      "value" : "https://www.inera.se"
    }]
  }],
  "description" : "Logisk modell för begäran i HamtaIckeAktuellaOrdinationer\n(urn:riv:se.apotekensservice:or:HamtaIckeAktuellaOrdinationerResponder:6, HamtaIckeAktuellaOrdinationerRequestType), inklusive SOAP-huvuden enligt WSDL.",
  "copyright" : "Copyright 2024 Inera AB. Licensieras under Creative Commons Attribution 4.0.",
  "fhirVersion" : "4.0.1",
  "kind" : "logical",
  "abstract" : false,
  "type" : "https://fhir.inera.se/ig/se-apotekensservice-or/StructureDefinition/hamtaickeaktuellaordinationer-request",
  "baseDefinition" : "http://hl7.org/fhir/StructureDefinition/Base",
  "derivation" : "specialization",
  "differential" : {
    "element" : [{
      "id" : "hamtaickeaktuellaordinationer-request",
      "path" : "hamtaickeaktuellaordinationer-request",
      "short" : "HamtaIckeAktuellaOrdinationer — Request",
      "definition" : "Logisk modell för begäran i HamtaIckeAktuellaOrdinationer\n(urn:riv:se.apotekensservice:or:HamtaIckeAktuellaOrdinationerResponder:6, HamtaIckeAktuellaOrdinationerRequestType), inklusive SOAP-huvuden enligt WSDL."
    },
    {
      "id" : "hamtaickeaktuellaordinationer-request.logicalAddress",
      "path" : "hamtaickeaktuellaordinationer-request.logicalAddress",
      "short" : "logicalAddress",
      "definition" : "SOAP-huvud LogicalAddress. Orgnr of Apotekens Service AB",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "hamtaickeaktuellaordinationer-request.argosHeader",
      "path" : "hamtaickeaktuellaordinationer-request.argosHeader",
      "short" : "argosHeader",
      "definition" : "SOAP-huvud ArgosHeader. Argos header of Apotekens Service AB. Check documentation regarding mandatory fields for this specific service interaction",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "BackboneElement"
      }]
    },
    {
      "id" : "hamtaickeaktuellaordinationer-request.argosHeader.forskrivarkod",
      "path" : "hamtaickeaktuellaordinationer-request.argosHeader.forskrivarkod",
      "short" : "forskrivarkod",
      "definition" : "forskrivarkod",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "hamtaickeaktuellaordinationer-request.argosHeader.legitimationskod",
      "path" : "hamtaickeaktuellaordinationer-request.argosHeader.legitimationskod",
      "short" : "legitimationskod",
      "definition" : "legitimationskod",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "hamtaickeaktuellaordinationer-request.argosHeader.fornamn",
      "path" : "hamtaickeaktuellaordinationer-request.argosHeader.fornamn",
      "short" : "fornamn",
      "definition" : "fornamn",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "hamtaickeaktuellaordinationer-request.argosHeader.efternamn",
      "path" : "hamtaickeaktuellaordinationer-request.argosHeader.efternamn",
      "short" : "efternamn",
      "definition" : "efternamn",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "hamtaickeaktuellaordinationer-request.argosHeader.yrkesgrupp",
      "path" : "hamtaickeaktuellaordinationer-request.argosHeader.yrkesgrupp",
      "short" : "yrkesgrupp",
      "definition" : "yrkesgrupp",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "hamtaickeaktuellaordinationer-request.argosHeader.befattningskod",
      "path" : "hamtaickeaktuellaordinationer-request.argosHeader.befattningskod",
      "short" : "befattningskod",
      "definition" : "befattningskod",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "hamtaickeaktuellaordinationer-request.argosHeader.arbetsplatskod",
      "path" : "hamtaickeaktuellaordinationer-request.argosHeader.arbetsplatskod",
      "short" : "arbetsplatskod",
      "definition" : "arbetsplatskod",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "hamtaickeaktuellaordinationer-request.argosHeader.arbetsplatsnamn",
      "path" : "hamtaickeaktuellaordinationer-request.argosHeader.arbetsplatsnamn",
      "short" : "arbetsplatsnamn",
      "definition" : "arbetsplatsnamn",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "hamtaickeaktuellaordinationer-request.argosHeader.postort",
      "path" : "hamtaickeaktuellaordinationer-request.argosHeader.postort",
      "short" : "postort",
      "definition" : "postort",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "hamtaickeaktuellaordinationer-request.argosHeader.postadress",
      "path" : "hamtaickeaktuellaordinationer-request.argosHeader.postadress",
      "short" : "postadress",
      "definition" : "postadress",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "hamtaickeaktuellaordinationer-request.argosHeader.postnummer",
      "path" : "hamtaickeaktuellaordinationer-request.argosHeader.postnummer",
      "short" : "postnummer",
      "definition" : "postnummer",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "hamtaickeaktuellaordinationer-request.argosHeader.telefonnummer",
      "path" : "hamtaickeaktuellaordinationer-request.argosHeader.telefonnummer",
      "short" : "telefonnummer",
      "definition" : "telefonnummer",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "hamtaickeaktuellaordinationer-request.argosHeader.requestId",
      "path" : "hamtaickeaktuellaordinationer-request.argosHeader.requestId",
      "short" : "requestId",
      "definition" : "requestId",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "hamtaickeaktuellaordinationer-request.argosHeader.rollnamn",
      "path" : "hamtaickeaktuellaordinationer-request.argosHeader.rollnamn",
      "short" : "rollnamn",
      "definition" : "rollnamn",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "hamtaickeaktuellaordinationer-request.argosHeader.directoryID",
      "path" : "hamtaickeaktuellaordinationer-request.argosHeader.directoryID",
      "short" : "directoryID",
      "definition" : "directoryID",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "hamtaickeaktuellaordinationer-request.argosHeader.hsaID",
      "path" : "hamtaickeaktuellaordinationer-request.argosHeader.hsaID",
      "short" : "hsaID",
      "definition" : "hsaID",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "hamtaickeaktuellaordinationer-request.argosHeader.katalog",
      "path" : "hamtaickeaktuellaordinationer-request.argosHeader.katalog",
      "short" : "katalog",
      "definition" : "katalog",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "hamtaickeaktuellaordinationer-request.argosHeader.organisationsnummer",
      "path" : "hamtaickeaktuellaordinationer-request.argosHeader.organisationsnummer",
      "short" : "organisationsnummer",
      "definition" : "organisationsnummer",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "hamtaickeaktuellaordinationer-request.argosHeader.systemnamn",
      "path" : "hamtaickeaktuellaordinationer-request.argosHeader.systemnamn",
      "short" : "systemnamn",
      "definition" : "systemnamn",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "hamtaickeaktuellaordinationer-request.argosHeader.systemversion",
      "path" : "hamtaickeaktuellaordinationer-request.argosHeader.systemversion",
      "short" : "systemversion",
      "definition" : "systemversion",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "hamtaickeaktuellaordinationer-request.argosHeader.systemIp",
      "path" : "hamtaickeaktuellaordinationer-request.argosHeader.systemIp",
      "short" : "systemIp",
      "definition" : "systemIp",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "hamtaickeaktuellaordinationer-request.fromDatum",
      "path" : "hamtaickeaktuellaordinationer-request.fromDatum",
      "short" : "fromDatum",
      "definition" : "Från och med datum för perioden som ska visas.",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "dateTime"
      }]
    },
    {
      "id" : "hamtaickeaktuellaordinationer-request.personnummer",
      "path" : "hamtaickeaktuellaordinationer-request.personnummer",
      "short" : "personnummer",
      "definition" : "Giltigt personnummer för patient.",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "hamtaickeaktuellaordinationer-request.ordinationsId",
      "path" : "hamtaickeaktuellaordinationer-request.ordinationsId",
      "short" : "ordinationsId",
      "definition" : "OrdinationsId. Anges om bara en ordination ska returneras.",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "hamtaickeaktuellaordinationer-request.grupplegitimationskod",
      "path" : "hamtaickeaktuellaordinationer-request.grupplegitimationskod",
      "short" : "grupplegitimationskod",
      "definition" : "Användarens 6-ställiga grupplegitimationskod. Obligatorisk för Apotekselev, receptarieelev, Teknikerelev och Europeisk farmaceut.",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "hamtaickeaktuellaordinationer-request.gruppforskrivarkod",
      "path" : "hamtaickeaktuellaordinationer-request.gruppforskrivarkod",
      "short" : "gruppforskrivarkod",
      "definition" : "Gruppförskrivarkod används då förskrivaren saknar individuell förskrivarkod men har via sin roll erhållit förskrivningsrätt. Kan exempelvis vara en AT-läkare eller förskrivare med förordnande. Förskrivarkoden definieras av Socialstyrelsen och gruppförskrivarkoden definieras av eHälsomyndigheten.",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    }]
  }
}

```
