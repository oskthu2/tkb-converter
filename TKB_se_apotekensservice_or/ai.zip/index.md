# Hem - se.apotekensservice: or — Ordinationer v7.0.0

* [**Table of Contents**](toc.md)
* **Hem**

## Hem

| | |
| :--- | :--- |
| *Official URL*:https://fhir.inera.se/ig/se-apotekensservice-or/ImplementationGuide/inera.se-apotekensservice-or | *Version*:7.0.0 |
| Active as of 2026-10-26 | *Computable Name*:seapotekensserviceor |
| **Copyright/Legal**: Copyright 2024 Inera AB. Licensieras under Creative Commons Attribution 4.0. | |

# se.apotekensservice: or — Ordinationer

**TKB-version:** 7.0 · **IG-version:** 7.0.0 · **Källa:** Bitbucket-tagg `7.0` 

## Översikt

* Svenskt kortnamn: Typ
  * ordination: Extern tjänstedomän
* Svenskt kortnamn: Förvaltare
  * ordination: E-hälsomyndigheten
* Svenskt kortnamn: Källkod
  * ordination: [Bitbucket](https://bitbucket.org/rivta-domains/riv.se.apotekensservice.or/src)
* Svenskt kortnamn: Ärenden
  * ordination: [Bitbucket issues](https://bitbucket.org/rivta-domains/riv.se.apotekensservice.or/issues)
* Svenskt kortnamn: Underlag för denna IG
  * ordination: Version 7.0 ·[tagg 7.0](https://bitbucket.org/rivta-domains/riv.se.apotekensservice.or/src/7.0)·[zip](https://bitbucket.org/rivta-domains/riv.se.apotekensservice.or/get/7.0.zip)
* Svenskt kortnamn: RIV-TA-portalen
  * ordination: [Alla tjänstedomäner](https://oskthu2.github.io/tkb-converter/rivta-portal/tjanstedomaner.html)·[Alla tjänstekontrakt](https://oskthu2.github.io/tkb-converter/rivta-portal/tjanstekontrakt.html)

FHIR Implementation Guide för tjänstedomänen **se: apotekensservice: or** version 7.0. Domänen förvaltas av eHälsomyndigheten (tidigare Apotekens Service AB) och innehåller tjänster för att hämta en patients aktuella respektive icke aktuella läkemedelsordinationer (recept och dosordinationer) med tillhörande information om artiklar, uttag, förskrivare och apotek.

**Observera:** källan innehåller ingen tjänstekontraktsbeskrivning (TKB). Denna IG är därför uppbyggd från domänens scheman (XSD/WSDL) och dess dokument med arkitekturella beslut. Avsnitt som i andra IG:er hämtas ur TKB:n är markerade med **SAKNAS I KÄLLDOKUMENT**. Beskrivningar av fält är hämtade ur schemaannoteringarna.

RIV-TA namnrymd: `urn:riv:se.apotekensservice:or`

Domänen innehåller följande tjänstekontrakt:

| | | |
| :--- | :--- | :--- |
| [HamtaAktuellaOrdinationer](7-tjanstekontrakt.md#hamtaaktuellaordinationer) | 5.2 | Fråga-svar |
| [HamtaIckeAktuellaOrdinationer](7-tjanstekontrakt.md#hamtaickeaktuellaordinationer) | 6.2 | Fråga-svar |

**Källa:** Bitbucket `rivta-domains/riv.se.apotekensservice.or`, tagg `7.0` (commit `242eca0ad25a`, 2019-12-05), samma commit som `master`.

### Versioner och granskningar

| | | | |
| :--- | :--- | :--- | :--- |
| 6.0 | AB |  | [zip](http://rivta.se/downloads//se_apotekensservice_or/6.0/ServiceContracts_se_apotekensservice_or_6.0.zip)·[källkod](https://bitbucket.org/rivta-domains/riv.se.apotekensservice.or/src/6.0) |
| 5.0 | AB |  | [zip](http://rivta.se/downloads//se_apotekensservice_or/5.0/ServiceContracts_se.apotekensservice_or_5.0.zip)·[källkod](https://bitbucket.org/rivta-domains/riv.se.apotekensservice.or/src/5.0) |
| 4.0_RC3 | AB |  | [zip](http://rivta.se/downloads/se_apotekensservice_or/4.0_RC3/ServiceContracts_se_apotekensservice_or_4.0_RC3.zip)·[källkod](https://bitbucket.org/rivta-domains/riv.se.apotekensservice.or/src/TD_APOTEKENSSERVICE_OR_4_0_RC3) |
| trunk | AB |  | [källkod](https://bitbucket.org/rivta-domains/riv.se.apotekensservice.or/src/master) |

*Källa: ögonblicksbild av DOMDB från 2021-08-24, via RIV-TA-portalen.*

## Innehåll

* [1 Inledning](1-inledning.md)
* [2 Versionsinformation](2-versionsinformation.md)
* [3 Tjänstedomänens arkitektur](3-tjanstedomanens-arkitektur.md)
* [4 Tjänstedomänens krav och regler](4-tjanstedomanens-krav-och-regler.md)
* [5 Tjänstedomänens meddelandemodeller](5-tjanstedomanens-meddelandemodeller.md)
* [6 Gemensamma informationskomponenter](6-gemensamma-informationskomponenter.md)
* [7 Tjänstekontrakt](7-tjanstekontrakt.md)
* [Artefakter](artifacts.md)

