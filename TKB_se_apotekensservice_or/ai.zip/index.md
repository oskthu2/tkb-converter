# Hem - se.apotekensservice: or — Ordinationer v7.0.0

* [**Table of Contents**](toc.md)
* **Hem**

## Hem

| | |
| :--- | :--- |
| *Official URL*:https://fhir.inera.se/ig/se-apotekensservice-or/ImplementationGuide/inera.se-apotekensservice-or | *Version*:7.0.0 |
| Draft as of 2026-09-26 | *Computable Name*:seapotekensserviceor |
| **Copyright/Legal**: Copyright 2024 Inera AB. Licensieras under Creative Commons Attribution 4.0. | |

# se.apotekensservice: or — Ordinationer

## Översikt

FHIR Implementation Guide för tjänstedomänen **se: apotekensservice: or** version 7.0. Domänen förvaltas av eHälsomyndigheten (tidigare Apotekens Service AB) och innehåller tjänster för att hämta en patients aktuella respektive icke aktuella läkemedelsordinationer (recept och dosordinationer) med tillhörande information om artiklar, uttag, förskrivare och apotek.

**Observera:** källan innehåller ingen tjänstekontraktsbeskrivning (TKB). Denna IG är därför uppbyggd från domänens scheman (XSD/WSDL) och dess dokument med arkitekturella beslut. Avsnitt som i andra IG:er hämtas ur TKB:n är markerade med **SAKNAS I KÄLLDOKUMENT**. Beskrivningar av fält är hämtade ur schemaannoteringarna.

RIV-TA namnrymd: `urn:riv:se.apotekensservice:or`

Domänen innehåller följande tjänstekontrakt:

| | | |
| :--- | :--- | :--- |
| [HamtaAktuellaOrdinationer](7-tjanstekontrakt.md#hamtaaktuellaordinationer) | 5.2 | Fråga-svar |
| [HamtaIckeAktuellaOrdinationer](7-tjanstekontrakt.md#hamtaickeaktuellaordinationer) | 6.2 | Fråga-svar |

**Källa:** Bitbucket `rivta-domains/riv.se.apotekensservice.or`, tagg `7.0` (commit `242eca0ad25a`, 2019-12-05), samma commit som `master`.

## Innehåll

* [1 Inledning](1-inledning.md)
* [2 Versionsinformation](2-versionsinformation.md)
* [3 Tjänstedomänens arkitektur](3-tjanstedomanens-arkitektur.md)
* [4 Tjänstedomänens krav och regler](4-tjanstedomanens-krav-och-regler.md)
* [5 Tjänstedomänens meddelandemodeller](5-tjanstedomanens-meddelandemodeller.md)
* [6 Gemensamma informationskomponenter](6-gemensamma-informationskomponenter.md)
* [7 Tjänstekontrakt](7-tjanstekontrakt.md)
* [Artefakter](artifacts.md)

