# Hem - druglogistics: dosedispensing — Dosdispensering v1.1.0

* [**Table of Contents**](toc.md)
* **Hem**

## Hem

| | |
| :--- | :--- |
| *Official URL*:https://fhir.inera.se/ig/druglogistics-dosedispensing/ImplementationGuide/inera.druglogistics-dosedispensing | *Version*:1.1.0 |
| Draft as of 2026-09-26 | *Computable Name*:druglogisticsdosedispensing |
| **Copyright/Legal**: Copyright 2024 Inera AB. Licensieras under Creative Commons Attribution 4.0. | |

# druglogistics: dosedispensing — Dosdispensering

## Översikt

FHIR Implementation Guide för tjänstedomänen **druglogistics: dosedispensing** version 1.1.0. Domänen innehåller tjänster mellan vårdsystem och dosapotek (Pascal/IOR-tjänsterna): registrera och uppdatera vårdtagare för dos, hämta vårdtagarinformation, beställa, hämta och avbeställa originalförpackningar, hämta dosapotekets lokala produktsortiment, söka vårdande enhet samt skicka, hämta och uppdatera status på meddelanden mellan vård och dosapotek.

**Observera:** källan innehåller ingen tjänstekontraktsbeskrivning (TKB). Denna IG är därför uppbyggd från domänens scheman (XSD/WSDL) samt de gränssnittsspecifikationer (PDF) som finns för varje tjänstekontrakt och dokumentet **Pascal – Objekt och felhantering**. Avsnitt som i andra IG:er hämtas ur TKB:n är markerade med **SAKNAS I KÄLLDOKUMENT**. Beskrivningar av fält är hämtade ur schemaannoteringarna.

RIV-TA namnrymd: `urn:riv:druglogistics:dosedispensing`

Domänen innehåller följande tjänstekontrakt:

| | | |
| :--- | :--- | :--- |
| [AvbestallOrginalforpackning](7-tjanstekontrakt.md#avbestallorginalforpackning) | 1.0 | Fråga-svar |
| [BestallOrginalforpackning](7-tjanstekontrakt.md#bestallorginalforpackning) | 1.0 | Fråga-svar |
| [HamtaLokaltProduktsortiment](7-tjanstekontrakt.md#hamtalokaltproduktsortiment) | 1.1 | Fråga-svar |
| [HamtaMeddelanden](7-tjanstekontrakt.md#hamtameddelanden) | 1.0 | Fråga-svar |
| [HamtaOrginalforpackning](7-tjanstekontrakt.md#hamtaorginalforpackning) | 1.0 | Fråga-svar |
| [HamtaVardtagareinformation](7-tjanstekontrakt.md#hamtavardtagareinformation) | 1.0 | Fråga-svar |
| [SkapaVardtagare](7-tjanstekontrakt.md#skapavardtagare) | 1.0 | Fråga-svar |
| [SkickaMeddelanden](7-tjanstekontrakt.md#skickameddelanden) | 1.0 | Fråga-svar |
| [SokVardandeEnhet](7-tjanstekontrakt.md#sokvardandeenhet) | 1.0 | Fråga-svar |
| [UppdateraMeddelandeStatus](7-tjanstekontrakt.md#uppdaterameddelandestatus) | 1.0 | Fråga-svar |
| [UppdateraVardtagareinformation](7-tjanstekontrakt.md#uppdateravardtagareinformation) | 1.0 | Fråga-svar |

**Källa:** Bitbucket `rivta-domains/riv.druglogistics.dosedispensing`, tagg `TD_DRUGLOGISTICS_DOSEDISPENSING_1_1_0` (commit `ff5de62545f2`, 2013-09-30). Taggens innehåll är detsamma som `master`.

## Innehåll

* [1 Inledning](1-inledning.md)
* [2 Versionsinformation](2-versionsinformation.md)
* [3 Tjänstedomänens arkitektur](3-tjanstedomanens-arkitektur.md)
* [4 Tjänstedomänens krav och regler](4-tjanstedomanens-krav-och-regler.md)
* [5 Tjänstedomänens meddelandemodeller](5-tjanstedomanens-meddelandemodeller.md)
* [6 Gemensamma informationskomponenter](6-gemensamma-informationskomponenter.md)
* [7 Tjänstekontrakt](7-tjanstekontrakt.md)
* [Artefakter](artifacts.md)

