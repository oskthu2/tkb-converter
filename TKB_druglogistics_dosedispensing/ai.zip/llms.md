# inera.druglogistics-dosedispensing#1.1.0: druglogistics: dosedispensing — Dosdispensering

## Pages

* [Hem](index.md)
* [7 Tjänstekontrakt](7-tjanstekontrakt.md)
* [5 Tjänstedomänens meddelandemodeller](5-tjanstedomanens-meddelandemodeller.md)
* [Artifacts Summary](artifacts.md)
* [6 Gemensamma informationskomponenter](6-gemensamma-informationskomponenter.md)
* [3 Tjänstedomänens arkitektur](3-tjanstedomanens-arkitektur.md)
* [4 Tjänstedomänens krav och regler](4-tjanstedomanens-krav-och-regler.md)
* [2 Versionsinformation](2-versionsinformation.md)
* [1 Inledning](1-inledning.md)

## Resources

### CodeSystems

* [Beställningsstatus](CodeSystem-dosedispensing-bestallningsstatus-cs.md)
* [Beställningsurval](CodeSystem-dosedispensing-bestallningsurval-cs.md)
* [Identitetstyp](CodeSystem-dosedispensing-identitetstyp-cs.md)
* [Kommunikationsriktning](CodeSystem-dosedispensing-kommunikationsriktning-cs.md)
* [Meddelandeprioritet](CodeSystem-dosedispensing-meddelandeprioritet-cs.md)
* [Meddelandestatus](CodeSystem-dosedispensing-meddelandestatus-cs.md)
* [Meddelandetyp](CodeSystem-dosedispensing-meddelandetyp-cs.md)
* [Resultatkod](CodeSystem-dosedispensing-resultatkod-cs.md)
* [Vårdtagarstatus](CodeSystem-dosedispensing-vardtagarstatus-cs.md)
* [Yrkeskod](CodeSystem-dosedispensing-yrkeskod-cs.md)

### ValueSets

* [Beställningsstatus](ValueSet-dosedispensing-bestallningsstatus-vs.md)
* [Beställningsurval](ValueSet-dosedispensing-bestallningsurval-vs.md)
* [Identitetstyp](ValueSet-dosedispensing-identitetstyp-vs.md)
* [Kommunikationsriktning](ValueSet-dosedispensing-kommunikationsriktning-vs.md)
* [Meddelandeprioritet](ValueSet-dosedispensing-meddelandeprioritet-vs.md)
* [Meddelandestatus](ValueSet-dosedispensing-meddelandestatus-vs.md)
* [Meddelandetyp](ValueSet-dosedispensing-meddelandetyp-vs.md)
* [Resultatkod](ValueSet-dosedispensing-resultatkod-vs.md)
* [Vårdtagarstatus](ValueSet-dosedispensing-vardtagarstatus-vs.md)
* [Yrkeskod](ValueSet-dosedispensing-yrkeskod-vs.md)

### Logicals

* [AvbestallOrginalforpackning — Request](StructureDefinition-avbestallorginalforpackning-request.md)
* [AvbestallOrginalforpackning — Response](StructureDefinition-avbestallorginalforpackning.md)
* [BestallOrginalforpackning — Request](StructureDefinition-bestallorginalforpackning-request.md)
* [BestallOrginalforpackning — Response](StructureDefinition-bestallorginalforpackning.md)
* [HamtaLokaltProduktsortiment — Request](StructureDefinition-hamtalokaltproduktsortiment-request.md)
* [HamtaLokaltProduktsortiment — Response](StructureDefinition-hamtalokaltproduktsortiment.md)
* [HamtaMeddelanden — Request](StructureDefinition-hamtameddelanden-request.md)
* [HamtaMeddelanden — Response](StructureDefinition-hamtameddelanden.md)
* [HamtaOrginalforpackning — Request](StructureDefinition-hamtaorginalforpackning-request.md)
* [HamtaOrginalforpackning — Response](StructureDefinition-hamtaorginalforpackning.md)
* [HamtaVardtagareinformation — Request](StructureDefinition-hamtavardtagareinformation-request.md)
* [HamtaVardtagareinformation — Response](StructureDefinition-hamtavardtagareinformation.md)
* [SkapaVardtagare — Request](StructureDefinition-skapavardtagare-request.md)
* [SkapaVardtagare — Response](StructureDefinition-skapavardtagare.md)
* [SkickaMeddelanden — Request](StructureDefinition-skickameddelanden-request.md)
* [SkickaMeddelanden — Response](StructureDefinition-skickameddelanden.md)
* [SokVardandeEnhet — Request](StructureDefinition-sokvardandeenhet-request.md)
* [SokVardandeEnhet — Response](StructureDefinition-sokvardandeenhet.md)
* [UppdateraMeddelandeStatus — Request](StructureDefinition-uppdaterameddelandestatus-request.md)
* [UppdateraMeddelandeStatus — Response](StructureDefinition-uppdaterameddelandestatus.md)
* [UppdateraVardtagareinformation — Request](StructureDefinition-uppdateravardtagareinformation-request.md)
* [UppdateraVardtagareinformation — Response](StructureDefinition-uppdateravardtagareinformation.md)

### ImplementationGuides

* [druglogistics: dosedispensing — Dosdispensering](index.md)
