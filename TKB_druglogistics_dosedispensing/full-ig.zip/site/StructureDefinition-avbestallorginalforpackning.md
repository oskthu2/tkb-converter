# AvbestallOrginalforpackning — Response - druglogistics: dosedispensing — Dosdispensering v1.1.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **AvbestallOrginalforpackning — Response**

## Logical Model: AvbestallOrginalforpackning — Response 

| | |
| :--- | :--- |
| *Official URL*:https://fhir.inera.se/ig/druglogistics-dosedispensing/StructureDefinition/avbestallorginalforpackning | *Version*:1.1.0 |
| Draft as of 2026-09-26 | *Computable Name*:AvbestallOrginalforpackning |
| **Copyright/Legal**: Copyright 2024 Inera AB. Licensieras under Creative Commons Attribution 4.0. | |

 
Logisk modell för svaret i AvbestallOrginalforpackning (urn:riv:druglogistics:dosedispensing:AvbestallOrginalforpackningResponder:1, AvbestallOrginalforpackningResponseType). 

**Usages:**

* This Logical Model is not used by any profiles in this Specification

You can also check for [usages in the FHIR IG Statistics](https://packages2.fhir.org/xig/resource/inera.druglogistics-dosedispensing|current/StructureDefinition/StructureDefinition-avbestallorginalforpackning.json)

### Formal Views of Profile Content

 [Description of Profiles, Differentials, Snapshots and how the different presentations work](http://build.fhir.org/ig/FHIR/ig-guidance/readingIgs.html#structure-definitions). 

 

Other representations of profile: [CSV](StructureDefinition-avbestallorginalforpackning.csv), [Excel](StructureDefinition-avbestallorginalforpackning.xlsx) 



## Resource Content

```json
{
  "resourceType" : "StructureDefinition",
  "id" : "avbestallorginalforpackning",
  "extension" : [{
    "url" : "http://hl7.org/fhir/StructureDefinition/structuredefinition-type-characteristics",
    "valueCode" : "can-be-target"
  }],
  "url" : "https://fhir.inera.se/ig/druglogistics-dosedispensing/StructureDefinition/avbestallorginalforpackning",
  "version" : "1.1.0",
  "name" : "AvbestallOrginalforpackning",
  "title" : "AvbestallOrginalforpackning — Response",
  "status" : "draft",
  "date" : "2026-09-26T19:21:50+00:00",
  "contact" : [{
    "name" : "Inera Arkitektur",
    "telecom" : [{
      "system" : "url",
      "value" : "https://www.inera.se"
    }]
  }],
  "description" : "Logisk modell för svaret i AvbestallOrginalforpackning\n(urn:riv:druglogistics:dosedispensing:AvbestallOrginalforpackningResponder:1, AvbestallOrginalforpackningResponseType).",
  "copyright" : "Copyright 2024 Inera AB. Licensieras under Creative Commons Attribution 4.0.",
  "fhirVersion" : "4.0.1",
  "kind" : "logical",
  "abstract" : false,
  "type" : "https://fhir.inera.se/ig/druglogistics-dosedispensing/StructureDefinition/avbestallorginalforpackning",
  "baseDefinition" : "http://hl7.org/fhir/StructureDefinition/Base",
  "derivation" : "specialization",
  "differential" : {
    "element" : [{
      "id" : "avbestallorginalforpackning",
      "path" : "avbestallorginalforpackning",
      "short" : "AvbestallOrginalforpackning — Response",
      "definition" : "Logisk modell för svaret i AvbestallOrginalforpackning\n(urn:riv:druglogistics:dosedispensing:AvbestallOrginalforpackningResponder:1, AvbestallOrginalforpackningResponseType)."
    },
    {
      "id" : "avbestallorginalforpackning.resultatkod",
      "path" : "avbestallorginalforpackning.resultatkod",
      "short" : "resultatkod",
      "definition" : "resultatkod",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "code"
      }],
      "binding" : {
        "strength" : "required",
        "valueSet" : "https://fhir.inera.se/ig/druglogistics-dosedispensing/ValueSet/dosedispensing-resultatkod-vs"
      }
    },
    {
      "id" : "avbestallorginalforpackning.meddelandetext",
      "path" : "avbestallorginalforpackning.meddelandetext",
      "short" : "meddelandetext",
      "definition" : "meddelandetext",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "avbestallorginalforpackning.meddelandeid",
      "path" : "avbestallorginalforpackning.meddelandeid",
      "short" : "meddelandeid",
      "definition" : "meddelandeid",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "integer"
      }]
    },
    {
      "id" : "avbestallorginalforpackning.Bestallningsrader",
      "path" : "avbestallorginalforpackning.Bestallningsrader",
      "short" : "Bestallningsrader",
      "definition" : "Bestallningsrader",
      "min" : 0,
      "max" : "*",
      "type" : [{
        "code" : "BackboneElement"
      }]
    },
    {
      "id" : "avbestallorginalforpackning.Bestallningsrader.bestallningsid",
      "path" : "avbestallorginalforpackning.Bestallningsrader.bestallningsid",
      "short" : "bestallningsid",
      "definition" : "bestallningsid",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "avbestallorginalforpackning.Bestallningsrader.radid",
      "path" : "avbestallorginalforpackning.Bestallningsrader.radid",
      "short" : "radid",
      "definition" : "radid",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "avbestallorginalforpackning.Bestallningsrader.Patientinformation",
      "path" : "avbestallorginalforpackning.Bestallningsrader.Patientinformation",
      "short" : "Patientinformation",
      "definition" : "Patientinformation",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "BackboneElement"
      }]
    },
    {
      "id" : "avbestallorginalforpackning.Bestallningsrader.Patientinformation.fornamn",
      "path" : "avbestallorginalforpackning.Bestallningsrader.Patientinformation.fornamn",
      "short" : "fornamn",
      "definition" : "Anvandarens fornamn.",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "avbestallorginalforpackning.Bestallningsrader.Patientinformation.mellannamn",
      "path" : "avbestallorginalforpackning.Bestallningsrader.Patientinformation.mellannamn",
      "short" : "mellannamn",
      "definition" : "Anvandarens mellanamn.",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "avbestallorginalforpackning.Bestallningsrader.Patientinformation.efternamn",
      "path" : "avbestallorginalforpackning.Bestallningsrader.Patientinformation.efternamn",
      "short" : "efternamn",
      "definition" : "Anvandarens efternamn.",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "avbestallorginalforpackning.Bestallningsrader.Patientinformation.identitetstyp",
      "path" : "avbestallorginalforpackning.Bestallningsrader.Patientinformation.identitetstyp",
      "short" : "identitetstyp",
      "definition" : "identitetstyp",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "code"
      }],
      "binding" : {
        "strength" : "required",
        "valueSet" : "https://fhir.inera.se/ig/druglogistics-dosedispensing/ValueSet/dosedispensing-identitetstyp-vs"
      }
    },
    {
      "id" : "avbestallorginalforpackning.Bestallningsrader.Patientinformation.personid",
      "path" : "avbestallorginalforpackning.Bestallningsrader.Patientinformation.personid",
      "short" : "personid",
      "definition" : "Anvandarens personid",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "avbestallorginalforpackning.Bestallningsrader.Patientinformation.lanskod",
      "path" : "avbestallorginalforpackning.Bestallningsrader.Patientinformation.lanskod",
      "short" : "lanskod",
      "definition" : "Anvandarens folkbokforda lanskod",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "avbestallorginalforpackning.Bestallningsrader.Patientinformation.kommunkod",
      "path" : "avbestallorginalforpackning.Bestallningsrader.Patientinformation.kommunkod",
      "short" : "kommunkod",
      "definition" : "Anvandarens folkbokforda kommunkod",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "avbestallorginalforpackning.Bestallningsrader.NPLpackid",
      "path" : "avbestallorginalforpackning.Bestallningsrader.NPLpackid",
      "short" : "NPLpackid",
      "definition" : "NPLpackid",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "avbestallorginalforpackning.Bestallningsrader.varunummer",
      "path" : "avbestallorginalforpackning.Bestallningsrader.varunummer",
      "short" : "varunummer",
      "definition" : "varunummer",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "avbestallorginalforpackning.Bestallningsrader.receptid",
      "path" : "avbestallorginalforpackning.Bestallningsrader.receptid",
      "short" : "receptid",
      "definition" : "receptid",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "avbestallorginalforpackning.Bestallningsrader.ordinationsid",
      "path" : "avbestallorginalforpackning.Bestallningsrader.ordinationsid",
      "short" : "ordinationsid",
      "definition" : "ordinationsid",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "avbestallorginalforpackning.Bestallningsrader.dosunderlagsversion",
      "path" : "avbestallorginalforpackning.Bestallningsrader.dosunderlagsversion",
      "short" : "dosunderlagsversion",
      "definition" : "dosunderlagsversion",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "avbestallorginalforpackning.Bestallningsrader.bestallningsresultat",
      "path" : "avbestallorginalforpackning.Bestallningsrader.bestallningsresultat",
      "short" : "bestallningsresultat",
      "definition" : "bestallningsresultat",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "integer"
      }]
    },
    {
      "id" : "avbestallorginalforpackning.Bestallningsrader.bestallningsresultattext",
      "path" : "avbestallorginalforpackning.Bestallningsrader.bestallningsresultattext",
      "short" : "bestallningsresultattext",
      "definition" : "bestallningsresultattext",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "avbestallorginalforpackning.Bestallningsrader.bestallningsstatus",
      "path" : "avbestallorginalforpackning.Bestallningsrader.bestallningsstatus",
      "short" : "bestallningsstatus",
      "definition" : "bestallningsstatus",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "code"
      }],
      "binding" : {
        "strength" : "required",
        "valueSet" : "https://fhir.inera.se/ig/druglogistics-dosedispensing/ValueSet/dosedispensing-bestallningsstatus-vs"
      }
    },
    {
      "id" : "avbestallorginalforpackning.Bestallningsrader.statustidpunkt",
      "path" : "avbestallorginalforpackning.Bestallningsrader.statustidpunkt",
      "short" : "statustidpunkt",
      "definition" : "statustidpunkt",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "dateTime"
      }]
    },
    {
      "id" : "avbestallorginalforpackning.Bestallningsrader.bestallningstatustext",
      "path" : "avbestallorginalforpackning.Bestallningsrader.bestallningstatustext",
      "short" : "bestallningstatustext",
      "definition" : "bestallningstatustext",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "avbestallorginalforpackning.Bestallningsrader.meddelandefranapotek",
      "path" : "avbestallorginalforpackning.Bestallningsrader.meddelandefranapotek",
      "short" : "meddelandefranapotek",
      "definition" : "meddelandefranapotek",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "avbestallorginalforpackning.Bestallningsrader.onskadleveranstid",
      "path" : "avbestallorginalforpackning.Bestallningsrader.onskadleveranstid",
      "short" : "onskadleveranstid",
      "definition" : "onskadleveranstid",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "dateTime"
      }]
    },
    {
      "id" : "avbestallorginalforpackning.Bestallningsrader.planeradleveranstid",
      "path" : "avbestallorginalforpackning.Bestallningsrader.planeradleveranstid",
      "short" : "planeradleveranstid",
      "definition" : "planeradleveranstid",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "dateTime"
      }]
    },
    {
      "id" : "avbestallorginalforpackning.Bestallningsrader.dosmottagareid",
      "path" : "avbestallorginalforpackning.Bestallningsrader.dosmottagareid",
      "short" : "dosmottagareid",
      "definition" : "dosmottagareid",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "avbestallorginalforpackning.Bestallningsrader.dosmottagarenamn",
      "path" : "avbestallorginalforpackning.Bestallningsrader.dosmottagarenamn",
      "short" : "dosmottagarenamn",
      "definition" : "dosmottagarenamn",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "avbestallorginalforpackning.Bestallningsrader.bestallningstid",
      "path" : "avbestallorginalforpackning.Bestallningsrader.bestallningstid",
      "short" : "bestallningstid",
      "definition" : "bestallningstid",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "dateTime"
      }]
    },
    {
      "id" : "avbestallorginalforpackning.Bestallningsrader.bestallarefornamn",
      "path" : "avbestallorginalforpackning.Bestallningsrader.bestallarefornamn",
      "short" : "bestallarefornamn",
      "definition" : "bestallarefornamn",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "avbestallorginalforpackning.Bestallningsrader.bestallareefternamn",
      "path" : "avbestallorginalforpackning.Bestallningsrader.bestallareefternamn",
      "short" : "bestallareefternamn",
      "definition" : "bestallareefternamn",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "avbestallorginalforpackning.Bestallningsrader.bestallarearbetsplats",
      "path" : "avbestallorginalforpackning.Bestallningsrader.bestallarearbetsplats",
      "short" : "bestallarearbetsplats",
      "definition" : "bestallarearbetsplats",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    }]
  }
}

```
