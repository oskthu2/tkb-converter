# 2 Versionsinformation - druglogistics: dosedispensing — Dosdispensering v1.1.0

* [**Table of Contents**](toc.md)
* **2 Versionsinformation**

## 2 Versionsinformation

## Versionsinformation

**SAKNAS I KÄLLDOKUMENT.** Det finns ingen TKB med revisionshistorik. Tabellen nedan är sammanställd ur repots taggar och WSDL-filernas revisionsuppgifter.

| | | | |
| :--- | :--- | :--- | :--- |
| 1.1.0 | 2013-09-30 | AvbestallOrginalforpackning 1.0, BestallOrginalforpackning 1.0, HamtaLokaltProduktsortiment 1.1 (och 1.0), HamtaMeddelanden 1.0, HamtaOrginalforpackning 1.0, HamtaVardtagareinformation 1.0, SkapaVardtagare 1.0, SkickaMeddelanden 1.0, SokVardandeEnhet 1.0, UppdateraMeddelandeStatus 1.0, UppdateraVardtagareinformation 1.0 | Ny version 1.1 av HamtaLokaltProduktsortiment med den valfria parametern landsting (releasenoteringar 1.0.6) |
| 1.0.1 | 2012-04-20 |   | Fältlängder uppdaterade i specifikationerna (tagg`TD_DOSDISPENSING_1_0_1_R`) |
| 1.0.0 | 2012-02-02 |   | Tagg`TD_DOSDISPENSING_1_0_0_R`; ny tjänst SokVardandeEnhet i releasenoteringar 1.0.5 |

### Revisioner per tjänstekontrakt (ur WSDL)

| | |
| :--- | :--- |
| AvbestallOrginalforpackning | - |
| BestallOrginalforpackning | - |
| HamtaLokaltProduktsortiment | - |
| HamtaMeddelanden | - |
| HamtaOrginalforpackning | - |
| HamtaVardtagareinformation | - |
| SkapaVardtagare | - |
| SkickaMeddelanden | - |
| SokVardandeEnhet | - |
| UppdateraMeddelandeStatus | - |
| UppdateraVardtagareinformation | - |

### Releasenoteringar

Domänens releasenoteringar ([releasenotes.txt](releasenotes.txt)) återges ordagrant:

```
Releasenotes 1.0.6

==================

2013-09-10: Release version 1.1 of HamtaLokaltProduktsortimentResponder

HamtaLokaltProduktsortimentResponder_1.1
---------------------------------------
- New optional request parameter "landsting" to filter results on
- Removed unused ##other element in request part to avoid ambiguity i xml schema 1.0

HamtaLokaltProduktsortimentResponder_1.1_ext:
---------------------------------------
- New extension schema for new attribute "landsting"

Releasenotes 1.0.5

==================

druglogistics_dosedispensing_1.0.xsd

------------------------------------
Added

- Removed attribute ansvarigkontakttelefon from KontaktinfoResponse
- Removed attribute anhorigkontakttelefon1 from KontaktinfoResponse
- Removed attribute anhorigkontakttelefon2 from KontaktinfoResponse

- New attribute ansvarigkontaktadress in KontaktinfoResponse
- New attribute ansvarigkontaktpostnummer in KontaktinfoResponse
- New attribute ansvarigkontaktpostort in KontaktinfoResponse
- New attribute ansvarigkontakttelefon1 in KontaktinfoResponse
- New attribute ansvarigkontakttelefon2 in KontaktinfoResponse
       
Interactions
------------------------------------
Added
- New interaction, SokVardandeEnhetInteraction.

Releasenotes 1.0.4

==================

druglogistics_dosedispensing_1.0.xsd

------------------------------------

Added

- New enum "Ej registrerad" in VardtagarStatusEnum

- New enum "BOL", "BO", "BL" and "LO" in MeddelandeStatusEnum

- New enum "VG" in MeddelandetypEnum

- New enum "Samtliga status" in BestallningsStatusEnum

Changed name hsaidforskrivare in hsaid in BehorighetsinfoRequest

Changed minOccurs into 0 for

- radid in BestallningsinfoResponse

- dosunderlagsversion in BestallningsinfoResponse

- yrkeskod in BehorighetsinfoRequest

- radid in AvbestallningsinfoRequest

- dosunderlagsversion in AvbestallningsinfoRequest

- onskadleveranstid in AvbestallningsinfoRequest¨

- radid in BestallningsinfoRequest

- dosmottagareid in BestallningsinfoRequest

- dosmottagarenamn in BestallningsinfoRequest

- dosmottagareid in ProduktionsinfoResponse

- dosmottagarenamn in ProduktionsinfoResponse

- dosmottagareid in SarskilltboendeinfoResponse

- dosmottagarenamn in SarskilltboendeinfoResponse

- dosmottagareid in BoendeinfoResponse

- dosmottagarenamn in BoendeinfoResponse

- dosaktor in ProduktionsinfoResponse

Added

- vilandestatusorsak in Vardtagarinformation

- ansvarigkontakttelefon in KontaktinfoResponse

- sandarehsaid in HamtaMeddelandeninfoResponse

HamtaLokaltProduktsortimentResponder_1.0.xsd

---------------------------------------

Changed minOccurs into 0 for

- Produktsortiment in HamtaLokaltProduktsortimentResponseType

SkapaVardtagareResponder_1.0.xsd

--------------------------------

Added

- forskrivaresamtyckearbetsplatskod in SkapaVardtagareType

- forskrivaresamtyckeyrkeskod in SkapaVardtagareType

Releasenotes 1.0.3

==================

inera_ior_1.0.xsd renamed druglogistics_dosedispensing_1.0.xsd

Changed stopptidordination to not mandatory in ProduktionsinfoResponse

Replaced urn:riv:inera:ior with urn:riv:druglogistics:dosedispensing in

-druglogistics_dosedispensing_1.0.xsd (previously inera_ior_1.0.xsd)

-AvbestallOrginalforpackningInteraction_1.0_RIVTABP20.wsdl

-AvbestallOrginalforpackningResponder_1.0.xsd

-BestallOrginalforpackningInteraction_1.0_RIVTABP20.wsdl

-BestallOrginalforpackningResponder_1.0.xsd

-HamtaLokaltProduktsortimentInteraction_1.0_RIVTABP20.wsdl

-HamtaLokaltProduktsortimentResponder_1.0.xsd

-HamtaMeddelandenInteraction_1.0_RIVTABP20.wsdl

-HamtaMeddelandenResponder_1.0.xsd

-HamtaOrginalforpackningInteraction_1.0_RIVTABP20.wsdl

-HamtaOrginalforpackningResponder_1.0.xsd

-HamtaVardtagareinformationInteraction_1.0_RIVTABP20.wsdl

-HamtaVardtagareinformationResponder_1.0.xsd

-SkapaVardtagareInteraction_1.0_RIVTABP20.wsdl

-SkapaVardtagareResponder_1.0.xsd

-SkickaMeddelandenInteraction_1.0_RIVTABP20.wsdl

-SkickaMeddelandenResponder_1.0.xsd

-UppdateraMeddelandeStatusInteraction_1.0_RIVTABP20.wsdl

-UppdateraMeddelandeStatusResponder_1.0.xsd

-UppdateraVardtagareinformationInteraction_1.0_RIVTABP20.wsdl

-UppdateraVardtagareinformationResponder_1.0.xsd

Releasenotes 1.0.2

==================

inera_ior_1.0.xsd

-----------------

Added 

- boendeenhetpostort in SarskilltboendeinfoResponse 

- forskrivarkod in MeddelandenutvalRequest

- lanskod in PatientinfoResponse

- kommunkod in PatientinfoResponse

Changed minOccurs into 0 for 

- frantid in Vardtagarstatusinfo

- tilltid in Vardtagarstatusinfo

- stopptidbestallning in ProduktionsinfoResponse

- boendeenhetavdelning in SarskilltboendeinfoResponse

Changed name in Vardtagarinformation

- Sarskilltboende into hemmaboende

- Boendeinformation into Hemmaboendeinformation

- Sarskilltboendeinformation into Leveransadressinformation

Removed

- arbetsplatskod in BoendeinfoResponse

SkapaVardtagareResponder_1.0.xsd

--------------------------------

Changed minOccurs into 0 in SkapaVardtagareResponseType for

- Patientinformation 

- Produktionsinformation

Added 

- akut in SkapaVardtagareType

HamtaMeddelandenResponder_1.0.xsd

---------------------------------

Changed 

- minOccurs into 0 for Meddelanden in HamtaMeddelandenResponseType

AvbestallOrginalforpackningResponder_1.0.xsd

--------------------------------------------

Changed 

- minOccurs into 0 for Bestallningsrader in AvbestallOrginalforpackningResponseType

BestallOrginalforpackningResponder_1.0.xsd

--------------------------------------------

Changed 

- minOccurs into 0 for Bestallningsrader in BestallOrginalforpackningResponseType

HamtalLokaltproduktsortiment_1.0.xsd

------------------------------------

Changed 

- minOccurs into 0 for Produktsortiment in HamtaLokaltProduktsortimentResponseType

HamtaOrginalforpackningResponder_1.0.xsd

----------------------------------------

Changed 

- minOccurs into 0 for ProduktsortimentResponse in HamtaOrginalforpackningResponseType

HamtaVardtagareinformationResponder_1.0.xsd

-------------------------------------------

Changed 

- minOccurs into 0 for Vardtagarinformation in HamtaVardtagareinformationResponseType

UppdateraMeddelandeStatusResponder_1.0.xsd

------------------------------------------

Changed 

- minOccurs into 0 for Meddelandeninfo in UppdateraMeddelandeStatusResponseType

UppdateraVardtagareinformationResponder_1.0.xsd

------------------------------------------------

Changed 

- minOccurs into 0 for Patientinformation in UppdateraVardtagareinformationResponseType

```

