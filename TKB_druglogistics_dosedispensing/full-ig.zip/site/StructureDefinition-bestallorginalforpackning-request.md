# BestallOrginalforpackning — Request - druglogistics: dosedispensing — Dosdispensering v1.1.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **BestallOrginalforpackning — Request**

## Logical Model: BestallOrginalforpackning — Request 

| | |
| :--- | :--- |
| *Official URL*:https://fhir.inera.se/ig/druglogistics-dosedispensing/StructureDefinition/bestallorginalforpackning-request | *Version*:1.1.0 |
| Draft as of 2026-09-26 | *Computable Name*:BestallOrginalforpackningRequest |
| **Copyright/Legal**: Copyright 2024 Inera AB. Licensieras under Creative Commons Attribution 4.0. | |

 
Logisk modell för begäran i BestallOrginalforpackning (urn:riv:druglogistics:dosedispensing:BestallOrginalforpackningResponder:1, BestallOrginalforpackningType), inklusive SOAP-huvuden enligt WSDL. 

**Usages:**

* This Logical Model is not used by any profiles in this Specification

You can also check for [usages in the FHIR IG Statistics](https://packages2.fhir.org/xig/resource/inera.druglogistics-dosedispensing|current/StructureDefinition/StructureDefinition-bestallorginalforpackning-request.json)

### Formal Views of Profile Content

 [Description of Profiles, Differentials, Snapshots and how the different presentations work](http://build.fhir.org/ig/FHIR/ig-guidance/readingIgs.html#structure-definitions). 

 

Other representations of profile: [CSV](StructureDefinition-bestallorginalforpackning-request.csv), [Excel](StructureDefinition-bestallorginalforpackning-request.xlsx) 



## Resource Content

```json
{
  "resourceType" : "StructureDefinition",
  "id" : "bestallorginalforpackning-request",
  "extension" : [{
    "url" : "http://hl7.org/fhir/StructureDefinition/structuredefinition-type-characteristics",
    "valueCode" : "can-be-target"
  }],
  "url" : "https://fhir.inera.se/ig/druglogistics-dosedispensing/StructureDefinition/bestallorginalforpackning-request",
  "version" : "1.1.0",
  "name" : "BestallOrginalforpackningRequest",
  "title" : "BestallOrginalforpackning — Request",
  "status" : "draft",
  "date" : "2026-09-26T19:21:50+00:00",
  "contact" : [{
    "name" : "Inera Arkitektur",
    "telecom" : [{
      "system" : "url",
      "value" : "https://www.inera.se"
    }]
  }],
  "description" : "Logisk modell för begäran i BestallOrginalforpackning\n(urn:riv:druglogistics:dosedispensing:BestallOrginalforpackningResponder:1, BestallOrginalforpackningType), inklusive SOAP-huvuden enligt WSDL.",
  "copyright" : "Copyright 2024 Inera AB. Licensieras under Creative Commons Attribution 4.0.",
  "fhirVersion" : "4.0.1",
  "kind" : "logical",
  "abstract" : false,
  "type" : "https://fhir.inera.se/ig/druglogistics-dosedispensing/StructureDefinition/bestallorginalforpackning-request",
  "baseDefinition" : "http://hl7.org/fhir/StructureDefinition/Base",
  "derivation" : "specialization",
  "differential" : {
    "element" : [{
      "id" : "bestallorginalforpackning-request",
      "path" : "bestallorginalforpackning-request",
      "short" : "BestallOrginalforpackning — Request",
      "definition" : "Logisk modell för begäran i BestallOrginalforpackning\n(urn:riv:druglogistics:dosedispensing:BestallOrginalforpackningResponder:1, BestallOrginalforpackningType), inklusive SOAP-huvuden enligt WSDL."
    },
    {
      "id" : "bestallorginalforpackning-request.logicalAddress",
      "path" : "bestallorginalforpackning-request.logicalAddress",
      "short" : "logicalAddress",
      "definition" : "SOAP-huvud LogicalAddress. Typen har inga element utöver utökningspunkter.",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "BackboneElement"
      }]
    },
    {
      "id" : "bestallorginalforpackning-request.glnkod",
      "path" : "bestallorginalforpackning-request.glnkod",
      "short" : "glnkod",
      "definition" : "glnkod",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "bestallorginalforpackning-request.Behorighetsinformation",
      "path" : "bestallorginalforpackning-request.Behorighetsinformation",
      "short" : "Behorighetsinformation",
      "definition" : "Behorighetsinformation",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "BackboneElement"
      }]
    },
    {
      "id" : "bestallorginalforpackning-request.Behorighetsinformation.fornamn",
      "path" : "bestallorginalforpackning-request.Behorighetsinformation.fornamn",
      "short" : "fornamn",
      "definition" : "fornamn",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "bestallorginalforpackning-request.Behorighetsinformation.efternamn",
      "path" : "bestallorginalforpackning-request.Behorighetsinformation.efternamn",
      "short" : "efternamn",
      "definition" : "efternamn",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "bestallorginalforpackning-request.Behorighetsinformation.forskrivarkod",
      "path" : "bestallorginalforpackning-request.Behorighetsinformation.forskrivarkod",
      "short" : "forskrivarkod",
      "definition" : "forskrivarkod",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "bestallorginalforpackning-request.Behorighetsinformation.yrkeskod",
      "path" : "bestallorginalforpackning-request.Behorighetsinformation.yrkeskod",
      "short" : "yrkeskod",
      "definition" : "yrkeskod",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "code"
      }],
      "binding" : {
        "strength" : "required",
        "valueSet" : "https://fhir.inera.se/ig/druglogistics-dosedispensing/ValueSet/dosedispensing-yrkeskod-vs"
      }
    },
    {
      "id" : "bestallorginalforpackning-request.Behorighetsinformation.arbetsplatskod",
      "path" : "bestallorginalforpackning-request.Behorighetsinformation.arbetsplatskod",
      "short" : "arbetsplatskod",
      "definition" : "arbetsplatskod",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "bestallorginalforpackning-request.Behorighetsinformation.hsaid",
      "path" : "bestallorginalforpackning-request.Behorighetsinformation.hsaid",
      "short" : "hsaid",
      "definition" : "hsaid",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "bestallorginalforpackning-request.Behorighetsinformation.personnummer",
      "path" : "bestallorginalforpackning-request.Behorighetsinformation.personnummer",
      "short" : "personnummer",
      "definition" : "personnummer",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "bestallorginalforpackning-request.Behorighetsinformation.organisationsnummer",
      "path" : "bestallorginalforpackning-request.Behorighetsinformation.organisationsnummer",
      "short" : "organisationsnummer",
      "definition" : "organisationsnummer",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "bestallorginalforpackning-request.Bestallningsinfo",
      "path" : "bestallorginalforpackning-request.Bestallningsinfo",
      "short" : "Bestallningsinfo",
      "definition" : "Bestallningsinfo",
      "min" : 1,
      "max" : "*",
      "type" : [{
        "code" : "BackboneElement"
      }]
    },
    {
      "id" : "bestallorginalforpackning-request.Bestallningsinfo.Patientinformation",
      "path" : "bestallorginalforpackning-request.Bestallningsinfo.Patientinformation",
      "short" : "Patientinformation",
      "definition" : "Patientinformation",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "BackboneElement"
      }]
    },
    {
      "id" : "bestallorginalforpackning-request.Bestallningsinfo.Patientinformation.fornamn",
      "path" : "bestallorginalforpackning-request.Bestallningsinfo.Patientinformation.fornamn",
      "short" : "fornamn",
      "definition" : "Anvandarens fornamn.",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "bestallorginalforpackning-request.Bestallningsinfo.Patientinformation.mellannamn",
      "path" : "bestallorginalforpackning-request.Bestallningsinfo.Patientinformation.mellannamn",
      "short" : "mellannamn",
      "definition" : "Anvandarens mellanamn.",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "bestallorginalforpackning-request.Bestallningsinfo.Patientinformation.efternamn",
      "path" : "bestallorginalforpackning-request.Bestallningsinfo.Patientinformation.efternamn",
      "short" : "efternamn",
      "definition" : "Anvandarens efternamn.",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "bestallorginalforpackning-request.Bestallningsinfo.Patientinformation.identitetstyp",
      "path" : "bestallorginalforpackning-request.Bestallningsinfo.Patientinformation.identitetstyp",
      "short" : "identitetstyp",
      "definition" : "identitetstyp",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "code"
      }],
      "binding" : {
        "strength" : "required",
        "valueSet" : "https://fhir.inera.se/ig/druglogistics-dosedispensing/ValueSet/dosedispensing-identitetstyp-vs"
      }
    },
    {
      "id" : "bestallorginalforpackning-request.Bestallningsinfo.Patientinformation.personid",
      "path" : "bestallorginalforpackning-request.Bestallningsinfo.Patientinformation.personid",
      "short" : "personid",
      "definition" : "Anvandarens personid",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "bestallorginalforpackning-request.Bestallningsinfo.Patientinformation.lanskod",
      "path" : "bestallorginalforpackning-request.Bestallningsinfo.Patientinformation.lanskod",
      "short" : "lanskod",
      "definition" : "Anvandarens folkbokforda lanskod",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "bestallorginalforpackning-request.Bestallningsinfo.Patientinformation.kommunkod",
      "path" : "bestallorginalforpackning-request.Bestallningsinfo.Patientinformation.kommunkod",
      "short" : "kommunkod",
      "definition" : "Anvandarens folkbokforda kommunkod",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "bestallorginalforpackning-request.Bestallningsinfo.bestallningsid",
      "path" : "bestallorginalforpackning-request.Bestallningsinfo.bestallningsid",
      "short" : "bestallningsid",
      "definition" : "bestallningsid",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "bestallorginalforpackning-request.Bestallningsinfo.radid",
      "path" : "bestallorginalforpackning-request.Bestallningsinfo.radid",
      "short" : "radid",
      "definition" : "radid",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "bestallorginalforpackning-request.Bestallningsinfo.NPLpackid",
      "path" : "bestallorginalforpackning-request.Bestallningsinfo.NPLpackid",
      "short" : "NPLpackid",
      "definition" : "NPLpackid",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "bestallorginalforpackning-request.Bestallningsinfo.varunummer",
      "path" : "bestallorginalforpackning-request.Bestallningsinfo.varunummer",
      "short" : "varunummer",
      "definition" : "varunummer",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "bestallorginalforpackning-request.Bestallningsinfo.receptid",
      "path" : "bestallorginalforpackning-request.Bestallningsinfo.receptid",
      "short" : "receptid",
      "definition" : "receptid",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "bestallorginalforpackning-request.Bestallningsinfo.ordinationsid",
      "path" : "bestallorginalforpackning-request.Bestallningsinfo.ordinationsid",
      "short" : "ordinationsid",
      "definition" : "ordinationsid",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "bestallorginalforpackning-request.Bestallningsinfo.dosunderlagsversion",
      "path" : "bestallorginalforpackning-request.Bestallningsinfo.dosunderlagsversion",
      "short" : "dosunderlagsversion",
      "definition" : "dosunderlagsversion",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "bestallorginalforpackning-request.Bestallningsinfo.antalforpackningar",
      "path" : "bestallorginalforpackning-request.Bestallningsinfo.antalforpackningar",
      "short" : "antalforpackningar",
      "definition" : "antalforpackningar",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "bestallorginalforpackning-request.Bestallningsinfo.akutbestallning",
      "path" : "bestallorginalforpackning-request.Bestallningsinfo.akutbestallning",
      "short" : "akutbestallning",
      "definition" : "akutbestallning",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "boolean"
      }]
    },
    {
      "id" : "bestallorginalforpackning-request.Bestallningsinfo.maxveckodos",
      "path" : "bestallorginalforpackning-request.Bestallningsinfo.maxveckodos",
      "short" : "maxveckodos",
      "definition" : "maxveckodos",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "bestallorginalforpackning-request.Bestallningsinfo.maxdygnsdos",
      "path" : "bestallorginalforpackning-request.Bestallningsinfo.maxdygnsdos",
      "short" : "maxdygnsdos",
      "definition" : "maxdygnsdos",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "bestallorginalforpackning-request.Bestallningsinfo.dosmottagareid",
      "path" : "bestallorginalforpackning-request.Bestallningsinfo.dosmottagareid",
      "short" : "dosmottagareid",
      "definition" : "dosmottagareid",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "bestallorginalforpackning-request.Bestallningsinfo.dosmottagarenamn",
      "path" : "bestallorginalforpackning-request.Bestallningsinfo.dosmottagarenamn",
      "short" : "dosmottagarenamn",
      "definition" : "dosmottagarenamn",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "bestallorginalforpackning-request.Bestallningsinfo.meddelandetillapotek",
      "path" : "bestallorginalforpackning-request.Bestallningsinfo.meddelandetillapotek",
      "short" : "meddelandetillapotek",
      "definition" : "meddelandetillapotek",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "bestallorginalforpackning-request.Bestallningsinfo.onskadleveransdatum",
      "path" : "bestallorginalforpackning-request.Bestallningsinfo.onskadleveransdatum",
      "short" : "onskadleveransdatum",
      "definition" : "onskadleveransdatum",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "dateTime"
      }]
    }]
  }
}

```
