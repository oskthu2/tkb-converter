# Hem - masterdata: citizen: patient v1.0.0-rc1.snapshot

* [**Table of Contents**](toc.md)
* **Hem**

## Hem

| | |
| :--- | :--- |
| *Official URL*:https://fhir.inera.se/ig/masterdata-citizen-patient/ImplementationGuide/inera.masterdata-citizen-patient | *Version*:1.0.0-rc1.snapshot |
| Draft as of 2026-10-08 | *Computable Name*:masterdatacitizenpatient |
| **Copyright/Legal**: Copyright 2024 Inera AB. Licensieras under Creative Commons Attribution 4.0. | |

# masterdata: citizen: patient

**TKB-version:** 1.0_RC1 · **IG-version:** 1.0.0-rc1.snapshot · **Källa:** Bitbucket-commit `efa4099dabb2` (ingen tagg) 

## Översikt

FHIR Implementation Guide för tjänstedomänen **masterdata: citizen: patient** (underlagförprocesstöd: invånare: patientuppgifter) version 1.0. Genererad från Ineras Tjänstekontraktsbeskrivning (TKB), version 1.0_RC1 (2017-01-26), och domänens WSDL- och XSD-filer (senaste commit på master, efa4099dabb2; domänen har inga taggar).

Tjänstedomänen hanterar patientens kontaktuppgifter: telefonnummer och elektroniska adresser samt kontaktpersoner som närstående, släktingar och företrädare. TKB:n är till stor del en ej ifylld mall, så fältreglerna i [avsnitt 7](7-tjanstekontrakt.md) bygger på schemana.

Domänen innehåller följande tjänstekontrakt:

| | | |
| :--- | :--- | :--- |
| [GetPatientContactInformation](7-tjanstekontrakt.md#getpatientcontactinformation) | 1.0 | Kontraktet används för att hämta kontaktuppgifter för en patient. |
| [UpdatePatientContactInformation](7-tjanstekontrakt.md#updatepatientcontactinformation) | 1.0 | Kontraktet används för att hämta kontaktuppgifter för en patient. |

## Innehåll

* [1 Inledning](1-inledning.md)
* [2 Versionsinformation](2-versionsinformation.md)
* [3 Tjänstedomänens arkitektur](3-tjanstedomanens-arkitektur.md)
* [4 Tjänstedomänens krav och regler](4-tjanstedomanens-krav-och-regler.md)
* [5 Tjänstedomänens meddelandemodeller](5-tjanstedomanens-meddelandemodeller.md)
* [6 Gemensamma informationskomponenter](6-gemensamma-informationskomponenter.md)
* [7 Tjänstekontrakt](7-tjanstekontrakt.md)
* [Artefakter](artifacts.md)

