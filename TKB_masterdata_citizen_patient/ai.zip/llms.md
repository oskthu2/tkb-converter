# inera.masterdata-citizen-patient#1.0.0: masterdata: citizen: patient

## Pages

* [Hem](index.md)
* [7 Tjänstekontrakt](7-tjanstekontrakt.md)
* [5 Tjänstedomänens meddelandemodeller](5-tjanstedomanens-meddelandemodeller.md)
* [Artifacts Summary](artifacts.md)
* [6 Gemensamma informationskomponenter](6-gemensamma-informationskomponenter.md)
* [3 Tjänstedomänens arkitektur](3-tjanstedomanens-arkitektur.md)
* [4 Tjänstedomänens krav och regler](4-tjanstedomanens-krav-och-regler.md)
* [2 Versionsinformation](2-versionsinformation.md)
* [1 Inledning](1-inledning.md)

## Resources

### CodeSystems

* [Resultatkod](CodeSystem-masterdata-citizen-patient-resultcodeenum-cs.md)
* [Typ av närståenderelation](CodeSystem-masterdata-citizen-patient-typeofcloserelation-cs.md)
* [Typ av kontakt](CodeSystem-masterdata-citizen-patient-typeofcontact-cs.md)
* [Kodverk för typ av kontaktrelation](CodeSystem-masterdata-citizen-patient-typeofcontactrelationcodesystem-cs.md)
* [Typ av släktrelation](CodeSystem-masterdata-citizen-patient-typeofrelative-cs.md)
* [Typ av företrädare](CodeSystem-masterdata-citizen-patient-typeofrepresentative-cs.md)
* [Typ av telekommunikation (kontaktperson)](CodeSystem-masterdata-citizen-patient-typeoftelecomcontactperson-cs.md)
* [Typ av telekommunikation (patient)](CodeSystem-masterdata-citizen-patient-typeoftelecompatient-cs.md)

### ValueSets

* [Resultatkod](ValueSet-masterdata-citizen-patient-resultcodeenum-vs.md)
* [Typ av närståenderelation](ValueSet-masterdata-citizen-patient-typeofcloserelation-vs.md)
* [Typ av kontakt](ValueSet-masterdata-citizen-patient-typeofcontact-vs.md)
* [Kodverk för typ av kontaktrelation](ValueSet-masterdata-citizen-patient-typeofcontactrelationcodesystem-vs.md)
* [Typ av släktrelation](ValueSet-masterdata-citizen-patient-typeofrelative-vs.md)
* [Typ av företrädare](ValueSet-masterdata-citizen-patient-typeofrepresentative-vs.md)
* [Typ av telekommunikation (kontaktperson)](ValueSet-masterdata-citizen-patient-typeoftelecomcontactperson-vs.md)
* [Typ av telekommunikation (patient)](ValueSet-masterdata-citizen-patient-typeoftelecompatient-vs.md)

### Logicals

* [GetPatientContactInformation — Request](StructureDefinition-getpatientcontactinformation-request.md)
* [GetPatientContactInformation — Response](StructureDefinition-getpatientcontactinformation.md)
* [UpdatePatientContactInformation — Request](StructureDefinition-updatepatientcontactinformation-request.md)
* [UpdatePatientContactInformation — Response](StructureDefinition-updatepatientcontactinformation.md)

### ImplementationGuides

* [masterdata: citizen: patient](index.md)
