# Hem - followup: processdevelopment: infections v1.0.2

* [**Table of Contents**](toc.md)
* **Hem**

## Hem

| | |
| :--- | :--- |
| *Official URL*:https://fhir.inera.se/ig/followup-processdevelopment-infections/ImplementationGuide/inera.followup-processdevelopment-infections | *Version*:1.0.2 |
| Draft as of 2026-09-26 | *Computable Name*:followupprocessdevelopmentinfections |
| **Copyright/Legal**: Copyright 2024 Inera AB. Licensieras under Creative Commons Attribution 4.0. | |

# followup: processdevelopment: infections

## Översikt

FHIR Implementation Guide för tjänstedomänen **followup: processdevelopment: infections** version 1.0.2. Genererad från Ineras Tjänstekontraktsbeskrivning (TKB).

Domänen innehåller tjänstekontrakt för registrering och radering av infektioner, antibiotikaanvändning, mikrolaboratoriesvar, åtgärder, tillstånd samt vårdtillfällen i Infektionsverktyget.

Domänen innehåller följande tjänstekontrakt:

| | | |
| :--- | :--- | :--- |
| [ProcessPrescriptionReason](7-tjanstekontrakt.md#processprescriptionreason) | 1.0 | Registrerar en ordinationsorsak med information om patient, organisatorisk enhet och ordination |
| [DeletePrescriptionReason](7-tjanstekontrakt.md#deleteprescriptionreason) | 1.0 | Raderar information som tidigare registrerats via ProcessPrescriptionReason |
| [DeletePrescription](7-tjanstekontrakt.md#deleteprescription) | 1.0 | Raderar information om en ordination som registrerats via ProcessPrescriptionReason |
| [ProcessLaboratoryReport](7-tjanstekontrakt.md#processlaboratoryreport) | 1.0 | Registrerar ett nytt laboratoriesvar med tillhörande information |
| [DeleteLaboratoryReport](7-tjanstekontrakt.md#deletelaboratoryreport) | 1.0 | Raderar information som tidigare registrerats via ProcessLaboratoryReport |
| [ProcessCareEncounter](7-tjanstekontrakt.md#processcareencounter) | 1.0 | Skriver vårdkontaktsdata till Infektionsverktyget |
| [DeleteCareEncounter](7-tjanstekontrakt.md#deletecareencounter) | 1.0 | Raderar information som tidigare registrerats via ProcessCareEncounter |

## Innehåll

* [1 Inledning](1-inledning.md)
* [2 Versionsinformation](2-versionsinformation.md)
* [3 Tjänstedomänens arkitektur](3-tjanstedomanens-arkitektur.md)
* [4 Tjänstedomänens krav och regler](4-tjanstedomanens-krav-och-regler.md)
* [5 Tjänstedomänens meddelandemodeller](5-tjanstedomanens-meddelandemodeller.md)
* [6 Gemensamma informationskomponenter](6-gemensamma-informationskomponenter.md)
* [7 Tjänstekontrakt](7-tjanstekontrakt.md)
* [Artefakter](artifacts.md)

