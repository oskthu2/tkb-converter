# Hem - followup: processdevelopment: infections v1.0.2-snapshot

* [**Table of Contents**](toc.md)
* **Hem**

## Hem

| | |
| :--- | :--- |
| *Official URL*:https://fhir.inera.se/ig/followup-processdevelopment-infections/ImplementationGuide/inera.followup-processdevelopment-infections | *Version*:1.0.2-snapshot |
| Draft as of 2026-11-06 | *Computable Name*:followupprocessdevelopmentinfections |
| **Copyright/Legal**: Copyright 2024 Inera AB. Licensieras under Creative Commons Attribution 4.0. | |

# followup: processdevelopment: infections

**TKB-version:** 1.0.2 · **IG-version:** 1.0.2-snapshot · **Källa:** Bitbucket-commit `b9bb3968f778` (ingen tagg) 

## Översikt

* Beskrivning: Svenskt kortnamn
  * Infektionsuppföljning är ett nationellt enhetligt IT-stöd som ska användas i lokalt förbättringsarbete. Syftet är att förebygga vårdrelaterade infektioner och förbättra kvaliteten i användningen av antibiotika. Infektionsuppföljnings tjänstekontrakt specificerar hur informationsöverföringen om vårdkontakter, antibiotikaanvändning, diagnoser, åtgärder och mikrolaboratoriesvar ska gå till från anslutna vårdgivare. Motsvarande tjänstekontrakt finns för att specificera hur radering av tidigare registrerad information ska gå till.Infektionsuppföljning har också ett tjänstekontrakt för en terminologiurvalstjänst, som specificerar vilka termer och begrepp som är aktuella för de informationsmängder som ingår i Infektionsverktyget.: infektionsuppföljning
* Beskrivning: Svenskt namn
  * Infektionsuppföljning är ett nationellt enhetligt IT-stöd som ska användas i lokalt förbättringsarbete. Syftet är att förebygga vårdrelaterade infektioner och förbättra kvaliteten i användningen av antibiotika. Infektionsuppföljnings tjänstekontrakt specificerar hur informationsöverföringen om vårdkontakter, antibiotikaanvändning, diagnoser, åtgärder och mikrolaboratoriesvar ska gå till från anslutna vårdgivare. Motsvarande tjänstekontrakt finns för att specificera hur radering av tidigare registrerad information ska gå till.Infektionsuppföljning har också ett tjänstekontrakt för en terminologiurvalstjänst, som specificerar vilka termer och begrepp som är aktuella för de informationsmängder som ingår i Infektionsverktyget.: uppföljning kärnprocess:hantera utfall för individer:infektioner
* Beskrivning: Typ
  * Infektionsuppföljning är ett nationellt enhetligt IT-stöd som ska användas i lokalt förbättringsarbete. Syftet är att förebygga vårdrelaterade infektioner och förbättra kvaliteten i användningen av antibiotika. Infektionsuppföljnings tjänstekontrakt specificerar hur informationsöverföringen om vårdkontakter, antibiotikaanvändning, diagnoser, åtgärder och mikrolaboratoriesvar ska gå till från anslutna vårdgivare. Motsvarande tjänstekontrakt finns för att specificera hur radering av tidigare registrerad information ska gå till.Infektionsuppföljning har också ett tjänstekontrakt för en terminologiurvalstjänst, som specificerar vilka termer och begrepp som är aktuella för de informationsmängder som ingår i Infektionsverktyget.: Nationell tjänstedomän
* Beskrivning: Anmärkning
  * Infektionsuppföljning är ett nationellt enhetligt IT-stöd som ska användas i lokalt förbättringsarbete. Syftet är att förebygga vårdrelaterade infektioner och förbättra kvaliteten i användningen av antibiotika. Infektionsuppföljnings tjänstekontrakt specificerar hur informationsöverföringen om vårdkontakter, antibiotikaanvändning, diagnoser, åtgärder och mikrolaboratoriesvar ska gå till från anslutna vårdgivare. Motsvarande tjänstekontrakt finns för att specificera hur radering av tidigare registrerad information ska gå till.Infektionsuppföljning har också ett tjänstekontrakt för en terminologiurvalstjänst, som specificerar vilka termer och begrepp som är aktuella för de informationsmängder som ingår i Infektionsverktyget.: dold på rivta.se
* Beskrivning: Källkod
  * Infektionsuppföljning är ett nationellt enhetligt IT-stöd som ska användas i lokalt förbättringsarbete. Syftet är att förebygga vårdrelaterade infektioner och förbättra kvaliteten i användningen av antibiotika. Infektionsuppföljnings tjänstekontrakt specificerar hur informationsöverföringen om vårdkontakter, antibiotikaanvändning, diagnoser, åtgärder och mikrolaboratoriesvar ska gå till från anslutna vårdgivare. Motsvarande tjänstekontrakt finns för att specificera hur radering av tidigare registrerad information ska gå till.Infektionsuppföljning har också ett tjänstekontrakt för en terminologiurvalstjänst, som specificerar vilka termer och begrepp som är aktuella för de informationsmängder som ingår i Infektionsverktyget.: [Bitbucket](https://bitbucket.org/rivta-domains/riv.followup.processdevelopment.infections/src)
* Beskrivning: Ärenden
  * Infektionsuppföljning är ett nationellt enhetligt IT-stöd som ska användas i lokalt förbättringsarbete. Syftet är att förebygga vårdrelaterade infektioner och förbättra kvaliteten i användningen av antibiotika. Infektionsuppföljnings tjänstekontrakt specificerar hur informationsöverföringen om vårdkontakter, antibiotikaanvändning, diagnoser, åtgärder och mikrolaboratoriesvar ska gå till från anslutna vårdgivare. Motsvarande tjänstekontrakt finns för att specificera hur radering av tidigare registrerad information ska gå till.Infektionsuppföljning har också ett tjänstekontrakt för en terminologiurvalstjänst, som specificerar vilka termer och begrepp som är aktuella för de informationsmängder som ingår i Infektionsverktyget.: [Bitbucket issues](https://bitbucket.org/rivta-domains/riv.followup.processdevelopment.infections/issues)
* Beskrivning: Underlag för denna IG
  * Infektionsuppföljning är ett nationellt enhetligt IT-stöd som ska användas i lokalt förbättringsarbete. Syftet är att förebygga vårdrelaterade infektioner och förbättra kvaliteten i användningen av antibiotika. Infektionsuppföljnings tjänstekontrakt specificerar hur informationsöverföringen om vårdkontakter, antibiotikaanvändning, diagnoser, åtgärder och mikrolaboratoriesvar ska gå till från anslutna vårdgivare. Motsvarande tjänstekontrakt finns för att specificera hur radering av tidigare registrerad information ska gå till.Infektionsuppföljning har också ett tjänstekontrakt för en terminologiurvalstjänst, som specificerar vilka termer och begrepp som är aktuella för de informationsmängder som ingår i Infektionsverktyget.: Version 1.0.2 ·[commit b9bb3968f778](https://bitbucket.org/rivta-domains/riv.followup.processdevelopment.infections/src/b9bb3968f778f951a15068def0c8a9e085e9c838)
* Beskrivning: RIV-TA-portalen
  * Infektionsuppföljning är ett nationellt enhetligt IT-stöd som ska användas i lokalt förbättringsarbete. Syftet är att förebygga vårdrelaterade infektioner och förbättra kvaliteten i användningen av antibiotika. Infektionsuppföljnings tjänstekontrakt specificerar hur informationsöverföringen om vårdkontakter, antibiotikaanvändning, diagnoser, åtgärder och mikrolaboratoriesvar ska gå till från anslutna vårdgivare. Motsvarande tjänstekontrakt finns för att specificera hur radering av tidigare registrerad information ska gå till.Infektionsuppföljning har också ett tjänstekontrakt för en terminologiurvalstjänst, som specificerar vilka termer och begrepp som är aktuella för de informationsmängder som ingår i Infektionsverktyget.: [Alla tjänstedomäner](https://oskthu2.github.io/tkb-converter/rivta-portal/tjanstedomaner.html)·[Alla tjänstekontrakt](https://oskthu2.github.io/tkb-converter/rivta-portal/tjanstekontrakt.html)

FHIR Implementation Guide för tjänstedomänen **followup: processdevelopment: infections** version 1.0.2. Genererad från Ineras Tjänstekontraktsbeskrivning (TKB).

Domänen innehåller tjänstekontrakt för registrering och radering av infektioner, antibiotikaanvändning, mikrolaboratoriesvar, åtgärder, tillstånd samt vårdtillfällen i Infektionsverktyget.

Domänen innehåller följande tjänstekontrakt:

| | | |
| :--- | :--- | :--- |
| [ProcessPrescriptionReason](7-tjanstekontrakt.md#processprescriptionreason) | 1.0 | Registrerar en ordinationsorsak med information om patient, organisatorisk enhet och ordination |
| [DeletePrescriptionReason](7-tjanstekontrakt.md#deleteprescriptionreason) | 1.0 | Raderar information som tidigare registrerats via ProcessPrescriptionReason |
| [DeletePrescription](7-tjanstekontrakt.md#deleteprescription) | 1.0 | Raderar information om en ordination som registrerats via ProcessPrescriptionReason |
| [ProcessLaboratoryReport](7-tjanstekontrakt.md#processlaboratoryreport) | 1.0 | Registrerar ett nytt laboratoriesvar med tillhörande information |
| [DeleteLaboratoryReport](7-tjanstekontrakt.md#deletelaboratoryreport) | 1.0 | Raderar information som tidigare registrerats via ProcessLaboratoryReport |
| [ProcessCareEncounter](7-tjanstekontrakt.md#processcareencounter) | 1.0 | Skriver vårdkontaktsdata till Infektionsverktyget |
| [DeleteCareEncounter](7-tjanstekontrakt.md#deletecareencounter) | 1.0 | Raderar information som tidigare registrerats via ProcessCareEncounter |

### Versioner och granskningar

| | | | |
| :--- | :--- | :--- | :--- |
| 1.0.2_RC1 | TKB, AB | Arkitektur & Regelverk: Säkerhet: GodkändArkitektur & Regelverk: Teknik: GodkändArkitektur & Regelverk: Informatik: Delvis Godkänd | [zip](https://bitbucket.org/rivta-domains/riv.followup.processdevelopment.infections/get/followup_processdevelopment_infections_1.0.2_RC1.zip)·[källkod](https://bitbucket.org/rivta-domains/riv.followup.processdevelopment.infections/src/followup_processdevelopment_infections_1.0.2_RC1) |
| trunk | TKB, AB |  | [källkod](https://bitbucket.org/rivta-domains/riv.followup.processdevelopment.infections/src/master) |

*Zip-arkiven hämtas från taggarna på Bitbucket. Granskningsprotokollen publicerades på rivta.se och länkas inte härifrån.*

*Källa: ögonblicksbild av DOMDB från 2021-08-24, via RIV-TA-portalen.*

## Innehåll

* [1 Inledning](1-inledning.md)
* [2 Versionsinformation](2-versionsinformation.md)
* [3 Tjänstedomänens arkitektur](3-tjanstedomanens-arkitektur.md)
* [4 Tjänstedomänens krav och regler](4-tjanstedomanens-krav-och-regler.md)
* [5 Tjänstedomänens meddelandemodeller](5-tjanstedomanens-meddelandemodeller.md)
* [6 Gemensamma informationskomponenter](6-gemensamma-informationskomponenter.md)
* [7 Tjänstekontrakt](7-tjanstekontrakt.md)
* [Artefakter](artifacts.md)

