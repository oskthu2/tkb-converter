# inera.followup-processdevelopment-infections#1.0.2: followup: processdevelopment: infections

## Pages

* [Hem](index.md)
* [7 Tjänstekontrakt](7-tjanstekontrakt.md)
* [1 Inledning](1-inledning.md)
* [4 Tjänstedomänens krav och regler](4-tjanstedomanens-krav-och-regler.md)
* [6 Gemensamma informationskomponenter](6-gemensamma-informationskomponenter.md)
* [3 Tjänstedomänens arkitektur](3-tjanstedomanens-arkitektur.md)
* [Artifacts Summary](artifacts.md)
* [2 Versionsinformation](2-versionsinformation.md)
* [5 Tjänstedomänens meddelandemodeller](5-tjanstedomanens-meddelandemodeller.md)

## Resources

### Logicals

* [DeleteCareEncounter — Request](StructureDefinition-deletecareencounter-request.md)
* [DeleteCareEncounter — Response](StructureDefinition-deletecareencounter-response.md)
* [DeleteLaboratoryReport — Request](StructureDefinition-deletelaboratoryreport-request.md)
* [DeleteLaboratoryReport — Response](StructureDefinition-deletelaboratoryreport-response.md)
* [DeletePrescription — Request](StructureDefinition-deleteprescription-request.md)
* [DeletePrescription — Response](StructureDefinition-deleteprescription-response.md)
* [DeletePrescriptionReason — Request](StructureDefinition-deleteprescriptionreason-request.md)
* [DeletePrescriptionReason — Response](StructureDefinition-deleteprescriptionreason-response.md)
* [ProcessCareEncounter — Request](StructureDefinition-processcareencounter-request.md)
* [ProcessCareEncounter — Response](StructureDefinition-processcareencounter-response.md)
* [ProcessLaboratoryReport — Request](StructureDefinition-processlaboratoryreport-request.md)
* [ProcessLaboratoryReport — Response](StructureDefinition-processlaboratoryreport-response.md)
* [ProcessPrescriptionReason — Request](StructureDefinition-processprescriptionreason-request.md)
* [ProcessPrescriptionReason — Response](StructureDefinition-processprescriptionreason-response.md)

### ImplementationGuides

* [followup: processdevelopment: infections](index.md)
