# ProcessPrescriptionReason — Request - followup: processdevelopment: infections v1.0.2-snapshot

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **ProcessPrescriptionReason — Request**

## Logical Model: ProcessPrescriptionReason — Request 

| | |
| :--- | :--- |
| *Official URL*:https://fhir.inera.se/ig/followup-processdevelopment-infections/StructureDefinition/processprescriptionreason-request | *Version*:1.0 |
| Draft as of 2026-11-06 | *Computable Name*:ProcessPrescriptionReasonRequest |
| **Copyright/Legal**: Copyright 2024 Inera AB. Licensieras under Creative Commons Attribution 4.0. | |

 
Logisk modell för requestparametrar i tjänstekontraktet ProcessPrescriptionReason (RIV-TA urn:riv:followup:processdevelopment:infections:ProcessPrescriptionReason:1). Registrerar en ordinationsorsak med information om patient, organisatorisk enhet, eventuellt aktivitet, ordination och ordinerad substans. 

**Usages:**

* This Logical Model is not used by any profiles in this Specification

You can also check for [usages in the FHIR IG Statistics](https://packages2.fhir.org/xig/resource/inera.followup-processdevelopment-infections|current/StructureDefinition/StructureDefinition-processprescriptionreason-request.json)

### Formal Views of Profile Content

 [Description of Profiles, Differentials, Snapshots and how the different presentations work](http://build.fhir.org/ig/FHIR/ig-guidance/readingIgs.html#structure-definitions). 

 

Other representations of profile: [CSV](StructureDefinition-processprescriptionreason-request.csv), [Excel](StructureDefinition-processprescriptionreason-request.xlsx) 



## Resource Content

```json
{
  "resourceType" : "StructureDefinition",
  "id" : "processprescriptionreason-request",
  "extension" : [{
    "url" : "http://hl7.org/fhir/StructureDefinition/structuredefinition-type-characteristics",
    "valueCode" : "can-be-target"
  }],
  "url" : "https://fhir.inera.se/ig/followup-processdevelopment-infections/StructureDefinition/processprescriptionreason-request",
  "version" : "1.0",
  "name" : "ProcessPrescriptionReasonRequest",
  "title" : "ProcessPrescriptionReason — Request",
  "status" : "draft",
  "date" : "2026-11-06T21:22:34+00:00",
  "contact" : [{
    "name" : "Inera Arkitektur",
    "telecom" : [{
      "system" : "url",
      "value" : "https://www.inera.se"
    }]
  }],
  "description" : "Logisk modell för requestparametrar i tjänstekontraktet ProcessPrescriptionReason\n(RIV-TA urn:riv:followup:processdevelopment:infections:ProcessPrescriptionReason:1).\nRegistrerar en ordinationsorsak med information om patient, organisatorisk enhet,\neventuellt aktivitet, ordination och ordinerad substans.",
  "copyright" : "Copyright 2024 Inera AB. Licensieras under Creative Commons Attribution 4.0.",
  "fhirVersion" : "4.0.1",
  "kind" : "logical",
  "abstract" : false,
  "type" : "https://fhir.inera.se/ig/followup-processdevelopment-infections/StructureDefinition/processprescriptionreason-request",
  "baseDefinition" : "http://hl7.org/fhir/StructureDefinition/Base",
  "derivation" : "specialization",
  "differential" : {
    "element" : [{
      "id" : "processprescriptionreason-request",
      "path" : "processprescriptionreason-request",
      "short" : "ProcessPrescriptionReason — Request",
      "definition" : "Logisk modell för requestparametrar i tjänstekontraktet ProcessPrescriptionReason\n(RIV-TA urn:riv:followup:processdevelopment:infections:ProcessPrescriptionReason:1).\nRegistrerar en ordinationsorsak med information om patient, organisatorisk enhet,\neventuellt aktivitet, ordination och ordinerad substans."
    },
    {
      "id" : "processprescriptionreason-request.prescriptionTime",
      "path" : "processprescriptionreason-request.prescriptionTime",
      "short" : "Tidpunkt då registreringen av ordinationsorsaken gjordes (YYYYMMDDhhmmss)",
      "definition" : "Tidpunkt då registreringen av ordinationsorsaken gjordes.\n\nI de fall en ordination finns anges här\n\nI annat fall lämnas detta fält tomt.",
      "comment" : "TKB-fält: `prescriptionTime` (`TimeStampType`, kardinalitet 0..1).",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "processprescriptionreason-request.substanceCode",
      "path" : "processprescriptionreason-request.substanceCode",
      "short" : "Läkemedelssubstans som är del av en läkemedelsordination",
      "definition" : "Hanterar information kring en läkemedelssubstans som är del av en läkemedelsordination\n\nKodverk: ATC",
      "comment" : "TKB-fält: `substanceCode` (`CVType`, kardinalitet 1..1).",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "CodeableConcept"
      }]
    },
    {
      "id" : "processprescriptionreason-request.prescriptionCareUnitId",
      "path" : "processprescriptionreason-request.prescriptionCareUnitId",
      "short" : "Medicinskt ansvarig för ordinationsmoment (HSA-id)",
      "definition" : "Medicinskt ansvarig för ordinationsmoment.",
      "comment" : "TKB-fält: `prescriptionCareUnitId` (`IIType`, kardinalitet 1..1).",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "Identifier"
      }]
    },
    {
      "id" : "processprescriptionreason-request.prescriptionLocationId",
      "path" : "processprescriptionreason-request.prescriptionLocationId",
      "short" : "Registreringsenhet för ordinationsmoment (HSA-id)",
      "definition" : "Registreringsenhet för ordinationsmoment.",
      "comment" : "TKB-fält: `prescriptionLocationId` (`IIType`, kardinalitet 0..1).",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "Identifier"
      }]
    },
    {
      "id" : "processprescriptionreason-request.prescriptionReasonCareUnitId",
      "path" : "processprescriptionreason-request.prescriptionReasonCareUnitId",
      "short" : "Medicinskt ansvarig för ordinationsorsak (HSA-id)",
      "definition" : "Medicinskt ansvarig för ordinationsorsak",
      "comment" : "TKB-fält: `prescriptionReasonCareUnitId` (`IIType`, kardinalitet 1..1).",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "Identifier"
      }]
    },
    {
      "id" : "processprescriptionreason-request.prescriptionReasonLocationId",
      "path" : "processprescriptionreason-request.prescriptionReasonLocationId",
      "short" : "Registreringsenhet för ordinationsorsak (HSA-id)",
      "definition" : "Registreringsenhet för ordinationsorsak",
      "comment" : "TKB-fält: `prescriptionReasonLocationId` (`IIType`, kardinalitet 0..1).",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "Identifier"
      }]
    },
    {
      "id" : "processprescriptionreason-request.conditionId",
      "path" : "processprescriptionreason-request.conditionId",
      "short" : "Id för patientens diagnos",
      "definition" : "Id för patientens diagnos",
      "comment" : "TKB-fält: `conditionId` (`IIType`, kardinalitet 0..1).\n\n**Modellanteckning:** Nationell OID för lokala ID:n: 1.2.752.129.2.1.2.1",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "Identifier"
      }]
    },
    {
      "id" : "processprescriptionreason-request.conditionCode",
      "path" : "processprescriptionreason-request.conditionCode",
      "short" : "Kod och klartext för patientens diagnos",
      "definition" : "Anger koden och klartext för patientens diagnos\n\nKodverk: SnomedCT, IV Annan, KSH97",
      "comment" : "TKB-fält: `conditionCode` (`CVType`, kardinalitet 0..1).",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "CodeableConcept"
      }]
    },
    {
      "id" : "processprescriptionreason-request.source",
      "path" : "processprescriptionreason-request.source",
      "short" : "Kod och klartext som anger hur infektionen uppstått",
      "definition" : "Kod och klartext som anger hur infektionen uppstått. Anger om det är samhälls- eller vårdförvärvad infektion eller ej infektion (vid förebyggande profylax)\n\nKodverk: IV Smittväg",
      "comment" : "TKB-fält: `source` (`CVType`, kardinalitet 0..1).",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "CodeableConcept"
      }]
    },
    {
      "id" : "processprescriptionreason-request.activityCode",
      "path" : "processprescriptionreason-request.activityCode",
      "short" : "Information om en aktivitet som är relevant att registrera",
      "definition" : "Information om en aktivitet som är relevant att registrera.\n\nKodverk: KVÅ, SnomedCT, IV Annan",
      "comment" : "TKB-fält: `activityCode` (`CVType`, kardinalitet 1..1).",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "CodeableConcept"
      }]
    },
    {
      "id" : "processprescriptionreason-request.activityId",
      "path" : "processprescriptionreason-request.activityId",
      "short" : "Unik identifierare för aktivitet",
      "definition" : "Unik identifierare för aktivitet",
      "comment" : "TKB-fält: `activityId` (`IIType`, kardinalitet 1..1).\n\n**Modellanteckning:** Nationell OID för lokala ID:n: 1.2.752.129.2.1.2.1.\nOBSERVERA: attributet har olika betydelse beroende på om mallen för Activity (profylax)\neller Condition (infektion) används.",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "Identifier"
      }]
    },
    {
      "id" : "processprescriptionreason-request.patient",
      "path" : "processprescriptionreason-request.patient",
      "short" : "Patientuppgifter",
      "definition" : "Patientuppgifter",
      "comment" : "TKB-fält: `patient` (`PatientType`, kardinalitet 1..1).",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "BackboneElement"
      }]
    },
    {
      "id" : "processprescriptionreason-request.patient.patientId",
      "path" : "processprescriptionreason-request.patient.patientId",
      "short" : "Patientens identifierare",
      "definition" : "Patientens identifierare",
      "comment" : "TKB-fält: `patient.id` (`IIType`, kardinalitet 1..1).",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "Identifier"
      }]
    },
    {
      "id" : "processprescriptionreason-request.patient.birthTime",
      "path" : "processprescriptionreason-request.patient.birthTime",
      "short" : "Patientens födelseår (ÅÅÅÅMMDD, ÅÅÅÅMM eller ÅÅÅÅ)",
      "definition" : "Patientens födelseår. Anges enligt ÅÅÅÅMMDD, ÅÅÅÅMM eller ÅÅÅÅ",
      "comment" : "TKB-fält: `patient.birthtime` (`DateType`, kardinalitet 1..1).",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "date"
      }]
    },
    {
      "id" : "processprescriptionreason-request.patient.gender",
      "path" : "processprescriptionreason-request.patient.gender",
      "short" : "Patientens kön",
      "definition" : "Kod och klartext som anger patientens kön",
      "comment" : "TKB-fält: `patient.gender` (`CVType`, kardinalitet 1..1).\n\n**Modellanteckning:** Kodverk KV Kön, OID: 1.2.752.129.2.2.1.1\n0 = not known, 1 = male, 2 = female, 9 = not applicable",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "CodeableConcept"
      }]
    },
    {
      "id" : "processprescriptionreason-request.prescriptionId",
      "path" : "processprescriptionreason-request.prescriptionId",
      "short" : "Unik identifierare för ordinationen",
      "definition" : "Unik identifierare för ordinationen",
      "comment" : "TKB-fält: `prescriptionId` (`IIType`, kardinalitet 1..1).\n\n**Modellanteckning:** Nationell OID för lokala ID:n: 1.2.752.129.2.1.2.1",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "Identifier"
      }]
    },
    {
      "id" : "processprescriptionreason-request.prescriptionReasonTime",
      "path" : "processprescriptionreason-request.prescriptionReasonTime",
      "short" : "Tidpunkt för ordinationen (YYYYMMDDhhmmss)",
      "definition" : "Tidpunkt för ordinationen.",
      "comment" : "TKB-fält: `prescriptionReasonTime` (`TimeStampType`, kardinalitet 0..1).",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    }]
  }
}

```
