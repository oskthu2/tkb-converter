# DeletePrescription — Response - followup: processdevelopment: infections v1.0.2-snapshot

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **DeletePrescription — Response**

## Logical Model: DeletePrescription — Response 

| | |
| :--- | :--- |
| *Official URL*:https://fhir.inera.se/ig/followup-processdevelopment-infections/StructureDefinition/deleteprescription-response | *Version*:1.0 |
| Draft as of 2026-11-09 | *Computable Name*:DeletePrescriptionResponse |
| **Copyright/Legal**: Copyright 2024 Inera AB. Licensieras under Creative Commons Attribution 4.0. | |

 
Logisk modell för responsen från tjänstekontraktet DeletePrescription (RIV-TA urn:riv:followup:processdevelopment:infections:DeletePrescription:1). 

**Usages:**

* This Logical Model is not used by any profiles in this Specification

You can also check for [usages in the FHIR IG Statistics](https://packages2.fhir.org/xig/resource/inera.followup-processdevelopment-infections|current/StructureDefinition/StructureDefinition-deleteprescription-response.json)

### Formal Views of Profile Content

 [Description of Profiles, Differentials, Snapshots and how the different presentations work](http://build.fhir.org/ig/FHIR/ig-guidance/readingIgs.html#structure-definitions). 

 

Other representations of profile: [CSV](StructureDefinition-deleteprescription-response.csv), [Excel](StructureDefinition-deleteprescription-response.xlsx) 



## Resource Content

```json
{
  "resourceType" : "StructureDefinition",
  "id" : "deleteprescription-response",
  "extension" : [{
    "url" : "http://hl7.org/fhir/StructureDefinition/structuredefinition-type-characteristics",
    "valueCode" : "can-be-target"
  }],
  "url" : "https://fhir.inera.se/ig/followup-processdevelopment-infections/StructureDefinition/deleteprescription-response",
  "version" : "1.0",
  "name" : "DeletePrescriptionResponse",
  "title" : "DeletePrescription — Response",
  "status" : "draft",
  "date" : "2026-11-09T03:32:51+00:00",
  "contact" : [{
    "name" : "Inera Arkitektur",
    "telecom" : [{
      "system" : "url",
      "value" : "https://www.inera.se"
    }]
  }],
  "description" : "Logisk modell för responsen från tjänstekontraktet DeletePrescription\n(RIV-TA urn:riv:followup:processdevelopment:infections:DeletePrescription:1).",
  "copyright" : "Copyright 2024 Inera AB. Licensieras under Creative Commons Attribution 4.0.",
  "fhirVersion" : "4.0.1",
  "kind" : "logical",
  "abstract" : false,
  "type" : "https://fhir.inera.se/ig/followup-processdevelopment-infections/StructureDefinition/deleteprescription-response",
  "baseDefinition" : "http://hl7.org/fhir/StructureDefinition/Base",
  "derivation" : "specialization",
  "differential" : {
    "element" : [{
      "id" : "deleteprescription-response",
      "path" : "deleteprescription-response",
      "short" : "DeletePrescription — Response",
      "definition" : "Logisk modell för responsen från tjänstekontraktet DeletePrescription\n(RIV-TA urn:riv:followup:processdevelopment:infections:DeletePrescription:1)."
    },
    {
      "id" : "deleteprescription-response.ResultCode",
      "path" : "deleteprescription-response.ResultCode",
      "short" : "ResultCode",
      "definition" : "OK = operationen genomförd utan fel\n\nERROR = Fel vid operationen\n\nINFO = Information finns om operationen",
      "comment" : "TKB-fält: `code` (`String`, kardinalitet 1..1).",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "code"
      }]
    },
    {
      "id" : "deleteprescription-response.comment",
      "path" : "deleteprescription-response.comment",
      "short" : "comment",
      "definition" : "Beskrivning av fel som uppstått alternativt information om genomförd operation.",
      "comment" : "TKB-fält: `comment` (`String`, kardinalitet 0..1).",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    }]
  }
}

```
