# Hem - itintegration: engagementindex v1.0.9

* [**Table of Contents**](toc.md)
* **Hem**

## Hem

| | |
| :--- | :--- |
| *Official URL*:https://fhir.inera.se/ig/itintegration-engagementindex/ImplementationGuide/inera.itintegration-engagementindex | *Version*:1.0.9 |
| Draft as of 2026-09-17 | *Computable Name*:itintegrationengagementindex |
| **Copyright/Legal**: Copyright 2024 Inera AB. Licensieras under Creative Commons Attribution 4.0. | |

# itintegration: engagementindex

## Översikt

Detta är en FHIR Implementation Guide genererad från TKB-dokumentation för tjänstedomänen **itintegration: engagementindex** version 1.0.9.

## Innehåll

* [1 Inledning](1-inledning.md)
* [2 Versionsinformation](2-versionsinformation.md)
* [3 Tjänstedomänens arkitektur](3-tjanstedomanens-arkitektur.md)
* [4 Tjänstedomänens krav och regler](4-tjanstedomanens-krav-och-regler.md)
* [5 Tjänstedomänens meddelandemodeller](5-tjanstedomanens-meddelandemodeller.md)
* [6 Gemensamma informationskomponenter](6-gemensamma-informationskomponenter.md)
* [7 Tjänstekontrakt](7-tjanstekontrakt.md)

