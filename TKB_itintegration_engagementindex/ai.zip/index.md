# Hem - itintegration: engagementindex v1.0.10

* [**Table of Contents**](toc.md)
* **Hem**

## Hem

| | |
| :--- | :--- |
| *Official URL*:https://fhir.inera.se/ig/itintegration-engagementindex/ImplementationGuide/inera.itintegration-engagementindex | *Version*:1.0.10 |
| Active as of 2026-10-12 | *Computable Name*:itintegrationengagementindex |
| **Copyright/Legal**: Copyright 2024 Inera AB. Licensieras under Creative Commons Attribution 4.0. | |

# itintegration: engagementindex

**TKB-version:** 1.0.10 · **IG-version:** 1.0.10 · **Källa:** Bitbucket-tagg `1.0.10` 

## Översikt

* Beskrivning: Svenskt kortnamn
  * Engagemangsindex är en stödtjänst som används av en tjänsteplattform. Informationen i indexet syftar till att minimera antalet anrop som en tjänstekonsument behöver göra för att få information om en specifik patient. Från indexet får tjänstekonsumenten information om vilka tjänsteproducenter som har information om den specifika patienten. Det räcker därmed att tjänstekonsumenten anropar dessa istället för att anropa alla tjänsteproducenter och fråga vilka av dem som har information om den specifika patienten. Indexet i sig innehåller inte någon patientinformation.: engagemangsindex
* Beskrivning: Svenskt namn
  * Engagemangsindex är en stödtjänst som används av en tjänsteplattform. Informationen i indexet syftar till att minimera antalet anrop som en tjänstekonsument behöver göra för att få information om en specifik patient. Från indexet får tjänstekonsumenten information om vilka tjänsteproducenter som har information om den specifika patienten. Det räcker därmed att tjänstekonsumenten anropar dessa istället för att anropa alla tjänsteproducenter och fråga vilka av dem som har information om den specifika patienten. Indexet i sig innehåller inte någon patientinformation.: infrastruktur:tjänsteförmedlingstjänster:engagemangsindex
* Beskrivning: Typ
  * Engagemangsindex är en stödtjänst som används av en tjänsteplattform. Informationen i indexet syftar till att minimera antalet anrop som en tjänstekonsument behöver göra för att få information om en specifik patient. Från indexet får tjänstekonsumenten information om vilka tjänsteproducenter som har information om den specifika patienten. Det räcker därmed att tjänstekonsumenten anropar dessa istället för att anropa alla tjänsteproducenter och fråga vilka av dem som har information om den specifika patienten. Indexet i sig innehåller inte någon patientinformation.: Nationell tjänstedomän
* Beskrivning: Källkod
  * Engagemangsindex är en stödtjänst som används av en tjänsteplattform. Informationen i indexet syftar till att minimera antalet anrop som en tjänstekonsument behöver göra för att få information om en specifik patient. Från indexet får tjänstekonsumenten information om vilka tjänsteproducenter som har information om den specifika patienten. Det räcker därmed att tjänstekonsumenten anropar dessa istället för att anropa alla tjänsteproducenter och fråga vilka av dem som har information om den specifika patienten. Indexet i sig innehåller inte någon patientinformation.: [Bitbucket](https://bitbucket.org/rivta-domains/riv.itintegration.engagementindex/src)
* Beskrivning: Ärenden
  * Engagemangsindex är en stödtjänst som används av en tjänsteplattform. Informationen i indexet syftar till att minimera antalet anrop som en tjänstekonsument behöver göra för att få information om en specifik patient. Från indexet får tjänstekonsumenten information om vilka tjänsteproducenter som har information om den specifika patienten. Det räcker därmed att tjänstekonsumenten anropar dessa istället för att anropa alla tjänsteproducenter och fråga vilka av dem som har information om den specifika patienten. Indexet i sig innehåller inte någon patientinformation.: [Bitbucket issues](https://bitbucket.org/rivta-domains/riv.itintegration.engagementindex/issues)
* Beskrivning: Underlag för denna IG
  * Engagemangsindex är en stödtjänst som används av en tjänsteplattform. Informationen i indexet syftar till att minimera antalet anrop som en tjänstekonsument behöver göra för att få information om en specifik patient. Från indexet får tjänstekonsumenten information om vilka tjänsteproducenter som har information om den specifika patienten. Det räcker därmed att tjänstekonsumenten anropar dessa istället för att anropa alla tjänsteproducenter och fråga vilka av dem som har information om den specifika patienten. Indexet i sig innehåller inte någon patientinformation.: Version 1.0.10 ·[tagg 1.0.10](https://bitbucket.org/rivta-domains/riv.itintegration.engagementindex/src/1.0.10)·[zip](https://bitbucket.org/rivta-domains/riv.itintegration.engagementindex/get/1.0.10.zip)
* Beskrivning: RIV-TA-portalen
  * Engagemangsindex är en stödtjänst som används av en tjänsteplattform. Informationen i indexet syftar till att minimera antalet anrop som en tjänstekonsument behöver göra för att få information om en specifik patient. Från indexet får tjänstekonsumenten information om vilka tjänsteproducenter som har information om den specifika patienten. Det räcker därmed att tjänstekonsumenten anropar dessa istället för att anropa alla tjänsteproducenter och fråga vilka av dem som har information om den specifika patienten. Indexet i sig innehåller inte någon patientinformation.: [Alla tjänstedomäner](https://oskthu2.github.io/tkb-converter/rivta-portal/tjanstedomaner.html)·[Alla tjänstekontrakt](https://oskthu2.github.io/tkb-converter/rivta-portal/tjanstekontrakt.html)

Detta är en FHIR Implementation Guide genererad från TKB-dokumentation för tjänstedomänen **itintegration: engagementindex** version 1.0.10.

Domänen innehåller följande tjänstekontrakt:

| | | |
| :--- | :--- | :--- |
| [FindContent](7-tjanstekontrakt.md#findcontent) | 1.0 | Tjänst som en applikation använder för att begära information från ett engagemangsindex. Tjänstekontraktet FindContent används för att söka fram och hämta indexinformation. Sökresultatet filtreras baserat på attribut i begäran. Används primärt av aggregerande tjänster i tjänsteplattformen. |
| [Update](7-tjanstekontrakt.md#update) | 1.0 | Definierar en tjänst som konsumenter kan använda för att uppdatera en engagemangsindexinstans. Med hjälp av uppdateringskontraktet (Update) kan källsystem (vårddokumentationssystem, tidbokningssystem m.fl.) skapa indexposter enligt regelverk för respektive tjänstedomän. Kontraktet Update används vid såväl skapande, uppdatering och radering av indexposter. |
| [ProcessNotification](7-tjanstekontrakt.md#processnotification) | 1.0 | Syftet med kontraktet är att kunna konsolidera indexinformation från flera index. Engagemangsindex agerar i rollen som tjänsteproducent för att ta emot information om förändringar i ett annat engagemangsindex. Engagemangsindex agerar som tjänstekonsument för att skicka förändringar till andra engagemangsindex. Kontraktet används för konsolidering av indexinformation från lokala instanser till nationell instans. |

### Versioner och granskningar

| | | | |
| :--- | :--- | :--- | :--- |
| 1.0.6 | TKB, AB | [Arkitektur & Regelverk: Teknik: Godkänd](http://rivta.se/downloads//itintegration_engagementindex/1.0.6/T-granskning%20-%20itintegration_engagementindex_1.0.6.docx) | [zip](http://rivta.se/downloads//itintegration_engagementindex/1.0.6/ServiceContracts_itintegration_engagementindex_1.0.6.zip)·[källkod](https://bitbucket.org/rivta-domains/riv.itintegration.engagementindex/src/1.0.6) |
| 1.0.5 | TKB, AB | [Arkitektur & Regelverk: Säkerhet: Godkänd](http://rivta.se/downloads//itintegration_engagementindex/1.0.5/VIS_granskning_itintegration_engagementindex_1.0.1.docx)[Arkitektur & Regelverk: Informatik: Underkänd](http://rivta.se/downloads//itintegration_engagementindex/1.0.5/VIS_granskning_itintegration_engagementindex_1.0.1.docx)[Arkitektur & Regelverk: Teknik: Godkänd](http://rivta.se/downloads//itintegration_engagementindex/1.0.5/AL-T%20Granskning%20av%20itintegration_engagementindex_1.0.1_RC4.docx) | [zip](http://rivta.se/downloads//itintegration_engagementindex/1.0.5/ServiceContracts_itintegration_engagementindex_1.0.5.zip)·[källkod](https://bitbucket.org/rivta-domains/riv.itintegration.engagementindex/src/1.0.5) |
| 1.0.1 | AB, TKB | [Arkitektur & Regelverk: Informatik: Underkänd](http://rivta.se/downloads/itintegration_engagementindex/1.0.1/VIS_granskning_itintegration_engagementindex_1.0.1.docx)[Arkitektur & Regelverk: Teknik: Godkänd](http://rivta.se/downloads/itintegration_engagementindex/1.0.1/AL-T%20Granskning%20av%20itintegration_engagementindex_1.0.1_RC4.docx)[Arkitektur & Regelverk: Säkerhet: Godkänd](http://rivta.se/downloads/itintegration_engagementindex/1.0.1/VIS_granskning_itintegration_engagementindex_1.0.1.docx) | [zip](http://rivta.se/downloads/itintegration_engagementindex/1.0.1/ServiceContracts_itintegration_engagementindex_1.0.1.zip)·[källkod](https://bitbucket.org/rivta-domains/riv.itintegration.engagementindex/src/itintegration_engagementindex_1.0.1) |
| trunk | TKB, AB |  | [källkod](https://bitbucket.org/rivta-domains/riv.itintegration.engagementindex/src/master) |

*Källa: ögonblicksbild av DOMDB från 2021-08-24, via RIV-TA-portalen.*

## Innehåll

* [1 Inledning](1-inledning.md)
* [2 Versionsinformation](2-versionsinformation.md)
* [3 Tjänstedomänens arkitektur](3-tjanstedomanens-arkitektur.md)
* [4 Tjänstedomänens krav och regler](4-tjanstedomanens-krav-och-regler.md)
* [5 Tjänstedomänens meddelandemodeller](5-tjanstedomanens-meddelandemodeller.md)
* [6 Gemensamma informationskomponenter](6-gemensamma-informationskomponenter.md)
* [7 Tjänstekontrakt](7-tjanstekontrakt.md)

