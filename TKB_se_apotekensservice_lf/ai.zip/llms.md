# inera.se-apotekensservice-lf#7.0.0: se.apotekensservice: lf — Läkemedelsförteckningen för vårdsystem

## Pages

* [Hem](index.md)
* [7 Tjänstekontrakt](7-tjanstekontrakt.md)
* [5 Tjänstedomänens meddelandemodeller](5-tjanstedomanens-meddelandemodeller.md)
* [Artifacts Summary](artifacts.md)
* [6 Gemensamma informationskomponenter](6-gemensamma-informationskomponenter.md)
* [3 Tjänstedomänens arkitektur](3-tjanstedomanens-arkitektur.md)
* [4 Tjänstedomänens krav och regler](4-tjanstedomanens-krav-och-regler.md)
* [2 Versionsinformation](2-versionsinformation.md)
* [1 Inledning](1-inledning.md)

## Resources

### Logicals

* [AterkallaSamtyckeVardsystem — Request](StructureDefinition-aterkallasamtyckevardsystem-request.md)
* [AterkallaSamtyckeVardsystem — Response](StructureDefinition-aterkallasamtyckevardsystem.md)
* [KontrolleraSamtyckeVardsystem — Request](StructureDefinition-kontrollerasamtyckevardsystem-request.md)
* [KontrolleraSamtyckeVardsystem — Response](StructureDefinition-kontrollerasamtyckevardsystem.md)
* [LasLFVardsystem — Request](StructureDefinition-laslfvardsystem-request.md)
* [LasLFVardsystem — Response](StructureDefinition-laslfvardsystem.md)
* [RegistreraSamtyckeVardsystem — Request](StructureDefinition-registrerasamtyckevardsystem-request.md)

### ImplementationGuides

* [se.apotekensservice: lf — Läkemedelsförteckningen för vårdsystem](index.md)
