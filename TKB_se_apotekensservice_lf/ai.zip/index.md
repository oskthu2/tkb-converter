# Hem - se.apotekensservice: lf — Läkemedelsförteckningen för vårdsystem v7.0.0-rc1

* [**Table of Contents**](toc.md)
* **Hem**

## Hem

| | |
| :--- | :--- |
| *Official URL*:https://fhir.inera.se/ig/se-apotekensservice-lf/ImplementationGuide/inera.se-apotekensservice-lf | *Version*:7.0.0-rc1 |
| Draft as of 2026-10-12 | *Computable Name*:seapotekensservicelf |
| **Copyright/Legal**: Copyright 2024 Inera AB. Licensieras under Creative Commons Attribution 4.0. | |

# se.apotekensservice: lf — Läkemedelsförteckningen för vårdsystem

**TKB-version:** 7.0_RC1 · **IG-version:** 7.0.0-rc1 · **Källa:** Bitbucket-tagg `7.0_RC1` 

## Översikt

* Svenskt kortnamn: Typ
  * läkemedelsförteckning: Extern tjänstedomän
* Svenskt kortnamn: Förvaltare
  * läkemedelsförteckning: E-hälsomyndigheten
* Svenskt kortnamn: Källkod
  * läkemedelsförteckning: [Bitbucket](https://bitbucket.org/rivta-domains/riv.se.apotekensservice.lf/src)
* Svenskt kortnamn: Ärenden
  * läkemedelsförteckning: [Bitbucket issues](https://bitbucket.org/rivta-domains/riv.se.apotekensservice.lf/issues)
* Svenskt kortnamn: Underlag för denna IG
  * läkemedelsförteckning: Version 7.0_RC1 ·[tagg 7.0_RC1](https://bitbucket.org/rivta-domains/riv.se.apotekensservice.lf/src/7.0_RC1)·[zip](https://bitbucket.org/rivta-domains/riv.se.apotekensservice.lf/get/7.0_RC1.zip)
* Svenskt kortnamn: RIV-TA-portalen
  * läkemedelsförteckning: [Alla tjänstedomäner](https://oskthu2.github.io/tkb-converter/rivta-portal/tjanstedomaner.html)·[Alla tjänstekontrakt](https://oskthu2.github.io/tkb-converter/rivta-portal/tjanstekontrakt.html)

FHIR Implementation Guide för tjänstedomänen **se: apotekensservice: lf** version 7.0. Domänen förvaltas av eHälsomyndigheten (tidigare Apotekens Service AB) och innehåller tjänster för vårdsystem att läsa en patients läkemedelsförteckning samt registrera, kontrollera och återkalla patientens samtycke till sådan åtkomst.

**Observera:** källan innehåller ingen tjänstekontraktsbeskrivning (TKB). Denna IG är därför uppbyggd från domänens scheman (XSD/WSDL) och dess dokument med arkitekturella beslut. Avsnitt som i andra IG:er hämtas ur TKB:n är markerade med **SAKNAS I KÄLLDOKUMENT**. Beskrivningar av fält är hämtade ur schemaannoteringarna.

RIV-TA namnrymd: `urn:riv:se.apotekensservice:lf`

Domänen innehåller följande tjänstekontrakt:

| | | |
| :--- | :--- | :--- |
| [AterkallaSamtyckeVardsystem](7-tjanstekontrakt.md#aterkallasamtyckevardsystem) | 1.0 | Fråga-svar |
| [KontrolleraSamtyckeVardsystem](7-tjanstekontrakt.md#kontrollerasamtyckevardsystem) | 1.0 | Fråga-svar |
| [LasLFVardsystem](7-tjanstekontrakt.md#laslfvardsystem) | 4.1 | Fråga-svar |
| [RegistreraSamtyckeVardsystem](7-tjanstekontrakt.md#registrerasamtyckevardsystem) | 1.0 | Uppdatering (tomt svar) |

**Källa:** Bitbucket `rivta-domains/riv.se.apotekensservice.lf`, tagg `7.0_RC1` (commit `93e163ae44d5`, 2020-02-11), samma commit som `master`. Det finns ingen fastställd 7.0-tagg; senaste fastställda är `5.0` (2017-01-26).

### Versioner och granskningar

| | | | |
| :--- | :--- | :--- | :--- |
| 5.0 | AB |  | [zip](http://rivta.se/downloads//se_apotekensservice_lf/5.0/ServiceContracts_se_apotekensservice_lf_5.0.zip)·[källkod](https://bitbucket.org/rivta-domains/riv.se.apotekensservice.lf/src/5.0) |
| 4.0 |  |  | [zip](http://rivta.se/downloads//se_apotekensservice_lf/4.0/ServiceContracts_se.apotekensservice_lf_4.0.zip)·[källkod](https://bitbucket.org/rivta-domains/riv.se.apotekensservice.lf/src/4.0) |
| 1.0.0 |  |  | [zip](http://rivta.se/downloads/se_apotekensservice_lf/1.0.0/ServiceContracts_se.apotekensservice_lf_1.0.0.zip)·[källkod](https://bitbucket.org/rivta-domains/riv.se.apotekensservice.lf/src/TD_APSE_LF_1_0_0_R) |
| trunk |  |  | [källkod](https://bitbucket.org/rivta-domains/riv.se.apotekensservice.lf/src/master) |

*Källa: ögonblicksbild av DOMDB från 2021-08-24, via RIV-TA-portalen.*

## Innehåll

* [1 Inledning](1-inledning.md)
* [2 Versionsinformation](2-versionsinformation.md)
* [3 Tjänstedomänens arkitektur](3-tjanstedomanens-arkitektur.md)
* [4 Tjänstedomänens krav och regler](4-tjanstedomanens-krav-och-regler.md)
* [5 Tjänstedomänens meddelandemodeller](5-tjanstedomanens-meddelandemodeller.md)
* [6 Gemensamma informationskomponenter](6-gemensamma-informationskomponenter.md)
* [7 Tjänstekontrakt](7-tjanstekontrakt.md)
* [Artefakter](artifacts.md)

