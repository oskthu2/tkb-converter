# inera.se-apotekensservice-expo#2.0.0: se.apotekensservice: expo — Expeditionsställen och dosmottagare

## Pages

* [Hem](index.md)
* [7 Tjänstekontrakt](7-tjanstekontrakt.md)
* [5 Tjänstedomänens meddelandemodeller](5-tjanstedomanens-meddelandemodeller.md)
* [Artifacts Summary](artifacts.md)
* [6 Gemensamma informationskomponenter](6-gemensamma-informationskomponenter.md)
* [3 Tjänstedomänens arkitektur](3-tjanstedomanens-arkitektur.md)
* [4 Tjänstedomänens krav och regler](4-tjanstedomanens-krav-och-regler.md)
* [2 Versionsinformation](2-versionsinformation.md)
* [1 Inledning](1-inledning.md)

## Resources

### Logicals

* [HamtaApoteksInfo — Request](StructureDefinition-hamtaapoteksinfo-request.md)
* [HamtaApoteksInfo — Response](StructureDefinition-hamtaapoteksinfo.md)
* [HamtaApoteksinfoEget — Request](StructureDefinition-hamtaapoteksinfoeget-request.md)
* [HamtaApoteksinfoEget — Response](StructureDefinition-hamtaapoteksinfoeget.md)
* [KontaktuppgifterHamta — Request](StructureDefinition-kontaktuppgifterhamta-request.md)
* [KontaktuppgifterHamta — Response](StructureDefinition-kontaktuppgifterhamta.md)
* [KontaktuppgifterUppdatera — Request](StructureDefinition-kontaktuppgifteruppdatera-request.md)
* [SkapaApotek — Request](StructureDefinition-skapaapotek-request.md)
* [SkapaApotek — Response](StructureDefinition-skapaapotek.md)
* [SkapaDosmottagare — Request](StructureDefinition-skapadosmottagare-request.md)
* [SkapaDosmottagare — Response](StructureDefinition-skapadosmottagare.md)
* [SokDosmottagare — Request](StructureDefinition-sokdosmottagare-request.md)
* [SokDosmottagare — Response](StructureDefinition-sokdosmottagare.md)
* [TaBortDosmottagare — Request](StructureDefinition-tabortdosmottagare-request.md)
* [UppdateraDosmottagare — Request](StructureDefinition-uppdateradosmottagare-request.md)
* [UppdateraExpoMedApotek — Request](StructureDefinition-uppdateraexpomedapotek-request.md)
* [UppdateraExpoMedApotek — Response](StructureDefinition-uppdateraexpomedapotek.md)

### ImplementationGuides

* [se.apotekensservice: expo — Expeditionsställen och dosmottagare](index.md)
