# Hem - se.apotekensservice: expo — Expeditionsställen och dosmottagare v2.0.0

* [**Table of Contents**](toc.md)
* **Hem**

## Hem

| | |
| :--- | :--- |
| *Official URL*:https://fhir.inera.se/ig/se-apotekensservice-expo/ImplementationGuide/inera.se-apotekensservice-expo | *Version*:2.0.0 |
| Draft as of 2026-09-26 | *Computable Name*:seapotekensserviceexpo |
| **Copyright/Legal**: Copyright 2024 Inera AB. Licensieras under Creative Commons Attribution 4.0. | |

# se.apotekensservice: expo — Expeditionsställen och dosmottagare

## Översikt

FHIR Implementation Guide för tjänstedomänen **se: apotekensservice: expo** version 2.0. Domänen förvaltas av eHälsomyndigheten (tidigare Apotekens Service AB) och innehåller tjänster för att hämta och uppdatera information om expeditionsställen (apotek), aktörers kontaktuppgifter och dosmottagare.

**Observera:** källan innehåller ingen tjänstekontraktsbeskrivning (TKB). Denna IG är därför uppbyggd från domänens scheman (XSD/WSDL) och dess dokument med arkitekturella beslut. Avsnitt som i andra IG:er hämtas ur TKB:n är markerade med **SAKNAS I KÄLLDOKUMENT**. Beskrivningar av fält är hämtade ur schemaannoteringarna.

RIV-TA namnrymd: `urn:riv:se.apotekensservice:expo`

Domänen innehåller följande tjänstekontrakt:

| | | |
| :--- | :--- | :--- |
| [HamtaApoteksInfo](7-tjanstekontrakt.md#hamtaapoteksinfo) | 1.0 | Fråga-svar |
| [HamtaApoteksinfoEget](7-tjanstekontrakt.md#hamtaapoteksinfoeget) | 5.0 | Fråga-svar |
| [KontaktuppgifterHamta](7-tjanstekontrakt.md#kontaktuppgifterhamta) | 4.0 | Fråga-svar |
| [KontaktuppgifterUppdatera](7-tjanstekontrakt.md#kontaktuppgifteruppdatera) | 5.0 | Uppdatering (tomt svar) |
| [SkapaApotek](7-tjanstekontrakt.md#skapaapotek) | 6.0 | Fråga-svar |
| [SkapaDosmottagare](7-tjanstekontrakt.md#skapadosmottagare) | 4.0 | Fråga-svar |
| [SokDosmottagare](7-tjanstekontrakt.md#sokdosmottagare) | 1.0 | Fråga-svar |
| [TaBortDosmottagare](7-tjanstekontrakt.md#tabortdosmottagare) | 1.0 | Uppdatering (tomt svar) |
| [UppdateraDosmottagare](7-tjanstekontrakt.md#uppdateradosmottagare) | 4.0 | Uppdatering (tomt svar) |
| [UppdateraExpoMedApotek](7-tjanstekontrakt.md#uppdateraexpomedapotek) | 6.0 | Fråga-svar |

**Källa:** Bitbucket `rivta-domains/riv.se.apotekensservice.expo`, commit `9aabc1797ea7` på `master` (2017-01-26), samma commit som taggen `2.0_RC1`. Repot har ingen fastställd 2.0-tagg.

## Innehåll

* [1 Inledning](1-inledning.md)
* [2 Versionsinformation](2-versionsinformation.md)
* [3 Tjänstedomänens arkitektur](3-tjanstedomanens-arkitektur.md)
* [4 Tjänstedomänens krav och regler](4-tjanstedomanens-krav-och-regler.md)
* [5 Tjänstedomänens meddelandemodeller](5-tjanstedomanens-meddelandemodeller.md)
* [6 Gemensamma informationskomponenter](6-gemensamma-informationskomponenter.md)
* [7 Tjänstekontrakt](7-tjanstekontrakt.md)
* [Artefakter](artifacts.md)

