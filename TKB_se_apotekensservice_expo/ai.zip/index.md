# Hem - se.apotekensservice: expo — Expeditionsställen och dosmottagare v2.0.0-rc1

* [**Table of Contents**](toc.md)
* **Hem**

## Hem

| | |
| :--- | :--- |
| *Official URL*:https://fhir.inera.se/ig/se-apotekensservice-expo/ImplementationGuide/inera.se-apotekensservice-expo | *Version*:2.0.0-rc1 |
| Draft as of 2026-10-26 | *Computable Name*:seapotekensserviceexpo |
| **Copyright/Legal**: Copyright 2024 Inera AB. Licensieras under Creative Commons Attribution 4.0. | |

# se.apotekensservice: expo — Expeditionsställen och dosmottagare

**TKB-version:** 2.0_RC1 · **IG-version:** 2.0.0-rc1 · **Källa:** Bitbucket-tagg `2.0_RC1` 

## Översikt

* Svenskt kortnamn: Typ
  * expeditionsställe: Extern tjänstedomän
* Svenskt kortnamn: Förvaltare
  * expeditionsställe: E-hälsomyndigheten
* Svenskt kortnamn: Källkod
  * expeditionsställe: [Bitbucket](https://bitbucket.org/rivta-domains/riv.se.apotekensservice.expo/src)
* Svenskt kortnamn: Ärenden
  * expeditionsställe: [Bitbucket issues](https://bitbucket.org/rivta-domains/riv.se.apotekensservice.expo/issues)
* Svenskt kortnamn: Underlag för denna IG
  * expeditionsställe: Version 2.0_RC1 ·[tagg 2.0_RC1](https://bitbucket.org/rivta-domains/riv.se.apotekensservice.expo/src/2.0_RC1)·[zip](https://bitbucket.org/rivta-domains/riv.se.apotekensservice.expo/get/9aabc1797ea7.zip)
* Svenskt kortnamn: RIV-TA-portalen
  * expeditionsställe: [Alla tjänstedomäner](https://oskthu2.github.io/tkb-converter/rivta-portal/tjanstedomaner.html)·[Alla tjänstekontrakt](https://oskthu2.github.io/tkb-converter/rivta-portal/tjanstekontrakt.html)

FHIR Implementation Guide för tjänstedomänen **se: apotekensservice: expo** version 2.0. Domänen förvaltas av eHälsomyndigheten (tidigare Apotekens Service AB) och innehåller tjänster för att hämta och uppdatera information om expeditionsställen (apotek), aktörers kontaktuppgifter och dosmottagare.

**Observera:** källan innehåller ingen tjänstekontraktsbeskrivning (TKB). Denna IG är därför uppbyggd från domänens scheman (XSD/WSDL) och dess dokument med arkitekturella beslut. Avsnitt som i andra IG:er hämtas ur TKB:n är markerade med **SAKNAS I KÄLLDOKUMENT**. Beskrivningar av fält är hämtade ur schemaannoteringarna.

RIV-TA namnrymd: `urn:riv:se.apotekensservice:expo`

Domänen innehåller följande tjänstekontrakt:

| | | |
| :--- | :--- | :--- |
| [HamtaApoteksInfo](7-tjanstekontrakt.md#hamtaapoteksinfo) | 1.0 | Fråga-svar |
| [HamtaApoteksinfoEget](7-tjanstekontrakt.md#hamtaapoteksinfoeget) | 5.0 | Fråga-svar |
| [KontaktuppgifterHamta](7-tjanstekontrakt.md#kontaktuppgifterhamta) | 4.0 | Fråga-svar |
| [KontaktuppgifterUppdatera](7-tjanstekontrakt.md#kontaktuppgifteruppdatera) | 5.0 | Uppdatering (tomt svar) |
| [SkapaApotek](7-tjanstekontrakt.md#skapaapotek) | 6.0 | Fråga-svar |
| [SkapaDosmottagare](7-tjanstekontrakt.md#skapadosmottagare) | 4.0 | Fråga-svar |
| [SokDosmottagare](7-tjanstekontrakt.md#sokdosmottagare) | 1.0 | Fråga-svar |
| [TaBortDosmottagare](7-tjanstekontrakt.md#tabortdosmottagare) | 1.0 | Uppdatering (tomt svar) |
| [UppdateraDosmottagare](7-tjanstekontrakt.md#uppdateradosmottagare) | 4.0 | Uppdatering (tomt svar) |
| [UppdateraExpoMedApotek](7-tjanstekontrakt.md#uppdateraexpomedapotek) | 6.0 | Fråga-svar |

**Källa:** Bitbucket `rivta-domains/riv.se.apotekensservice.expo`, commit `9aabc1797ea7` på `master` (2017-01-26), samma commit som taggen `2.0_RC1`. Repot har ingen fastställd 2.0-tagg.

### Versioner och granskningar

| | | | |
| :--- | :--- | :--- | :--- |
| 2.0_RC1 | AB |  | [zip](http://rivta.se/downloads//se_apotekensservice_expo/2.0_RC1/ServiceContracts_se_apotekensservice_expo_2.0_RC1.zip)·[källkod](https://bitbucket.org/rivta-domains/riv.se.apotekensservice.expo/src/2.0_RC1) |
| 1.0_beta_r588 |  |  | [zip](http://rivta.se/downloads/se_apotekensservice_expo/1.0-beta-r588/ServiceContracts_se.apotekensservice_expo_1.0-beta-r588.zip)·[källkod](https://bitbucket.org/rivta-domains/riv.se.apotekensservice.expo/src/1.0-beta-r588) |
| trunk |  |  | [källkod](https://bitbucket.org/rivta-domains/riv.se.apotekensservice.expo/src/master) |

*Källa: ögonblicksbild av DOMDB från 2021-08-24, via RIV-TA-portalen.*

## Innehåll

* [1 Inledning](1-inledning.md)
* [2 Versionsinformation](2-versionsinformation.md)
* [3 Tjänstedomänens arkitektur](3-tjanstedomanens-arkitektur.md)
* [4 Tjänstedomänens krav och regler](4-tjanstedomanens-krav-och-regler.md)
* [5 Tjänstedomänens meddelandemodeller](5-tjanstedomanens-meddelandemodeller.md)
* [6 Gemensamma informationskomponenter](6-gemensamma-informationskomponenter.md)
* [7 Tjänstekontrakt](7-tjanstekontrakt.md)
* [Artefakter](artifacts.md)

