# HamtaApoteksInfo — Response - se.apotekensservice: expo — Expeditionsställen och dosmottagare v2.0.0-rc1

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **HamtaApoteksInfo — Response**

## Logical Model: HamtaApoteksInfo — Response 

| | |
| :--- | :--- |
| *Official URL*:https://fhir.inera.se/ig/se-apotekensservice-expo/StructureDefinition/hamtaapoteksinfo | *Version*:1.0 |
| Draft as of 2026-11-09 | *Computable Name*:HamtaApoteksInfo |
| **Copyright/Legal**: Copyright 2024 Inera AB. Licensieras under Creative Commons Attribution 4.0. | |

 
Logisk modell för svaret i HamtaApoteksInfo (urn:riv:se.apotekensservice:expo:HamtaApoteksInfoResponder:1, HamtaApoteksInfoResponseType). 

**Usages:**

* This Logical Model is not used by any profiles in this Specification

You can also check for [usages in the FHIR IG Statistics](https://packages2.fhir.org/xig/resource/inera.se-apotekensservice-expo|current/StructureDefinition/StructureDefinition-hamtaapoteksinfo.json)

### Formal Views of Profile Content

 [Description of Profiles, Differentials, Snapshots and how the different presentations work](http://build.fhir.org/ig/FHIR/ig-guidance/readingIgs.html#structure-definitions). 

 

Other representations of profile: [CSV](StructureDefinition-hamtaapoteksinfo.csv), [Excel](StructureDefinition-hamtaapoteksinfo.xlsx) 



## Resource Content

```json
{
  "resourceType" : "StructureDefinition",
  "id" : "hamtaapoteksinfo",
  "extension" : [{
    "url" : "http://hl7.org/fhir/StructureDefinition/structuredefinition-type-characteristics",
    "valueCode" : "can-be-target"
  }],
  "url" : "https://fhir.inera.se/ig/se-apotekensservice-expo/StructureDefinition/hamtaapoteksinfo",
  "version" : "1.0",
  "name" : "HamtaApoteksInfo",
  "title" : "HamtaApoteksInfo — Response",
  "status" : "draft",
  "date" : "2026-11-09T03:47:50+00:00",
  "contact" : [{
    "name" : "Inera Arkitektur",
    "telecom" : [{
      "system" : "url",
      "value" : "https://www.inera.se"
    }]
  }],
  "description" : "Logisk modell för svaret i HamtaApoteksInfo\n(urn:riv:se.apotekensservice:expo:HamtaApoteksInfoResponder:1, HamtaApoteksInfoResponseType).",
  "copyright" : "Copyright 2024 Inera AB. Licensieras under Creative Commons Attribution 4.0.",
  "fhirVersion" : "4.0.1",
  "kind" : "logical",
  "abstract" : false,
  "type" : "https://fhir.inera.se/ig/se-apotekensservice-expo/StructureDefinition/hamtaapoteksinfo",
  "baseDefinition" : "http://hl7.org/fhir/StructureDefinition/Base",
  "derivation" : "specialization",
  "differential" : {
    "element" : [{
      "id" : "hamtaapoteksinfo",
      "path" : "hamtaapoteksinfo",
      "short" : "HamtaApoteksInfo — Response",
      "definition" : "Logisk modell för svaret i HamtaApoteksInfo\n(urn:riv:se.apotekensservice:expo:HamtaApoteksInfoResponder:1, HamtaApoteksInfoResponseType)."
    },
    {
      "id" : "hamtaapoteksinfo.apoteksinformationLista",
      "path" : "hamtaapoteksinfo.apoteksinformationLista",
      "short" : "ApoteksinformationResponse",
      "definition" : "Lista innehållande ett eller flera Apoteksinformation.",
      "comment" : "TKB-fält: `apoteksinformationLista` (`ApoteksinformationResponse`, kardinalitet 1..*).",
      "min" : 1,
      "max" : "*",
      "type" : [{
        "code" : "Base"
      }]
    },
    {
      "id" : "hamtaapoteksinfo.apoteksinformationLista.aktorsnamn",
      "path" : "hamtaapoteksinfo.apoteksinformationLista.aktorsnamn",
      "short" : "Officiellt namn för aktör",
      "definition" : "Officiellt namn för aktör",
      "comment" : "TKB-fält: `../aktorsnamn` (`string`, kardinalitet 0..1).",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "hamtaapoteksinfo.apoteksinformationLista.aktorsorgnr",
      "path" : "hamtaapoteksinfo.apoteksinformationLista.aktorsorgnr",
      "short" : "Aktörens organisationsnummer.",
      "definition" : "Aktörens organisationsnummer.",
      "comment" : "TKB-fält: `../aktorsorgnr` (`long`, kardinalitet 0..1).",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "hamtaapoteksinfo.apoteksinformationLista.allmantelefon",
      "path" : "hamtaapoteksinfo.apoteksinformationLista.allmantelefon",
      "short" : "Telefonnummer för allmänheten",
      "definition" : "Telefonnummer för allmänheten",
      "comment" : "TKB-fält: `../allmantelefon` (`string`, kardinalitet 0..1).",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "hamtaapoteksinfo.apoteksinformationLista.besoksadress",
      "path" : "hamtaapoteksinfo.apoteksinformationLista.besoksadress",
      "short" : "Expeditionsställets besöksadress",
      "definition" : "Expeditionsställets besöksadress",
      "comment" : "TKB-fält: `../besoksadress` (`string`, kardinalitet 0..1).",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "hamtaapoteksinfo.apoteksinformationLista.eReceptDjur",
      "path" : "hamtaapoteksinfo.apoteksinformationLista.eReceptDjur",
      "short" : "Markering gällande om apoteket kan expediera elektroniska djurrecept.",
      "definition" : "Markering gällande om apoteket kan expediera elektroniska djurrecept.",
      "comment" : "TKB-fält: `../eReceptDjur` (`boolean`, kardinalitet 1..1).",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "boolean"
      }]
    },
    {
      "id" : "hamtaapoteksinfo.apoteksinformationLista.fax",
      "path" : "hamtaapoteksinfo.apoteksinformationLista.fax",
      "short" : "Expeditionsställets faxnummer",
      "definition" : "Expeditionsställets faxnummer",
      "comment" : "TKB-fält: `../fax` (`string`, kardinalitet 0..1).",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "hamtaapoteksinfo.apoteksinformationLista.glnKod",
      "path" : "hamtaapoteksinfo.apoteksinformationLista.glnKod",
      "short" : "Expeditionsställets GLN-kod",
      "definition" : "Expeditionsställets GLN-kod",
      "comment" : "TKB-fält: `../glnKod` (`string`, kardinalitet 1..1).",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "hamtaapoteksinfo.apoteksinformationLista.huvudtypkod",
      "path" : "hamtaapoteksinfo.apoteksinformationLista.huvudtypkod",
      "short" : "Kod som beskriver huvudverksamheten för expeditionsstället",
      "definition" : "Kod som beskriver huvudverksamheten för expeditionsstället",
      "comment" : "TKB-fält: `../huvudtypkod` (`string`, kardinalitet 0..1).",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "hamtaapoteksinfo.apoteksinformationLista.namn",
      "path" : "hamtaapoteksinfo.apoteksinformationLista.namn",
      "short" : "Expeditionsställets officiella namn",
      "definition" : "Expeditionsställets officiella namn",
      "comment" : "TKB-fält: `../namn` (`string`, kardinalitet 0..1).",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "hamtaapoteksinfo.apoteksinformationLista.ort",
      "path" : "hamtaapoteksinfo.apoteksinformationLista.ort",
      "short" : "Expeditionsställets besöksort",
      "definition" : "Expeditionsställets besöksort",
      "comment" : "TKB-fält: `../ort` (`string`, kardinalitet 0..1).",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "hamtaapoteksinfo.apoteksinformationLista.slutdatum",
      "path" : "hamtaapoteksinfo.apoteksinformationLista.slutdatum",
      "short" : "Datum för stängning av verksamhet",
      "definition" : "Datum för stängning av verksamhet",
      "comment" : "TKB-fält: `../slutdatum` (`dateTime`, kardinalitet 0..1).",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "dateTime"
      }]
    },
    {
      "id" : "hamtaapoteksinfo.apoteksinformationLista.startdatum",
      "path" : "hamtaapoteksinfo.apoteksinformationLista.startdatum",
      "short" : "Datum för start av verksamhet",
      "definition" : "Datum för start av verksamhet",
      "comment" : "TKB-fält: `../startdatum` (`dateTime`, kardinalitet 1..1).",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "dateTime"
      }]
    }]
  }
}

```
