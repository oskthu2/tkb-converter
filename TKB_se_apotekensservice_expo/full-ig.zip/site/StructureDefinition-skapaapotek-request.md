# SkapaApotek — Request - se.apotekensservice: expo — Expeditionsställen och dosmottagare v2.0.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **SkapaApotek — Request**

## Logical Model: SkapaApotek — Request 

| | |
| :--- | :--- |
| *Official URL*:https://fhir.inera.se/ig/se-apotekensservice-expo/StructureDefinition/skapaapotek-request | *Version*:2.0.0 |
| Draft as of 2026-09-26 | *Computable Name*:SkapaApotekRequest |
| **Copyright/Legal**: Copyright 2024 Inera AB. Licensieras under Creative Commons Attribution 4.0. | |

 
Logisk modell för begäran i SkapaApotek (urn:riv:se.apotekensservice:expo:SkapaApotekResponder:6, SkapaApotekRequestType), inklusive SOAP-huvuden enligt WSDL. 

**Usages:**

* This Logical Model is not used by any profiles in this Specification

You can also check for [usages in the FHIR IG Statistics](https://packages2.fhir.org/xig/resource/inera.se-apotekensservice-expo|current/StructureDefinition/StructureDefinition-skapaapotek-request.json)

### Formal Views of Profile Content

 [Description of Profiles, Differentials, Snapshots and how the different presentations work](http://build.fhir.org/ig/FHIR/ig-guidance/readingIgs.html#structure-definitions). 

 

Other representations of profile: [CSV](StructureDefinition-skapaapotek-request.csv), [Excel](StructureDefinition-skapaapotek-request.xlsx) 



## Resource Content

```json
{
  "resourceType" : "StructureDefinition",
  "id" : "skapaapotek-request",
  "extension" : [{
    "url" : "http://hl7.org/fhir/StructureDefinition/structuredefinition-type-characteristics",
    "valueCode" : "can-be-target"
  }],
  "url" : "https://fhir.inera.se/ig/se-apotekensservice-expo/StructureDefinition/skapaapotek-request",
  "version" : "2.0.0",
  "name" : "SkapaApotekRequest",
  "title" : "SkapaApotek — Request",
  "status" : "draft",
  "date" : "2026-09-26T19:42:44+00:00",
  "contact" : [{
    "name" : "Inera Arkitektur",
    "telecom" : [{
      "system" : "url",
      "value" : "https://www.inera.se"
    }]
  }],
  "description" : "Logisk modell för begäran i SkapaApotek\n(urn:riv:se.apotekensservice:expo:SkapaApotekResponder:6, SkapaApotekRequestType), inklusive SOAP-huvuden enligt WSDL.",
  "copyright" : "Copyright 2024 Inera AB. Licensieras under Creative Commons Attribution 4.0.",
  "fhirVersion" : "4.0.1",
  "kind" : "logical",
  "abstract" : false,
  "type" : "https://fhir.inera.se/ig/se-apotekensservice-expo/StructureDefinition/skapaapotek-request",
  "baseDefinition" : "http://hl7.org/fhir/StructureDefinition/Base",
  "derivation" : "specialization",
  "differential" : {
    "element" : [{
      "id" : "skapaapotek-request",
      "path" : "skapaapotek-request",
      "short" : "SkapaApotek — Request",
      "definition" : "Logisk modell för begäran i SkapaApotek\n(urn:riv:se.apotekensservice:expo:SkapaApotekResponder:6, SkapaApotekRequestType), inklusive SOAP-huvuden enligt WSDL."
    },
    {
      "id" : "skapaapotek-request.logicalAddress",
      "path" : "skapaapotek-request.logicalAddress",
      "short" : "logicalAddress",
      "definition" : "SOAP-huvud LogicalAddress. Orgnr of Apotekens Service AB",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "skapaapotek-request.argosHeader",
      "path" : "skapaapotek-request.argosHeader",
      "short" : "argosHeader",
      "definition" : "SOAP-huvud ArgosHeader. Argos header of Apotekens Service AB. Check documentation regarding mandatory fields for this specific service interaction",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "BackboneElement"
      }]
    },
    {
      "id" : "skapaapotek-request.argosHeader.forskrivarkod",
      "path" : "skapaapotek-request.argosHeader.forskrivarkod",
      "short" : "forskrivarkod",
      "definition" : "forskrivarkod",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "skapaapotek-request.argosHeader.legitimationskod",
      "path" : "skapaapotek-request.argosHeader.legitimationskod",
      "short" : "legitimationskod",
      "definition" : "legitimationskod",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "skapaapotek-request.argosHeader.fornamn",
      "path" : "skapaapotek-request.argosHeader.fornamn",
      "short" : "fornamn",
      "definition" : "fornamn",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "skapaapotek-request.argosHeader.efternamn",
      "path" : "skapaapotek-request.argosHeader.efternamn",
      "short" : "efternamn",
      "definition" : "efternamn",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "skapaapotek-request.argosHeader.yrkesgrupp",
      "path" : "skapaapotek-request.argosHeader.yrkesgrupp",
      "short" : "yrkesgrupp",
      "definition" : "yrkesgrupp",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "skapaapotek-request.argosHeader.befattningskod",
      "path" : "skapaapotek-request.argosHeader.befattningskod",
      "short" : "befattningskod",
      "definition" : "befattningskod",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "skapaapotek-request.argosHeader.arbetsplatskod",
      "path" : "skapaapotek-request.argosHeader.arbetsplatskod",
      "short" : "arbetsplatskod",
      "definition" : "arbetsplatskod",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "skapaapotek-request.argosHeader.arbetsplatsnamn",
      "path" : "skapaapotek-request.argosHeader.arbetsplatsnamn",
      "short" : "arbetsplatsnamn",
      "definition" : "arbetsplatsnamn",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "skapaapotek-request.argosHeader.postort",
      "path" : "skapaapotek-request.argosHeader.postort",
      "short" : "postort",
      "definition" : "postort",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "skapaapotek-request.argosHeader.postadress",
      "path" : "skapaapotek-request.argosHeader.postadress",
      "short" : "postadress",
      "definition" : "postadress",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "skapaapotek-request.argosHeader.postnummer",
      "path" : "skapaapotek-request.argosHeader.postnummer",
      "short" : "postnummer",
      "definition" : "postnummer",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "skapaapotek-request.argosHeader.telefonnummer",
      "path" : "skapaapotek-request.argosHeader.telefonnummer",
      "short" : "telefonnummer",
      "definition" : "telefonnummer",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "skapaapotek-request.argosHeader.requestId",
      "path" : "skapaapotek-request.argosHeader.requestId",
      "short" : "requestId",
      "definition" : "requestId",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "skapaapotek-request.argosHeader.rollnamn",
      "path" : "skapaapotek-request.argosHeader.rollnamn",
      "short" : "rollnamn",
      "definition" : "rollnamn",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "skapaapotek-request.argosHeader.hsaID",
      "path" : "skapaapotek-request.argosHeader.hsaID",
      "short" : "hsaID",
      "definition" : "hsaID",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "skapaapotek-request.argosHeader.katalog",
      "path" : "skapaapotek-request.argosHeader.katalog",
      "short" : "katalog",
      "definition" : "katalog",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "skapaapotek-request.argosHeader.organisationsnummer",
      "path" : "skapaapotek-request.argosHeader.organisationsnummer",
      "short" : "organisationsnummer",
      "definition" : "organisationsnummer",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "skapaapotek-request.argosHeader.systemnamn",
      "path" : "skapaapotek-request.argosHeader.systemnamn",
      "short" : "systemnamn",
      "definition" : "systemnamn",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "skapaapotek-request.argosHeader.systemversion",
      "path" : "skapaapotek-request.argosHeader.systemversion",
      "short" : "systemversion",
      "definition" : "systemversion",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "skapaapotek-request.argosHeader.systemIp",
      "path" : "skapaapotek-request.argosHeader.systemIp",
      "short" : "systemIp",
      "definition" : "systemIp",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "skapaapotek-request.allmTelefon",
      "path" : "skapaapotek-request.allmTelefon",
      "short" : "allmTelefon",
      "definition" : "Expeditionsställets allmänna telefonnummer.",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "skapaapotek-request.besoksAdress",
      "path" : "skapaapotek-request.besoksAdress",
      "short" : "besoksAdress",
      "definition" : "Expeditionsställets besöksadress.",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "skapaapotek-request.besoksort",
      "path" : "skapaapotek-request.besoksort",
      "short" : "besoksort",
      "definition" : "Expeditionsställets ort (besöksort).",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "skapaapotek-request.eRecept",
      "path" : "skapaapotek-request.eRecept",
      "short" : "eRecept",
      "definition" : "Flagga som anger om expeditionsstället är ett apotek som kan hantera e-recept för besökande privat personer. Om eRecept är satt så är termerna kortNamn och recepturtelefon obligatoriska.",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "boolean"
      }]
    },
    {
      "id" : "skapaapotek-request.eReceptDjur",
      "path" : "skapaapotek-request.eReceptDjur",
      "short" : "eReceptDjur",
      "definition" : "Markering om apoteket kan expediera elektroniska djurrecept eller ej. Om eReceptDjur är satt så är termerna kortNamn och recepturtelefon obligatoriska.",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "boolean"
      }]
    },
    {
      "id" : "skapaapotek-request.faxnummer",
      "path" : "skapaapotek-request.faxnummer",
      "short" : "faxnummer",
      "definition" : "Expeditionsställets faxnummer. Obligatoriskt om huvudorganisationskod = DX eller om Organisationskod = DOS",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "skapaapotek-request.huvudOrgTypKod",
      "path" : "skapaapotek-request.huvudOrgTypKod",
      "short" : "huvudOrgTypKod",
      "definition" : "Huvudtypkoden är till stöd för dagens lösning av vårdsystem. På sikt önskar Apotekens Service AB att dessa koder arbetas bort och byts ut mot organisationstypflaggorna (ADM, DIST, DJAP, DOS, EA, EH, GSL, SA, TILV) Möjliga värden: ADM, AP, DIAP, DJUR, DX, OAP, SA, TVAP ADM En organisatiorisk enhet inom ett företag som har rent administrativa uppgifter. AP Apotek för allmänheten - enhet för detaljhandel med läkemedel med farmaceutisk bemanning under öppethållandet. DIAP Distansapotek - Större apoteksenhet med ansvar att kunna distribuera apoteksvaror direkt till avtalskunder, apoteksombud eller privatpersoner DJUR Ett apotek som har utökat djursortiment. DX Dosapotek - enhet för produktion av dosdispenserade läkemedel. OAP Övriga apotek - gammal definition av apotek. Bör ej användas. SA Sjukhusapotek - apotek som ger service till slutenvårdsenheter TVAP Enhet som på beställning tillverkar specifika individanpassade läkemedel.",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "skapaapotek-request.idLista",
      "path" : "skapaapotek-request.idLista",
      "short" : "idLista",
      "definition" : "Lista innehållande en eller flera identifierare för expeditionsstället. En Identitet som ska gälla för ett expeditionsställe kan skickas en eller flera gånger och tas aldrig bort. Vid uppdatering av ett expeditionsställe skickas en eller flera identiteter som identifierare. Obs! GLN-kod måste alltid skickas med.",
      "min" : 1,
      "max" : "*",
      "type" : [{
        "code" : "BackboneElement"
      }]
    },
    {
      "id" : "skapaapotek-request.idLista.exportId",
      "path" : "skapaapotek-request.idLista.exportId",
      "short" : "exportId",
      "definition" : "Obligatorisk för identitet med glnKod. Måste vara true om eRecept och/eller eReceptDjur är true. ExportId får ej sättas till true för en butikskod (används bara för GLN).",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "boolean"
      }]
    },
    {
      "id" : "skapaapotek-request.idLista.glnKod",
      "path" : "skapaapotek-request.idLista.glnKod",
      "short" : "glnKod",
      "definition" : "Expeditionsställets GLN-kod Måste sättas på en av identiteterna. Endast en glnkod per expeditionsställe är tillåtet.",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "skapaapotek-request.kommun",
      "path" : "skapaapotek-request.kommun",
      "short" : "kommun",
      "definition" : "Expeditionsställets kommuntillhörighet, kod enligt SCB.",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "integer"
      }]
    },
    {
      "id" : "skapaapotek-request.kortNamn",
      "path" : "skapaapotek-request.kortNamn",
      "short" : "kortNamn",
      "definition" : "Kortversion på apoteksnamn. Behövs i bla i vårdsystem. Om termen eRecept och/eller eReceptDjur är satt så är termerna kortNamn och recepturtelefon obligatoriska.",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "skapaapotek-request.lan",
      "path" : "skapaapotek-request.lan",
      "short" : "lan",
      "definition" : "Expeditionsställets länstillhörighet, kod enligt SCB.",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "integer"
      }]
    },
    {
      "id" : "skapaapotek-request.namn",
      "path" : "skapaapotek-request.namn",
      "short" : "namn",
      "definition" : "Expeditionsställets officiella namn.",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "skapaapotek-request.oppetHallandeLista",
      "path" : "skapaapotek-request.oppetHallandeLista",
      "short" : "oppetHallandeLista",
      "definition" : "När expeditionsstället har öppet. Måste skickas med vid varje uppdatering. All tidigare öppethållande data raderas innan det nya öppethållande datat läggs in.",
      "min" : 0,
      "max" : "*",
      "type" : [{
        "code" : "BackboneElement"
      }]
    },
    {
      "id" : "skapaapotek-request.oppetHallandeLista.dagBenamning",
      "path" : "skapaapotek-request.oppetHallandeLista.dagBenamning",
      "short" : "dagBenamning",
      "definition" : "Exempelvis \"Nyårsafton\".",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "skapaapotek-request.oppetHallandeLista.lunchFrom",
      "path" : "skapaapotek-request.oppetHallandeLista.lunchFrom",
      "short" : "lunchFrom",
      "definition" : "Om lunchstängt, \"stänger för lunch\". Format: HHmm H=Timme (0-23) m=Minut (0-59)",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "skapaapotek-request.oppetHallandeLista.lunchTom",
      "path" : "skapaapotek-request.oppetHallandeLista.lunchTom",
      "short" : "lunchTom",
      "definition" : "Om lunchstängt, \"Öppnar igen efter lunch kl\". Format: HHmm H=Timme (0-23) m=Minut (0-59)",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "skapaapotek-request.oppetHallandeLista.oppnar",
      "path" : "skapaapotek-request.oppetHallandeLista.oppnar",
      "short" : "oppnar",
      "definition" : "Öppningstid vardagar/vekodagnr. Format: HHmm H=Timme (0-23) m=Minut (0-59)",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "skapaapotek-request.oppetHallandeLista.slutDatum",
      "path" : "skapaapotek-request.oppetHallandeLista.slutDatum",
      "short" : "slutDatum",
      "definition" : "Sista dagen i en period vid typ N, P eller S. Obligatorisk vid typ P, S eller D. Om typ D är slutdatum = startdatum.",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "dateTime"
      }]
    },
    {
      "id" : "skapaapotek-request.oppetHallandeLista.stanger",
      "path" : "skapaapotek-request.oppetHallandeLista.stanger",
      "short" : "stanger",
      "definition" : "Stängningstid vardagar/vekodagnr. Format: HHmm H=Timme (0-23) m=Minut (0-59)",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "skapaapotek-request.oppetHallandeLista.startDatum",
      "path" : "skapaapotek-request.oppetHallandeLista.startDatum",
      "short" : "startDatum",
      "definition" : "Första dagen i en period vid typ N, P eller S. Vid typ D anges datum för aktuell dag exv 2010-12-23.",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "dateTime"
      }]
    },
    {
      "id" : "skapaapotek-request.oppetHallandeLista.tfStangtOrsak",
      "path" : "skapaapotek-request.oppetHallandeLista.tfStangtOrsak",
      "short" : "tfStangtOrsak",
      "definition" : "Orsak till tillfällig stängning.",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "skapaapotek-request.oppetHallandeLista.typ",
      "path" : "skapaapotek-request.oppetHallandeLista.typ",
      "short" : "typ",
      "definition" : "Typ av öppethållande. N = Normalt P = avvikande under angiven period D = avvikande under angiven dag S = tillfälligt stängt under angiven period",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "skapaapotek-request.oppetHallandeLista.veckodagnr",
      "path" : "skapaapotek-request.oppetHallandeLista.veckodagnr",
      "short" : "veckodagnr",
      "definition" : "Ett nummer för veckodagen 1-7 för Måndag till Söndag, V för vardagar.",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "skapaapotek-request.orgNr",
      "path" : "skapaapotek-request.orgNr",
      "short" : "orgNr",
      "definition" : "Aktörens organisationsnummer (xs:long i schemat.)",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "skapaapotek-request.orgTypADM",
      "path" : "skapaapotek-request.orgTypADM",
      "short" : "orgTypADM",
      "definition" : "Kod ADM som beskriver typ av expeditionsställe. En organisatiorisk enhet inom ett företag som har rent administrativa uppgifter.",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "boolean"
      }]
    },
    {
      "id" : "skapaapotek-request.orgTypDIST",
      "path" : "skapaapotek-request.orgTypDIST",
      "short" : "orgTypDIST",
      "definition" : "Kod DIST som beskriver typ av expeditionsställe. Distansapotek - Större apoteksenhet med ansvar att kunna distribuera apoteksvaror direkt till avtalskunder, apoteksombud eller privatpersoner",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "boolean"
      }]
    },
    {
      "id" : "skapaapotek-request.orgTypDJAP",
      "path" : "skapaapotek-request.orgTypDJAP",
      "short" : "orgTypDJAP",
      "definition" : "Kod DJAP som beskriver typ av expeditionsställe. Ett apotek som har utökat djursortiment.",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "boolean"
      }]
    },
    {
      "id" : "skapaapotek-request.orgTypDOS",
      "path" : "skapaapotek-request.orgTypDOS",
      "short" : "orgTypDOS",
      "definition" : "Kod DOS som beskriver typ av expeditionsställe. Dosapotek - enhet för produktion av dosdispenserade läkemedel.",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "boolean"
      }]
    },
    {
      "id" : "skapaapotek-request.orgTypEA",
      "path" : "skapaapotek-request.orgTypEA",
      "short" : "orgTypEA",
      "definition" : "Kod EA som beskriver typ av expeditionsställe. Apotek för allmänheten - enhet för detaljhandel med läkemedel med farmaceutisk bemanning under öppethållandet.",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "boolean"
      }]
    },
    {
      "id" : "skapaapotek-request.orgTypEH",
      "path" : "skapaapotek-request.orgTypEH",
      "short" : "orgTypEH",
      "definition" : "Kod EH som beskriver typ av expeditionsställe. En enhet som som kan lämna ut e-handel, dit man kan skicka e-handelspacket.",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "boolean"
      }]
    },
    {
      "id" : "skapaapotek-request.orgTypGSL",
      "path" : "skapaapotek-request.orgTypGSL",
      "short" : "orgTypGSL",
      "definition" : "Kod GSL som beskriver typ av expeditionsställe. Alla expeditionställen som säljer sortimentet på 80-listan (t ex shopar) ska ha flaggan satt. \"General Sales list\" - även kallad för \"80-listan\", enbart varor som ej är receptbelagda och som ingår i 80-sortimentet. Alla expeditionställen som säljer sortimentet på 80-listan (t ex shopar) ska ha flaggan satt.",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "boolean"
      }]
    },
    {
      "id" : "skapaapotek-request.orgTypSA",
      "path" : "skapaapotek-request.orgTypSA",
      "short" : "orgTypSA",
      "definition" : "Kod SA som beskriver typ av expeditionsställe. Sjukhusapotek - apotek som ger service till slutenvårdsenheter.",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "boolean"
      }]
    },
    {
      "id" : "skapaapotek-request.orgTypTILV",
      "path" : "skapaapotek-request.orgTypTILV",
      "short" : "orgTypTILV",
      "definition" : "Kod TILV som beskriver typ av expeditionsställe. Enhet som på beställning tillverkar individanpassade specifika läkemedel.",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "boolean"
      }]
    },
    {
      "id" : "skapaapotek-request.postAdress",
      "path" : "skapaapotek-request.postAdress",
      "short" : "postAdress",
      "definition" : "Expeditionsställets postAdress.",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "skapaapotek-request.postNr",
      "path" : "skapaapotek-request.postNr",
      "short" : "postNr",
      "definition" : "Expeditionsställets postNr.",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "skapaapotek-request.postort",
      "path" : "skapaapotek-request.postort",
      "short" : "postort",
      "definition" : "Expeditionsställets postort.",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "skapaapotek-request.recepturtelefon",
      "path" : "skapaapotek-request.recepturtelefon",
      "short" : "recepturtelefon",
      "definition" : "Expeditionsställets receptur telefonnummer. Om termen eRecept och/eller eReceptDjur är satt så är termerna kortNamn och recepturtelefon obligatoriska.",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "skapaapotek-request.slutDatum",
      "path" : "skapaapotek-request.slutDatum",
      "short" : "slutDatum",
      "definition" : "Datum för avslut av verksamhet.",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "dateTime"
      }]
    },
    {
      "id" : "skapaapotek-request.startDatum",
      "path" : "skapaapotek-request.startDatum",
      "short" : "startDatum",
      "definition" : "Datum för start av verksamhet. Det datum som allmänheten kan använda Apoteket.",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "dateTime"
      }]
    },
    {
      "id" : "skapaapotek-request.tidigareGlnKod",
      "path" : "skapaapotek-request.tidigareGlnKod",
      "short" : "tidigareGlnKod",
      "definition" : "Expeditionsställets tidigare ägares GLN.",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    }]
  }
}

```
