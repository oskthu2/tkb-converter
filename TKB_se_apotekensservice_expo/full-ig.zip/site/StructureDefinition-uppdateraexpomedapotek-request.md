# UppdateraExpoMedApotek — Request - se.apotekensservice: expo — Expeditionsställen och dosmottagare v2.0.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **UppdateraExpoMedApotek — Request**

## Logical Model: UppdateraExpoMedApotek — Request 

| | |
| :--- | :--- |
| *Official URL*:https://fhir.inera.se/ig/se-apotekensservice-expo/StructureDefinition/uppdateraexpomedapotek-request | *Version*:2.0.0 |
| Draft as of 2026-09-26 | *Computable Name*:UppdateraExpoMedApotekRequest |
| **Copyright/Legal**: Copyright 2024 Inera AB. Licensieras under Creative Commons Attribution 4.0. | |

 
Logisk modell för begäran i UppdateraExpoMedApotek (urn:riv:se.apotekensservice:expo:UppdateraExpoMedApotekResponder:6, UppdateraExpoMedApotekRequestType), inklusive SOAP-huvuden enligt WSDL. 

**Usages:**

* This Logical Model is not used by any profiles in this Specification

You can also check for [usages in the FHIR IG Statistics](https://packages2.fhir.org/xig/resource/inera.se-apotekensservice-expo|current/StructureDefinition/StructureDefinition-uppdateraexpomedapotek-request.json)

### Formal Views of Profile Content

 [Description of Profiles, Differentials, Snapshots and how the different presentations work](http://build.fhir.org/ig/FHIR/ig-guidance/readingIgs.html#structure-definitions). 

 

Other representations of profile: [CSV](StructureDefinition-uppdateraexpomedapotek-request.csv), [Excel](StructureDefinition-uppdateraexpomedapotek-request.xlsx) 



## Resource Content

```json
{
  "resourceType" : "StructureDefinition",
  "id" : "uppdateraexpomedapotek-request",
  "extension" : [{
    "url" : "http://hl7.org/fhir/StructureDefinition/structuredefinition-type-characteristics",
    "valueCode" : "can-be-target"
  }],
  "url" : "https://fhir.inera.se/ig/se-apotekensservice-expo/StructureDefinition/uppdateraexpomedapotek-request",
  "version" : "2.0.0",
  "name" : "UppdateraExpoMedApotekRequest",
  "title" : "UppdateraExpoMedApotek — Request",
  "status" : "draft",
  "date" : "2026-09-26T19:42:44+00:00",
  "contact" : [{
    "name" : "Inera Arkitektur",
    "telecom" : [{
      "system" : "url",
      "value" : "https://www.inera.se"
    }]
  }],
  "description" : "Logisk modell för begäran i UppdateraExpoMedApotek\n(urn:riv:se.apotekensservice:expo:UppdateraExpoMedApotekResponder:6, UppdateraExpoMedApotekRequestType), inklusive SOAP-huvuden enligt WSDL.",
  "copyright" : "Copyright 2024 Inera AB. Licensieras under Creative Commons Attribution 4.0.",
  "fhirVersion" : "4.0.1",
  "kind" : "logical",
  "abstract" : false,
  "type" : "https://fhir.inera.se/ig/se-apotekensservice-expo/StructureDefinition/uppdateraexpomedapotek-request",
  "baseDefinition" : "http://hl7.org/fhir/StructureDefinition/Base",
  "derivation" : "specialization",
  "differential" : {
    "element" : [{
      "id" : "uppdateraexpomedapotek-request",
      "path" : "uppdateraexpomedapotek-request",
      "short" : "UppdateraExpoMedApotek — Request",
      "definition" : "Logisk modell för begäran i UppdateraExpoMedApotek\n(urn:riv:se.apotekensservice:expo:UppdateraExpoMedApotekResponder:6, UppdateraExpoMedApotekRequestType), inklusive SOAP-huvuden enligt WSDL."
    },
    {
      "id" : "uppdateraexpomedapotek-request.logicalAddress",
      "path" : "uppdateraexpomedapotek-request.logicalAddress",
      "short" : "logicalAddress",
      "definition" : "SOAP-huvud LogicalAddress. Orgnr of Apotekens Service AB",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "uppdateraexpomedapotek-request.argosHeader",
      "path" : "uppdateraexpomedapotek-request.argosHeader",
      "short" : "argosHeader",
      "definition" : "SOAP-huvud ArgosHeader. Argos header of Apotekens Service AB. Check documentation regarding mandatory fields for this specific service interaction",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "BackboneElement"
      }]
    },
    {
      "id" : "uppdateraexpomedapotek-request.argosHeader.forskrivarkod",
      "path" : "uppdateraexpomedapotek-request.argosHeader.forskrivarkod",
      "short" : "forskrivarkod",
      "definition" : "forskrivarkod",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "uppdateraexpomedapotek-request.argosHeader.legitimationskod",
      "path" : "uppdateraexpomedapotek-request.argosHeader.legitimationskod",
      "short" : "legitimationskod",
      "definition" : "legitimationskod",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "uppdateraexpomedapotek-request.argosHeader.fornamn",
      "path" : "uppdateraexpomedapotek-request.argosHeader.fornamn",
      "short" : "fornamn",
      "definition" : "fornamn",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "uppdateraexpomedapotek-request.argosHeader.efternamn",
      "path" : "uppdateraexpomedapotek-request.argosHeader.efternamn",
      "short" : "efternamn",
      "definition" : "efternamn",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "uppdateraexpomedapotek-request.argosHeader.yrkesgrupp",
      "path" : "uppdateraexpomedapotek-request.argosHeader.yrkesgrupp",
      "short" : "yrkesgrupp",
      "definition" : "yrkesgrupp",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "uppdateraexpomedapotek-request.argosHeader.befattningskod",
      "path" : "uppdateraexpomedapotek-request.argosHeader.befattningskod",
      "short" : "befattningskod",
      "definition" : "befattningskod",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "uppdateraexpomedapotek-request.argosHeader.arbetsplatskod",
      "path" : "uppdateraexpomedapotek-request.argosHeader.arbetsplatskod",
      "short" : "arbetsplatskod",
      "definition" : "arbetsplatskod",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "uppdateraexpomedapotek-request.argosHeader.arbetsplatsnamn",
      "path" : "uppdateraexpomedapotek-request.argosHeader.arbetsplatsnamn",
      "short" : "arbetsplatsnamn",
      "definition" : "arbetsplatsnamn",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "uppdateraexpomedapotek-request.argosHeader.postort",
      "path" : "uppdateraexpomedapotek-request.argosHeader.postort",
      "short" : "postort",
      "definition" : "postort",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "uppdateraexpomedapotek-request.argosHeader.postadress",
      "path" : "uppdateraexpomedapotek-request.argosHeader.postadress",
      "short" : "postadress",
      "definition" : "postadress",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "uppdateraexpomedapotek-request.argosHeader.postnummer",
      "path" : "uppdateraexpomedapotek-request.argosHeader.postnummer",
      "short" : "postnummer",
      "definition" : "postnummer",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "uppdateraexpomedapotek-request.argosHeader.telefonnummer",
      "path" : "uppdateraexpomedapotek-request.argosHeader.telefonnummer",
      "short" : "telefonnummer",
      "definition" : "telefonnummer",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "uppdateraexpomedapotek-request.argosHeader.requestId",
      "path" : "uppdateraexpomedapotek-request.argosHeader.requestId",
      "short" : "requestId",
      "definition" : "requestId",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "uppdateraexpomedapotek-request.argosHeader.rollnamn",
      "path" : "uppdateraexpomedapotek-request.argosHeader.rollnamn",
      "short" : "rollnamn",
      "definition" : "rollnamn",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "uppdateraexpomedapotek-request.argosHeader.hsaID",
      "path" : "uppdateraexpomedapotek-request.argosHeader.hsaID",
      "short" : "hsaID",
      "definition" : "hsaID",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "uppdateraexpomedapotek-request.argosHeader.katalog",
      "path" : "uppdateraexpomedapotek-request.argosHeader.katalog",
      "short" : "katalog",
      "definition" : "katalog",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "uppdateraexpomedapotek-request.argosHeader.organisationsnummer",
      "path" : "uppdateraexpomedapotek-request.argosHeader.organisationsnummer",
      "short" : "organisationsnummer",
      "definition" : "organisationsnummer",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "uppdateraexpomedapotek-request.argosHeader.systemnamn",
      "path" : "uppdateraexpomedapotek-request.argosHeader.systemnamn",
      "short" : "systemnamn",
      "definition" : "systemnamn",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "uppdateraexpomedapotek-request.argosHeader.systemversion",
      "path" : "uppdateraexpomedapotek-request.argosHeader.systemversion",
      "short" : "systemversion",
      "definition" : "systemversion",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "uppdateraexpomedapotek-request.argosHeader.systemIp",
      "path" : "uppdateraexpomedapotek-request.argosHeader.systemIp",
      "short" : "systemIp",
      "definition" : "systemIp",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "uppdateraexpomedapotek-request.allmTelefon",
      "path" : "uppdateraexpomedapotek-request.allmTelefon",
      "short" : "allmTelefon",
      "definition" : "Expeditionsställets allmänna telefonnummer.",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "uppdateraexpomedapotek-request.besoksAdress",
      "path" : "uppdateraexpomedapotek-request.besoksAdress",
      "short" : "besoksAdress",
      "definition" : "Expeditionsställets besöksadress.",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "uppdateraexpomedapotek-request.besoksort",
      "path" : "uppdateraexpomedapotek-request.besoksort",
      "short" : "besoksort",
      "definition" : "Expeditionsställets ort (besöksort).",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "uppdateraexpomedapotek-request.eRecept",
      "path" : "uppdateraexpomedapotek-request.eRecept",
      "short" : "eRecept",
      "definition" : "Flagga som anger om expeditionsstället är ett apotek som kan hantera e-recept för besökande privat personer. Om eRecept är satt så är termerna kortNamn och recepturtelefon obligatoriska.",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "boolean"
      }]
    },
    {
      "id" : "uppdateraexpomedapotek-request.eReceptDjur",
      "path" : "uppdateraexpomedapotek-request.eReceptDjur",
      "short" : "eReceptDjur",
      "definition" : "Markering om apoteket kan expediera elektroniska djurrecept eller ej. Om eReceptDjur är satt så är termerna kortNamn och recepturtelefon obligatoriska.",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "boolean"
      }]
    },
    {
      "id" : "uppdateraexpomedapotek-request.faxnummer",
      "path" : "uppdateraexpomedapotek-request.faxnummer",
      "short" : "faxnummer",
      "definition" : "Expeditionsställets faxnummer. Obligatoriskt om huvudorganisationskod = DX eller om Organisationskod = DOS",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "uppdateraexpomedapotek-request.huvudOrgTypKod",
      "path" : "uppdateraexpomedapotek-request.huvudOrgTypKod",
      "short" : "huvudOrgTypKod",
      "definition" : "Huvudtypkoden är till stöd för dagens lösning av vårdsystem. På sikt önskar Apotekens Service AB att dessa koder arbetas bort och byts ut mot organisationstypflaggorna (ADM, DIST, DJAP, DOS, EA, EH, GSL, SA, TILV) Möjliga värden: ADM, AP, DIAP, DJUR, DX, OAP, SA, TVAP ADM En organisatiorisk enhet inom ett företag som har rent administrativa uppgifter. AP Apotek för allmänheten - enhet för detaljhandel med läkemedel med farmaceutisk bemanning under öppethållandet. DIAP Distansapotek - Större apoteksenhet med ansvar att kunna distribuera apoteksvaror direkt till avtalskunder, apoteksombud eller privatpersoner DJUR Ett apotek som har utökat djursortiment. DX Dosapotek - enhet för produktion av dosdispenserade läkemedel. OAP Övriga apotek - gammal definition av apotek. Bör ej användas. SA Sjukhusapotek - apotek som ger service till slutenvårdsenheter TVAP Enhet som på beställning tillverkar specifika individanpassade läkemedel.",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "uppdateraexpomedapotek-request.idLista",
      "path" : "uppdateraexpomedapotek-request.idLista",
      "short" : "idLista",
      "definition" : "Lista innehållande en eller flera identifierare för expeditionsstället. En Identitet som ska gälla för ett expeditionsställe kan skickas en eller flera gånger och tas aldrig bort. Vid uppdatering av ett expeditionsställe skickas en eller flera identiteter som identifierare. Obs! GLN-kod måste alltid skickas med.",
      "min" : 1,
      "max" : "*",
      "type" : [{
        "code" : "BackboneElement"
      }]
    },
    {
      "id" : "uppdateraexpomedapotek-request.idLista.exportId",
      "path" : "uppdateraexpomedapotek-request.idLista.exportId",
      "short" : "exportId",
      "definition" : "Obligatorisk för identitet med glnKod. Måste vara true om eRecept och/eller eReceptDjur är true. ExportId får ej sättas till true för en butikskod (används bara för GLN).",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "boolean"
      }]
    },
    {
      "id" : "uppdateraexpomedapotek-request.idLista.glnKod",
      "path" : "uppdateraexpomedapotek-request.idLista.glnKod",
      "short" : "glnKod",
      "definition" : "Expeditionsställets GLN-kod Måste sättas på en av identiteterna. Endast en glnkod per expeditionsställe är tillåtet.",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "uppdateraexpomedapotek-request.kommun",
      "path" : "uppdateraexpomedapotek-request.kommun",
      "short" : "kommun",
      "definition" : "Expeditionsställets kommuntillhörighet, kod enligt SCB.",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "integer"
      }]
    },
    {
      "id" : "uppdateraexpomedapotek-request.kortNamn",
      "path" : "uppdateraexpomedapotek-request.kortNamn",
      "short" : "kortNamn",
      "definition" : "Kortversion på apoteksnamn. Behövs i bla i vårdsystem. Om termen eRecept och/eller eReceptDjur är satt så är termerna kortNamn och recepturtelefon obligatoriska.",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "uppdateraexpomedapotek-request.lan",
      "path" : "uppdateraexpomedapotek-request.lan",
      "short" : "lan",
      "definition" : "Expeditionsställets länstillhörighet, kod enligt SCB.",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "integer"
      }]
    },
    {
      "id" : "uppdateraexpomedapotek-request.namn",
      "path" : "uppdateraexpomedapotek-request.namn",
      "short" : "namn",
      "definition" : "Expeditionsställets officiella namn.",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "uppdateraexpomedapotek-request.oppetHallandeLista",
      "path" : "uppdateraexpomedapotek-request.oppetHallandeLista",
      "short" : "oppetHallandeLista",
      "definition" : "När expeditionsstället har öppet. Måste skickas med vid varje uppdatering. All tidigare öppethållande data raderas innan det nya öppethållande datat läggs in.",
      "min" : 0,
      "max" : "*",
      "type" : [{
        "code" : "BackboneElement"
      }]
    },
    {
      "id" : "uppdateraexpomedapotek-request.oppetHallandeLista.dagBenamning",
      "path" : "uppdateraexpomedapotek-request.oppetHallandeLista.dagBenamning",
      "short" : "dagBenamning",
      "definition" : "Exempelvis \"Nyårsafton\".",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "uppdateraexpomedapotek-request.oppetHallandeLista.lunchFrom",
      "path" : "uppdateraexpomedapotek-request.oppetHallandeLista.lunchFrom",
      "short" : "lunchFrom",
      "definition" : "Om lunchstängt, \"stänger för lunch\". Format: HHmm H=Timme (0-23) m=Minut (0-59)",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "uppdateraexpomedapotek-request.oppetHallandeLista.lunchTom",
      "path" : "uppdateraexpomedapotek-request.oppetHallandeLista.lunchTom",
      "short" : "lunchTom",
      "definition" : "Om lunchstängt, \"Öppnar igen efter lunch kl\". Format: HHmm H=Timme (0-23) m=Minut (0-59)",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "uppdateraexpomedapotek-request.oppetHallandeLista.oppnar",
      "path" : "uppdateraexpomedapotek-request.oppetHallandeLista.oppnar",
      "short" : "oppnar",
      "definition" : "Öppningstid vardagar/vekodagnr. Format: HHmm H=Timme (0-23) m=Minut (0-59)",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "uppdateraexpomedapotek-request.oppetHallandeLista.slutDatum",
      "path" : "uppdateraexpomedapotek-request.oppetHallandeLista.slutDatum",
      "short" : "slutDatum",
      "definition" : "Sista dagen i en period vid typ N, P eller S. Obligatorisk vid typ P, S eller D. Om typ D är slutdatum = startdatum.",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "dateTime"
      }]
    },
    {
      "id" : "uppdateraexpomedapotek-request.oppetHallandeLista.stanger",
      "path" : "uppdateraexpomedapotek-request.oppetHallandeLista.stanger",
      "short" : "stanger",
      "definition" : "Stängningstid vardagar/vekodagnr. Format: HHmm H=Timme (0-23) m=Minut (0-59)",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "uppdateraexpomedapotek-request.oppetHallandeLista.startDatum",
      "path" : "uppdateraexpomedapotek-request.oppetHallandeLista.startDatum",
      "short" : "startDatum",
      "definition" : "Första dagen i en period vid typ N, P eller S. Vid typ D anges datum för aktuell dag exv 2010-12-23.",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "dateTime"
      }]
    },
    {
      "id" : "uppdateraexpomedapotek-request.oppetHallandeLista.tfStangtOrsak",
      "path" : "uppdateraexpomedapotek-request.oppetHallandeLista.tfStangtOrsak",
      "short" : "tfStangtOrsak",
      "definition" : "Orsak till tillfällig stängning.",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "uppdateraexpomedapotek-request.oppetHallandeLista.typ",
      "path" : "uppdateraexpomedapotek-request.oppetHallandeLista.typ",
      "short" : "typ",
      "definition" : "Typ av öppethållande. N = Normalt P = avvikande under angiven period D = avvikande under angiven dag S = tillfälligt stängt under angiven period",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "uppdateraexpomedapotek-request.oppetHallandeLista.veckodagnr",
      "path" : "uppdateraexpomedapotek-request.oppetHallandeLista.veckodagnr",
      "short" : "veckodagnr",
      "definition" : "Ett nummer för veckodagen 1-7 för Måndag till Söndag, V för vardagar.",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "uppdateraexpomedapotek-request.orgNr",
      "path" : "uppdateraexpomedapotek-request.orgNr",
      "short" : "orgNr",
      "definition" : "Aktörens organisationsnummer (xs:long i schemat.)",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "uppdateraexpomedapotek-request.orgTypADM",
      "path" : "uppdateraexpomedapotek-request.orgTypADM",
      "short" : "orgTypADM",
      "definition" : "Kod ADM som beskriver typ av expeditionsställe. En organisatiorisk enhet inom ett företag som har rent administrativa uppgifter.",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "boolean"
      }]
    },
    {
      "id" : "uppdateraexpomedapotek-request.orgTypDIST",
      "path" : "uppdateraexpomedapotek-request.orgTypDIST",
      "short" : "orgTypDIST",
      "definition" : "Kod DIST som beskriver typ av expeditionsställe. Distansapotek - Större apoteksenhet med ansvar att kunna distribuera apoteksvaror direkt till avtalskunder, apoteksombud eller privatpersoner",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "boolean"
      }]
    },
    {
      "id" : "uppdateraexpomedapotek-request.orgTypDJAP",
      "path" : "uppdateraexpomedapotek-request.orgTypDJAP",
      "short" : "orgTypDJAP",
      "definition" : "Kod DJAP som beskriver typ av expeditionsställe. Ett apotek som har utökat djursortiment.",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "boolean"
      }]
    },
    {
      "id" : "uppdateraexpomedapotek-request.orgTypDOS",
      "path" : "uppdateraexpomedapotek-request.orgTypDOS",
      "short" : "orgTypDOS",
      "definition" : "Kod DOS som beskriver typ av expeditionsställe. Dosapotek - enhet för produktion av dosdispenserade läkemedel.",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "boolean"
      }]
    },
    {
      "id" : "uppdateraexpomedapotek-request.orgTypEA",
      "path" : "uppdateraexpomedapotek-request.orgTypEA",
      "short" : "orgTypEA",
      "definition" : "Kod EA som beskriver typ av expeditionsställe. Apotek för allmänheten - enhet för detaljhandel med läkemedel med farmaceutisk bemanning under öppethållandet.",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "boolean"
      }]
    },
    {
      "id" : "uppdateraexpomedapotek-request.orgTypEH",
      "path" : "uppdateraexpomedapotek-request.orgTypEH",
      "short" : "orgTypEH",
      "definition" : "Kod EH som beskriver typ av expeditionsställe. En enhet som som kan lämna ut e-handel, dit man kan skicka e-handelspacket.",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "boolean"
      }]
    },
    {
      "id" : "uppdateraexpomedapotek-request.orgTypGSL",
      "path" : "uppdateraexpomedapotek-request.orgTypGSL",
      "short" : "orgTypGSL",
      "definition" : "Kod GSL som beskriver typ av expeditionsställe. Alla expeditionställen som säljer sortimentet på 80-listan (t ex shopar) ska ha flaggan satt. \"General Sales list\" - även kallad för \"80-listan\", enbart varor som ej är receptbelagda och som ingår i 80-sortimentet. Alla expeditionställen som säljer sortimentet på 80-listan (t ex shopar) ska ha flaggan satt.",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "boolean"
      }]
    },
    {
      "id" : "uppdateraexpomedapotek-request.orgTypSA",
      "path" : "uppdateraexpomedapotek-request.orgTypSA",
      "short" : "orgTypSA",
      "definition" : "Kod SA som beskriver typ av expeditionsställe. Sjukhusapotek - apotek som ger service till slutenvårdsenheter.",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "boolean"
      }]
    },
    {
      "id" : "uppdateraexpomedapotek-request.orgTypTILV",
      "path" : "uppdateraexpomedapotek-request.orgTypTILV",
      "short" : "orgTypTILV",
      "definition" : "Kod TILV som beskriver typ av expeditionsställe. Enhet som på beställning tillverkar individanpassade specifika läkemedel.",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "boolean"
      }]
    },
    {
      "id" : "uppdateraexpomedapotek-request.postAdress",
      "path" : "uppdateraexpomedapotek-request.postAdress",
      "short" : "postAdress",
      "definition" : "Expeditionsställets postAdress.",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "uppdateraexpomedapotek-request.postNr",
      "path" : "uppdateraexpomedapotek-request.postNr",
      "short" : "postNr",
      "definition" : "Expeditionsställets postNr.",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "uppdateraexpomedapotek-request.postort",
      "path" : "uppdateraexpomedapotek-request.postort",
      "short" : "postort",
      "definition" : "Expeditionsställets postort.",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "uppdateraexpomedapotek-request.recepturtelefon",
      "path" : "uppdateraexpomedapotek-request.recepturtelefon",
      "short" : "recepturtelefon",
      "definition" : "Expeditionsställets receptur telefonnummer. Om termen eRecept och/eller eReceptDjur är satt så är termerna kortNamn och recepturtelefon obligatoriska.",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "uppdateraexpomedapotek-request.slutDatum",
      "path" : "uppdateraexpomedapotek-request.slutDatum",
      "short" : "slutDatum",
      "definition" : "Datum för avslut av verksamhet.",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "dateTime"
      }]
    },
    {
      "id" : "uppdateraexpomedapotek-request.startDatum",
      "path" : "uppdateraexpomedapotek-request.startDatum",
      "short" : "startDatum",
      "definition" : "Datum för start av verksamhet. Det datum som allmänheten kan använda Apoteket.",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "dateTime"
      }]
    },
    {
      "id" : "uppdateraexpomedapotek-request.tidigareGlnKod",
      "path" : "uppdateraexpomedapotek-request.tidigareGlnKod",
      "short" : "tidigareGlnKod",
      "definition" : "Expeditionsställets tidigare ägares GLN.",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    }]
  }
}

```
