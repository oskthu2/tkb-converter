# SaveFormTemplate — Request - infrastructure: eservicesupply: forminteraction v2.1.1

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **SaveFormTemplate — Request**

## Logical Model: SaveFormTemplate — Request 

| | |
| :--- | :--- |
| *Official URL*:https://fhir.inera.se/ig/infrastructure-eservicesupply-forminteraction/StructureDefinition/saveformtemplate-request | *Version*:2.1 |
| Active as of 2026-10-12 | *Computable Name*:SaveFormTemplateRequest |
| **Copyright/Legal**: Copyright 2024 Inera AB. Licensieras under Creative Commons Attribution 4.0. | |

 
Logisk modell för requestparametrar i SaveFormTemplate. 

**Usages:**

* This Logical Model is not used by any profiles in this Specification

You can also check for [usages in the FHIR IG Statistics](https://packages2.fhir.org/xig/resource/inera.infrastructure-eservicesupply-forminteraction|current/StructureDefinition/StructureDefinition-saveformtemplate-request.json)

### Formal Views of Profile Content

 [Description of Profiles, Differentials, Snapshots and how the different presentations work](http://build.fhir.org/ig/FHIR/ig-guidance/readingIgs.html#structure-definitions). 

 

Other representations of profile: [CSV](StructureDefinition-saveformtemplate-request.csv), [Excel](StructureDefinition-saveformtemplate-request.xlsx) 



## Resource Content

```json
{
  "resourceType" : "StructureDefinition",
  "id" : "saveformtemplate-request",
  "extension" : [{
    "url" : "http://hl7.org/fhir/StructureDefinition/structuredefinition-type-characteristics",
    "valueCode" : "can-be-target"
  }],
  "url" : "https://fhir.inera.se/ig/infrastructure-eservicesupply-forminteraction/StructureDefinition/saveformtemplate-request",
  "version" : "2.1",
  "name" : "SaveFormTemplateRequest",
  "title" : "SaveFormTemplate — Request",
  "status" : "active",
  "date" : "2026-10-12T12:33:27+00:00",
  "contact" : [{
    "name" : "Inera Arkitektur",
    "telecom" : [{
      "system" : "url",
      "value" : "https://www.inera.se"
    }]
  }],
  "description" : "Logisk modell för requestparametrar i SaveFormTemplate.",
  "copyright" : "Copyright 2024 Inera AB. Licensieras under Creative Commons Attribution 4.0.",
  "fhirVersion" : "4.0.1",
  "kind" : "logical",
  "abstract" : false,
  "type" : "https://fhir.inera.se/ig/infrastructure-eservicesupply-forminteraction/StructureDefinition/saveformtemplate-request",
  "baseDefinition" : "http://hl7.org/fhir/StructureDefinition/Base",
  "derivation" : "specialization",
  "differential" : {
    "element" : [{
      "id" : "saveformtemplate-request",
      "path" : "saveformtemplate-request",
      "short" : "SaveFormTemplate — Request",
      "definition" : "Logisk modell för requestparametrar i SaveFormTemplate."
    },
    {
      "id" : "saveformtemplate-request.formTemplate",
      "path" : "saveformtemplate-request.formTemplate",
      "short" : "Formulärmall",
      "definition" : "Objektet innehåller formulärmallen som ska sparas. Källdokumentet specificerar\ninte formulärmallens interna struktur i denna kontraktsbeskrivning (endast\n\"Objektet innehåller formulärmallen\"). Se det delade domänschemat\n(infrastructure_eservicesupply_forminteraction_2.1.xsd) för den fullständiga\nXSD-strukturen.",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "BackboneElement"
      }]
    }]
  }
}

```
