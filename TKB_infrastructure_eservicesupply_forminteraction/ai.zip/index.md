# Hem - infrastructure: eservicesupply: forminteraction v2.1

* [**Table of Contents**](toc.md)
* **Hem**

## Hem

| | |
| :--- | :--- |
| *Official URL*:https://fhir.inera.se/ig/infrastructure-eservicesupply-forminteraction/ImplementationGuide/inera.infrastructure-eservicesupply-forminteraction | *Version*:2.1 |
| Draft as of 2026-09-09 | *Computable Name*:infrastructureeservicesupplyforminteraction |
| **Copyright/Legal**: Copyright 2024 Inera AB. Licensieras under Creative Commons Attribution 4.0. | |

# infrastructure: eservicesupply: forminteraction

## Översikt

FHIR Implementation Guide för tjänstedomänen **infrastructure: eservicesupply: forminteraction** version 2.1. Genererad från Ineras Tjänstekontraktsbeskrivning (TKB).

Domänen definierar tjänstekontrakt för formulärinteraktion mellan patient/invånare och vårdverksamhet, alternativt mellan patient-e-tjänst och verksamhetssystem. Tjänstedomänens tjänstekontrakt möjliggör en vård-initierad process för formulärbegäran gentemot identifierad invånare eller patient.

Domänen innehåller följande tjänstekontrakt:

| | | |
| :--- | :--- | :--- |
| [GetFormTemplates](7-tjanstekontrakt.md#getformtemplates) | 2.0 | Hämta tillgängliga formulärmallar för invånare |
| [CreateForm](7-tjanstekontrakt.md#createform) | 2.1 | Skapa och initiera/starta ett formulär |
| [GetForms](7-tjanstekontrakt.md#getforms) | 2.0 | Lista alla pågående/avslutade formulär |
| [GetForm](7-tjanstekontrakt.md#getform) | 2.1 | Hämta ett specifikt formulär |
| [GetFormQuestionPage](7-tjanstekontrakt.md#getformquestionpage) | 2.0 | Navigera framåt eller bakåt i ett formulär |
| [SaveFormPage](7-tjanstekontrakt.md#saveformpage) | 2.1 | Spara invånarens besvarade frågor |
| [SaveForm](7-tjanstekontrakt.md#saveform) | 2.1 | Avsluta/stänga ett ifyllt formulär |
| [CancelForm](7-tjanstekontrakt.md#cancelform) | 2.0 | Avbryta/radera ett formulär |
| [CreateFormRequest](7-tjanstekontrakt.md#createformrequest) | 2.0 | Skapa en begäran om formulär (formulärbegäran) |
| [GetFormTemplate](7-tjanstekontrakt.md#getformtemplate) | 2.1 | Hämta en formulärmall |
| [SaveFormTemplate](7-tjanstekontrakt.md#saveformtemplate) | 2.1 | Spara en formulärmall |
| [DeleteFormTemplate](7-tjanstekontrakt.md#deleteformtemplate) | 1.0 | Makulera en formulärmall |

## Innehåll

* [1 Inledning](1-inledning.md)
* [2 Versionsinformation](2-versionsinformation.md)
* [3 Tjänstedomänens arkitektur](3-tjanstedomanens-arkitektur.md)
* [4 Tjänstedomänens krav och regler](4-tjanstedomanens-krav-och-regler.md)
* [5 Tjänstedomänens meddelandemodeller](5-tjanstedomanens-meddelandemodeller.md)
* [7 Tjänstekontrakt](7-tjanstekontrakt.md)
* [Artefakter](artifacts.md)

