# Hem - infrastructure: eservicesupply: forminteraction v2.1.1

* [**Table of Contents**](toc.md)
* **Hem**

## Hem

| | |
| :--- | :--- |
| *Official URL*:https://fhir.inera.se/ig/infrastructure-eservicesupply-forminteraction/ImplementationGuide/inera.infrastructure-eservicesupply-forminteraction | *Version*:2.1.1 |
| Active as of 2026-11-06 | *Computable Name*:infrastructureeservicesupplyforminteraction |
| **Copyright/Legal**: Copyright 2024 Inera AB. Licensieras under Creative Commons Attribution 4.0. | |

# infrastructure: eservicesupply: forminteraction

**TKB-version:** 2.1.1 · **IG-version:** 2.1.1 · **Källa:** Bitbucket-tagg `2.1.1` 

## Översikt

* Beskrivning: Svenskt kortnamn
  * Formulärtjänsten möjliggör hantering av formulärinformation mellan olika aktörer. Tjänstekontraktet möjliggör insamling av olika typer av formulärinformation. Tjänstekonsument och tjänsteproducent kan använda tjänstekontraktet på olika sätt och i olika steg i sina processer. Exempel: * En vårdaktivitet kräver en hälsodeklaration. * Ett vårdbesök föranleder en registreringsblankett * En behandling kräver uppföljning + Biverkningsregistrering + Effektmätning av behandling * Informationsinsamling under begäran och bedömning av vårdbegäran. Denna domän hette tidigare infrastructure:supportservices:forminteraction.: formulärhantering
* Beskrivning: Svenskt namn
  * Formulärtjänsten möjliggör hantering av formulärinformation mellan olika aktörer. Tjänstekontraktet möjliggör insamling av olika typer av formulärinformation. Tjänstekonsument och tjänsteproducent kan använda tjänstekontraktet på olika sätt och i olika steg i sina processer. Exempel: * En vårdaktivitet kräver en hälsodeklaration. * Ett vårdbesök föranleder en registreringsblankett * En behandling kräver uppföljning + Biverkningsregistrering + Effektmätning av behandling * Informationsinsamling under begäran och bedömning av vårdbegäran. Denna domän hette tidigare infrastructure:supportservices:forminteraction.: infrastruktur:etjänsteförsörjning:formulärhantering
* Beskrivning: Typ
  * Formulärtjänsten möjliggör hantering av formulärinformation mellan olika aktörer. Tjänstekontraktet möjliggör insamling av olika typer av formulärinformation. Tjänstekonsument och tjänsteproducent kan använda tjänstekontraktet på olika sätt och i olika steg i sina processer. Exempel: * En vårdaktivitet kräver en hälsodeklaration. * Ett vårdbesök föranleder en registreringsblankett * En behandling kräver uppföljning + Biverkningsregistrering + Effektmätning av behandling * Informationsinsamling under begäran och bedömning av vårdbegäran. Denna domän hette tidigare infrastructure:supportservices:forminteraction.: Nationell tjänstedomän
* Beskrivning: Källkod
  * Formulärtjänsten möjliggör hantering av formulärinformation mellan olika aktörer. Tjänstekontraktet möjliggör insamling av olika typer av formulärinformation. Tjänstekonsument och tjänsteproducent kan använda tjänstekontraktet på olika sätt och i olika steg i sina processer. Exempel: * En vårdaktivitet kräver en hälsodeklaration. * Ett vårdbesök föranleder en registreringsblankett * En behandling kräver uppföljning + Biverkningsregistrering + Effektmätning av behandling * Informationsinsamling under begäran och bedömning av vårdbegäran. Denna domän hette tidigare infrastructure:supportservices:forminteraction.: [Bitbucket](https://bitbucket.org/rivta-domains/riv.infrastructure.eservicesupply.forminteraction/src)
* Beskrivning: Ärenden
  * Formulärtjänsten möjliggör hantering av formulärinformation mellan olika aktörer. Tjänstekontraktet möjliggör insamling av olika typer av formulärinformation. Tjänstekonsument och tjänsteproducent kan använda tjänstekontraktet på olika sätt och i olika steg i sina processer. Exempel: * En vårdaktivitet kräver en hälsodeklaration. * Ett vårdbesök föranleder en registreringsblankett * En behandling kräver uppföljning + Biverkningsregistrering + Effektmätning av behandling * Informationsinsamling under begäran och bedömning av vårdbegäran. Denna domän hette tidigare infrastructure:supportservices:forminteraction.: [Bitbucket issues](https://bitbucket.org/rivta-domains/riv.infrastructure.eservicesupply.forminteraction/issues)
* Beskrivning: Informationssida
  * Formulärtjänsten möjliggör hantering av formulärinformation mellan olika aktörer. Tjänstekontraktet möjliggör insamling av olika typer av formulärinformation. Tjänstekonsument och tjänsteproducent kan använda tjänstekontraktet på olika sätt och i olika steg i sina processer. Exempel: * En vårdaktivitet kräver en hälsodeklaration. * Ett vårdbesök föranleder en registreringsblankett * En behandling kräver uppföljning + Biverkningsregistrering + Effektmätning av behandling * Informationsinsamling under begäran och bedömning av vårdbegäran. Denna domän hette tidigare infrastructure:supportservices:forminteraction.: [Confluence](https://bitbucket.org/rivta-domains/riv.infrastructure.eservicesupply.forminteraction/wiki/)
* Beskrivning: Underlag för denna IG
  * Formulärtjänsten möjliggör hantering av formulärinformation mellan olika aktörer. Tjänstekontraktet möjliggör insamling av olika typer av formulärinformation. Tjänstekonsument och tjänsteproducent kan använda tjänstekontraktet på olika sätt och i olika steg i sina processer. Exempel: * En vårdaktivitet kräver en hälsodeklaration. * Ett vårdbesök föranleder en registreringsblankett * En behandling kräver uppföljning + Biverkningsregistrering + Effektmätning av behandling * Informationsinsamling under begäran och bedömning av vårdbegäran. Denna domän hette tidigare infrastructure:supportservices:forminteraction.: Version 2.1.1 ·[tagg 2.1.1](https://bitbucket.org/rivta-domains/riv.infrastructure.eservicesupply.forminteraction/src/2.1.1)
* Beskrivning: RIV-TA-portalen
  * Formulärtjänsten möjliggör hantering av formulärinformation mellan olika aktörer. Tjänstekontraktet möjliggör insamling av olika typer av formulärinformation. Tjänstekonsument och tjänsteproducent kan använda tjänstekontraktet på olika sätt och i olika steg i sina processer. Exempel: * En vårdaktivitet kräver en hälsodeklaration. * Ett vårdbesök föranleder en registreringsblankett * En behandling kräver uppföljning + Biverkningsregistrering + Effektmätning av behandling * Informationsinsamling under begäran och bedömning av vårdbegäran. Denna domän hette tidigare infrastructure:supportservices:forminteraction.: [Alla tjänstedomäner](https://oskthu2.github.io/tkb-converter/rivta-portal/tjanstedomaner.html)·[Alla tjänstekontrakt](https://oskthu2.github.io/tkb-converter/rivta-portal/tjanstekontrakt.html)

FHIR Implementation Guide för tjänstedomänen **infrastructure: eservicesupply: forminteraction** version 2.1.1. Genererad från Ineras Tjänstekontraktsbeskrivning (TKB).

Domänen definierar tjänstekontrakt för formulärinteraktion mellan patient/invånare och vårdverksamhet, alternativt mellan patient-e-tjänst och verksamhetssystem. Tjänstedomänens tjänstekontrakt möjliggör en vård-initierad process för formulärbegäran gentemot identifierad invånare eller patient.

Domänen innehåller följande tjänstekontrakt:

| | | |
| :--- | :--- | :--- |
| [GetFormTemplates](7-tjanstekontrakt.md#getformtemplates) | 2.0 | Hämta tillgängliga formulärmallar för invånare |
| [CreateForm](7-tjanstekontrakt.md#createform) | 2.1 | Skapa och initiera/starta ett formulär |
| [GetForms](7-tjanstekontrakt.md#getforms) | 2.0 | Lista alla pågående/avslutade formulär |
| [GetForm](7-tjanstekontrakt.md#getform) | 2.1 | Hämta ett specifikt formulär |
| [GetFormQuestionPage](7-tjanstekontrakt.md#getformquestionpage) | 2.0 | Navigera framåt eller bakåt i ett formulär |
| [SaveFormPage](7-tjanstekontrakt.md#saveformpage) | 2.1 | Spara invånarens besvarade frågor |
| [SaveForm](7-tjanstekontrakt.md#saveform) | 2.1 | Avsluta/stänga ett ifyllt formulär |
| [CancelForm](7-tjanstekontrakt.md#cancelform) | 2.0 | Avbryta/radera ett formulär |
| [CreateFormRequest](7-tjanstekontrakt.md#createformrequest) | 2.0 | Skapa en begäran om formulär (formulärbegäran) |
| [GetFormTemplate](7-tjanstekontrakt.md#getformtemplate) | 2.1 | Hämta en formulärmall |
| [SaveFormTemplate](7-tjanstekontrakt.md#saveformtemplate) | 2.1 | Spara en formulärmall |
| [DeleteFormTemplate](7-tjanstekontrakt.md#deleteformtemplate) | 1.0 | Makulera en formulärmall |

### Versioner och granskningar

| | | | |
| :--- | :--- | :--- | :--- |
| 2.0 | TKB, AB | Arkitektur & Regelverk: Säkerhet: Delvis GodkändArkitektur & Regelverk: Informatik: UnderkändArkitektur & Regelverk: Teknik: Godkänd | [zip](https://bitbucket.org/rivta-domains/riv.infrastructure.eservicesupply.forminteraction/get/2.0.zip)·[källkod](https://bitbucket.org/rivta-domains/riv.infrastructure.eservicesupply.forminteraction/src/2.0) |
| trunk | TKB, AB |  | [källkod](https://bitbucket.org/rivta-domains/riv.infrastructure.eservicesupply.forminteraction/src/master) |

*Zip-arkiven hämtas från taggarna på Bitbucket. Granskningsprotokollen publicerades på rivta.se och länkas inte härifrån.*

*Källa: ögonblicksbild av DOMDB från 2021-08-24, via RIV-TA-portalen.*

## Innehåll

* [1 Inledning](1-inledning.md)
* [2 Versionsinformation](2-versionsinformation.md)
* [3 Tjänstedomänens arkitektur](3-tjanstedomanens-arkitektur.md)
* [4 Tjänstedomänens krav och regler](4-tjanstedomanens-krav-och-regler.md)
* [5 Tjänstedomänens meddelandemodeller](5-tjanstedomanens-meddelandemodeller.md)
* [7 Tjänstekontrakt](7-tjanstekontrakt.md)
* [Artefakter](artifacts.md)

