# inera.infrastructure-informationstructureservice-terminology#1.0.0: infrastructure: informationstructureservice: terminology

## Pages

* [Hem](index.md)
* [7 Tjänstekontrakt](7-tjanstekontrakt.md)
* [5 Tjänstedomänens meddelandemodeller](5-tjanstedomanens-meddelandemodeller.md)
* [Artifacts Summary](artifacts.md)
* [6 Tjänstedomänens gemensamma komponenter](6-gemensamma-informationskomponenter.md)
* [3 Tjänstedomänens arkitektur](3-tjanstedomanens-arkitektur.md)
* [4 Tjänstedomänens krav och regler](4-tjanstedomanens-krav-och-regler.md)
* [2 Versionsinformation](2-versionsinformation.md)
* [1 Inledning](1-inledning.md)

## Resources

### CodeSystems

* [Resultatkod](CodeSystem-terminology-resultcode-cs.md)

### ValueSets

* [Resultatkod](ValueSet-terminology-resultcode-vs.md)

### Logicals

* [GetConcepts — Request](StructureDefinition-getconcepts-request.md)
* [GetConcepts — Response](StructureDefinition-getconcepts.md)
* [GetTerminologySubset — Request](StructureDefinition-getterminologysubset-request.md)
* [GetTerminologySubset — Response](StructureDefinition-getterminologysubset.md)
* [GetTerminologySubsetInformation — Request](StructureDefinition-getterminologysubsetinformation-request.md)
* [GetTerminologySubsetInformation — Response](StructureDefinition-getterminologysubsetinformation.md)

### ImplementationGuides

* [infrastructure: informationstructureservice: terminology](index.md)
