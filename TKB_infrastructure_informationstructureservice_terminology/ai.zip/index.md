# Hem - infrastructure: informationstructureservice: terminology v1.0.0-snapshot

* [**Table of Contents**](toc.md)
* **Hem**

## Hem

| | |
| :--- | :--- |
| *Official URL*:https://fhir.inera.se/ig/infrastructure-informationstructureservice-terminology/ImplementationGuide/inera.infrastructure-informationstructureservice-terminology | *Version*:1.0.0-snapshot |
| Draft as of 2026-10-12 | *Computable Name*:infrastructureinformationstructureserviceterminology |
| **Copyright/Legal**: Copyright 2024 Inera AB. Licensieras under Creative Commons Attribution 4.0. | |

# infrastructure: informationstructureservice: terminology

**TKB-version:** PA1 · **IG-version:** 1.0.0-snapshot · **Källa:** Bitbucket-commit `23f2de6a6b95` (ingen tagg) 

## Översikt

* Svenskt kortnamn: Svenskt namn
  * terminologi: infrastruktur:informations-strukturtjänster:terminologi
* Svenskt kortnamn: Typ
  * terminologi: Nationell tjänstedomän
* Svenskt kortnamn: Källkod
  * terminologi: [Bitbucket](https://bitbucket.org/rivta-domains/riv.infrastructure.informationstructureservice.terminology/src)
* Svenskt kortnamn: Ärenden
  * terminologi: [Bitbucket issues](https://bitbucket.org/rivta-domains/riv.infrastructure.informationstructureservice.terminology/issues)
* Svenskt kortnamn: Underlag för denna IG
  * terminologi: Version PA1 ·[commit 23f2de6a6b95](https://bitbucket.org/rivta-domains/riv.infrastructure.informationstructureservice.terminology/src/23f2de6a6b95c45a036e7dba55da35d72cd07039)·[zip](https://bitbucket.org/rivta-domains/riv.infrastructure.informationstructureservice.terminology/get/23f2de6a6b95.zip)
* Svenskt kortnamn: RIV-TA-portalen
  * terminologi: [Alla tjänstedomäner](https://oskthu2.github.io/tkb-converter/rivta-portal/tjanstedomaner.html)·[Alla tjänstekontrakt](https://oskthu2.github.io/tkb-converter/rivta-portal/tjanstekontrakt.html)

FHIR Implementation Guide för tjänstedomänen **infrastructure: informationstructureservice: terminology** (Terminologitjänst) version 1.0.0. Genererad från Ineras Tjänstekontraktsbeskrivning (TKB), version PA1 (2013-10-30), och domänens WSDL- och XSD-filer.

Terminologitjänsten ger tillgång till urval av begrepp och termer ur klassifikationer och begreppssystem som Snomed CT, ICD-10 och ATC.

Domänen innehåller följande tjänstekontrakt:

| | | |
| :--- | :--- | :--- |
| [GetTerminologySubset](7-tjanstekontrakt.md#getterminologysubset) | 1.0 | Hämtar ett urval (subset) av begrepp och termer ur en eller flera terminologier |
| [GetTerminologySubsetInformation](7-tjanstekontrakt.md#getterminologysubsetinformation) | 1.0 | Hämtar namn, id och versionsidentifierare för ett eller flera urval |
| [GetConcepts](7-tjanstekontrakt.md#getconcepts) | 1.0 | Söker begrepp och termer i ett urval |

### Versioner och granskningar

| | | | |
| :--- | :--- | :--- | :--- |
| trunk | IS, TKB, AB |  | [källkod](https://bitbucket.org/rivta-domains/riv.infrastructure.informationstructureservice.terminology/src/master) |

*Källa: ögonblicksbild av DOMDB från 2021-08-24, via RIV-TA-portalen.*

## Innehåll

* [1 Inledning](1-inledning.md)
* [2 Versionsinformation](2-versionsinformation.md)
* [3 Tjänstedomänens arkitektur](3-tjanstedomanens-arkitektur.md)
* [4 Tjänstedomänens krav och regler](4-tjanstedomanens-krav-och-regler.md)
* [5 Tjänstedomänens meddelandemodeller](5-tjanstedomanens-meddelandemodeller.md)
* [6 Tjänstedomänens gemensamma komponenter](6-gemensamma-informationskomponenter.md)
* [7 Tjänstekontrakt](7-tjanstekontrakt.md)
* [Artefakter](artifacts.md)

