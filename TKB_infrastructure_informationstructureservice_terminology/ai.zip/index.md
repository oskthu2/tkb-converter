# Hem - infrastructure: informationstructureservice: terminology v1.0.0

* [**Table of Contents**](toc.md)
* **Hem**

## Hem

| | |
| :--- | :--- |
| *Official URL*:https://fhir.inera.se/ig/infrastructure-informationstructureservice-terminology/ImplementationGuide/inera.infrastructure-informationstructureservice-terminology | *Version*:1.0.0 |
| Draft as of 2026-09-26 | *Computable Name*:infrastructureinformationstructureserviceterminology |
| **Copyright/Legal**: Copyright 2024 Inera AB. Licensieras under Creative Commons Attribution 4.0. | |

# infrastructure: informationstructureservice: terminology

## Översikt

FHIR Implementation Guide för tjänstedomänen **infrastructure: informationstructureservice: terminology** (Terminologitjänst) version 1.0.0. Genererad från Ineras Tjänstekontraktsbeskrivning (TKB), version PA1 (2013-10-30), och domänens WSDL- och XSD-filer.

Terminologitjänsten ger tillgång till urval av begrepp och termer ur klassifikationer och begreppssystem som Snomed CT, ICD-10 och ATC.

Domänen innehåller följande tjänstekontrakt:

| | | |
| :--- | :--- | :--- |
| [GetTerminologySubset](7-tjanstekontrakt.md#getterminologysubset) | 1.0 | Hämtar ett urval (subset) av begrepp och termer ur en eller flera terminologier |
| [GetTerminologySubsetInformation](7-tjanstekontrakt.md#getterminologysubsetinformation) | 1.0 | Hämtar namn, id och versionsidentifierare för ett eller flera urval |
| [GetConcepts](7-tjanstekontrakt.md#getconcepts) | 1.0 | Söker begrepp och termer i ett urval |

## Innehåll

* [1 Inledning](1-inledning.md)
* [2 Versionsinformation](2-versionsinformation.md)
* [3 Tjänstedomänens arkitektur](3-tjanstedomanens-arkitektur.md)
* [4 Tjänstedomänens krav och regler](4-tjanstedomanens-krav-och-regler.md)
* [5 Tjänstedomänens meddelandemodeller](5-tjanstedomanens-meddelandemodeller.md)
* [6 Tjänstedomänens gemensamma komponenter](6-gemensamma-informationskomponenter.md)
* [7 Tjänstekontrakt](7-tjanstekontrakt.md)
* [Artefakter](artifacts.md)

