# 1 Inledning - infrastructure: directory: employee v4.0.0

* [**Table of Contents**](toc.md)
* **1 Inledning**

## 1 Inledning

## Inledning

Detta är beskrivningen av tjänstekontrakten i tjänstedomänen Infrastructure: Directory: Employee Tjänstekontrakten är baserade på RIVTA 2.1 [R2] och reglerade genom arkitekturella beslut [R1]. Tjänstekontraktsbeskrivningen är en kravspecifikation. Den skall fungera som ett teknikneutralt, formellt regelverk som reglerar integrationskrav för parter (tjänstekonsumenter och tjänsteproducenter) som avser ansluta system för samverkan enligt dessa tjänstekontrakt. Tjänstekontraktsbeskrivningen är också ett viktigt underlag för skapande av de tekniska kontrakten (scheman och WSDL-filer). Detta dokument kompletterar reglerna i de tekniska kontrakten. Tjänsteproducenter och tjänstekonsumenter ska m.a.o. följa såväl de maskintolkbara reglerna i de tekniska kontrakten, så väl som de regler som uttrycks verbalt i detta dokument.

### Svenskt namn

Infrastruktur Katalogtjänster Medarbetare Medarbetare

