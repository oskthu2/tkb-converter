# inera.infrastructure-directory-employee#4.0.0: infrastructure: directory: employee

## Pages

* [Hem](index.md)
* [7 Tjänstekontrakt](7-tjanstekontrakt.md)
* [1 Inledning](1-inledning.md)
* [4 Tjänstedomänens krav och regler](4-tjanstedomanens-krav-och-regler.md)
* [6 Gemensamma informationskomponenter](6-gemensamma-informationskomponenter.md)
* [3 Tjänstedomänens arkitektur](3-tjanstedomanens-arkitektur.md)
* [Artifacts Summary](artifacts.md)
* [2 Versionsinformation](2-versionsinformation.md)
* [5 Tjänstedomänens meddelandemodeller](5-tjanstedomanens-meddelandemodeller.md)

## Resources

### Logicals

* [GetCommissionMembers — Request](StructureDefinition-getcommissionmembers-request.md)
* [GetCommissionMembers](StructureDefinition-getcommissionmembers.md)
* [GetCommissionMembersIncludingProtectedPerson — Request](StructureDefinition-getcommissionmembersincludingprotectedperson-request.md)
* [GetCommissionMembersIncludingProtectedPerson](StructureDefinition-getcommissionmembersincludingprotectedperson.md)
* [GetEmployee — Request](StructureDefinition-getemployee-request.md)
* [GetEmployee](StructureDefinition-getemployee.md)
* [GetEmployeeIncludingProtectedPerson — Request](StructureDefinition-getemployeeincludingprotectedperson-request.md)
* [GetEmployeeIncludingProtectedPerson](StructureDefinition-getemployeeincludingprotectedperson.md)

### ImplementationGuides

* [infrastructure: directory: employee](index.md)
