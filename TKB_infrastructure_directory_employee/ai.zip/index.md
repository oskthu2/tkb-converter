# Hem - infrastructure: directory: employee v4.0.0-snapshot

* [**Table of Contents**](toc.md)
* **Hem**

## Hem

| | |
| :--- | :--- |
| *Official URL*:https://fhir.inera.se/ig/infrastructure-directory-employee/ImplementationGuide/inera.infrastructure-directory-employee | *Version*:4.0.0-snapshot |
| Draft as of 2026-11-06 | *Computable Name*:infrastructuredirectoryemployee |
| **Copyright/Legal**: Copyright 2024 Inera AB. Licensieras under Creative Commons Attribution 4.0. | |

# infrastructure: directory: employee

**TKB-version:** 4.0 · **IG-version:** 4.0.0-snapshot · **Källa:** Bitbucket-commit `35b5c769b2bc` (ingen tagg) 

## Översikt

* Beskrivning: Svenskt kortnamn
  * Tjänstedomänens ändamål är att förse övriga tjänster med kvalitetssäkrade och aktuella personuppgifter om personer som är anställda inom eller arbetar på uppdrag av organisationer verksamma inom vård och omsorg. Användningsområden utgörs främst av vårdprofessionens sökningar efter kontaktinformation och andra egenskaper för personer verksamma inom vård och omsorg.: medarbetare
* Beskrivning: Svenskt namn
  * Tjänstedomänens ändamål är att förse övriga tjänster med kvalitetssäkrade och aktuella personuppgifter om personer som är anställda inom eller arbetar på uppdrag av organisationer verksamma inom vård och omsorg. Användningsområden utgörs främst av vårdprofessionens sökningar efter kontaktinformation och andra egenskaper för personer verksamma inom vård och omsorg.: infrastruktur:katalogtjänster:medarbetare
* Beskrivning: Typ
  * Tjänstedomänens ändamål är att förse övriga tjänster med kvalitetssäkrade och aktuella personuppgifter om personer som är anställda inom eller arbetar på uppdrag av organisationer verksamma inom vård och omsorg. Användningsområden utgörs främst av vårdprofessionens sökningar efter kontaktinformation och andra egenskaper för personer verksamma inom vård och omsorg.: Nationell tjänstedomän
* Beskrivning: Källkod
  * Tjänstedomänens ändamål är att förse övriga tjänster med kvalitetssäkrade och aktuella personuppgifter om personer som är anställda inom eller arbetar på uppdrag av organisationer verksamma inom vård och omsorg. Användningsområden utgörs främst av vårdprofessionens sökningar efter kontaktinformation och andra egenskaper för personer verksamma inom vård och omsorg.: [Bitbucket](https://bitbucket.org/rivta-domains/riv.infrastructure.directory.employee/src)
* Beskrivning: Ärenden
  * Tjänstedomänens ändamål är att förse övriga tjänster med kvalitetssäkrade och aktuella personuppgifter om personer som är anställda inom eller arbetar på uppdrag av organisationer verksamma inom vård och omsorg. Användningsområden utgörs främst av vårdprofessionens sökningar efter kontaktinformation och andra egenskaper för personer verksamma inom vård och omsorg.: [Bitbucket issues](https://bitbucket.org/rivta-domains/riv.infrastructure.directory.employee/issues)
* Beskrivning: Underlag för denna IG
  * Tjänstedomänens ändamål är att förse övriga tjänster med kvalitetssäkrade och aktuella personuppgifter om personer som är anställda inom eller arbetar på uppdrag av organisationer verksamma inom vård och omsorg. Användningsområden utgörs främst av vårdprofessionens sökningar efter kontaktinformation och andra egenskaper för personer verksamma inom vård och omsorg.: Version 4.0 ·[commit 35b5c769b2bc](https://bitbucket.org/rivta-domains/riv.infrastructure.directory.employee/src/35b5c769b2bcf8413d3006893a3f17736358298e)·[zip](https://bitbucket.org/rivta-domains/riv.infrastructure.directory.employee/downloads/)
* Beskrivning: RIV-TA-portalen
  * Tjänstedomänens ändamål är att förse övriga tjänster med kvalitetssäkrade och aktuella personuppgifter om personer som är anställda inom eller arbetar på uppdrag av organisationer verksamma inom vård och omsorg. Användningsområden utgörs främst av vårdprofessionens sökningar efter kontaktinformation och andra egenskaper för personer verksamma inom vård och omsorg.: [Alla tjänstedomäner](https://oskthu2.github.io/tkb-converter/rivta-portal/tjanstedomaner.html)·[Alla tjänstekontrakt](https://oskthu2.github.io/tkb-converter/rivta-portal/tjanstekontrakt.html)

FHIR Implementation Guide för tjänstedomänen **infrastructure: directory: employee** version 4.0. Genererad från Ineras Tjänstekontraktsbeskrivning (TKB).

Tjänstedomänen innehåller tjänstekontrakt för att hämta information om personer som är anställda inom eller arbetar på uppdrag av en organisation verksam inom svensk vård och omsorg (Katalogtjänst HSA).

Domänen innehåller följande tjänstekontrakt:

| | | |
| :--- | :--- | :--- |
| [GetEmployeeIncludingProtectedPerson](7-tjanstekontrakt.md#getemployeeincludingprotectedperson) | 4.0 | Hämtar information om en angiven person, inklusive skyddade personer |
| [GetEmployee](7-tjanstekontrakt.md#getemployee) | 4.0 | Hämtar information om en angiven person (exkluderar skyddade personer) |
| [GetCommissionMembersIncludingProtectedPerson](7-tjanstekontrakt.md#getcommissionmembersincludingprotectedperson) | 3.0 | Hämtar personal med vårdmedarbetaruppdrag inom en vårdenhet, inklusive skyddade personer |
| [GetCommissionMembers](7-tjanstekontrakt.md#getcommissionmembers) | 3.0 | Hämtar personal med vårdmedarbetaruppdrag inom en vårdenhet (exkluderar skyddade personer) |

### Versioner och granskningar

| | | | |
| :--- | :--- | :--- | :--- |
| 3.0 | TKB, AB | Arkitektur & Regelverk: Säkerhet: GodkändArkitektur & Regelverk: Teknik: GodkändArkitektur & Regelverk: Informatik: Godkänd | [zip](https://bitbucket.org/rivta-domains/riv.infrastructure.directory.employee/get/3.0.zip)·[källkod](https://bitbucket.org/rivta-domains/riv.infrastructure.directory.employee/src/3.0) |
| 2.2 | TKB, AB | Arkitektur & Regelverk: Teknik: Godkänd | [zip](https://bitbucket.org/rivta-domains/riv.infrastructure.directory.employee/get/2.2.zip)·[källkod](https://bitbucket.org/rivta-domains/riv.infrastructure.directory.employee/src/2.2) |
| 2.1 | AB, TKB | Arkitektur & Regelverk: Teknik: GodkändArkitektur & Regelverk: Säkerhet: GodkändArkitektur & Regelverk: Informatik: Godkänd | [zip](https://bitbucket.org/rivta-domains/riv.infrastructure.directory.employee/get/2.1.zip)·[källkod](https://bitbucket.org/rivta-domains/riv.infrastructure.directory.employee/src/2.1) |
| trunk | AB, TKB |  | [källkod](https://bitbucket.org/rivta-domains/riv.infrastructure.directory.employee/src/master) |

*Zip-arkiven hämtas från taggarna på Bitbucket. Granskningsprotokollen publicerades på rivta.se och länkas inte härifrån.*

*Källa: ögonblicksbild av DOMDB från 2021-08-24, via RIV-TA-portalen.*

## Innehåll

* [1 Inledning](1-inledning.md)
* [2 Versionsinformation](2-versionsinformation.md)
* [3 Tjänstedomänens arkitektur](3-tjanstedomanens-arkitektur.md)
* [4 Tjänstedomänens krav och regler](4-tjanstedomanens-krav-och-regler.md)
* [5 Tjänstedomänens meddelandemodeller](5-tjanstedomanens-meddelandemodeller.md)
* [6 Gemensamma informationskomponenter](6-gemensamma-informationskomponenter.md)
* [7 Tjänstekontrakt](7-tjanstekontrakt.md)
* [Artefakter](artifacts.md)

