# Hem - infrastructure: directory: employee v4.0.0

* [**Table of Contents**](toc.md)
* **Hem**

## Hem

| | |
| :--- | :--- |
| *Official URL*:https://fhir.inera.se/ig/infrastructure-directory-employee/ImplementationGuide/inera.infrastructure-directory-employee | *Version*:4.0.0 |
| Draft as of 2026-09-09 | *Computable Name*:infrastructuredirectoryemployee |
| **Copyright/Legal**: Copyright 2024 Inera AB. Licensieras under Creative Commons Attribution 4.0. | |

# infrastructure: directory: employee

## Översikt

FHIR Implementation Guide för tjänstedomänen **infrastructure: directory: employee** version 4.0. Genererad från Ineras Tjänstekontraktsbeskrivning (TKB).

Tjänstedomänen innehåller tjänstekontrakt för att hämta information om personer som är anställda inom eller arbetar på uppdrag av en organisation verksam inom svensk vård och omsorg (Katalogtjänst HSA).

Domänen innehåller följande tjänstekontrakt:

| | | |
| :--- | :--- | :--- |
| [GetEmployeeIncludingProtectedPerson](7-tjanstekontrakt.md#getemployeeincludingprotectedperson) | 4.0 | Hämtar information om en angiven person, inklusive skyddade personer |
| [GetEmployee](7-tjanstekontrakt.md#getemployee) | 4.0 | Hämtar information om en angiven person (exkluderar skyddade personer) |
| [GetCommissionMembersIncludingProtectedPerson](7-tjanstekontrakt.md#getcommissionmembersincludingprotectedperson) | 3.0 | Hämtar personal med vårdmedarbetaruppdrag inom en vårdenhet, inklusive skyddade personer |
| [GetCommissionMembers](7-tjanstekontrakt.md#getcommissionmembers) | 3.0 | Hämtar personal med vårdmedarbetaruppdrag inom en vårdenhet (exkluderar skyddade personer) |

## Innehåll

* [1 Inledning](1-inledning.md)
* [2 Versionsinformation](2-versionsinformation.md)
* [3 Tjänstedomänens arkitektur](3-tjanstedomanens-arkitektur.md)
* [4 Tjänstedomänens krav och regler](4-tjanstedomanens-krav-och-regler.md)
* [5 Tjänstedomänens meddelandemodeller](5-tjanstedomanens-meddelandemodeller.md)
* [6 Gemensamma informationskomponenter](6-gemensamma-informationskomponenter.md)
* [7 Tjänstekontrakt](7-tjanstekontrakt.md)
* [Artefakter](artifacts.md)

