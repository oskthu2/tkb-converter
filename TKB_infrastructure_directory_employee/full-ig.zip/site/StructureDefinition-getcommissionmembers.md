# GetCommissionMembers - infrastructure: directory: employee v4.0.0-snapshot

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **GetCommissionMembers**

## Logical Model: GetCommissionMembers 

| | |
| :--- | :--- |
| *Official URL*:https://fhir.inera.se/ig/infrastructure-directory-employee/StructureDefinition/getcommissionmembers | *Version*:3.0 |
| Draft as of 2026-11-09 | *Computable Name*:GetCommissionMembers |
| **Copyright/Legal**: Copyright 2024 Inera AB. Licensieras under Creative Commons Attribution 4.0. | |

 
Logisk modell för tjänstekontraktet GetCommissionMembers (RIV-TA urn:riv:infrastructure:directory:employee:GetCommissionMembers:3). Representerar responsens informationsstruktur. Är identisk med GetCommissionMembersIncludingProtectedPerson förutom att skyddade personer aldrig returneras — fältet protectedPerson returneras alltså aldrig. 

**Usages:**

* This Logical Model is not used by any profiles in this Specification

You can also check for [usages in the FHIR IG Statistics](https://packages2.fhir.org/xig/resource/inera.infrastructure-directory-employee|current/StructureDefinition/StructureDefinition-getcommissionmembers.json)

### Formal Views of Profile Content

 [Description of Profiles, Differentials, Snapshots and how the different presentations work](http://build.fhir.org/ig/FHIR/ig-guidance/readingIgs.html#structure-definitions). 

 

Other representations of profile: [CSV](StructureDefinition-getcommissionmembers.csv), [Excel](StructureDefinition-getcommissionmembers.xlsx) 



## Resource Content

```json
{
  "resourceType" : "StructureDefinition",
  "id" : "getcommissionmembers",
  "extension" : [{
    "url" : "http://hl7.org/fhir/StructureDefinition/structuredefinition-type-characteristics",
    "valueCode" : "can-be-target"
  }],
  "url" : "https://fhir.inera.se/ig/infrastructure-directory-employee/StructureDefinition/getcommissionmembers",
  "version" : "3.0",
  "name" : "GetCommissionMembers",
  "title" : "GetCommissionMembers",
  "status" : "draft",
  "date" : "2026-11-09T03:37:12+00:00",
  "contact" : [{
    "name" : "Inera Arkitektur",
    "telecom" : [{
      "system" : "url",
      "value" : "https://www.inera.se"
    }]
  }],
  "description" : "Logisk modell för tjänstekontraktet GetCommissionMembers\n(RIV-TA urn:riv:infrastructure:directory:employee:GetCommissionMembers:3).\nRepresenterar responsens informationsstruktur.\nÄr identisk med GetCommissionMembersIncludingProtectedPerson förutom att\nskyddade personer aldrig returneras — fältet protectedPerson returneras alltså aldrig.",
  "copyright" : "Copyright 2024 Inera AB. Licensieras under Creative Commons Attribution 4.0.",
  "fhirVersion" : "4.0.1",
  "kind" : "logical",
  "abstract" : false,
  "type" : "https://fhir.inera.se/ig/infrastructure-directory-employee/StructureDefinition/getcommissionmembers",
  "baseDefinition" : "http://hl7.org/fhir/StructureDefinition/Base",
  "derivation" : "specialization",
  "differential" : {
    "element" : [{
      "id" : "getcommissionmembers",
      "path" : "getcommissionmembers",
      "short" : "GetCommissionMembers",
      "definition" : "Logisk modell för tjänstekontraktet GetCommissionMembers\n(RIV-TA urn:riv:infrastructure:directory:employee:GetCommissionMembers:3).\nRepresenterar responsens informationsstruktur.\nÄr identisk med GetCommissionMembersIncludingProtectedPerson förutom att\nskyddade personer aldrig returneras — fältet protectedPerson returneras alltså aldrig."
    },
    {
      "id" : "getcommissionmembers.personInformation",
      "path" : "getcommissionmembers.personInformation",
      "short" : "PersonInformationType",
      "definition" : "personInformation",
      "min" : 0,
      "max" : "*",
      "type" : [{
        "code" : "Base"
      }]
    },
    {
      "id" : "getcommissionmembers.personInformation.personHsaId",
      "path" : "getcommissionmembers.personInformation.personHsaId",
      "short" : "personHsaId",
      "definition" : "personHsaId",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "getcommissionmembers.personInformation.givenName",
      "path" : "getcommissionmembers.personInformation.givenName",
      "short" : "givenName",
      "definition" : "givenName",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "getcommissionmembers.personInformation.middleAndSurName",
      "path" : "getcommissionmembers.personInformation.middleAndSurName",
      "short" : "middleAndSurName",
      "definition" : "middleAndSurName",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "getcommissionmembers.personInformation.nickName",
      "path" : "getcommissionmembers.personInformation.nickName",
      "short" : "nickName",
      "definition" : "nickName",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "getcommissionmembers.personInformation.mail",
      "path" : "getcommissionmembers.personInformation.mail",
      "short" : "mail",
      "definition" : "mail",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "getcommissionmembers.personInformation.telephoneNumber",
      "path" : "getcommissionmembers.personInformation.telephoneNumber",
      "short" : "telephoneNumber",
      "definition" : "telephoneNumber",
      "min" : 0,
      "max" : "*",
      "type" : [{
        "code" : "string",
        "profile" : ["https://fhir.inera.se/ig/infrastructure-directory-employee/StructureDefinition/TelephoneNumberType"]
      }]
    },
    {
      "id" : "getcommissionmembers.personInformation.switchboardNumber",
      "path" : "getcommissionmembers.personInformation.switchboardNumber",
      "short" : "switchboardNumber",
      "definition" : "switchboardNumber",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string",
        "profile" : ["https://fhir.inera.se/ig/infrastructure-directory-employee/StructureDefinition/TelephoneNumberType"]
      }]
    },
    {
      "id" : "getcommissionmembers.personInformation.nonPublicTelephoneNumber",
      "path" : "getcommissionmembers.personInformation.nonPublicTelephoneNumber",
      "short" : "nonPublicTelephoneNumber",
      "definition" : "nonPublicTelephoneNumber",
      "min" : 0,
      "max" : "*",
      "type" : [{
        "code" : "string",
        "profile" : ["https://fhir.inera.se/ig/infrastructure-directory-employee/StructureDefinition/TelephoneNumberType"]
      }]
    },
    {
      "id" : "getcommissionmembers.personInformation.mobileNumber",
      "path" : "getcommissionmembers.personInformation.mobileNumber",
      "short" : "mobileNumber",
      "definition" : "mobileNumber",
      "min" : 0,
      "max" : "*",
      "type" : [{
        "code" : "string",
        "profile" : ["https://fhir.inera.se/ig/infrastructure-directory-employee/StructureDefinition/TelephoneNumberType"]
      }]
    },
    {
      "id" : "getcommissionmembers.personInformation.facsimileTelephoneNumber",
      "path" : "getcommissionmembers.personInformation.facsimileTelephoneNumber",
      "short" : "facsimileTelephoneNumber",
      "definition" : "facsimileTelephoneNumber",
      "min" : 0,
      "max" : "*",
      "type" : [{
        "code" : "string",
        "profile" : ["https://fhir.inera.se/ig/infrastructure-directory-employee/StructureDefinition/TelephoneNumberType"]
      }]
    },
    {
      "id" : "getcommissionmembers.personInformation.telephoneHour",
      "path" : "getcommissionmembers.personInformation.telephoneHour",
      "short" : "TimeSpanType",
      "definition" : "telephoneHour",
      "min" : 0,
      "max" : "*",
      "type" : [{
        "code" : "Base"
      }]
    },
    {
      "id" : "getcommissionmembers.personInformation.telephoneHour.fromDay",
      "path" : "getcommissionmembers.personInformation.telephoneHour.fromDay",
      "short" : "fromDay",
      "definition" : "fromDay",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "getcommissionmembers.personInformation.telephoneHour.fromTime",
      "path" : "getcommissionmembers.personInformation.telephoneHour.fromTime",
      "short" : "fromTime",
      "definition" : "fromTime",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "time"
      }]
    },
    {
      "id" : "getcommissionmembers.personInformation.telephoneHour.toDay",
      "path" : "getcommissionmembers.personInformation.telephoneHour.toDay",
      "short" : "toDay",
      "definition" : "toDay",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "getcommissionmembers.personInformation.telephoneHour.toTime",
      "path" : "getcommissionmembers.personInformation.telephoneHour.toTime",
      "short" : "toTime",
      "definition" : "toTime",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "time"
      }]
    },
    {
      "id" : "getcommissionmembers.personInformation.telephoneHour.comment",
      "path" : "getcommissionmembers.personInformation.telephoneHour.comment",
      "short" : "comment",
      "definition" : "comment",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "getcommissionmembers.personInformation.telephoneHour.fromDate",
      "path" : "getcommissionmembers.personInformation.telephoneHour.fromDate",
      "short" : "fromDate",
      "definition" : "fromDate",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "getcommissionmembers.personInformation.telephoneHour.toDate",
      "path" : "getcommissionmembers.personInformation.telephoneHour.toDate",
      "short" : "toDate",
      "definition" : "toDate",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "getcommissionmembers.personInformation.postalAddress",
      "path" : "getcommissionmembers.personInformation.postalAddress",
      "short" : "AddressType",
      "definition" : "postalAddress",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "Base"
      }]
    },
    {
      "id" : "getcommissionmembers.personInformation.postalAddress.addressLine",
      "path" : "getcommissionmembers.personInformation.postalAddress.addressLine",
      "short" : "addressLine",
      "definition" : "addressLine",
      "min" : 1,
      "max" : "*",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "getcommissionmembers.personInformation.description",
      "path" : "getcommissionmembers.personInformation.description",
      "short" : "description",
      "definition" : "description",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "getcommissionmembers.personInformation.title",
      "path" : "getcommissionmembers.personInformation.title",
      "short" : "title",
      "definition" : "title",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "getcommissionmembers.personInformation.healthCareProfessionalLicence",
      "path" : "getcommissionmembers.personInformation.healthCareProfessionalLicence",
      "short" : "healthCareProfessionalLicence",
      "definition" : "healthCareProfessionalLicence",
      "min" : 0,
      "max" : "*",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "getcommissionmembers.personInformation.paTitle",
      "path" : "getcommissionmembers.personInformation.paTitle",
      "short" : "PaTitleType",
      "definition" : "paTitle",
      "min" : 0,
      "max" : "*",
      "type" : [{
        "code" : "Base"
      }]
    },
    {
      "id" : "getcommissionmembers.personInformation.paTitle.paTitleName",
      "path" : "getcommissionmembers.personInformation.paTitle.paTitleName",
      "short" : "paTitleName",
      "definition" : "paTitleName",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "getcommissionmembers.personInformation.paTitle.paTitleCode",
      "path" : "getcommissionmembers.personInformation.paTitle.paTitleCode",
      "short" : "paTitleCode",
      "definition" : "paTitleCode",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "getcommissionmembers.personInformation.specialityName",
      "path" : "getcommissionmembers.personInformation.specialityName",
      "short" : "specialityName",
      "definition" : "specialityName",
      "min" : 0,
      "max" : "*",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "getcommissionmembers.personInformation.specialityCode",
      "path" : "getcommissionmembers.personInformation.specialityCode",
      "short" : "specialityCode",
      "definition" : "specialityCode",
      "min" : 0,
      "max" : "*",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "getcommissionmembers.personInformation.dn",
      "path" : "getcommissionmembers.personInformation.dn",
      "short" : "dn",
      "definition" : "dn",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "string",
        "profile" : ["https://fhir.inera.se/ig/infrastructure-directory-employee/StructureDefinition/DNType"]
      }]
    },
    {
      "id" : "getcommissionmembers.personInformation.protectedPerson",
      "path" : "getcommissionmembers.personInformation.protectedPerson",
      "short" : "protectedPerson",
      "definition" : "protectedPerson",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "boolean"
      }]
    },
    {
      "id" : "getcommissionmembers.personInformation.personStartDate",
      "path" : "getcommissionmembers.personInformation.personStartDate",
      "short" : "personStartDate",
      "definition" : "personStartDate",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "dateTime"
      }]
    },
    {
      "id" : "getcommissionmembers.personInformation.personEndDate",
      "path" : "getcommissionmembers.personInformation.personEndDate",
      "short" : "personEndDate",
      "definition" : "personEndDate",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "dateTime"
      }]
    },
    {
      "id" : "getcommissionmembers.personInformation.feignedPerson",
      "path" : "getcommissionmembers.personInformation.feignedPerson",
      "short" : "feignedPerson",
      "definition" : "feignedPerson",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "boolean"
      }]
    },
    {
      "id" : "getcommissionmembers.personInformation.healthCareProfessionalLicenceSpeciality",
      "path" : "getcommissionmembers.personInformation.healthCareProfessionalLicenceSpeciality",
      "short" : "HealthCareProfessionalLicenceSpecialityType",
      "definition" : "healthCareProfessionalLicenceSpeciality",
      "min" : 0,
      "max" : "*",
      "type" : [{
        "code" : "Base"
      }]
    },
    {
      "id" : "getcommissionmembers.personInformation.healthCareProfessionalLicenceSpeciality.healthCareProfessionalLicence",
      "path" : "getcommissionmembers.personInformation.healthCareProfessionalLicenceSpeciality.healthCareProfessionalLicence",
      "short" : "healthCareProfessionalLicence",
      "definition" : "healthCareProfessionalLicence",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "getcommissionmembers.personInformation.healthCareProfessionalLicenceSpeciality.specialityCode",
      "path" : "getcommissionmembers.personInformation.healthCareProfessionalLicenceSpeciality.specialityCode",
      "short" : "specialityCode",
      "definition" : "specialityCode",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "getcommissionmembers.personInformation.healthCareProfessionalLicenceSpeciality.specialityName",
      "path" : "getcommissionmembers.personInformation.healthCareProfessionalLicenceSpeciality.specialityName",
      "short" : "specialityName",
      "definition" : "specialityName",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "getcommissionmembers.personInformation.age",
      "path" : "getcommissionmembers.personInformation.age",
      "short" : "age",
      "definition" : "age",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "getcommissionmembers.personInformation.gender",
      "path" : "getcommissionmembers.personInformation.gender",
      "short" : "gender",
      "definition" : "gender",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "getcommissionmembers.personInformation.structuredPostalAddress",
      "path" : "getcommissionmembers.personInformation.structuredPostalAddress",
      "short" : "StructuredPostalAddressType",
      "definition" : "structuredPostalAddress",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "Base"
      }]
    },
    {
      "id" : "getcommissionmembers.personInformation.structuredPostalAddress.addressee",
      "path" : "getcommissionmembers.personInformation.structuredPostalAddress.addressee",
      "short" : "addressee",
      "definition" : "addressee",
      "min" : 1,
      "max" : "*",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "getcommissionmembers.personInformation.structuredPostalAddress.street",
      "path" : "getcommissionmembers.personInformation.structuredPostalAddress.street",
      "short" : "street",
      "definition" : "street",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "getcommissionmembers.personInformation.structuredPostalAddress.premisesNumber",
      "path" : "getcommissionmembers.personInformation.structuredPostalAddress.premisesNumber",
      "short" : "premisesNumber",
      "definition" : "premisesNumber",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "getcommissionmembers.personInformation.structuredPostalAddress.premisesLetter",
      "path" : "getcommissionmembers.personInformation.structuredPostalAddress.premisesLetter",
      "short" : "premisesLetter",
      "definition" : "premisesLetter",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "getcommissionmembers.personInformation.structuredPostalAddress.postCode",
      "path" : "getcommissionmembers.personInformation.structuredPostalAddress.postCode",
      "short" : "postCode",
      "definition" : "postCode",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "getcommissionmembers.personInformation.structuredPostalAddress.town",
      "path" : "getcommissionmembers.personInformation.structuredPostalAddress.town",
      "short" : "town",
      "definition" : "town",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    }]
  }
}

```
