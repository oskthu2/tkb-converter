# inera.clinicalprocess-activityprescription-logistics#1.0.2: clinicalprocess: activityprescription: logistics — Ordinationslogistik

## Pages

* [Hem](index.md)
* [7 Tjänstekontrakt](7-tjanstekontrakt.md)
* [5 Tjänstedomänens krav och regler](5-tjanstedomanens-krav-och-regler.md)
* [6 Tjänstedomänens meddelandemodeller](6-tjanstedomanens-meddelandemodeller.md)
* [4 Tjänstedomänens arkitektur](4-tjanstedomanens-arkitektur.md)
* [Artifacts Summary](artifacts.md)
* [3 Referenser](3-referenser.md)
* [2 Versionsinformation](2-versionsinformation.md)
* [1 Inledning](1-inledning.md)

## Resources

### CodeSystems

* [atkomsttyp](CodeSystem-atkomsttyp-cs.md)
* [resultCodeEnum](CodeSystem-resultcode-cs.md)

### ValueSets

* [Atkomsttyp — ValueSet](ValueSet-atkomsttyp-vs.md)
* [ResultCode — ValueSet](ValueSet-resultcode-vs.md)

### Logicals

* [GetDispensedDrugs — Request](StructureDefinition-getdispenseddrugs-request.md)
* [GetDispensedDrugs](StructureDefinition-getdispenseddrugs.md)
* [PrintListOfDispensedDrugs — Request](StructureDefinition-printlistofdispenseddrugs-request.md)
* [PrintListOfDispensedDrugs](StructureDefinition-printlistofdispenseddrugs.md)

### ImplementationGuides

* [clinicalprocess: activityprescription: logistics — Ordinationslogistik](index.md)
