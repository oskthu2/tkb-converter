# Hem - clinicalprocess: activityprescription: logistics — Ordinationslogistik v1.0.2

* [**Table of Contents**](toc.md)
* **Hem**

## Hem

| | |
| :--- | :--- |
| *Official URL*:https://fhir.inera.se/ig/clinicalprocess-activityprescription-logistics/ImplementationGuide/inera.clinicalprocess-activityprescription-logistics | *Version*:1.0.2 |
| Draft as of 2026-09-26 | *Computable Name*:clinicalprocessactivityprescriptionlogistics |
| **Copyright/Legal**: Copyright 2024 Inera AB. Licensieras under Creative Commons Attribution 4.0. | |

# clinicalprocess: activityprescription: logistics — Ordinationslogistik

## Översikt

FHIR Implementation Guide för tjänstedomänen **clinicalprocess: activityprescription: logistics** ("Nationella Tjänstekontrakt för Hantera aktiviteter, ordinationslogistik") version 1.0.2. Genererad från Ineras Tjänstekontraktsbeskrivning (TKB).

Tjänstedomänen omfattar funktioner av logistisk art som stödjer ordinationsprocessen i vården, främst hämtning av uthämtade läkemedel ur eHälsomyndighetens Läkemedelsförteckning (LF).

RIV-TA namnrymd: `urn:riv:clinicalprocess:activityprescription:logistics`

Domänen innehåller följande tjänstekontrakt:

| | | |
| :--- | :--- | :--- |
| [GetDispensedDrugs](7-tjanstekontrakt.md#getdispenseddrugs) | 1.0 | Hämtar en patients Läkemedelsförteckning med ordinationsmappning |
| [PrintListOfDispensedDrugs](7-tjanstekontrakt.md#printlistofdispenseddrugs) | 1.0 | Hämtar en PDF-rapport med patientens Läkemedelsförteckning |

**Källa:** TKB-dokumentet (`Tjanstekontraktsbeskrivning - clinicalprocess_activityprescription_logistics.doc`, version 1.0.2, 2014-11-14) från Bitbucket `rivta-domains/riv.clinicalprocess.activityprescription.logistics`, commit `69b4fefff3e9` på `master` (repot har inga taggar).

## Innehåll

* [1 Inledning](1-inledning.md)
* [2 Versionsinformation](2-versionsinformation.md)
* [3 Referenser](3-referenser.md)
* [4 Tjänstedomänens arkitektur](4-tjanstedomanens-arkitektur.md)
* [5 Tjänstedomänens krav och regler](5-tjanstedomanens-krav-och-regler.md)
* [6 Tjänstedomänens meddelandemodeller](6-tjanstedomanens-meddelandemodeller.md)
* [7 Tjänstekontrakt](7-tjanstekontrakt.md)
* [Artefakter](artifacts.md)

