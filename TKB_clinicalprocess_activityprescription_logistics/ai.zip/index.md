# Hem - clinicalprocess: activityprescription: logistics — Ordinationslogistik v1.0.2-snapshot

* [**Table of Contents**](toc.md)
* **Hem**

## Hem

| | |
| :--- | :--- |
| *Official URL*:https://fhir.inera.se/ig/clinicalprocess-activityprescription-logistics/ImplementationGuide/inera.clinicalprocess-activityprescription-logistics | *Version*:1.0.2-snapshot |
| Draft as of 2026-10-26 | *Computable Name*:clinicalprocessactivityprescriptionlogistics |
| **Copyright/Legal**: Copyright 2024 Inera AB. Licensieras under Creative Commons Attribution 4.0. | |

# clinicalprocess: activityprescription: logistics — Ordinationslogistik

**TKB-version:** 1.0.2 · **IG-version:** 1.0.2-snapshot · **Källa:** Bitbucket-commit `69b4fefff3e9` (ingen tagg) 

## Översikt

* Beskrivning: Svenskt kortnamn
  * Denna domänen är inte aktuellt längre och det är rest från Nodprojektet: ordinationslogistik
* Beskrivning: Svenskt namn
  * Denna domänen är inte aktuellt längre och det är rest från Nodprojektet: vård- och omsorg kärnprocess:hantera aktiviteter:ordinationslogistik
* Beskrivning: Typ
  * Denna domänen är inte aktuellt längre och det är rest från Nodprojektet: Nationell tjänstedomän
* Beskrivning: Anmärkning
  * Denna domänen är inte aktuellt längre och det är rest från Nodprojektet: dold på rivta.se
* Beskrivning: Källkod
  * Denna domänen är inte aktuellt längre och det är rest från Nodprojektet: [Bitbucket](https://bitbucket.org/rivta-domains/riv.clinicalprocess.activityprescription.logistics/src)
* Beskrivning: Ärenden
  * Denna domänen är inte aktuellt längre och det är rest från Nodprojektet: [Bitbucket issues](https://bitbucket.org/rivta-domains/riv.clinicalprocess.activityprescription.logistics/issues)
* Beskrivning: Underlag för denna IG
  * Denna domänen är inte aktuellt längre och det är rest från Nodprojektet: Version 1.0.2 ·[commit 69b4fefff3e9](https://bitbucket.org/rivta-domains/riv.clinicalprocess.activityprescription.logistics/src/69b4fefff3e9a58dc886d0c62b1ce6f2631e829f)·[zip](https://bitbucket.org/rivta-domains/riv.clinicalprocess.activityprescription.logistics/get/69b4fefff3e9.zip)
* Beskrivning: RIV-TA-portalen
  * Denna domänen är inte aktuellt längre och det är rest från Nodprojektet: [Alla tjänstedomäner](https://oskthu2.github.io/tkb-converter/rivta-portal/tjanstedomaner.html)·[Alla tjänstekontrakt](https://oskthu2.github.io/tkb-converter/rivta-portal/tjanstekontrakt.html)

FHIR Implementation Guide för tjänstedomänen **clinicalprocess: activityprescription: logistics** ("Nationella Tjänstekontrakt för Hantera aktiviteter, ordinationslogistik") version 1.0.2. Genererad från Ineras Tjänstekontraktsbeskrivning (TKB).

Tjänstedomänen omfattar funktioner av logistisk art som stödjer ordinationsprocessen i vården, främst hämtning av uthämtade läkemedel ur eHälsomyndighetens Läkemedelsförteckning (LF).

RIV-TA namnrymd: `urn:riv:clinicalprocess:activityprescription:logistics`

Domänen innehåller följande tjänstekontrakt:

| | | |
| :--- | :--- | :--- |
| [GetDispensedDrugs](7-tjanstekontrakt.md#getdispenseddrugs) | 1.0 | Hämtar en patients Läkemedelsförteckning med ordinationsmappning |
| [PrintListOfDispensedDrugs](7-tjanstekontrakt.md#printlistofdispenseddrugs) | 1.0 | Hämtar en PDF-rapport med patientens Läkemedelsförteckning |

**Källa:** TKB-dokumentet (`Tjanstekontraktsbeskrivning - clinicalprocess_activityprescription_logistics.doc`, version 1.0.2, 2014-11-14) från Bitbucket `rivta-domains/riv.clinicalprocess.activityprescription.logistics`, commit `69b4fefff3e9` på `master` (repot har inga taggar).

### Versioner och granskningar

| | | | |
| :--- | :--- | :--- | :--- |
| 1.0.0_beta_r2037 |  | Äldre granskningsprocess: Informatik: GodkändÄldre granskningsprocess: Säkerhet: GodkändÄldre granskningsprocess: Teknik: Godkänd | [zip](http://rivta.se/downloads/clinicalprocess_activityprescription_logistics/1.0.0-beta_r2037/ServiceContracts_clinicalprocess_activityprescription_logistics_1.0.0-beta_r2037.zip)·[källkod](https://bitbucket.org/rivta-domains/riv.clinicalprocess.activityprescription.logistics/src/69b4fefff3e9a58dc886d0c62b1ce6f2631e829f) |
| trunk | TKB |  | [källkod](https://bitbucket.org/rivta-domains/riv.clinicalprocess.activityprescription.logistics/src/master) |

*Källa: ögonblicksbild av DOMDB från 2021-08-24, via RIV-TA-portalen.*

## Innehåll

* [1 Inledning](1-inledning.md)
* [2 Versionsinformation](2-versionsinformation.md)
* [3 Referenser](3-referenser.md)
* [4 Tjänstedomänens arkitektur](4-tjanstedomanens-arkitektur.md)
* [5 Tjänstedomänens krav och regler](5-tjanstedomanens-krav-och-regler.md)
* [6 Tjänstedomänens meddelandemodeller](6-tjanstedomanens-meddelandemodeller.md)
* [7 Tjänstekontrakt](7-tjanstekontrakt.md)
* [Artefakter](artifacts.md)

