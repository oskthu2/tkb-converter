# Hem - ehr: patientrelationship v1.0.1

* [**Table of Contents**](toc.md)
* **Hem**

## Hem

| | |
| :--- | :--- |
| *Official URL*:https://fhir.inera.se/ig/ehr-patientrelationship/ImplementationGuide/inera.ehr-patientrelationship | *Version*:1.0.1 |
| Draft as of 2026-09-09 | *Computable Name*:ehrpatientrelationship |
| **Copyright/Legal**: Copyright 2024 Inera AB. Licensieras under Creative Commons Attribution 4.0. | |

# ehr: patientrelationship

## Översikt

FHIR Implementation Guide för tjänstedomänen **ehr: patientrelationship** version 1.0.1. Genererad från Ineras Tjänstekontraktsbeskrivning (TKB).

Domänen hanterar patientrelationer mellan vårdpersonal och patient i enlighet med Patientdatalagen (PDL). Namespace: `urn:riv:ehr:patientrelationship`

Domänen innehåller följande tjänstekontrakt:

| | | | |
| :--- | :--- | :--- | :--- |
| [GetPatientRelationsForPatient](7-tjanstekontrakt.md#getpatientrelationsforpatient) | 1.0 | querying | Läs patientrelationer för patient inom vårdgivare |
| [GetPatientRelationsForCareProvider](7-tjanstekontrakt.md#getpatientrelationsforcareprovider) | 1.0 | querying | Läs patientrelationer inom vårdgivare |
| [GetExtendedPatientRelationsForPatient](7-tjanstekontrakt.md#getextendedpatientrelationsforpatient) | 1.0 | administration | Läs patientrelationer för patient med utökad information |
| [CheckPatientRelation](7-tjanstekontrakt.md#checkpatientrelation) | 1.0 | accesscontrol | Kontrollera om patientrelation finns |
| [RegisterExtendedPatientRelation](7-tjanstekontrakt.md#registerextendedpatientrelation) | 1.0 | administration | Registrera patientrelation med utökad information |
| [CancelExtendedPatientRelation](7-tjanstekontrakt.md#cancelextendedpatientrelation) | 1.0 | administration | Återkalla patientrelation med utökad information |
| [DeleteExtendedPatientRelation](7-tjanstekontrakt.md#deleteextendedpatientrelation) | 1.0 | administration | Makulera patientrelation med utökad information |

## Innehåll

* [1 Inledning](1-inledning.md)
* [2 Generella regler](2-generella-regler.md)
* [7 Tjänstekontrakt](7-tjanstekontrakt.md)
* [8 Datatyper](8-datatyper.md)
* [Artefakter](artifacts.md)

