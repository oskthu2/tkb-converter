# Hem - ehr: patientrelationship v1.0.1-snapshot

* [**Table of Contents**](toc.md)
* **Hem**

## Hem

| | |
| :--- | :--- |
| *Official URL*:https://fhir.inera.se/ig/ehr-patientrelationship/ImplementationGuide/inera.ehr-patientrelationship | *Version*:1.0.1-snapshot |
| Draft as of 2026-11-06 | *Computable Name*:ehrpatientrelationship |
| **Copyright/Legal**: Copyright 2024 Inera AB. Licensieras under Creative Commons Attribution 4.0. | |

# ehr: patientrelationship

**TKB-version:** 1.0.1 · **IG-version:** 1.0.1-snapshot · **Källa:** Bitbucket-commit `75d0292db437` (ingen tagg) 

## Översikt

* Beskrivning: Svenskt kortnamn
  * Patientrelationshantering registrerar och lagrar information om relationer mellan personal och patient. Tjänstekontrakten för Patientrelationshantering gör det möjligt för vårdpersonal att genom sina vårdsystem på ett flexibelt sätt hantera sina "egna" patientrelationer, samtidigt som samverkan möjliggörs med nationella e-tjänster som erbjuder direktåtkomst till patientuppgifter. Tjänstekontrakten specificerar bland annat hur patientrelationsunderlag ska hämtas ut för intern kontroll av patientrelation i vårdsystemet, hur anrop från ett vårdsystem ska göras för att kontrollera om patientrelation finns eller inte, och för att kunna ge patienten en sammanställd lista av dennes alla patientrelationer som finns registrerade hos vårdgivaren.: patientrelationshantering
* Beskrivning: Svenskt namn
  * Patientrelationshantering registrerar och lagrar information om relationer mellan personal och patient. Tjänstekontrakten för Patientrelationshantering gör det möjligt för vårdpersonal att genom sina vårdsystem på ett flexibelt sätt hantera sina "egna" patientrelationer, samtidigt som samverkan möjliggörs med nationella e-tjänster som erbjuder direktåtkomst till patientuppgifter. Tjänstekontrakten specificerar bland annat hur patientrelationsunderlag ska hämtas ut för intern kontroll av patientrelation i vårdsystemet, hur anrop från ett vårdsystem ska göras för att kontrollera om patientrelation finns eller inte, och för att kunna ge patienten en sammanställd lista av dennes alla patientrelationer som finns registrerade hos vårdgivaren.: infrastruktur:säkerhetstjänster:patientrelationshantering
* Beskrivning: Typ
  * Patientrelationshantering registrerar och lagrar information om relationer mellan personal och patient. Tjänstekontrakten för Patientrelationshantering gör det möjligt för vårdpersonal att genom sina vårdsystem på ett flexibelt sätt hantera sina "egna" patientrelationer, samtidigt som samverkan möjliggörs med nationella e-tjänster som erbjuder direktåtkomst till patientuppgifter. Tjänstekontrakten specificerar bland annat hur patientrelationsunderlag ska hämtas ut för intern kontroll av patientrelation i vårdsystemet, hur anrop från ett vårdsystem ska göras för att kontrollera om patientrelation finns eller inte, och för att kunna ge patienten en sammanställd lista av dennes alla patientrelationer som finns registrerade hos vårdgivaren.: Nationell tjänstedomän
* Beskrivning: Källkod
  * Patientrelationshantering registrerar och lagrar information om relationer mellan personal och patient. Tjänstekontrakten för Patientrelationshantering gör det möjligt för vårdpersonal att genom sina vårdsystem på ett flexibelt sätt hantera sina "egna" patientrelationer, samtidigt som samverkan möjliggörs med nationella e-tjänster som erbjuder direktåtkomst till patientuppgifter. Tjänstekontrakten specificerar bland annat hur patientrelationsunderlag ska hämtas ut för intern kontroll av patientrelation i vårdsystemet, hur anrop från ett vårdsystem ska göras för att kontrollera om patientrelation finns eller inte, och för att kunna ge patienten en sammanställd lista av dennes alla patientrelationer som finns registrerade hos vårdgivaren.: [Bitbucket](https://bitbucket.org/rivta-domains/riv.ehr.patientrelationship/src)
* Beskrivning: Ärenden
  * Patientrelationshantering registrerar och lagrar information om relationer mellan personal och patient. Tjänstekontrakten för Patientrelationshantering gör det möjligt för vårdpersonal att genom sina vårdsystem på ett flexibelt sätt hantera sina "egna" patientrelationer, samtidigt som samverkan möjliggörs med nationella e-tjänster som erbjuder direktåtkomst till patientuppgifter. Tjänstekontrakten specificerar bland annat hur patientrelationsunderlag ska hämtas ut för intern kontroll av patientrelation i vårdsystemet, hur anrop från ett vårdsystem ska göras för att kontrollera om patientrelation finns eller inte, och för att kunna ge patienten en sammanställd lista av dennes alla patientrelationer som finns registrerade hos vårdgivaren.: [Bitbucket issues](https://bitbucket.org/rivta-domains/riv.ehr.patientrelationship/issues)
* Beskrivning: Underlag för denna IG
  * Patientrelationshantering registrerar och lagrar information om relationer mellan personal och patient. Tjänstekontrakten för Patientrelationshantering gör det möjligt för vårdpersonal att genom sina vårdsystem på ett flexibelt sätt hantera sina "egna" patientrelationer, samtidigt som samverkan möjliggörs med nationella e-tjänster som erbjuder direktåtkomst till patientuppgifter. Tjänstekontrakten specificerar bland annat hur patientrelationsunderlag ska hämtas ut för intern kontroll av patientrelation i vårdsystemet, hur anrop från ett vårdsystem ska göras för att kontrollera om patientrelation finns eller inte, och för att kunna ge patienten en sammanställd lista av dennes alla patientrelationer som finns registrerade hos vårdgivaren.: Version 1.0.1 ·[commit 75d0292db437](https://bitbucket.org/rivta-domains/riv.ehr.patientrelationship/src/75d0292db437ae9f42b77382fb53b840982a744b)
* Beskrivning: RIV-TA-portalen
  * Patientrelationshantering registrerar och lagrar information om relationer mellan personal och patient. Tjänstekontrakten för Patientrelationshantering gör det möjligt för vårdpersonal att genom sina vårdsystem på ett flexibelt sätt hantera sina "egna" patientrelationer, samtidigt som samverkan möjliggörs med nationella e-tjänster som erbjuder direktåtkomst till patientuppgifter. Tjänstekontrakten specificerar bland annat hur patientrelationsunderlag ska hämtas ut för intern kontroll av patientrelation i vårdsystemet, hur anrop från ett vårdsystem ska göras för att kontrollera om patientrelation finns eller inte, och för att kunna ge patienten en sammanställd lista av dennes alla patientrelationer som finns registrerade hos vårdgivaren.: [Alla tjänstedomäner](https://oskthu2.github.io/tkb-converter/rivta-portal/tjanstedomaner.html)·[Alla tjänstekontrakt](https://oskthu2.github.io/tkb-converter/rivta-portal/tjanstekontrakt.html)

FHIR Implementation Guide för tjänstedomänen **ehr: patientrelationship** version 1.0.1. Genererad från Ineras Tjänstekontraktsbeskrivning (TKB).

Domänen hanterar patientrelationer mellan vårdpersonal och patient i enlighet med Patientdatalagen (PDL). Namespace: `urn:riv:ehr:patientrelationship`

Domänen innehåller följande tjänstekontrakt:

| | | | |
| :--- | :--- | :--- | :--- |
| [GetPatientRelationsForPatient](7-tjanstekontrakt.md#getpatientrelationsforpatient) | 1.0 | querying | Läs patientrelationer för patient inom vårdgivare |
| [GetPatientRelationsForCareProvider](7-tjanstekontrakt.md#getpatientrelationsforcareprovider) | 1.0 | querying | Läs patientrelationer inom vårdgivare |
| [GetExtendedPatientRelationsForPatient](7-tjanstekontrakt.md#getextendedpatientrelationsforpatient) | 1.0 | administration | Läs patientrelationer för patient med utökad information |
| [CheckPatientRelation](7-tjanstekontrakt.md#checkpatientrelation) | 1.0 | accesscontrol | Kontrollera om patientrelation finns |
| [RegisterExtendedPatientRelation](7-tjanstekontrakt.md#registerextendedpatientrelation) | 1.0 | administration | Registrera patientrelation med utökad information |
| [CancelExtendedPatientRelation](7-tjanstekontrakt.md#cancelextendedpatientrelation) | 1.0 | administration | Återkalla patientrelation med utökad information |
| [DeleteExtendedPatientRelation](7-tjanstekontrakt.md#deleteextendedpatientrelation) | 1.0 | administration | Makulera patientrelation med utökad information |

### Versioner och granskningar

| | | | |
| :--- | :--- | :--- | :--- |
| 1.0.1 | AB, TKB | Äldre granskningsprocess: Teknik: Godkänd | [zip](https://bitbucket.org/rivta-domains/riv.ehr.patientrelationship/get/ehr_patientrelationship_1.0.1_RC1.zip)·[källkod](https://bitbucket.org/rivta-domains/riv.ehr.patientrelationship/src/ehr_patientrelationship_1.0.1_RC1) |
| trunk | TKB, AB |  | [källkod](https://bitbucket.org/rivta-domains/riv.ehr.patientrelationship/src/master) |

*Zip-arkiven hämtas från taggarna på Bitbucket. Granskningsprotokollen publicerades på rivta.se och länkas inte härifrån.*

*Källa: ögonblicksbild av DOMDB från 2021-08-24, via RIV-TA-portalen.*

## Innehåll

* [1 Inledning](1-inledning.md)
* [2 Generella regler](2-generella-regler.md)
* [7 Tjänstekontrakt](7-tjanstekontrakt.md)
* [8 Datatyper](8-datatyper.md)
* [Artefakter](artifacts.md)

