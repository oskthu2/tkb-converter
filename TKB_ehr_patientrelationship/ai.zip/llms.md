# inera.ehr-patientrelationship#1.0.1: ehr: patientrelationship

## Pages

* [Hem](index.md)
* [7 Tjänstekontrakt](7-tjanstekontrakt.md)
* [1 Inledning](1-inledning.md)
* [2 Generella regler](2-generella-regler.md)
* [8 Datatyper](8-datatyper.md)
* [Artifacts Summary](artifacts.md)

## Resources

### CodeSystems

* [ResultCode](CodeSystem-resultcode-cs.md)

### ValueSets

* [ResultCode — ValueSet](ValueSet-resultcode-vs.md)

### Logicals

* [CancelExtendedPatientRelation — Request](StructureDefinition-cancelextendedpatientrelation-request.md)
* [CancelExtendedPatientRelation](StructureDefinition-cancelextendedpatientrelation.md)
* [CheckPatientRelation — Request](StructureDefinition-checkpatientrelation-request.md)
* [CheckPatientRelation](StructureDefinition-checkpatientrelation.md)
* [DeleteExtendedPatientRelation — Request](StructureDefinition-deleteextendedpatientrelation-request.md)
* [DeleteExtendedPatientRelation](StructureDefinition-deleteextendedpatientrelation.md)
* [GetExtendedPatientRelationsForPatient — Request](StructureDefinition-getextendedpatientrelationsforpatient-request.md)
* [GetExtendedPatientRelationsForPatient](StructureDefinition-getextendedpatientrelationsforpatient.md)
* [GetPatientRelationsForCareProvider — Request](StructureDefinition-getpatientrelationsforcareprovider-request.md)
* [GetPatientRelationsForCareProvider](StructureDefinition-getpatientrelationsforcareprovider.md)
* [GetPatientRelationsForPatient — Request](StructureDefinition-getpatientrelationsforpatient-request.md)
* [GetPatientRelationsForPatient](StructureDefinition-getpatientrelationsforpatient.md)
* [RegisterExtendedPatientRelation — Request](StructureDefinition-registerextendedpatientrelation-request.md)
* [RegisterExtendedPatientRelation](StructureDefinition-registerextendedpatientrelation.md)

### ImplementationGuides

* [ehr: patientrelationship](index.md)
