# Hem - ehr:accesscontrol v1.0.6

* [**Table of Contents**](toc.md)
* **Hem**

## Hem

| | |
| :--- | :--- |
| *Official URL*:https://fhir.inera.se/ig/ehr-accesscontrol/ImplementationGuide/inera.ehr-accesscontrol | *Version*:1.0.6 |
| Active as of 2026-10-08 | *Computable Name*:ehrAccessControl |
| **Copyright/Legal**: Copyright 2024 Inera AB. Licensieras under Creative Commons Attribution 4.0. | |

# ehr:accesscontrol

**TKB-version:** 1.0.6 · **IG-version:** 1.0.6 · **Källa:** Bitbucket-commit `ce5a101eb0df`, efter taggen `1.0.6` 

## Översikt

FHIR Implementation Guide för tjänstedomänen **ehr:accesscontrol** version 1.0.6. Genererad från Ineras Tjänstekontraktsbeskrivning (TKB).

Domänen innehåller följande tjänstekontrakt:

| | | |
| :--- | :--- | :--- |
| [AssertCareEngagement](7-tjanstekontrakt.md#assertcareengagement) | 1.0 | Ger svar på om en medarbetare med uppdrag på angiven vårdenhet ska ges möjlighet att begära åtkomst till sammanhållen journalföring (TGP — Tillgänglig Patient). |

## Innehåll

* [1 Inledning](1-inledning.md)
* [2 Versionsinformation](2-versionsinformation.md)
* [3 Tjänstedomänens arkitektur](3-tjanstedomanens-arkitektur.md)
* [4 Tjänstedomänens krav och regler](4-tjanstedomanens-krav-och-regler.md)
* [5 Tjänstedomänens meddelandemodeller](5-tjanstedomanens-meddelandemodeller.md)
* [6 Gemensamma informationskomponenter](6-gemensamma-informationskomponenter.md)
* [7 Tjänstekontrakt](7-tjanstekontrakt.md)
* [Artefakter](artifacts.md)

