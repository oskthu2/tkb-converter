# Hem - ehr:accesscontrol v1.0.6

* [**Table of Contents**](toc.md)
* **Hem**

## Hem

| | |
| :--- | :--- |
| *Official URL*:https://fhir.inera.se/ig/ehr-accesscontrol/ImplementationGuide/inera.ehr-accesscontrol | *Version*:1.0.6 |
| Active as of 2026-11-09 | *Computable Name*:ehrAccessControl |
| **Copyright/Legal**: Copyright 2024 Inera AB. Licensieras under Creative Commons Attribution 4.0. | |

# ehr:accesscontrol

**TKB-version:** 1.0.6 · **IG-version:** 1.0.6 · **Källa:** Bitbucket-commit `ce5a101eb0df`, efter taggen `1.0.6` 

## Översikt

* Beskrivning: Svenskt kortnamn
  * Tjänstekontraktet för Tillgänglig patient (TGP) används av fristående e-tjänster som erbjuder professionen direktåtkomst till sammanhållen journalföring. Tjänsteproducenter för tjänstekontraktet ger svar på om aktuell användare av en sådan e-tjänst (t.ex. NPÖ-tjänsten) genom sitt medarbetaruppdrag har dokumenterad relation till patienten som styrker att tjänstekonsumenten (e-tjänsten) ska erbjuda användaren åtkomst till sammanhållen journalföring. Vanligen är PAS- eller journalsystemen tjänsteproducenter för kontraktet. Det är alltså den egna verksamhetens IT-system som agerar tjänsteproducent när en medarbetare begär åtkomst till sammanhållen journalföring via en fristående etjänst. *OBSERVERA: I releasepaketet nedan finns testsviter, dessa testsviter kan med fördel användas vid testning. Skicka i nuläget däremot inte in testresultat i den mall för självdeklaration som också finns där, då Ineras testmodell ännu inte är införd för den här tjänsten.”: tillgänglig patient (TGP)
* Beskrivning: Svenskt namn
  * Tjänstekontraktet för Tillgänglig patient (TGP) används av fristående e-tjänster som erbjuder professionen direktåtkomst till sammanhållen journalföring. Tjänsteproducenter för tjänstekontraktet ger svar på om aktuell användare av en sådan e-tjänst (t.ex. NPÖ-tjänsten) genom sitt medarbetaruppdrag har dokumenterad relation till patienten som styrker att tjänstekonsumenten (e-tjänsten) ska erbjuda användaren åtkomst till sammanhållen journalföring. Vanligen är PAS- eller journalsystemen tjänsteproducenter för kontraktet. Det är alltså den egna verksamhetens IT-system som agerar tjänsteproducent när en medarbetare begär åtkomst till sammanhållen journalföring via en fristående etjänst. *OBSERVERA: I releasepaketet nedan finns testsviter, dessa testsviter kan med fördel användas vid testning. Skicka i nuläget däremot inte in testresultat i den mall för självdeklaration som också finns där, då Ineras testmodell ännu inte är införd för den här tjänsten.”: infrastruktur:säkerhetstjänster:patientrelation
* Beskrivning: Typ
  * Tjänstekontraktet för Tillgänglig patient (TGP) används av fristående e-tjänster som erbjuder professionen direktåtkomst till sammanhållen journalföring. Tjänsteproducenter för tjänstekontraktet ger svar på om aktuell användare av en sådan e-tjänst (t.ex. NPÖ-tjänsten) genom sitt medarbetaruppdrag har dokumenterad relation till patienten som styrker att tjänstekonsumenten (e-tjänsten) ska erbjuda användaren åtkomst till sammanhållen journalföring. Vanligen är PAS- eller journalsystemen tjänsteproducenter för kontraktet. Det är alltså den egna verksamhetens IT-system som agerar tjänsteproducent när en medarbetare begär åtkomst till sammanhållen journalföring via en fristående etjänst. *OBSERVERA: I releasepaketet nedan finns testsviter, dessa testsviter kan med fördel användas vid testning. Skicka i nuläget däremot inte in testresultat i den mall för självdeklaration som också finns där, då Ineras testmodell ännu inte är införd för den här tjänsten.”: Nationell tjänstedomän
* Beskrivning: Källkod
  * Tjänstekontraktet för Tillgänglig patient (TGP) används av fristående e-tjänster som erbjuder professionen direktåtkomst till sammanhållen journalföring. Tjänsteproducenter för tjänstekontraktet ger svar på om aktuell användare av en sådan e-tjänst (t.ex. NPÖ-tjänsten) genom sitt medarbetaruppdrag har dokumenterad relation till patienten som styrker att tjänstekonsumenten (e-tjänsten) ska erbjuda användaren åtkomst till sammanhållen journalföring. Vanligen är PAS- eller journalsystemen tjänsteproducenter för kontraktet. Det är alltså den egna verksamhetens IT-system som agerar tjänsteproducent när en medarbetare begär åtkomst till sammanhållen journalföring via en fristående etjänst. *OBSERVERA: I releasepaketet nedan finns testsviter, dessa testsviter kan med fördel användas vid testning. Skicka i nuläget däremot inte in testresultat i den mall för självdeklaration som också finns där, då Ineras testmodell ännu inte är införd för den här tjänsten.”: [Bitbucket](https://bitbucket.org/rivta-domains/riv.ehr.accesscontrol/src)
* Beskrivning: Ärenden
  * Tjänstekontraktet för Tillgänglig patient (TGP) används av fristående e-tjänster som erbjuder professionen direktåtkomst till sammanhållen journalföring. Tjänsteproducenter för tjänstekontraktet ger svar på om aktuell användare av en sådan e-tjänst (t.ex. NPÖ-tjänsten) genom sitt medarbetaruppdrag har dokumenterad relation till patienten som styrker att tjänstekonsumenten (e-tjänsten) ska erbjuda användaren åtkomst till sammanhållen journalföring. Vanligen är PAS- eller journalsystemen tjänsteproducenter för kontraktet. Det är alltså den egna verksamhetens IT-system som agerar tjänsteproducent när en medarbetare begär åtkomst till sammanhållen journalföring via en fristående etjänst. *OBSERVERA: I releasepaketet nedan finns testsviter, dessa testsviter kan med fördel användas vid testning. Skicka i nuläget däremot inte in testresultat i den mall för självdeklaration som också finns där, då Ineras testmodell ännu inte är införd för den här tjänsten.”: [Bitbucket issues](https://bitbucket.org/rivta-domains/riv.ehr.accesscontrol/issues)
* Beskrivning: Underlag för denna IG
  * Tjänstekontraktet för Tillgänglig patient (TGP) används av fristående e-tjänster som erbjuder professionen direktåtkomst till sammanhållen journalföring. Tjänsteproducenter för tjänstekontraktet ger svar på om aktuell användare av en sådan e-tjänst (t.ex. NPÖ-tjänsten) genom sitt medarbetaruppdrag har dokumenterad relation till patienten som styrker att tjänstekonsumenten (e-tjänsten) ska erbjuda användaren åtkomst till sammanhållen journalföring. Vanligen är PAS- eller journalsystemen tjänsteproducenter för kontraktet. Det är alltså den egna verksamhetens IT-system som agerar tjänsteproducent när en medarbetare begär åtkomst till sammanhållen journalföring via en fristående etjänst. *OBSERVERA: I releasepaketet nedan finns testsviter, dessa testsviter kan med fördel användas vid testning. Skicka i nuläget däremot inte in testresultat i den mall för självdeklaration som också finns där, då Ineras testmodell ännu inte är införd för den här tjänsten.”: Version 1.0.6 ·[tagg 1.0.6](https://bitbucket.org/rivta-domains/riv.ehr.accesscontrol/src/1.0.6)·[zip](https://bitbucket.org/rivta-domains/riv.ehr.accesscontrol/src/master/)
* Beskrivning: RIV-TA-portalen
  * Tjänstekontraktet för Tillgänglig patient (TGP) används av fristående e-tjänster som erbjuder professionen direktåtkomst till sammanhållen journalföring. Tjänsteproducenter för tjänstekontraktet ger svar på om aktuell användare av en sådan e-tjänst (t.ex. NPÖ-tjänsten) genom sitt medarbetaruppdrag har dokumenterad relation till patienten som styrker att tjänstekonsumenten (e-tjänsten) ska erbjuda användaren åtkomst till sammanhållen journalföring. Vanligen är PAS- eller journalsystemen tjänsteproducenter för kontraktet. Det är alltså den egna verksamhetens IT-system som agerar tjänsteproducent när en medarbetare begär åtkomst till sammanhållen journalföring via en fristående etjänst. *OBSERVERA: I releasepaketet nedan finns testsviter, dessa testsviter kan med fördel användas vid testning. Skicka i nuläget däremot inte in testresultat i den mall för självdeklaration som också finns där, då Ineras testmodell ännu inte är införd för den här tjänsten.”: [Alla tjänstedomäner](https://oskthu2.github.io/tkb-converter/rivta-portal/tjanstedomaner.html)·[Alla tjänstekontrakt](https://oskthu2.github.io/tkb-converter/rivta-portal/tjanstekontrakt.html)

FHIR Implementation Guide för tjänstedomänen **ehr:accesscontrol** version 1.0.6. Genererad från Ineras Tjänstekontraktsbeskrivning (TKB).

Domänen innehåller följande tjänstekontrakt:

| | | |
| :--- | :--- | :--- |
| [AssertCareEngagement](7-tjanstekontrakt.md#assertcareengagement) | 1.0 | Ger svar på om en medarbetare med uppdrag på angiven vårdenhet ska ges möjlighet att begära åtkomst till sammanhållen journalföring (TGP — Tillgänglig Patient). |

### Versioner och granskningar

| | | | |
| :--- | :--- | :--- | :--- |
| 1.0.5 | AB, TKB | Arkitektur & Regelverk: Teknik: GodkändArkitektur & Regelverk: Informatik: GodkändArkitektur & Regelverk: Säkerhet: Godkänd | [zip](https://bitbucket.org/rivta-domains/riv.ehr.accesscontrol/get/1.0.5.zip)·[källkod](https://bitbucket.org/rivta-domains/riv.ehr.accesscontrol/src/1.0.5) |
| 1.0.4 | AB, TKB | Arkitektur & Regelverk: Informatik: GodkändArkitektur & Regelverk: Säkerhet: GodkändArkitektur & Regelverk: Teknik: Godkänd | [zip](https://bitbucket.org/rivta-domains/riv.ehr.accesscontrol/get/ehr_accesscontrol_1.0.4.zip)·[källkod](https://bitbucket.org/rivta-domains/riv.ehr.accesscontrol/src/ehr_accesscontrol_1.0.4) |
| trunk | AB, TKB |  | [källkod](https://bitbucket.org/rivta-domains/riv.ehr.accesscontrol/src/master) |

*Zip-arkiven hämtas från taggarna på Bitbucket. Granskningsprotokollen publicerades på rivta.se och länkas inte härifrån.*

*Källa: ögonblicksbild av DOMDB från 2021-08-24, via RIV-TA-portalen.*

## Innehåll

* [1 Inledning](1-inledning.md)
* [2 Versionsinformation](2-versionsinformation.md)
* [3 Tjänstedomänens arkitektur](3-tjanstedomanens-arkitektur.md)
* [4 Tjänstedomänens krav och regler](4-tjanstedomanens-krav-och-regler.md)
* [5 Tjänstedomänens meddelandemodeller](5-tjanstedomanens-meddelandemodeller.md)
* [6 Gemensamma informationskomponenter](6-gemensamma-informationskomponenter.md)
* [7 Tjänstekontrakt](7-tjanstekontrakt.md)
* [Artefakter](artifacts.md)

