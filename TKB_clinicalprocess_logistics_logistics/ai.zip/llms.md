# inera.clinicalprocess-logistics-logistics#3.0.13: clinicalprocess: logistics: logistics

## Pages

* [Hem](index.md)
* [7 Tjänstekontrakt](7-tjanstekontrakt.md)
* [1 Inledning](1-inledning.md)
* [4 Tjänstedomänens krav och regler](4-tjanstedomanens-krav-och-regler.md)
* [6 Gemensamma informationskomponenter](6-gemensamma-informationskomponenter.md)
* [3 Tjänstedomänens arkitektur](3-tjanstedomanens-arkitektur.md)
* [Artifacts Summary](artifacts.md)
* [2 Versionsinformation](2-versionsinformation.md)
* [5 Tjänstedomänens meddelandemodeller](5-tjanstedomanens-meddelandemodeller.md)

## Resources

### CodeSystems

* [TypeOfCarePlan](CodeSystem-typeofcareplan-cs.md)

### ValueSets

* [TypeOfCarePlan — ValueSet](ValueSet-typeofcareplan-vs.md)

### Logicals

* [GetCarePlans — Request](StructureDefinition-getcareaplans-request.md)
* [GetCarePlans](StructureDefinition-getcareaplans.md)
* [GetCareContacts — Request](StructureDefinition-getcarecontacts-request.md)
* [GetCareContacts](StructureDefinition-getcarecontacts.md)

### ImplementationGuides

* [clinicalprocess: logistics: logistics](index.md)
