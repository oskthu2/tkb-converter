# Hem - clinicalprocess: logistics: logistics v3.0.13

* [**Table of Contents**](toc.md)
* **Hem**

## Hem

| | |
| :--- | :--- |
| *Official URL*:https://fhir.inera.se/ig/clinicalprocess-logistics-logistics/ImplementationGuide/inera.clinicalprocess-logistics-logistics | *Version*:3.0.13 |
| Draft as of 2026-09-26 | *Computable Name*:clinicalprocesslogisticslogistics |
| **Copyright/Legal**: Copyright 2024 Inera AB. Licensieras under Creative Commons Attribution 4.0. | |

# clinicalprocess: logistics: logistics

## Översikt

Detta är en FHIR Implementation Guide genererad från TKB-dokumentation för tjänstedomänen **clinicalprocess: logistics: logistics** version 3.0.13.

Tjänstedomänen syftar till att tillmötesgå behovet av både patientens och hälso- och sjukvårdspersonalens direktåtkomst till patientens vårdinformation. Tjänsterna i denna domän erbjuder sökning efter logistikrelaterad information från hälso- och sjukvårdens journal- och patientadministrativa system.

Tjänstekontrakten är baserade på RIV-TA 2.1 och reglerade genom arkitekturella beslut.

## Tjänstekontrakt

| | | |
| :--- | :--- | :--- |
| GetCareContacts | 3.0 | Returnerar vårdkontakter som finns dokumenterade för en patient |
| GetCarePlans | 2.0 | Returnerar vård- och omsorgsplaner som finns dokumenterade för en patient |

## Innehåll

* [1 Inledning](1-inledning.md)
* [2 Versionsinformation](2-versionsinformation.md)
* [3 Tjänstedomänens arkitektur](3-tjanstedomanens-arkitektur.md)
* [4 Tjänstedomänens krav och regler](4-tjanstedomanens-krav-och-regler.md)
* [5 Tjänstedomänens meddelandemodeller](5-tjanstedomanens-meddelandemodeller.md)
* [6 Gemensamma informationskomponenter](6-gemensamma-informationskomponenter.md)
* [7 Tjänstekontrakt](7-tjanstekontrakt.md)

