# Hem - clinicalprocess: logistics: logistics v3.0.13

* [**Table of Contents**](toc.md)
* **Hem**

## Hem

| | |
| :--- | :--- |
| *Official URL*:https://fhir.inera.se/ig/clinicalprocess-logistics-logistics/ImplementationGuide/inera.clinicalprocess-logistics-logistics | *Version*:3.0.13 |
| Active as of 2026-10-12 | *Computable Name*:clinicalprocesslogisticslogistics |
| **Copyright/Legal**: Copyright 2024 Inera AB. Licensieras under Creative Commons Attribution 4.0. | |

# clinicalprocess: logistics: logistics

**TKB-version:** 3.0.13 · **IG-version:** 3.0.13 · **Källa:** Bitbucket-tagg `3.0.13` · **Andra huvudversioner:** [2.0.7](https://oskthu2.github.io/tkb-converter/TKB_clinicalprocess_logistics_logistics/2.0.7/index.html) 

## Översikt

* Beskrivning: Svenskt kortnamn
  * Denna domän hanterar information om historiska och framtida vårdkontakter samt vårdplaner.: resurssamordning
* Beskrivning: Svenskt namn
  * Denna domän hanterar information om historiska och framtida vårdkontakter samt vårdplaner.: operativt processtöd:samordna resurser över verksamhetsstrukturer: logistik
* Beskrivning: Typ
  * Denna domän hanterar information om historiska och framtida vårdkontakter samt vårdplaner.: Nationell tjänstedomän
* Beskrivning: Förvaltare
  * Denna domän hanterar information om historiska och framtida vårdkontakter samt vårdplaner.: Tjänstekontraktsförvaltningen, TK-forvaltningen@inera.se
* Beskrivning: Källkod
  * Denna domän hanterar information om historiska och framtida vårdkontakter samt vårdplaner.: [Bitbucket](https://bitbucket.org/rivta-domains/riv.clinicalprocess.logistics.logistics/src)
* Beskrivning: Ärenden
  * Denna domän hanterar information om historiska och framtida vårdkontakter samt vårdplaner.: [Bitbucket issues](https://bitbucket.org/rivta-domains/riv.clinicalprocess.logistics.logistics/issues)
* Beskrivning: Informationssida
  * Denna domän hanterar information om historiska och framtida vårdkontakter samt vårdplaner.: [Confluence](https://inera.atlassian.net/wiki/spaces/OITOF/pages/21823645/clinicalprocess+logistics+logistics+resurssamordning)
* Beskrivning: Underlag för denna IG
  * Denna domän hanterar information om historiska och framtida vårdkontakter samt vårdplaner.: Version 3.0.13 ·[tagg 3.0.13](https://bitbucket.org/rivta-domains/riv.clinicalprocess.logistics.logistics/src/3.0.13)·[zip](https://bitbucket.org/rivta-domains/riv.clinicalprocess.logistics.logistics/downloads/clinicalprocess_logistics_logistics_3.0.13.zip)
* Beskrivning: RIV-TA-portalen
  * Denna domän hanterar information om historiska och framtida vårdkontakter samt vårdplaner.: [Alla tjänstedomäner](https://oskthu2.github.io/tkb-converter/rivta-portal/tjanstedomaner.html)·[Alla tjänstekontrakt](https://oskthu2.github.io/tkb-converter/rivta-portal/tjanstekontrakt.html)

Detta är en FHIR Implementation Guide genererad från TKB-dokumentation för tjänstedomänen **clinicalprocess: logistics: logistics** version 3.0.13.

Tjänstedomänen syftar till att tillmötesgå behovet av både patientens och hälso- och sjukvårdspersonalens direktåtkomst till patientens vårdinformation. Tjänsterna i denna domän erbjuder sökning efter logistikrelaterad information från hälso- och sjukvårdens journal- och patientadministrativa system.

Tjänstekontrakten är baserade på RIV-TA 2.1 och reglerade genom arkitekturella beslut.

## Tjänstekontrakt

| | | |
| :--- | :--- | :--- |
| [GetCareContacts](7-tjanstekontrakt.md#getcarecontacts) | 3.0 | Returnerar vårdkontakter som finns dokumenterade för en patient |
| [GetCarePlans](7-tjanstekontrakt.md#getcareplans) | 2.0 | Returnerar vård- och omsorgsplaner som finns dokumenterade för en patient |

### Versioner och granskningar

| | | | |
| :--- | :--- | :--- | :--- |
| 3.0.9 | TKB, AB | [Arkitektur & Regelverk: Säkerhet: Godkänd](http://rivta.se/downloads//clinicalprocess_logistics_logistics/3.0.9/VIS_granskning%20-%20%20clinicalprocess_logistic_logistic_3.0.9.docx)[Arkitektur & Regelverk: Informatik: Godkänd](http://rivta.se/downloads//clinicalprocess_logistics_logistics/3.0.9/VIS_granskning%20-%20%20clinicalprocess_logistic_logistic_3.0.9.docx)[Arkitektur & Regelverk: Teknik: Godkänd](http://rivta.se/downloads//clinicalprocess_logistics_logistics/3.0.9/T-granskning%20-%20%20clinicalprocess_logistic_logistic_3.0.9.docx) | [zip](http://rivta.se/downloads//clinicalprocess_logistics_logistics/3.0.9/ServiceContracts_clinicalprocess_logistics_logistics_3.0.9.zip)·[källkod](https://bitbucket.org/rivta-domains/riv.clinicalprocess.logistics.logistics/src/3.0.9) |
| 2.0.3 | TKB | [Äldre granskningsprocess: Teknik: Godkänd](http://rivta.se/downloads//clinicalprocess_logistics_logistics/2.0.3/T-granskning%20clinicalprocess_logistics_logistics_2.0.3.docx) | [zip](http://rivta.se/downloads//clinicalprocess_logistics_logistics/2.0.3/ServiceContracts_clinicalprocess_logistics_logistics_2.0.3.zip)·[källkod](https://bitbucket.org/rivta-domains/riv.clinicalprocess.logistics.logistics/src/2.0.3) |
| trunk | AB, TKB |  | [källkod](https://bitbucket.org/rivta-domains/riv.clinicalprocess.logistics.logistics/src/master) |

*Källa: ögonblicksbild av DOMDB från 2021-08-24, via RIV-TA-portalen.*

## Innehåll

* [1 Inledning](1-inledning.md)
* [2 Versionsinformation](2-versionsinformation.md)
* [3 Tjänstedomänens arkitektur](3-tjanstedomanens-arkitektur.md)
* [4 Tjänstedomänens krav och regler](4-tjanstedomanens-krav-och-regler.md)
* [5 Tjänstedomänens meddelandemodeller](5-tjanstedomanens-meddelandemodeller.md)
* [6 Gemensamma informationskomponenter](6-gemensamma-informationskomponenter.md)
* [7 Tjänstekontrakt](7-tjanstekontrakt.md)

