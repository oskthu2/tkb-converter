# Hem - clinicalprocess: logistics: logistics 2.0.7 v2.0.7

* [**Table of Contents**](toc.md)
* **Hem**

## Hem

| | |
| :--- | :--- |
| *Official URL*:https://fhir.inera.se/ig/clinicalprocess-logistics-logistics/ImplementationGuide/inera.clinicalprocess-logistics-logistics | *Version*:2.0.7 |
| Active as of 2026-10-08 | *Computable Name*:clinicalprocesslogisticslogistics |
| **Copyright/Legal**: Copyright 2024 Inera AB. Licensieras under Creative Commons Attribution 4.0. | |

# clinicalprocess: logistics: logistics 2.0.7

**TKB-version:** 2.0.7 · **IG-version:** 2.0.7 · **Källa:** Bitbucket-tagg `2.0.7` · **Andra huvudversioner:** [3.0.13](https://oskthu2.github.io/tkb-converter/TKB_clinicalprocess_logistics_logistics/index.html) 

> **Äldre huvudversion.** Detta är TKB 2.0.7 (Bitbucket-tagg `2.0.7`). Den senaste huvudversionen, 3.0 (TKB 3.0.13), finns på [clinicalprocess: logistics: logistics](https://oskthu2.github.io/tkb-converter/TKB_clinicalprocess_logistics_logistics/index.html).

## Översikt

FHIR Implementation Guide för tjänstedomänen **clinicalprocess: logistics: logistics** ("operativt processtöd: samordna resurser över verksamhetsstrukturer: logistik", resurssamordning) version 2.0.7. Genererad från Ineras Tjänstekontraktsbeskrivning (TKB).

Domänen hanterar information om historiska och framtida vårdkontakter. Tjänstekontrakten är baserade på RIV-TA 2.1 och reglerade genom arkitekturella beslut. Huvudversion 2 av domänen innehåller ett tjänstekontrakt.

RIV-TA namnrymd: `urn:riv:clinicalprocess:logistics:logistics:2`

Domänen innehåller följande tjänstekontrakt:

| | | |
| :--- | :--- | :--- |
| [GetCareContacts](7-tjanstekontrakt.md#getcarecontacts) | 2.0 | Returnerar vårdkontakter som finns dokumenterade för en patient |

**Källa:** TKB-dokumentet `TKB_clinicalprocess_logistics_logistics.docx` (version 2.0.7, 2026-06-03) med scheman från Bitbucket `rivta-domains/riv.clinicalprocess.logistics.logistics`, tagg `2.0.7` (commit `42851358d799`). Dokumentets kapitel 5 (Gemensamma informationskomponenter) och 6 (Tjänstekontrakt) ligger här som kapitel 6 och 7, enligt mallens ordning. Kapitel 5 saknas i källdokumentet.

## Innehåll

* [1 Inledning](1-inledning.md)
* [2 Versionsinformation](2-versionsinformation.md)
* [3 Tjänstedomänens arkitektur](3-tjanstedomanens-arkitektur.md)
* [4 Tjänstedomänens krav och regler](4-tjanstedomanens-krav-och-regler.md)
* [5 Tjänstedomänens meddelandemodeller](5-tjanstedomanens-meddelandemodeller.md)
* [6 Gemensamma informationskomponenter](6-gemensamma-informationskomponenter.md)
* [7 Tjänstekontrakt](7-tjanstekontrakt.md)
* [8 Bilaga MIM-mappningar GetCareContacts](8-bilaga-mim-mappningar-getcarecontacts.md)
* [Artefakter](artifacts.md)

