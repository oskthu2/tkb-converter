# Hem - clinicalprocess: logistics: logistics 2.0.7 v2.0.7

* [**Table of Contents**](toc.md)
* **Hem**

## Hem

| | |
| :--- | :--- |
| *Official URL*:https://fhir.inera.se/ig/clinicalprocess-logistics-logistics/ImplementationGuide/inera.clinicalprocess-logistics-logistics | *Version*:2.0.7 |
| Active as of 2026-11-09 | *Computable Name*:clinicalprocesslogisticslogistics |
| **Copyright/Legal**: Copyright 2024 Inera AB. Licensieras under Creative Commons Attribution 4.0. | |

# clinicalprocess: logistics: logistics 2.0.7

**TKB-version:** 2.0.7 · **IG-version:** 2.0.7 · **Källa:** Bitbucket-tagg `2.0.7` · **Andra huvudversioner:** [3.0.13](https://oskthu2.github.io/tkb-converter/TKB_clinicalprocess_logistics_logistics/index.html) 

> **Äldre huvudversion.** Detta är TKB 2.0.7 (Bitbucket-tagg `2.0.7`). Den senaste huvudversionen, 3.0 (TKB 3.0.13), finns på [clinicalprocess: logistics: logistics](https://oskthu2.github.io/tkb-converter/TKB_clinicalprocess_logistics_logistics/index.html).

## Översikt

* Beskrivning: Svenskt kortnamn
  * Denna domän hanterar information om historiska och framtida vårdkontakter samt vårdplaner.: resurssamordning
* Beskrivning: Svenskt namn
  * Denna domän hanterar information om historiska och framtida vårdkontakter samt vårdplaner.: operativt processtöd:samordna resurser över verksamhetsstrukturer: logistik
* Beskrivning: Typ
  * Denna domän hanterar information om historiska och framtida vårdkontakter samt vårdplaner.: Nationell tjänstedomän
* Beskrivning: Förvaltare
  * Denna domän hanterar information om historiska och framtida vårdkontakter samt vårdplaner.: Tjänstekontraktsförvaltningen, TK-forvaltningen@inera.se
* Beskrivning: Källkod
  * Denna domän hanterar information om historiska och framtida vårdkontakter samt vårdplaner.: [Bitbucket](https://bitbucket.org/rivta-domains/riv.clinicalprocess.logistics.logistics/src)
* Beskrivning: Ärenden
  * Denna domän hanterar information om historiska och framtida vårdkontakter samt vårdplaner.: [Bitbucket issues](https://bitbucket.org/rivta-domains/riv.clinicalprocess.logistics.logistics/issues)
* Beskrivning: Informationssida
  * Denna domän hanterar information om historiska och framtida vårdkontakter samt vårdplaner.: [Confluence](https://inera.atlassian.net/wiki/spaces/OITOF/pages/21823645/clinicalprocess+logistics+logistics+resurssamordning)
* Beskrivning: Underlag för denna IG
  * Denna domän hanterar information om historiska och framtida vårdkontakter samt vårdplaner.: Version 2.0.7 ·[tagg 2.0.7](https://bitbucket.org/rivta-domains/riv.clinicalprocess.logistics.logistics/src/2.0.7)·[zip](https://bitbucket.org/rivta-domains/riv.clinicalprocess.logistics.logistics/get/2.0.7.zip)
* Beskrivning: RIV-TA-portalen
  * Denna domän hanterar information om historiska och framtida vårdkontakter samt vårdplaner.: [Alla tjänstedomäner](https://oskthu2.github.io/tkb-converter/rivta-portal/tjanstedomaner.html)·[Alla tjänstekontrakt](https://oskthu2.github.io/tkb-converter/rivta-portal/tjanstekontrakt.html)

FHIR Implementation Guide för tjänstedomänen **clinicalprocess: logistics: logistics** ("operativt processtöd: samordna resurser över verksamhetsstrukturer: logistik", resurssamordning) version 2.0.7. Genererad från Ineras Tjänstekontraktsbeskrivning (TKB).

Domänen hanterar information om historiska och framtida vårdkontakter. Tjänstekontrakten är baserade på RIV-TA 2.1 och reglerade genom arkitekturella beslut. Huvudversion 2 av domänen innehåller ett tjänstekontrakt.

RIV-TA namnrymd: `urn:riv:clinicalprocess:logistics:logistics:2`

Domänen innehåller följande tjänstekontrakt:

| | | |
| :--- | :--- | :--- |
| [GetCareContacts](7-tjanstekontrakt.md#getcarecontacts) | 2.0 | Returnerar vårdkontakter som finns dokumenterade för en patient |

**Källa:** TKB-dokumentet `TKB_clinicalprocess_logistics_logistics.docx` (version 2.0.7, 2026-06-03) med scheman från Bitbucket `rivta-domains/riv.clinicalprocess.logistics.logistics`, tagg `2.0.7` (commit `42851358d799`). Dokumentets kapitel 5 (Gemensamma informationskomponenter) och 6 (Tjänstekontrakt) ligger här som kapitel 6 och 7, enligt mallens ordning. Kapitel 5 saknas i källdokumentet.

### Versioner och granskningar

| | | | |
| :--- | :--- | :--- | :--- |
| 3.0.9 | TKB, AB | Arkitektur & Regelverk: Säkerhet: GodkändArkitektur & Regelverk: Informatik: GodkändArkitektur & Regelverk: Teknik: Godkänd | [zip](https://bitbucket.org/rivta-domains/riv.clinicalprocess.logistics.logistics/get/3.0.9.zip)·[källkod](https://bitbucket.org/rivta-domains/riv.clinicalprocess.logistics.logistics/src/3.0.9) |
| 2.0.3 | TKB | Äldre granskningsprocess: Teknik: Godkänd | [zip](https://bitbucket.org/rivta-domains/riv.clinicalprocess.logistics.logistics/get/2.0.3.zip)·[källkod](https://bitbucket.org/rivta-domains/riv.clinicalprocess.logistics.logistics/src/2.0.3) |
| trunk | AB, TKB |  | [källkod](https://bitbucket.org/rivta-domains/riv.clinicalprocess.logistics.logistics/src/master) |

*Zip-arkiven hämtas från taggarna på Bitbucket. Granskningsprotokollen publicerades på rivta.se och länkas inte härifrån.*

*Källa: ögonblicksbild av DOMDB från 2021-08-24, via RIV-TA-portalen.*

## Innehåll

* [1 Inledning](1-inledning.md)
* [2 Versionsinformation](2-versionsinformation.md)
* [3 Tjänstedomänens arkitektur](3-tjanstedomanens-arkitektur.md)
* [4 Tjänstedomänens krav och regler](4-tjanstedomanens-krav-och-regler.md)
* [5 Tjänstedomänens meddelandemodeller](5-tjanstedomanens-meddelandemodeller.md)
* [6 Gemensamma informationskomponenter](6-gemensamma-informationskomponenter.md)
* [7 Tjänstekontrakt](7-tjanstekontrakt.md)
* [8 Bilaga MIM-mappningar GetCareContacts](8-bilaga-mim-mappningar-getcarecontacts.md)
* [Artefakter](artifacts.md)

