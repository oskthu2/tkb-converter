# inera.clinicalprocess-logistics-logistics#2.0.7: clinicalprocess: logistics: logistics 2.0.7

## Pages

* [Hem](index.md)
* [7 Tjänstekontrakt](7-tjanstekontrakt.md)
* [5 Tjänstedomänens meddelandemodeller](5-tjanstedomanens-meddelandemodeller.md)
* [8 Bilaga MIM-mappningar GetCareContacts](8-bilaga-mim-mappningar-getcarecontacts.md)
* [Artifacts Summary](artifacts.md)
* [6 Gemensamma informationskomponenter](6-gemensamma-informationskomponenter.md)
* [3 Tjänstedomänens arkitektur](3-tjanstedomanens-arkitektur.md)
* [4 Tjänstedomänens krav och regler](4-tjanstedomanens-krav-och-regler.md)
* [2 Versionsinformation](2-versionsinformation.md)
* [1 Inledning](1-inledning.md)

## Resources

### CodeSystems

* [CareContactCode](CodeSystem-carecontactcode-cs.md)
* [CareContactStatus](CodeSystem-carecontactstatus-cs.md)

### ValueSets

* [CareContactCode — ValueSet](ValueSet-carecontactcode-vs.md)
* [CareContactStatus — ValueSet](ValueSet-carecontactstatus-vs.md)

### Logicals

* [GetCareContacts — Request](StructureDefinition-getcarecontacts-request.md)
* [GetCareContacts](StructureDefinition-getcarecontacts.md)

### ImplementationGuides

* [clinicalprocess: logistics: logistics 2.0.7](index.md)
