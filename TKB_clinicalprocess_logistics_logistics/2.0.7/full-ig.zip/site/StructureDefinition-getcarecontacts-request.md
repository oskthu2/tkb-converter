# GetCareContacts — Request - clinicalprocess: logistics: logistics 2.0.7 v2.0.7

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **GetCareContacts — Request**

## Logical Model: GetCareContacts — Request 

| | |
| :--- | :--- |
| *Official URL*:https://fhir.inera.se/ig/clinicalprocess-logistics-logistics/StructureDefinition/getcarecontacts-request | *Version*:2.0 |
| Active as of 2026-10-08 | *Computable Name*:GetCareContactsRequest |
| **Copyright/Legal**: Copyright 2024 Inera AB. Licensieras under Creative Commons Attribution 4.0. | |

 
Logisk modell för begäran i tjänstekontraktet GetCareContacts 2.0 (RIV-TA urn:riv:clinicalprocess:logistics:logistics:GetCareContactsResponder:2). Representerar GetCareContactsType i GetCareContactsResponder_2.0.xsd. 

**Usages:**

* This Logical Model is not used by any profiles in this Specification

You can also check for [usages in the FHIR IG Statistics](https://packages2.fhir.org/xig/resource/inera.clinicalprocess-logistics-logistics|current/StructureDefinition/StructureDefinition-getcarecontacts-request.json)

### Formal Views of Profile Content

 [Description of Profiles, Differentials, Snapshots and how the different presentations work](http://build.fhir.org/ig/FHIR/ig-guidance/readingIgs.html#structure-definitions). 

 

Other representations of profile: [CSV](StructureDefinition-getcarecontacts-request.csv), [Excel](StructureDefinition-getcarecontacts-request.xlsx) 



## Resource Content

```json
{
  "resourceType" : "StructureDefinition",
  "id" : "getcarecontacts-request",
  "extension" : [{
    "url" : "http://hl7.org/fhir/StructureDefinition/structuredefinition-type-characteristics",
    "valueCode" : "can-be-target"
  }],
  "url" : "https://fhir.inera.se/ig/clinicalprocess-logistics-logistics/StructureDefinition/getcarecontacts-request",
  "version" : "2.0",
  "name" : "GetCareContactsRequest",
  "title" : "GetCareContacts — Request",
  "status" : "active",
  "date" : "2026-10-08T18:12:50+00:00",
  "contact" : [{
    "name" : "Inera Arkitektur",
    "telecom" : [{
      "system" : "url",
      "value" : "https://www.inera.se"
    }]
  }],
  "description" : "Logisk modell för begäran i tjänstekontraktet GetCareContacts 2.0\n(RIV-TA urn:riv:clinicalprocess:logistics:logistics:GetCareContactsResponder:2).\nRepresenterar GetCareContactsType i GetCareContactsResponder_2.0.xsd.",
  "copyright" : "Copyright 2024 Inera AB. Licensieras under Creative Commons Attribution 4.0.",
  "fhirVersion" : "4.0.1",
  "kind" : "logical",
  "abstract" : false,
  "type" : "https://fhir.inera.se/ig/clinicalprocess-logistics-logistics/StructureDefinition/getcarecontacts-request",
  "baseDefinition" : "http://hl7.org/fhir/StructureDefinition/Base",
  "derivation" : "specialization",
  "differential" : {
    "element" : [{
      "id" : "getcarecontacts-request",
      "path" : "getcarecontacts-request",
      "short" : "GetCareContacts — Request",
      "definition" : "Logisk modell för begäran i tjänstekontraktet GetCareContacts 2.0\n(RIV-TA urn:riv:clinicalprocess:logistics:logistics:GetCareContactsResponder:2).\nRepresenterar GetCareContactsType i GetCareContactsResponder_2.0.xsd.",
      "constraint" : [{
        "key" : "getcarecontacts-request-sourcesystem-when-id",
        "severity" : "error",
        "human" : "sourceSystemHSAId är tvingande om careContactId angivits.",
        "expression" : "careContactId.exists() implies sourceSystemHSAId.exists()",
        "source" : "https://fhir.inera.se/ig/clinicalprocess-logistics-logistics/StructureDefinition/getcarecontacts-request"
      }]
    },
    {
      "id" : "getcarecontacts-request.careUnitHSAId",
      "path" : "getcarecontacts-request.careUnitHSAId",
      "short" : "Begränsning av sökning avseende vårdenheter",
      "definition" : "Begränsning av sökning avseende vårdenheter vilket motsvarar careUnitHSAId i HealthcareProfessionalType.\nTyp HSAIdType (system = urn:oid:1.2.752.129.2.1.4.1).",
      "min" : 0,
      "max" : "*",
      "type" : [{
        "code" : "Identifier"
      }]
    },
    {
      "id" : "getcarecontacts-request.patientId",
      "path" : "getcarecontacts-request.patientId",
      "short" : "Id för patienten",
      "definition" : "Typ PersonIdType. value sätts till patientens identifierare, angiven med 12 siffror utan avskiljare.\nsystem sätts till OID för typ av identifierare (fältet type i schemat):\npersonnummer 1.2.752.129.2.1.3.1, samordningsnummer 1.2.752.129.2.1.3.3,\nreservnummer lokalt definierad OID, exempelvis SLL reservnummer 1.2.752.97.3.1.3.",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "Identifier"
      }]
    },
    {
      "id" : "getcarecontacts-request.timePeriod",
      "path" : "getcarecontacts-request.timePeriod",
      "short" : "Begränsar sökningen till det angivna intervallet",
      "definition" : "Typ DatePeriodType. Endast poster returneras där datumintervallet som bildas av authorTime,\ncareContactTimePeriod.start och careContactTimePeriod.end i svaret helt eller delvis överlappar\nsökintervallet. Vid jämförelse konverteras datapostens tidpunkter till datum.",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "BackboneElement"
      }]
    },
    {
      "id" : "getcarecontacts-request.timePeriod.start",
      "path" : "getcarecontacts-request.timePeriod.start",
      "short" : "Startdatum (ÅÅÅÅMMDD)",
      "definition" : "Startdatum (ÅÅÅÅMMDD)",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "date"
      }]
    },
    {
      "id" : "getcarecontacts-request.timePeriod.end",
      "path" : "getcarecontacts-request.timePeriod.end",
      "short" : "Slutdatum (ÅÅÅÅMMDD)",
      "definition" : "Slutdatum (ÅÅÅÅMMDD)",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "date"
      }]
    },
    {
      "id" : "getcarecontacts-request.sourceSystemHSAId",
      "path" : "getcarecontacts-request.sourceSystemHSAId",
      "short" : "Begränsar sökningen till det angivna källsystemet",
      "definition" : "Tjänsteproducenten förväntas enbart returnera poster som tillhör efterfrågat källsystem.\nVärdet måste överensstämma med logicalAddress i anropets tekniska kuvertering (SOAP-header),\nvilket innebär att aggregerande tjänster inte används när fältet anges.\nFältet är tvingande om careContactId angivits. Typ HSAIdType.",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "Identifier"
      }]
    },
    {
      "id" : "getcarecontacts-request.careContactId",
      "path" : "getcarecontacts-request.careContactId",
      "short" : "Begränsar sökningen till angivna vårdkontakter",
      "definition" : "Identitet för den hälso- och sjukvårdskontakt som föranlett den information som omfattas av dokumentet.\nIdentiteten är unik inom källsystemet.",
      "min" : 0,
      "max" : "*",
      "type" : [{
        "code" : "string"
      }]
    }]
  }
}

```
