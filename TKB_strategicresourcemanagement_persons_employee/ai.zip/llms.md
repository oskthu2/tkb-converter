# inera.strategicresourcemanagement-persons-employee#2.0.0-rc1: strategicresourcemanagement: persons: employee

## Pages

* [Hem](index.md)
* [7 Tjänstekontrakt](7-tjanstekontrakt.md)
* [5 Tjänstedomänens meddelandemodeller](5-tjanstedomanens-meddelandemodeller.md)
* [Artifacts Summary](artifacts.md)
* [6 Gemensamma informationskomponenter](6-gemensamma-informationskomponenter.md)
* [8 Bilaga, attributtabeller](8-bilaga-attributtabeller.md)
* [3 Tjänstedomänens arkitektur](3-tjanstedomanens-arkitektur.md)
* [4 Tjänstedomänens krav och regler](4-tjanstedomanens-krav-och-regler.md)
* [2 Versionsinformation](2-versionsinformation.md)
* [1 Inledning](1-inledning.md)

## Resources

### Logicals

* [GetCommissionMembers — Request](StructureDefinition-getcommissionmembers-request.md)
* [GetCommissionMembers — Response](StructureDefinition-getcommissionmembers.md)
* [GetCommissionMembersIncludingProtectedPerson — Request](StructureDefinition-getcommissionmembersincludingprotectedperson-request.md)
* [GetCommissionMembersIncludingProtectedPerson — Response](StructureDefinition-getcommissionmembersincludingprotectedperson.md)
* [GetEmployee — Request](StructureDefinition-getemployee-request.md)
* [GetEmployee — Response](StructureDefinition-getemployee.md)
* [GetEmployeeIncludingProtectedPerson — Request](StructureDefinition-getemployeeincludingprotectedperson-request.md)
* [GetEmployeeIncludingProtectedPerson — Response](StructureDefinition-getemployeeincludingprotectedperson.md)

### ImplementationGuides

* [strategicresourcemanagement: persons: employee](index.md)
