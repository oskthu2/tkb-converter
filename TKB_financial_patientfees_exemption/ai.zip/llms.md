# inera.financial-patientfees-exemption#1.0.0: financial: patientfees: exemption

## Pages

* [Hem](index.md)
* [7 Tjänstekontrakt](7-tjanstekontrakt.md)
* [5 Tjänstedomänens meddelandemodeller](5-tjanstedomanens-meddelandemodeller.md)
* [Artifacts Summary](artifacts.md)
* [6 Gemensamma informationskomponenter](6-gemensamma-informationskomponenter.md)
* [3 Tjänstedomänens arkitektur](3-tjanstedomanens-arkitektur.md)
* [4 Tjänstedomänens krav och regler](4-tjanstedomanens-krav-och-regler.md)
* [2 Versionsinformation](2-versionsinformation.md)
* [1 Inledning](1-inledning.md)

## Resources

### CodeSystems

* [ActorType](CodeSystem-patientfees-exemption-actortype-cs.md)
* [ResultCode](CodeSystem-patientfees-exemption-resultcode-cs.md)
* [TypeOfExemption](CodeSystem-patientfees-exemption-typeofexemption-cs.md)

### ValueSets

* [ActorType](ValueSet-patientfees-exemption-actortype-vs.md)
* [ResultCode](ValueSet-patientfees-exemption-resultcode-vs.md)
* [TypeOfExemption](ValueSet-patientfees-exemption-typeofexemption-vs.md)

### Logicals

* [ProcessExemptionStatuses — Request](StructureDefinition-processexemptionstatuses-request.md)
* [ProcessExemptionStatuses — Response](StructureDefinition-processexemptionstatuses.md)
* [RequestExemptionStatuses — Request](StructureDefinition-requestexemptionstatuses-request.md)

### ImplementationGuides

* [financial: patientfees: exemption](index.md)
