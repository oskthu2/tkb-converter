# Hem - financial: patientfees: exemption v1.0.0

* [**Table of Contents**](toc.md)
* **Hem**

## Hem

| | |
| :--- | :--- |
| *Official URL*:https://fhir.inera.se/ig/financial-patientfees-exemption/ImplementationGuide/inera.financial-patientfees-exemption | *Version*:1.0.0 |
| Draft as of 2026-09-28 | *Computable Name*:financialpatientfeesexemption |
| **Copyright/Legal**: Copyright 2024 Inera AB. Licensieras under Creative Commons Attribution 4.0. | |

# financial: patientfees: exemption

## Översikt

FHIR Implementation Guide för tjänstedomänen **financial: patientfees: exemption** (Nationellt högkostnadsskydd) version 1.0. Genererad från Ineras Tjänstekontraktbeskrivning (TKB), version 1.0 (2024-03-25), och domänens WSDL- och XSD-filer.

Domänen gör det möjligt att hämta en patients högkostnadsskydd (frikort och registrerade patientavgifter) från andra vårdgivare, så att högkostnadsskyddet kan tillämpas nationellt.

Domänen innehåller följande tjänstekontrakt:

| | | |
| :--- | :--- | :--- |
| [RequestExemptionStatuses](7-tjanstekontrakt.md#requestexemptionstatuses) | 1.0 | Detta tjänstekontrakt används för att begära ut högkostandsskyddstatus samt alla transaktioner 12 månader bakåt i tiden för det patientId som anges i begäran. Genom att anropa tjänstekontraktet initieras en begäran om ett utlämnande. Den efterfrågade informationen skickas sedan av utlämnande part via tjänstekontraktet ProcessExemptionStatuses. |
| [ProcessExemptionStatuses](7-tjanstekontrakt.md#processexemptionstatuses) | 1.0 | Detta tjänstekontrakt används för att lämna ut högkostandsskyddstatus samt alla transaktioner 12 månader bakåt i tiden för det patientId som begärts ut. |

## Innehåll

* [1 Inledning](1-inledning.md)
* [2 Versionsinformation](2-versionsinformation.md)
* [3 Tjänstedomänens arkitektur](3-tjanstedomanens-arkitektur.md)
* [4 Tjänstedomänens krav och regler](4-tjanstedomanens-krav-och-regler.md)
* [5 Tjänstedomänens meddelandemodeller](5-tjanstedomanens-meddelandemodeller.md)
* [6 Gemensamma informationskomponenter](6-gemensamma-informationskomponenter.md)
* [7 Tjänstekontrakt](7-tjanstekontrakt.md)
* [Artefakter](artifacts.md)

