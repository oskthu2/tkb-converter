# Hem - financial: patientfees: exemption v1.0.0

* [**Table of Contents**](toc.md)
* **Hem**

## Hem

| | |
| :--- | :--- |
| *Official URL*:https://fhir.inera.se/ig/financial-patientfees-exemption/ImplementationGuide/inera.financial-patientfees-exemption | *Version*:1.0.0 |
| Active as of 2026-11-06 | *Computable Name*:financialpatientfeesexemption |
| **Copyright/Legal**: Copyright 2024 Inera AB. Licensieras under Creative Commons Attribution 4.0. | |

# financial: patientfees: exemption

**TKB-version:** 1.0 · **IG-version:** 1.0.0 · **Källa:** Bitbucket-commit `fbd046e11e50`, efter taggen `1.0` 

## Översikt

* Svenskt kortnamn: Svenskt namn
  * Högkostnadsskydd: Nationellt Högkostnadsskydd
* Svenskt kortnamn: Typ
  * Högkostnadsskydd: Nationell tjänstedomän
* Svenskt kortnamn: Anmärkning
  * Högkostnadsskydd: dold på rivta.se
* Svenskt kortnamn: Källkod
  * Högkostnadsskydd: [Bitbucket](https://bitbucket.org/rivta-domains/riv.financial.patientfees.exemption/src)
* Svenskt kortnamn: Underlag för denna IG
  * Högkostnadsskydd: Version 1.0 ·[tagg 1.0](https://bitbucket.org/rivta-domains/riv.financial.patientfees.exemption/src/1.0)·[zip](https://bitbucket.org/rivta-domains/riv.financial.patientfees.exemption/get/fbd046e11e50.zip)
* Svenskt kortnamn: RIV-TA-portalen
  * Högkostnadsskydd: [Alla tjänstedomäner](https://oskthu2.github.io/tkb-converter/rivta-portal/tjanstedomaner.html)·[Alla tjänstekontrakt](https://oskthu2.github.io/tkb-converter/rivta-portal/tjanstekontrakt.html)

FHIR Implementation Guide för tjänstedomänen **financial: patientfees: exemption** (Nationellt högkostnadsskydd) version 1.0. Genererad från Ineras Tjänstekontraktbeskrivning (TKB), version 1.0 (2024-03-25), och domänens WSDL- och XSD-filer.

Domänen gör det möjligt att hämta en patients högkostnadsskydd (frikort och registrerade patientavgifter) från andra vårdgivare, så att högkostnadsskyddet kan tillämpas nationellt.

Domänen innehåller följande tjänstekontrakt:

| | | |
| :--- | :--- | :--- |
| [RequestExemptionStatuses](7-tjanstekontrakt.md#requestexemptionstatuses) | 1.0 | Detta tjänstekontrakt används för att begära ut högkostandsskyddstatus samt alla transaktioner 12 månader bakåt i tiden för det patientId som anges i begäran. Genom att anropa tjänstekontraktet initieras en begäran om ett utlämnande. Den efterfrågade informationen skickas sedan av utlämnande part via tjänstekontraktet ProcessExemptionStatuses. |
| [ProcessExemptionStatuses](7-tjanstekontrakt.md#processexemptionstatuses) | 1.0 | Detta tjänstekontrakt används för att lämna ut högkostandsskyddstatus samt alla transaktioner 12 månader bakåt i tiden för det patientId som begärts ut. |

### Versioner och granskningar

| | | | |
| :--- | :--- | :--- | :--- |
| trunk |  |  |  |

*Zip-arkiven hämtas från taggarna på Bitbucket. Granskningsprotokollen publicerades på rivta.se och länkas inte härifrån.*

*Källa: ögonblicksbild av DOMDB från 2021-08-24, via RIV-TA-portalen.*

## Innehåll

* [1 Inledning](1-inledning.md)
* [2 Versionsinformation](2-versionsinformation.md)
* [3 Tjänstedomänens arkitektur](3-tjanstedomanens-arkitektur.md)
* [4 Tjänstedomänens krav och regler](4-tjanstedomanens-krav-och-regler.md)
* [5 Tjänstedomänens meddelandemodeller](5-tjanstedomanens-meddelandemodeller.md)
* [6 Gemensamma informationskomponenter](6-gemensamma-informationskomponenter.md)
* [7 Tjänstekontrakt](7-tjanstekontrakt.md)
* [Artefakter](artifacts.md)

