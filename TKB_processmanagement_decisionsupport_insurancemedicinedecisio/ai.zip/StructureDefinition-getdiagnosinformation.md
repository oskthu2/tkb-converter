# GetDiagnosInformation - processmanagement: decisionsupport: insurancemedicinedecisionsupport v1.0.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **GetDiagnosInformation**

## Logical Model: GetDiagnosInformation 

| | |
| :--- | :--- |
| *Official URL*:https://fhir.inera.se/ig/processmanagement-decisionsupport-insurancemedicinedecisio/StructureDefinition/getdiagnosinformation | *Version*:1.0 |
| Active as of 2026-11-09 | *Computable Name*:GetDiagnosInformation |
| **Copyright/Legal**: Copyright 2024 Inera AB. Licensieras under Creative Commons Attribution 4.0. | |

 
Logisk modell för tjänstekontraktet GetDiagnosInformation (RIV-TA urn:riv:processmanagement:decisionsupport:insurancemedicinedecisionsupport:GetDiagnosInformation:1). Representerar responsens informationsstruktur — generell information om diagnoser. Sådan information kan gälla för en eller flera diagnoser samtidigt. 

**Usages:**

* This Logical Model is not used by any profiles in this Specification

You can also check for [usages in the FHIR IG Statistics](https://packages2.fhir.org/xig/resource/inera.processmanagement-decisionsupport-insurancemedicinedecisio|current/StructureDefinition/StructureDefinition-getdiagnosinformation.json)

### Formal Views of Profile Content

 [Description of Profiles, Differentials, Snapshots and how the different presentations work](http://build.fhir.org/ig/FHIR/ig-guidance/readingIgs.html#structure-definitions). 

 

Other representations of profile: [CSV](StructureDefinition-getdiagnosinformation.csv), [Excel](StructureDefinition-getdiagnosinformation.xlsx) 



## Resource Content

```json
{
  "resourceType" : "StructureDefinition",
  "id" : "getdiagnosinformation",
  "extension" : [{
    "url" : "http://hl7.org/fhir/StructureDefinition/structuredefinition-type-characteristics",
    "valueCode" : "can-be-target"
  }],
  "url" : "https://fhir.inera.se/ig/processmanagement-decisionsupport-insurancemedicinedecisio/StructureDefinition/getdiagnosinformation",
  "version" : "1.0",
  "name" : "GetDiagnosInformation",
  "title" : "GetDiagnosInformation",
  "status" : "active",
  "date" : "2026-11-09T03:46:58+00:00",
  "contact" : [{
    "name" : "Inera Arkitektur",
    "telecom" : [{
      "system" : "url",
      "value" : "https://www.inera.se"
    }]
  }],
  "description" : "Logisk modell för tjänstekontraktet GetDiagnosInformation\n(RIV-TA urn:riv:processmanagement:decisionsupport:insurancemedicinedecisionsupport:GetDiagnosInformation:1).\nRepresenterar responsens informationsstruktur — generell information om diagnoser.\nSådan information kan gälla för en eller flera diagnoser samtidigt.",
  "copyright" : "Copyright 2024 Inera AB. Licensieras under Creative Commons Attribution 4.0.",
  "fhirVersion" : "4.0.1",
  "kind" : "logical",
  "abstract" : false,
  "type" : "https://fhir.inera.se/ig/processmanagement-decisionsupport-insurancemedicinedecisio/StructureDefinition/getdiagnosinformation",
  "baseDefinition" : "http://hl7.org/fhir/StructureDefinition/Base",
  "derivation" : "specialization",
  "differential" : {
    "element" : [{
      "id" : "getdiagnosinformation",
      "path" : "getdiagnosinformation",
      "short" : "GetDiagnosInformation",
      "definition" : "Logisk modell för tjänstekontraktet GetDiagnosInformation\n(RIV-TA urn:riv:processmanagement:decisionsupport:insurancemedicinedecisionsupport:GetDiagnosInformation:1).\nRepresenterar responsens informationsstruktur — generell information om diagnoser.\nSådan information kan gälla för en eller flera diagnoser samtidigt."
    },
    {
      "id" : "getdiagnosinformation.diagnosInformation",
      "path" : "getdiagnosinformation.diagnosInformation",
      "short" : "DiagnosInformationType",
      "definition" : "diagnosInformation",
      "comment" : "TKB-fält: `diagnosInformation` (`diagnosInformationType`, kardinalitet 0..*).",
      "min" : 0,
      "max" : "*",
      "type" : [{
        "code" : "Base"
      }]
    },
    {
      "id" : "getdiagnosinformation.diagnosInformation.informationsId",
      "path" : "getdiagnosinformation.diagnosInformation.informationsId",
      "short" : "informationsId",
      "definition" : "Identitet för diagnosinformationen",
      "comment" : "TKB-fält: `../informationsId` (`II`, kardinalitet 1..1).",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "https://fhir.inera.se/ig/processmanagement-decisionsupport-insurancemedicinedecisio/StructureDefinition/IIType"
      }]
    },
    {
      "id" : "getdiagnosinformation.diagnosInformation.giltighetstid",
      "path" : "getdiagnosinformation.diagnosInformation.giltighetstid",
      "short" : "IVLType",
      "definition" : "Tid då diagnosinformationen är giltig. Starttiden i intervallet skall alltid anges. Om sluttid ej anges är diagnosinformationen aktiv. Diagnosinformation som inte är aktiv skall innehålla ett slutdatum, som ligger tidigare än aktuellt datum, eller ett startdatum som ligger senare än aktuellt datum.",
      "comment" : "TKB-fält: `../giltighetsTid` (`IVL`, kardinalitet 1..1).",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "Base"
      }]
    },
    {
      "id" : "getdiagnosinformation.diagnosInformation.giltighetstid.start",
      "path" : "getdiagnosinformation.diagnosInformation.giltighetstid.start",
      "short" : "start",
      "definition" : "Starttid",
      "comment" : "TKB-fält: `../../start` (`Date`, kardinalitet 1..1).",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "string",
        "profile" : ["https://fhir.inera.se/ig/processmanagement-decisionsupport-insurancemedicinedecisio/StructureDefinition/DatumType"]
      }]
    },
    {
      "id" : "getdiagnosinformation.diagnosInformation.giltighetstid.slut",
      "path" : "getdiagnosinformation.diagnosInformation.giltighetstid.slut",
      "short" : "slut",
      "definition" : "Sluttid",
      "comment" : "TKB-fält: `../../slut` (`Date`, kardinalitet 0..1).",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string",
        "profile" : ["https://fhir.inera.se/ig/processmanagement-decisionsupport-insurancemedicinedecisio/StructureDefinition/DatumType"]
      }]
    },
    {
      "id" : "getdiagnosinformation.diagnosInformation.verson",
      "path" : "getdiagnosinformation.diagnosInformation.verson",
      "short" : "verson",
      "definition" : "verson",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "integer"
      }]
    },
    {
      "id" : "getdiagnosinformation.diagnosInformation.rubrik",
      "path" : "getdiagnosinformation.diagnosInformation.rubrik",
      "short" : "rubrik",
      "definition" : "Rubriken för diagnosinformationen",
      "comment" : "TKB-fält: `../rubrik` (`string`, kardinalitet 1..1).",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "getdiagnosinformation.diagnosInformation.funktionsnedsattningBeskrivning",
      "path" : "getdiagnosinformation.diagnosInformation.funktionsnedsattningBeskrivning",
      "short" : "funktionsnedsattningBeskrivning",
      "definition" : "funktionsnedsattningBeskrivning",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "getdiagnosinformation.diagnosInformation.aktivitetsbegransningBeskrivning",
      "path" : "getdiagnosinformation.diagnosInformation.aktivitetsbegransningBeskrivning",
      "short" : "aktivitetsbegransningBeskrivning",
      "definition" : "En beskrivande text för aktivitetsbegränsningar förknippade med diagnosen.",
      "comment" : "TKB-fält: `../aktivitetsbegransningBeskrivning` (`string`, kardinalitet 0..1).",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "getdiagnosinformation.diagnosInformation.huvuddiagnos",
      "path" : "getdiagnosinformation.diagnosInformation.huvuddiagnos",
      "short" : "HuvuddiagnosType",
      "definition" : "huvuddiagnos",
      "comment" : "TKB-fält: `../huvuddiagnos` (`HuvuddiagnosType`, kardinalitet 1..*).",
      "min" : 1,
      "max" : "*",
      "type" : [{
        "code" : "Base"
      }]
    },
    {
      "id" : "getdiagnosinformation.diagnosInformation.huvuddiagnos.kod",
      "path" : "getdiagnosinformation.diagnosInformation.huvuddiagnos.kod",
      "short" : "ICD10SEType",
      "definition" : "kod",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "Base"
      }]
    },
    {
      "id" : "getdiagnosinformation.diagnosInformation.funktionsnedsattning",
      "path" : "getdiagnosinformation.diagnosInformation.funktionsnedsattning",
      "short" : "FunktionsnedsattningType",
      "definition" : "Innehåller information om en eller flera funktionsnedsättningar som vanligt förekommer för den eller de diagnoser som diagnosgruppen omfattar.",
      "comment" : "TKB-fält: `../funktionsnedsattning` (`FunktionsnedsattningType`, kardinalitet 0..*).",
      "min" : 0,
      "max" : "*",
      "type" : [{
        "code" : "Base"
      }]
    },
    {
      "id" : "getdiagnosinformation.diagnosInformation.funktionsnedsattning.kod",
      "path" : "getdiagnosinformation.diagnosInformation.funktionsnedsattning.kod",
      "short" : "ICFType",
      "definition" : "Kod som anger Funktionsnedsättning",
      "comment" : "TKB-fält: `../../kod` (`CVtype`, kardinalitet 1..1).",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "Base"
      }]
    },
    {
      "id" : "getdiagnosinformation.diagnosInformation.aktivitetsbegransning",
      "path" : "getdiagnosinformation.diagnosInformation.aktivitetsbegransning",
      "short" : "AktivitetsbegransningType",
      "definition" : "Innehåller information om en eller flera aktivitetsbegränsning som vanligt förekommer för den eller de diagnoser som diagnosgruppen omfattar.",
      "comment" : "TKB-fält: `../aktivitetsbegransning` (`AktivitetsbegransningType`, kardinalitet 0..*).",
      "min" : 0,
      "max" : "*",
      "type" : [{
        "code" : "Base"
      }]
    },
    {
      "id" : "getdiagnosinformation.diagnosInformation.aktivitetsbegransning.kod",
      "path" : "getdiagnosinformation.diagnosInformation.aktivitetsbegransning.kod",
      "short" : "ICFType",
      "definition" : "Kod som anger Aktivitetsbegränsning",
      "comment" : "TKB-fält: `../../kod` (`CVtype`, kardinalitet 1..1).",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "Base"
      }]
    },
    {
      "id" : "getdiagnosinformation.diagnosInformation.ovrigFmbInformation",
      "path" : "getdiagnosinformation.diagnosInformation.ovrigFmbInformation",
      "short" : "OvrigFmbInformationType",
      "definition" : "ovrigFmbInformation",
      "comment" : "TKB-fält: `../ovrigFmbInformation` (`OvrigFmbInformationType`, kardinalitet 0..1).",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "Base"
      }]
    },
    {
      "id" : "getdiagnosinformation.diagnosInformation.ovrigFmbInformation.symtomPrognosBehandling",
      "path" : "getdiagnosinformation.diagnosInformation.ovrigFmbInformation.symtomPrognosBehandling",
      "short" : "symtomPrognosBehandling",
      "definition" : "Allmän information om symtom, prognos samt behandling.",
      "comment" : "TKB-fält: `../../symtomPrognosBehandling` (`String`, kardinalitet 0..1).",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "getdiagnosinformation.diagnosInformation.ovrigFmbInformation.genrellInformation",
      "path" : "getdiagnosinformation.diagnosInformation.ovrigFmbInformation.genrellInformation",
      "short" : "genrellInformation",
      "definition" : "genrellInformation",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "getdiagnosinformation.version",
      "path" : "getdiagnosinformation.version",
      "short" : "VersionType",
      "definition" : "Versionsnummer för diagnosinformationen. Versionen räknas upp när diagnosinformationen förändrats i sin innebörd eller ändrar giltighetstid.",
      "comment" : "TKB-fält: `../version` (`Int`, kardinalitet 1..1).",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "Base"
      }]
    },
    {
      "id" : "getdiagnosinformation.version.senasteVersionsuppdatering",
      "path" : "getdiagnosinformation.version.senasteVersionsuppdatering",
      "short" : "senasteVersionsuppdatering",
      "definition" : "Anger när diagnosinformation senast bytte versionsnummer (skapades, ändrade innebörd eller togs bort) bland alla diagnosinformation, dvs det kan vara diagnosinformation som ej returnerats i svaret som föranlett ett nytt datum.",
      "comment" : "TKB-fält: `../senasteVersionsuppdatering` (`dateTime`, kardinalitet 1..1).",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "string",
        "profile" : ["https://fhir.inera.se/ig/processmanagement-decisionsupport-insurancemedicinedecisio/StructureDefinition/TidpunktType"]
      }]
    },
    {
      "id" : "getdiagnosinformation.version.senateAndring",
      "path" : "getdiagnosinformation.version.senateAndring",
      "short" : "senateAndring",
      "definition" : "senateAndring",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "string",
        "profile" : ["https://fhir.inera.se/ig/processmanagement-decisionsupport-insurancemedicinedecisio/StructureDefinition/TidpunktType"]
      }]
    }]
  }
}

```
