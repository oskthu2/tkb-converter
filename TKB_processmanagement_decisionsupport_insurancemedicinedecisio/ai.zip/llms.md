# inera.processmanagement-decisionsupport-insurancemedicinedecisio#1.0.0: processmanagement: decisionsupport: insurancemedicinedecisionsupport

## Pages

* [Hem](index.md)
* [7 Tjänstekontrakt](7-tjanstekontrakt.md)
* [2 Versionsinformation](2-versionsinformation.md)
* [3 Tjänstedomänens arkitektur](3-tjanstedomanens-arkitektur.md)
* [1 Inledning](1-inledning.md)
* [Artifacts Summary](artifacts.md)
* [6 Gemensamma informationskomponenter](6-gemensamma-informationskomponenter.md)
* [5 Tjänstedomänens meddelandemodeller](5-tjanstedomanens-meddelandemodeller.md)
* [4 Tjänstedomänens krav och regler](4-tjanstedomanens-krav-och-regler.md)

## Resources

### Logicals

* [IIType](StructureDefinition-IIType.md)
* [GetDiagnosInformation — Request](StructureDefinition-getdiagnosinformation-request.md)
* [GetDiagnosInformation](StructureDefinition-getdiagnosinformation.md)
* [GetFmb — Request](StructureDefinition-getfmb-request.md)
* [GetFmb](StructureDefinition-getfmb.md)
* [GetVersions](StructureDefinition-getversions.md)

### Primitive-type Profiles

* [DatumType](StructureDefinition-DatumType.md)
* [TidpunktType](StructureDefinition-TidpunktType.md)

### ImplementationGuides

* [processmanagement: decisionsupport: insurancemedicinedecisionsupport](index.md)
