# Hem - processmanagement: decisionsupport: insurancemedicinedecisionsupport v1.0.0

* [**Table of Contents**](toc.md)
* **Hem**

## Hem

| | |
| :--- | :--- |
| *Official URL*:https://fhir.inera.se/ig/processmanagement-decisionsupport-insurancemedicinedecisio/ImplementationGuide/inera.processmanagement-decisionsupport-insurancemedicinedecisio | *Version*:1.0.0 |
| Active as of 2026-11-09 | *Computable Name*:processmanagementdecisionsupportinsurancemedicinedecisio |
| **Copyright/Legal**: Copyright 2024 Inera AB. Licensieras under Creative Commons Attribution 4.0. | |

# processmanagement: decisionsupport: insurancemedicinedecisionsupport

**TKB-version:** 1.0 · **IG-version:** 1.0.0 · **Källa:** Bitbucket-commit `538dddbc8542`, efter taggen `processmanagement_decisionsupport_insurancemedicinedecisionsupport_1.0` 

## Översikt

* Beskrivning: Svenskt kortnamn
  * Syftet med denna tjänstedomän är att effektivisera processen kring sjukskrivningsbedömningar. Detta åstadkoms genom att domänen gör grundläggande information för sjukskrivningsbedömningar tillgänglig på ett strukturerat sätt, så att dessa kan integreras i informationssystem. Tjänstekontrakten inom domänen hanterar informationsflöden som kan; ge vägledning om vilka informationsmängder som är av vikt vid en sjukskrivningsbedömning, ge beslutsunderlag för sjukskrivningsbedömning baserat på de värden som anges, samt att ge övrig information om en diagnos som inte är kopplad till sjukskrivningsbedömningen - men som kan vara till stöd i sjukskrivningsprocessen.: försäkringsmedicinskt beslutsstöd
* Beskrivning: Svenskt namn
  * Syftet med denna tjänstedomän är att effektivisera processen kring sjukskrivningsbedömningar. Detta åstadkoms genom att domänen gör grundläggande information för sjukskrivningsbedömningar tillgänglig på ett strukturerat sätt, så att dessa kan integreras i informationssystem. Tjänstekontrakten inom domänen hanterar informationsflöden som kan; ge vägledning om vilka informationsmängder som är av vikt vid en sjukskrivningsbedömning, ge beslutsunderlag för sjukskrivningsbedömning baserat på de värden som anges, samt att ge övrig information om en diagnos som inte är kopplad till sjukskrivningsbedömningen - men som kan vara till stöd i sjukskrivningsprocessen.: operativ processtyrning:beslutsstöd:försäkringsmedicinskt beslutsstöd
* Beskrivning: Typ
  * Syftet med denna tjänstedomän är att effektivisera processen kring sjukskrivningsbedömningar. Detta åstadkoms genom att domänen gör grundläggande information för sjukskrivningsbedömningar tillgänglig på ett strukturerat sätt, så att dessa kan integreras i informationssystem. Tjänstekontrakten inom domänen hanterar informationsflöden som kan; ge vägledning om vilka informationsmängder som är av vikt vid en sjukskrivningsbedömning, ge beslutsunderlag för sjukskrivningsbedömning baserat på de värden som anges, samt att ge övrig information om en diagnos som inte är kopplad till sjukskrivningsbedömningen - men som kan vara till stöd i sjukskrivningsprocessen.: Nationell tjänstedomän
* Beskrivning: Källkod
  * Syftet med denna tjänstedomän är att effektivisera processen kring sjukskrivningsbedömningar. Detta åstadkoms genom att domänen gör grundläggande information för sjukskrivningsbedömningar tillgänglig på ett strukturerat sätt, så att dessa kan integreras i informationssystem. Tjänstekontrakten inom domänen hanterar informationsflöden som kan; ge vägledning om vilka informationsmängder som är av vikt vid en sjukskrivningsbedömning, ge beslutsunderlag för sjukskrivningsbedömning baserat på de värden som anges, samt att ge övrig information om en diagnos som inte är kopplad till sjukskrivningsbedömningen - men som kan vara till stöd i sjukskrivningsprocessen.: [Bitbucket](https://bitbucket.org/rivta-domains/riv.processmanagement.decisionsupport.insurancemedicinedecisio/src)
* Beskrivning: Ärenden
  * Syftet med denna tjänstedomän är att effektivisera processen kring sjukskrivningsbedömningar. Detta åstadkoms genom att domänen gör grundläggande information för sjukskrivningsbedömningar tillgänglig på ett strukturerat sätt, så att dessa kan integreras i informationssystem. Tjänstekontrakten inom domänen hanterar informationsflöden som kan; ge vägledning om vilka informationsmängder som är av vikt vid en sjukskrivningsbedömning, ge beslutsunderlag för sjukskrivningsbedömning baserat på de värden som anges, samt att ge övrig information om en diagnos som inte är kopplad till sjukskrivningsbedömningen - men som kan vara till stöd i sjukskrivningsprocessen.: [Bitbucket issues](https://bitbucket.org/rivta-domains/riv.processmanagement.decisionsupport.insurancemedicinedecisio/issues)
* Beskrivning: Underlag för denna IG
  * Syftet med denna tjänstedomän är att effektivisera processen kring sjukskrivningsbedömningar. Detta åstadkoms genom att domänen gör grundläggande information för sjukskrivningsbedömningar tillgänglig på ett strukturerat sätt, så att dessa kan integreras i informationssystem. Tjänstekontrakten inom domänen hanterar informationsflöden som kan; ge vägledning om vilka informationsmängder som är av vikt vid en sjukskrivningsbedömning, ge beslutsunderlag för sjukskrivningsbedömning baserat på de värden som anges, samt att ge övrig information om en diagnos som inte är kopplad till sjukskrivningsbedömningen - men som kan vara till stöd i sjukskrivningsprocessen.: Version 1.0 ·[tagg processmanagement_decisionsupport_insurancemedicinedecisionsupport_1.0](https://bitbucket.org/rivta-domains/riv.processmanagement.decisionsupport.insurancemedicinedecisio/src/processmanagement_decisionsupport_insurancemedicinedecisionsupport_1.0)·[zip](https://api.bitbucket.org/2.0/repositories/rivta-domains/riv.processmanagement.decisionsupport.insurancemedicinedecisio/src/master/docs/TKB_processmanagement_decisionsupport_insurancemedicinedecisionsupport.docx)
* Beskrivning: RIV-TA-portalen
  * Syftet med denna tjänstedomän är att effektivisera processen kring sjukskrivningsbedömningar. Detta åstadkoms genom att domänen gör grundläggande information för sjukskrivningsbedömningar tillgänglig på ett strukturerat sätt, så att dessa kan integreras i informationssystem. Tjänstekontrakten inom domänen hanterar informationsflöden som kan; ge vägledning om vilka informationsmängder som är av vikt vid en sjukskrivningsbedömning, ge beslutsunderlag för sjukskrivningsbedömning baserat på de värden som anges, samt att ge övrig information om en diagnos som inte är kopplad till sjukskrivningsbedömningen - men som kan vara till stöd i sjukskrivningsprocessen.: [Alla tjänstedomäner](https://oskthu2.github.io/tkb-converter/rivta-portal/tjanstedomaner.html)·[Alla tjänstekontrakt](https://oskthu2.github.io/tkb-converter/rivta-portal/tjanstekontrakt.html)

FHIR Implementation Guide för tjänstedomänen **processmanagement: decisionsupport: insurancemedicinedecisionsupport** version 1.0. Genererad från Ineras Tjänstekontraktsbeskrivning (TKB).

Domänen tillhandahåller strukturerad information som ligger till grund för försäkringsmedicinska sjukskrivningsbedömningar, inklusive det försäkringsmedicinska beslutsstödet (FMB) och diagnosinformation från Socialstyrelsen.

Domänen innehåller följande tjänstekontrakt:

| | | |
| :--- | :--- | :--- |
| [GetFmb](7-tjanstekontrakt.md#getfmb) | 1.0 | Hämtar beslutsunderlag från FMB (Försäkringsmedicinskt beslutsstöd) |
| [GetDiagnosInformation](7-tjanstekontrakt.md#getdiagnosinformation) | 1.0 | Returnerar generell information om diagnoser |
| [GetVersions](7-tjanstekontrakt.md#getversions) | 1.0 | Returnerar versionsinformation för FMB och diagnosinformation |

### Versioner och granskningar

| | | | |
| :--- | :--- | :--- | :--- |
| 1.0 | TKB, AB | Arkitektur & Regelverk: Teknik: GodkändArkitektur & Regelverk: Informatik: UnderkändArkitektur & Regelverk: Säkerhet: Godkänd | [zip](https://bitbucket.org/rivta-domains/riv.processmanagement.decisionsupport.insurancemedicinedecisio/get/processmanagement_decisionsupport_insurancemedicinedecisionsupport_1.0.zip)·[källkod](https://bitbucket.org/rivta-domains/riv.processmanagement.decisionsupport.insurancemedicinedecisio/src/processmanagement_decisionsupport_insurancemedicinedecisionsupport_1.0) |
| trunk | AB, TKB |  | [källkod](https://bitbucket.org/rivta-domains/riv.processmanagement.decisionsupport.insurancemedicinedecisio/src/master) |

*Zip-arkiven hämtas från taggarna på Bitbucket. Granskningsprotokollen publicerades på rivta.se och länkas inte härifrån.*

*Källa: ögonblicksbild av DOMDB från 2021-08-24, via RIV-TA-portalen.*

## Innehåll

* [1 Inledning](1-inledning.md)
* [2 Versionsinformation](2-versionsinformation.md)
* [3 Tjänstedomänens arkitektur](3-tjanstedomanens-arkitektur.md)
* [4 Tjänstedomänens krav och regler](4-tjanstedomanens-krav-och-regler.md)
* [5 Tjänstedomänens meddelandemodeller](5-tjanstedomanens-meddelandemodeller.md)
* [6 Gemensamma informationskomponenter](6-gemensamma-informationskomponenter.md)
* [7 Tjänstekontrakt](7-tjanstekontrakt.md)
* [Artefakter](artifacts.md)

