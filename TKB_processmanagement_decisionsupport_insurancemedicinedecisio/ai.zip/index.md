# Hem - processmanagement: decisionsupport: insurancemedicinedecisionsupport v1.0.0

* [**Table of Contents**](toc.md)
* **Hem**

## Hem

| | |
| :--- | :--- |
| *Official URL*:https://fhir.inera.se/ig/processmanagement-decisionsupport-insurancemedicinedecisio/ImplementationGuide/inera.processmanagement-decisionsupport-insurancemedicinedecisio | *Version*:1.0.0 |
| Draft as of 2026-09-17 | *Computable Name*:processmanagementdecisionsupportinsurancemedicinedecisio |
| **Copyright/Legal**: Copyright 2024 Inera AB. Licensieras under Creative Commons Attribution 4.0. | |

# processmanagement: decisionsupport: insurancemedicinedecisionsupport

## Översikt

FHIR Implementation Guide för tjänstedomänen **processmanagement: decisionsupport: insurancemedicinedecisionsupport** version 1.0. Genererad från Ineras Tjänstekontraktsbeskrivning (TKB).

Domänen tillhandahåller strukturerad information som ligger till grund för försäkringsmedicinska sjukskrivningsbedömningar, inklusive det försäkringsmedicinska beslutsstödet (FMB) och diagnosinformation från Socialstyrelsen.

Domänen innehåller följande tjänstekontrakt:

| | | |
| :--- | :--- | :--- |
| [GetFmb](7-tjanstekontrakt.md#getfmb) | 1.0 | Hämtar beslutsunderlag från FMB (Försäkringsmedicinskt beslutsstöd) |
| [GetDiagnosInformation](7-tjanstekontrakt.md#getdiagnosinformation) | 1.0 | Returnerar generell information om diagnoser |
| [GetVersions](7-tjanstekontrakt.md#getversions) | 1.0 | Returnerar versionsinformation för FMB och diagnosinformation |

## Innehåll

* [1 Inledning](1-inledning.md)
* [2 Versionsinformation](2-versionsinformation.md)
* [3 Tjänstedomänens arkitektur](3-tjanstedomanens-arkitektur.md)
* [4 Tjänstedomänens krav och regler](4-tjanstedomanens-krav-och-regler.md)
* [5 Tjänstedomänens meddelandemodeller](5-tjanstedomanens-meddelandemodeller.md)
* [6 Gemensamma informationskomponenter](6-gemensamma-informationskomponenter.md)
* [7 Tjänstekontrakt](7-tjanstekontrakt.md)
* [Artefakter](artifacts.md)

