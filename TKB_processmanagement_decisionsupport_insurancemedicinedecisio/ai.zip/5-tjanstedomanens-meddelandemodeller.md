# 5 Tjänstedomänens meddelandemodeller - processmanagement: decisionsupport: insurancemedicinedecisionsupport v1.0.0

* [**Table of Contents**](toc.md)
* **5 Tjänstedomänens meddelandemodeller**

## 5 Tjänstedomänens meddelandemodeller

# 5 Tjänstedomänens meddelandemodeller

Här beskrivs de meddelandemodeller som tjänstekontrakten bygger på. För varje meddelandemodell beskrivs hur mappning sker mot domäninformationsmodellen som återfinns i Informationsspecifikationen i de fall de skiljer sig åt. Skillnad i form av användning av a istället för å eller ä, samt o istället för ö tas inte med.

## V-MIM GetFMB-Request

![](img_004.png)

## V-MIM GetFMB-Response

![](img_005.png)

## V-MIM DiagnosInformation-Request

![](img_006.png)

## V-MIM DiagnosInformation-Response

![](img_007.png)

## V-MIM GetVersions-response

![](img_001.png)

## Mappning av MIM mot RIM

| | |
| :--- | :--- |
| beslutsunderlag.underlagsId | Saknar motsvarighet i RIM |
| beslutsunderlag.giltighetstid | Saknar motsvarighet i RIM |
| beslutsunderlag.version | Saknar motsvarighet i RIM |
| beslutsunderlag.textuelltUnderlag | Saknar motsvarighet i RIM |
| beslutsunderlag.sjukskrivningstidTest | Saknar motsvarighet i RIM |
| beslutsunderlag.sjukskrivningstid | Saknar motsvarighet i RIM |
| beslutsunderlag.sjukskrivningsgrad | Saknar motsvarighet i RIM |
| beslutsunderlag.senastAndrad | Saknar motsvarighet i RIM |
| rehabiliteringsInformation.beskrivning | Saknar motsvarighet i RIM |
| huvudDiagnos.värde | Huvuddiagnos.Värde |
| arbetsbelastning.kod | Observation.värde |
| komplicerandeFaktor.kod | Observation.värde |
| planeradAtgard.kod | Åtgärd.kod |
| pagaendeAtgard.kod | Åtgärd.kod |
| samsjuklighet.kod | Observation.värde |
| sjukdomsforlopp.kod | Observation.värde |
| svarighetsgrad.kod | Observation.värde |
| utfordAtgard.kod | Åtgärd.kod |
| diagnosInformation.informationsId | Saknar motsvarighet i RIM |
| diagnosInformation.giltighetsTid | Saknar motsvarighet i RIM |
| diagnosInformation.version | Saknar motsvarighet i RIM |
| diagnosInformation.rubrik | Saknar motsvarighet i RIM |
| diagnosInformation.aktivitetsbegransningBeskrivning | Saknar motsvarighet i RIM |
| diagnosInformation.funktionsnedsattningsBeskrivning | Saknar motsvarighet i RIM |
| diagnosInformation.senastAndrad | Saknar motsvarighet i RIM |
| huvuddiagnos.varde | Saknar motsvarighet i RIM |
| aktivitetsbegransning.kod | Observation.värde |
| funktionsnedsattning.kod | Observation.värde |
| ovrigFmbInformation.symtomPrognosBehandling | Saknar motsvarighet i RIM |
| ovrigFmbInformation.generellInformation | Saknar motsvarighet i RIM |

## Formatregler

### Tidsangivelser

Datum värdet är en sträng på formatet "ÅÅÅÅMMDDhhmmss" som matchar begränsad ISO 8601. Tidszon skall ej vara, alla tider anges i svensk normaltid respektive svensk normalsommartid.

