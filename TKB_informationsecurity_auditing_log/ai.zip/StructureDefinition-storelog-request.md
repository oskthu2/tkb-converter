# StoreLog — Request - informationsecurity: auditing: log v2.0.8

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **StoreLog — Request**

## Logical Model: StoreLog — Request 

| | |
| :--- | :--- |
| *Official URL*:https://fhir.inera.se/ig/informationsecurity-auditing-log/StructureDefinition/storelog-request | *Version*:2.0 |
| Active as of 2026-11-09 | *Computable Name*:StoreLogRequest |
| **Copyright/Legal**: Copyright 2024 Inera AB. Licensieras under Creative Commons Attribution 4.0. | |

 
Logisk modell för begäran i StoreLog (urn:riv:informationsecurity:auditing:log:StoreLogResponder:2, StoreLogType), inklusive SOAP-huvuden enligt WSDL. 

**Usages:**

* This Logical Model is not used by any profiles in this Specification

You can also check for [usages in the FHIR IG Statistics](https://packages2.fhir.org/xig/resource/inera.informationsecurity-auditing-log|current/StructureDefinition/StructureDefinition-storelog-request.json)

### Formal Views of Profile Content

 [Description of Profiles, Differentials, Snapshots and how the different presentations work](http://build.fhir.org/ig/FHIR/ig-guidance/readingIgs.html#structure-definitions). 

 

Other representations of profile: [CSV](StructureDefinition-storelog-request.csv), [Excel](StructureDefinition-storelog-request.xlsx) 



## Resource Content

```json
{
  "resourceType" : "StructureDefinition",
  "id" : "storelog-request",
  "extension" : [{
    "url" : "http://hl7.org/fhir/StructureDefinition/structuredefinition-type-characteristics",
    "valueCode" : "can-be-target"
  }],
  "url" : "https://fhir.inera.se/ig/informationsecurity-auditing-log/StructureDefinition/storelog-request",
  "version" : "2.0",
  "name" : "StoreLogRequest",
  "title" : "StoreLog — Request",
  "status" : "active",
  "date" : "2026-11-09T03:34:46+00:00",
  "contact" : [{
    "name" : "Inera Arkitektur",
    "telecom" : [{
      "system" : "url",
      "value" : "https://www.inera.se"
    }]
  }],
  "description" : "Logisk modell för begäran i StoreLog\n(urn:riv:informationsecurity:auditing:log:StoreLogResponder:2, StoreLogType), inklusive SOAP-huvuden enligt WSDL.",
  "copyright" : "Copyright 2024 Inera AB. Licensieras under Creative Commons Attribution 4.0.",
  "fhirVersion" : "4.0.1",
  "kind" : "logical",
  "abstract" : false,
  "type" : "https://fhir.inera.se/ig/informationsecurity-auditing-log/StructureDefinition/storelog-request",
  "baseDefinition" : "http://hl7.org/fhir/StructureDefinition/Base",
  "derivation" : "specialization",
  "differential" : {
    "element" : [{
      "id" : "storelog-request",
      "path" : "storelog-request",
      "short" : "StoreLog — Request",
      "definition" : "Logisk modell för begäran i StoreLog\n(urn:riv:informationsecurity:auditing:log:StoreLogResponder:2, StoreLogType), inklusive SOAP-huvuden enligt WSDL."
    },
    {
      "id" : "storelog-request.log",
      "path" : "storelog-request.log",
      "short" : "LogType",
      "definition" : "En kollektion av loggposter som ska lagras i loggtjänsten.",
      "comment" : "TKB-fält: `Log*` (`urn:riv:informationsecurity:auditing:log:2:LogType`, kardinalitet 1..*).",
      "min" : 1,
      "max" : "*",
      "type" : [{
        "code" : "Base"
      }]
    },
    {
      "id" : "storelog-request.log.logId",
      "path" : "storelog-request.log.logId",
      "short" : "logId",
      "definition" : "logId",
      "comment" : "TKB-fält: `../logId` (`Id`, kardinalitet 1..1).",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "storelog-request.log.system",
      "path" : "storelog-request.log.system",
      "short" : "SystemType",
      "definition" : "Datatyp som representerar ett system i loggposten. Det system som skapar loggposten.",
      "comment" : "TKB-fält: `../system` (`SystemType`, kardinalitet 1..1).",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "Base"
      }]
    },
    {
      "id" : "storelog-request.log.system.systemId",
      "path" : "storelog-request.log.system.systemId",
      "short" : "systemId",
      "definition" : "systemId",
      "comment" : "TKB-fält: `../../systemId` (`HsaId`, kardinalitet 1..1).",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "storelog-request.log.system.systemName",
      "path" : "storelog-request.log.system.systemName",
      "short" : "systemName",
      "definition" : "systemName",
      "comment" : "TKB-fält: `../../systemName` (`SystemName`, kardinalitet 0..1).",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "storelog-request.log.activity",
      "path" : "storelog-request.log.activity",
      "short" : "ActivityType",
      "definition" : "Datatyp som representerar vilken typ av aktivitet som utförts, på vilken nivå, tidpunkt samt syftet med aktiviteten.",
      "comment" : "TKB-fält: `../activity` (`ActivityType`, kardinalitet 1..1).",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "Base"
      }]
    },
    {
      "id" : "storelog-request.log.activity.activityType",
      "path" : "storelog-request.log.activity.activityType",
      "short" : "activityType",
      "definition" : "activityType",
      "comment" : "TKB-fält: `../../activityType` (`ActivityTypeValue`, kardinalitet 1..1).",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "storelog-request.log.activity.activityLevel",
      "path" : "storelog-request.log.activity.activityLevel",
      "short" : "activityLevel",
      "definition" : "activityLevel",
      "comment" : "TKB-fält: `../../activityLevel` (`ActivityLevel`, kardinalitet 0..1).",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "storelog-request.log.activity.activityArgs",
      "path" : "storelog-request.log.activity.activityArgs",
      "short" : "activityArgs",
      "definition" : "activityArgs",
      "comment" : "TKB-fält: `../../activityArgs` (`ActivityArgs`, kardinalitet 0..1).",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "storelog-request.log.activity.startDate",
      "path" : "storelog-request.log.activity.startDate",
      "short" : "startDate",
      "definition" : "startDate",
      "comment" : "TKB-fält: `../../startDate` (`dateTime`, kardinalitet 1..1).",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "dateTime"
      }]
    },
    {
      "id" : "storelog-request.log.activity.purpose",
      "path" : "storelog-request.log.activity.purpose",
      "short" : "purpose",
      "definition" : "purpose",
      "comment" : "TKB-fält: `../../purpose` (`PurposeDescription`, kardinalitet 1..1).",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "storelog-request.log.user",
      "path" : "storelog-request.log.user",
      "short" : "UserType",
      "definition" : "Datatyp som representerar användaren som utfört aktivitet, tillika ägare av loggpost.",
      "comment" : "TKB-fält: `../user` (`UserType`, kardinalitet 1..1).",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "Base"
      }]
    },
    {
      "id" : "storelog-request.log.user.userId",
      "path" : "storelog-request.log.user.userId",
      "short" : "userId",
      "definition" : "userId",
      "comment" : "TKB-fält: `../../userId` (`HsaId`, kardinalitet 1..1).",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "storelog-request.log.user.name",
      "path" : "storelog-request.log.user.name",
      "short" : "name",
      "definition" : "name",
      "comment" : "TKB-fält: `../../name` (`UserName`, kardinalitet 0..1).",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "storelog-request.log.user.personId",
      "path" : "storelog-request.log.user.personId",
      "short" : "personId",
      "definition" : "En universellt unik identifierare.",
      "comment" : "TKB-fält: `../../personId` (`IIType`, kardinalitet 0..1).",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "https://fhir.inera.se/ig/rivta-datatypes/StructureDefinition/IIType"
      }]
    },
    {
      "id" : "storelog-request.log.user.assignment",
      "path" : "storelog-request.log.user.assignment",
      "short" : "assignment",
      "definition" : "assignment",
      "comment" : "TKB-fält: `../../assignment` (`Assignment`, kardinalitet 0..1).",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "storelog-request.log.user.title",
      "path" : "storelog-request.log.user.title",
      "short" : "title",
      "definition" : "title",
      "comment" : "TKB-fält: `../../title` (`UserTitle`, kardinalitet 0..1).",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "storelog-request.log.user.careProvider",
      "path" : "storelog-request.log.user.careProvider",
      "short" : "CareProviderType",
      "definition" : "Datatyp som representerar en vårdgivare.",
      "comment" : "TKB-fält: `../../careProvider` (`CareProviderType`, kardinalitet 1..1).",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "Base"
      }]
    },
    {
      "id" : "storelog-request.log.user.careProvider.careProviderId",
      "path" : "storelog-request.log.user.careProvider.careProviderId",
      "short" : "careProviderId",
      "definition" : "careProviderId",
      "comment" : "TKB-fält: `../../../careProviderId` (`HsaId`, kardinalitet 1..1).",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "storelog-request.log.user.careProvider.careProviderName",
      "path" : "storelog-request.log.user.careProvider.careProviderName",
      "short" : "careProviderName",
      "definition" : "careProviderName",
      "comment" : "TKB-fält: `../../../careProviderName` (`CareProviderName`, kardinalitet 0..1).",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "storelog-request.log.user.careUnit",
      "path" : "storelog-request.log.user.careUnit",
      "short" : "CareUnitType",
      "definition" : "Datatyp som representerar en vårdenhet.",
      "comment" : "TKB-fält: `../../careUnit` (`CareUnitType`, kardinalitet 1..1).",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "Base"
      }]
    },
    {
      "id" : "storelog-request.log.user.careUnit.careUnitId",
      "path" : "storelog-request.log.user.careUnit.careUnitId",
      "short" : "careUnitId",
      "definition" : "careUnitId",
      "comment" : "TKB-fält: `../../../careUnitId` (`HsaId`, kardinalitet 1..1).",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "storelog-request.log.user.careUnit.careUnitName",
      "path" : "storelog-request.log.user.careUnit.careUnitName",
      "short" : "careUnitName",
      "definition" : "careUnitName",
      "comment" : "TKB-fält: `../../../careUnitName` (`CareUnitName`, kardinalitet 0..1).",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "storelog-request.log.resources",
      "path" : "storelog-request.log.resources",
      "short" : "ResourcesType",
      "definition" : "Information om aktuella resurser. En loggpost kan hålla en eller flera resurser.",
      "comment" : "TKB-fält: `../resources` (`ResourcesType`, kardinalitet 1..1).",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "Base"
      }]
    },
    {
      "id" : "storelog-request.log.resources.resource",
      "path" : "storelog-request.log.resources.resource",
      "short" : "ResourceType",
      "definition" : "Datatyp som representerar en resurs i loggposten.",
      "comment" : "TKB-fält: `../../resource` (`ResourceType`, kardinalitet 1..*).",
      "min" : 1,
      "max" : "*",
      "type" : [{
        "code" : "Base"
      }]
    },
    {
      "id" : "storelog-request.log.resources.resource.resourceType",
      "path" : "storelog-request.log.resources.resource.resourceType",
      "short" : "resourceType",
      "definition" : "resourceType",
      "comment" : "TKB-fält: `../../../resourceType` (`ResourceTypeValue`, kardinalitet 1..1).",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "storelog-request.log.resources.resource.patient",
      "path" : "storelog-request.log.resources.resource.patient",
      "short" : "PatientType",
      "definition" : "Datatyp som representerar en patient i en resurs.",
      "comment" : "TKB-fält: `../../../patient` (`PatientType`, kardinalitet 0..1).",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "Base"
      }]
    },
    {
      "id" : "storelog-request.log.resources.resource.patient.patientId",
      "path" : "storelog-request.log.resources.resource.patient.patientId",
      "short" : "patientId",
      "definition" : "En universellt unik identifierare.",
      "comment" : "TKB-fält: `../../../../patientId` (`IIType`, kardinalitet 1..1).",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "https://fhir.inera.se/ig/rivta-datatypes/StructureDefinition/IIType"
      }]
    },
    {
      "id" : "storelog-request.log.resources.resource.patient.patientName",
      "path" : "storelog-request.log.resources.resource.patient.patientName",
      "short" : "patientName",
      "definition" : "patientName",
      "comment" : "TKB-fält: `../../../../patientName` (`PatientName`, kardinalitet 0..1).",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "storelog-request.log.resources.resource.careProvider",
      "path" : "storelog-request.log.resources.resource.careProvider",
      "short" : "CareProviderType",
      "definition" : "Datatyp som representerar en vårdgivare.",
      "comment" : "TKB-fält: `../../../careProvider` (`CareProviderType`, kardinalitet 1..1).",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "Base"
      }]
    },
    {
      "id" : "storelog-request.log.resources.resource.careProvider.careProviderId",
      "path" : "storelog-request.log.resources.resource.careProvider.careProviderId",
      "short" : "careProviderId",
      "definition" : "careProviderId",
      "comment" : "TKB-fält: `../../../../careProviderId` (`HsaId`, kardinalitet 1..1).",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "storelog-request.log.resources.resource.careProvider.careProviderName",
      "path" : "storelog-request.log.resources.resource.careProvider.careProviderName",
      "short" : "careProviderName",
      "definition" : "careProviderName",
      "comment" : "TKB-fält: `../../../../careProviderName` (`CareProviderName`, kardinalitet 0..1).",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "storelog-request.log.resources.resource.careUnit",
      "path" : "storelog-request.log.resources.resource.careUnit",
      "short" : "CareUnitType",
      "definition" : "Datatyp som representerar en vårdenhet.",
      "comment" : "TKB-fält: `../../../careUnit` (`CareUnitType`, kardinalitet 0..1).",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "Base"
      }]
    },
    {
      "id" : "storelog-request.log.resources.resource.careUnit.careUnitId",
      "path" : "storelog-request.log.resources.resource.careUnit.careUnitId",
      "short" : "careUnitId",
      "definition" : "careUnitId",
      "comment" : "TKB-fält: `../../../../careUnitId` (`HsaId`, kardinalitet 1..1).",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "storelog-request.log.resources.resource.careUnit.careUnitName",
      "path" : "storelog-request.log.resources.resource.careUnit.careUnitName",
      "short" : "careUnitName",
      "definition" : "careUnitName",
      "comment" : "TKB-fält: `../../../../careUnitName` (`CareUnitName`, kardinalitet 0..1).",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    }]
  }
}

```
