# Hem - informationsecurity: auditing: log v2.0.8

* [**Table of Contents**](toc.md)
* **Hem**

## Hem

| | |
| :--- | :--- |
| *Official URL*:https://fhir.inera.se/ig/informationsecurity-auditing-log/ImplementationGuide/inera.informationsecurity-auditing-log | *Version*:2.0.8 |
| Active as of 2026-10-12 | *Computable Name*:informationsecurityauditinglog |
| **Copyright/Legal**: Copyright 2024 Inera AB. Licensieras under Creative Commons Attribution 4.0. | |

# informationsecurity: auditing: log

**TKB-version:** 2.0.8 · **IG-version:** 2.0.8 · **Källa:** Bitbucket-tagg `2.0.8` 

## Översikt

* Beskrivning: Svenskt kortnamn
  * Logghantering lagrar information om åtkomstrelaterade händelser från olika system på ett strukturerat sätt, och används av system och tjänster som till exempel NPÖ och Pascal. Syftet är att man i efterhand ska kunna se vem som tagit del av vilken patientinformation. Tjänstekontrakten för Logghantering säkerställer att uppföljning av åtkomst till journaluppgifter sker på ett enhetligt sätt, och enligt de lagar och förordningar som gäller. Tjänstekontrakten gör det också möjligt för patienten/medborgaren att själv kunna få se vilka vårdgivare som har haft åtkomst till patientens journaler via till exempel Journalen på 1177 Vårdguidens e-tjänster.: loggtjänst
* Beskrivning: Svenskt namn
  * Logghantering lagrar information om åtkomstrelaterade händelser från olika system på ett strukturerat sätt, och används av system och tjänster som till exempel NPÖ och Pascal. Syftet är att man i efterhand ska kunna se vem som tagit del av vilken patientinformation. Tjänstekontrakten för Logghantering säkerställer att uppföljning av åtkomst till journaluppgifter sker på ett enhetligt sätt, och enligt de lagar och förordningar som gäller. Tjänstekontrakten gör det också möjligt för patienten/medborgaren att själv kunna få se vilka vårdgivare som har haft åtkomst till patientens journaler via till exempel Journalen på 1177 Vårdguidens e-tjänster.: informationssäkerhet:uppföljning:åtkomstlogg
* Beskrivning: Typ
  * Logghantering lagrar information om åtkomstrelaterade händelser från olika system på ett strukturerat sätt, och används av system och tjänster som till exempel NPÖ och Pascal. Syftet är att man i efterhand ska kunna se vem som tagit del av vilken patientinformation. Tjänstekontrakten för Logghantering säkerställer att uppföljning av åtkomst till journaluppgifter sker på ett enhetligt sätt, och enligt de lagar och förordningar som gäller. Tjänstekontrakten gör det också möjligt för patienten/medborgaren att själv kunna få se vilka vårdgivare som har haft åtkomst till patientens journaler via till exempel Journalen på 1177 Vårdguidens e-tjänster.: Nationell tjänstedomän
* Beskrivning: Källkod
  * Logghantering lagrar information om åtkomstrelaterade händelser från olika system på ett strukturerat sätt, och används av system och tjänster som till exempel NPÖ och Pascal. Syftet är att man i efterhand ska kunna se vem som tagit del av vilken patientinformation. Tjänstekontrakten för Logghantering säkerställer att uppföljning av åtkomst till journaluppgifter sker på ett enhetligt sätt, och enligt de lagar och förordningar som gäller. Tjänstekontrakten gör det också möjligt för patienten/medborgaren att själv kunna få se vilka vårdgivare som har haft åtkomst till patientens journaler via till exempel Journalen på 1177 Vårdguidens e-tjänster.: [Bitbucket](https://bitbucket.org/rivta-domains/riv.informationsecurity.auditing.log/src)
* Beskrivning: Underlag för denna IG
  * Logghantering lagrar information om åtkomstrelaterade händelser från olika system på ett strukturerat sätt, och används av system och tjänster som till exempel NPÖ och Pascal. Syftet är att man i efterhand ska kunna se vem som tagit del av vilken patientinformation. Tjänstekontrakten för Logghantering säkerställer att uppföljning av åtkomst till journaluppgifter sker på ett enhetligt sätt, och enligt de lagar och förordningar som gäller. Tjänstekontrakten gör det också möjligt för patienten/medborgaren att själv kunna få se vilka vårdgivare som har haft åtkomst till patientens journaler via till exempel Journalen på 1177 Vårdguidens e-tjänster.: Version 2.0.8 ·[tagg 2.0.8](https://bitbucket.org/rivta-domains/riv.informationsecurity.auditing.log/src/2.0.8)·[zip](https://bitbucket.org/rivta-domains/riv.informationsecurity.auditing.log/get/2.0.8.zip)
* Beskrivning: RIV-TA-portalen
  * Logghantering lagrar information om åtkomstrelaterade händelser från olika system på ett strukturerat sätt, och används av system och tjänster som till exempel NPÖ och Pascal. Syftet är att man i efterhand ska kunna se vem som tagit del av vilken patientinformation. Tjänstekontrakten för Logghantering säkerställer att uppföljning av åtkomst till journaluppgifter sker på ett enhetligt sätt, och enligt de lagar och förordningar som gäller. Tjänstekontrakten gör det också möjligt för patienten/medborgaren att själv kunna få se vilka vårdgivare som har haft åtkomst till patientens journaler via till exempel Journalen på 1177 Vårdguidens e-tjänster.: [Alla tjänstedomäner](https://oskthu2.github.io/tkb-converter/rivta-portal/tjanstedomaner.html)·[Alla tjänstekontrakt](https://oskthu2.github.io/tkb-converter/rivta-portal/tjanstekontrakt.html)

FHIR Implementation Guide för tjänstedomänen **informationsecurity: auditing: log** (Loggtjänst, Informationssäkerhet: Uppföljning: Åtkomstlogg) version 2.0.8. Genererad från Ineras Tjänstekontraktsbeskrivning (TKB), version 2.0.8 (2024-10-24), och domänens WSDL- och XSD-filer (tagg 2.0.8).

Domänen standardiserar informationsutbytet med loggtjänster: registrering av åtkomstloggar enligt patientdatalagen och uppföljning av dem ur patientens, vårdgivarens och informationsägarens perspektiv.

Domänen innehåller följande tjänstekontrakt:

| | | |
| :--- | :--- | :--- |
| [StoreLog](7-tjanstekontrakt.md#storelog) | 2.0 | Tjänst som sparar en eller flera loggposter i loggtjänsten för att möjliggöra uppföljning enligt PDL. Loggposter ska sparas i ett arkiv med löpnummer samt signeras för att säkerställa integriteten av loggposter. |
| [GetLogs](7-tjanstekontrakt.md#getlogs) | 2.0 | Tjänst som returnerar loggposter utifrån angivna sökkriterier, all åtkomst som har skett av vårdgivarens medarbetare. |
| [GetAccessLogsForPatient](7-tjanstekontrakt.md#getaccesslogsforpatient) | 2.0 | Tjänst som returnerar lista för angiven patient, vilka vårdgivare och vårdaktör som har haft åtkomst till information. Informationen som returneras innehåller även tidpunkt, syfte och typ av resurs. |
| [GetInfoLogs](7-tjanstekontrakt.md#getinfologs) | 2.0 | Tjänst som returnerar loggposter utifrån angivna sökkriterier, vilka vårdgivare som har haft åtkomst till vårdgivarens information där vårdgivaren är informationsägare. |
| [GetLogsByOrder](7-tjanstekontrakt.md#getlogsbyorder) | 1.0 | En tjänst som returnerar ett unikt ordernummer (order-id) vilket senare kan användas för anrop av tjänsten GetFilesForOrderId för att från denna tjänst erhålla ett unikt URL, vilket man sedan kan använda för att via REST-anrop hämta hem de filer som har skapats av GetLogsByOrder, se kap 3.1.5. |
| [GetFilesForOrderId](7-tjanstekontrakt.md#getfilesfororderid) | 1.0 | Tjänst för få en adress (URL) utifrån ett givet OrderId, där man kan hämta begärda data. Till exempel personposter utifrån en tidigare begärd sökning med tjänsten SearchPersonsForProfileByOrder eller förändrade personposter. |

### Versioner och granskningar

| | | | |
| :--- | :--- | :--- | :--- |
| 2.0.4 | IS, TKB, AB | [Arkitektur & Regelverk: Informatik: Godkänd](http://rivta.se/downloads//informationsecurity_auditing_log/2.0.4/VIS_granskning%20-%20informationsecurity_auditing_log_2.0.4.docx)[Arkitektur & Regelverk: Teknik: Godkänd](http://rivta.se/downloads//informationsecurity_auditing_log/2.0.4/T-granskning_informationsecurity_auditing_log_2.0.4.docx)[Arkitektur & Regelverk: Säkerhet: Godkänd](http://rivta.se/downloads//informationsecurity_auditing_log/2.0.4/VIS_granskning%20-%20informationsecurity_auditing_log_2.0.4.docx) | [zip](http://rivta.se/downloads//informationsecurity_auditing_log/2.0.4/ServiceContracts_informationsecurity_auditing_log_2.0.4.zip)·[källkod](https://bitbucket.org/rivta-domains/riv.informationsecurity.auditing.log/src/2.0.4) |
| trunk |  |  |  |

*Källa: ögonblicksbild av DOMDB från 2021-08-24, via RIV-TA-portalen.*

## Innehåll

* [1 Inledning](1-inledning.md)
* [2 Versionsinformation](2-versionsinformation.md)
* [3 Tjänstedomänens arkitektur](3-tjanstedomanens-arkitektur.md)
* [4 Tjänstedomänens krav och regler](4-tjanstedomanens-krav-och-regler.md)
* [5 Tjänstedomänens meddelandemodeller](5-tjanstedomanens-meddelandemodeller.md)
* [6 Gemensamma informationskomponenter](6-gemensamma-informationskomponenter.md)
* [7 Tjänstekontrakt](7-tjanstekontrakt.md)
* [Artefakter](artifacts.md)

