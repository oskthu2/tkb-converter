# GetAccessLogsForPatient — Response - informationsecurity: auditing: log v2.0.8

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **GetAccessLogsForPatient — Response**

## Logical Model: GetAccessLogsForPatient — Response 

| | |
| :--- | :--- |
| *Official URL*:https://fhir.inera.se/ig/informationsecurity-auditing-log/StructureDefinition/getaccesslogsforpatient | *Version*:2.0.8 |
| Draft as of 2026-09-28 | *Computable Name*:GetAccessLogsForPatient |
| **Copyright/Legal**: Copyright 2024 Inera AB. Licensieras under Creative Commons Attribution 4.0. | |

 
Logisk modell för svaret i GetAccessLogsForPatient (urn:riv:informationsecurity:auditing:log:GetAccessLogsForPatientResponder:2, GetAccessLogsForPatientResponseType). 

**Usages:**

* This Logical Model is not used by any profiles in this Specification

You can also check for [usages in the FHIR IG Statistics](https://packages2.fhir.org/xig/resource/inera.informationsecurity-auditing-log|current/StructureDefinition/StructureDefinition-getaccesslogsforpatient.json)

### Formal Views of Profile Content

 [Description of Profiles, Differentials, Snapshots and how the different presentations work](http://build.fhir.org/ig/FHIR/ig-guidance/readingIgs.html#structure-definitions). 

 

Other representations of profile: [CSV](StructureDefinition-getaccesslogsforpatient.csv), [Excel](StructureDefinition-getaccesslogsforpatient.xlsx) 



## Resource Content

```json
{
  "resourceType" : "StructureDefinition",
  "id" : "getaccesslogsforpatient",
  "extension" : [{
    "url" : "http://hl7.org/fhir/StructureDefinition/structuredefinition-type-characteristics",
    "valueCode" : "can-be-target"
  }],
  "url" : "https://fhir.inera.se/ig/informationsecurity-auditing-log/StructureDefinition/getaccesslogsforpatient",
  "version" : "2.0.8",
  "name" : "GetAccessLogsForPatient",
  "title" : "GetAccessLogsForPatient — Response",
  "status" : "draft",
  "date" : "2026-09-28T09:01:27+00:00",
  "contact" : [{
    "name" : "Inera Arkitektur",
    "telecom" : [{
      "system" : "url",
      "value" : "https://www.inera.se"
    }]
  }],
  "description" : "Logisk modell för svaret i GetAccessLogsForPatient\n(urn:riv:informationsecurity:auditing:log:GetAccessLogsForPatientResponder:2, GetAccessLogsForPatientResponseType).",
  "copyright" : "Copyright 2024 Inera AB. Licensieras under Creative Commons Attribution 4.0.",
  "fhirVersion" : "4.0.1",
  "kind" : "logical",
  "abstract" : false,
  "type" : "https://fhir.inera.se/ig/informationsecurity-auditing-log/StructureDefinition/getaccesslogsforpatient",
  "baseDefinition" : "http://hl7.org/fhir/StructureDefinition/Base",
  "derivation" : "specialization",
  "differential" : {
    "element" : [{
      "id" : "getaccesslogsforpatient",
      "path" : "getaccesslogsforpatient",
      "short" : "GetAccessLogsForPatient — Response",
      "definition" : "Logisk modell för svaret i GetAccessLogsForPatient\n(urn:riv:informationsecurity:auditing:log:GetAccessLogsForPatientResponder:2, GetAccessLogsForPatientResponseType)."
    },
    {
      "id" : "getaccesslogsforpatient.accessLogsResult",
      "path" : "getaccesslogsforpatient.accessLogsResult",
      "short" : "accessLogsResult",
      "definition" : "Datatyp som returneras av tjänst. accessLogs ej satt vid eventuella fel.",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "BackboneElement"
      }]
    },
    {
      "id" : "getaccesslogsforpatient.accessLogsResult.reportResult",
      "path" : "getaccesslogsforpatient.accessLogsResult.reportResult",
      "short" : "reportResult",
      "definition" : "reportResult",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "BackboneElement"
      }]
    },
    {
      "id" : "getaccesslogsforpatient.accessLogsResult.reportResult.result",
      "path" : "getaccesslogsforpatient.accessLogsResult.reportResult.result",
      "short" : "result",
      "definition" : "Datatyp som returneras som ett generellt svar från alla förändrande tjänster, t.ex. skapa, radera, etc. En anropande klient skall alltid kontrollera att resultatkoden inte innehåller fel för att på så sätt veta om anropet lyckades. Alla svarskoder förutom OK och INFO betyder att åtgärden inte genomfördes.",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "BackboneElement"
      }]
    },
    {
      "id" : "getaccesslogsforpatient.accessLogsResult.reportResult.result.resultCode",
      "path" : "getaccesslogsforpatient.accessLogsResult.reportResult.result.resultCode",
      "short" : "resultCode",
      "definition" : "resultCode",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "code"
      }],
      "binding" : {
        "strength" : "required",
        "valueSet" : "https://fhir.inera.se/ig/informationsecurity-auditing-log/ValueSet/auditing-log-resultcode-vs"
      }
    },
    {
      "id" : "getaccesslogsforpatient.accessLogsResult.reportResult.result.resultText",
      "path" : "getaccesslogsforpatient.accessLogsResult.reportResult.result.resultText",
      "short" : "resultText",
      "definition" : "resultText",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "getaccesslogsforpatient.accessLogsResult.reportResult.startInterval",
      "path" : "getaccesslogsforpatient.accessLogsResult.reportResult.startInterval",
      "short" : "startInterval",
      "definition" : "startInterval",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "dateTime"
      }]
    },
    {
      "id" : "getaccesslogsforpatient.accessLogsResult.reportResult.endInterval",
      "path" : "getaccesslogsforpatient.accessLogsResult.reportResult.endInterval",
      "short" : "endInterval",
      "definition" : "endInterval",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "dateTime"
      }]
    },
    {
      "id" : "getaccesslogsforpatient.accessLogsResult.reportResult.queuedReportId",
      "path" : "getaccesslogsforpatient.accessLogsResult.reportResult.queuedReportId",
      "short" : "queuedReportId",
      "definition" : "queuedReportId",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "getaccesslogsforpatient.accessLogsResult.reportResult.queueTime",
      "path" : "getaccesslogsforpatient.accessLogsResult.reportResult.queueTime",
      "short" : "queueTime",
      "definition" : "queueTime",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "integer"
      }]
    },
    {
      "id" : "getaccesslogsforpatient.accessLogsResult.accesssLogs",
      "path" : "getaccesslogsforpatient.accessLogsResult.accesssLogs",
      "short" : "accesssLogs",
      "definition" : "Datatyp som håller lista med Access loggar. Kan vara en tom lista.",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "BackboneElement"
      }]
    },
    {
      "id" : "getaccesslogsforpatient.accessLogsResult.accesssLogs.accessLog",
      "path" : "getaccesslogsforpatient.accessLogsResult.accesssLogs.accessLog",
      "short" : "accessLog",
      "definition" : "Datatyp som håller information för vilken vårdgivare och vårdenhet som haft åtkomst samt typ av resurs, orsak och tidpunkt.",
      "min" : 0,
      "max" : "*",
      "type" : [{
        "code" : "BackboneElement"
      }]
    },
    {
      "id" : "getaccesslogsforpatient.accessLogsResult.accesssLogs.accessLog.careProviderId",
      "path" : "getaccesslogsforpatient.accessLogsResult.accesssLogs.accessLog.careProviderId",
      "short" : "careProviderId",
      "definition" : "careProviderId",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "getaccesslogsforpatient.accessLogsResult.accesssLogs.accessLog.careProviderName",
      "path" : "getaccesslogsforpatient.accessLogsResult.accesssLogs.accessLog.careProviderName",
      "short" : "careProviderName",
      "definition" : "careProviderName",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "getaccesslogsforpatient.accessLogsResult.accesssLogs.accessLog.careUnitId",
      "path" : "getaccesslogsforpatient.accessLogsResult.accesssLogs.accessLog.careUnitId",
      "short" : "careUnitId",
      "definition" : "careUnitId",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "getaccesslogsforpatient.accessLogsResult.accesssLogs.accessLog.careUnitName",
      "path" : "getaccesslogsforpatient.accessLogsResult.accesssLogs.accessLog.careUnitName",
      "short" : "careUnitName",
      "definition" : "careUnitName",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "getaccesslogsforpatient.accessLogsResult.accesssLogs.accessLog.accessDate",
      "path" : "getaccesslogsforpatient.accessLogsResult.accesssLogs.accessLog.accessDate",
      "short" : "accessDate",
      "definition" : "accessDate",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "dateTime"
      }]
    },
    {
      "id" : "getaccesslogsforpatient.accessLogsResult.accesssLogs.accessLog.userId",
      "path" : "getaccesslogsforpatient.accessLogsResult.accesssLogs.accessLog.userId",
      "short" : "userId",
      "definition" : "userId",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "getaccesslogsforpatient.accessLogsResult.accesssLogs.accessLog.userName",
      "path" : "getaccesslogsforpatient.accessLogsResult.accesssLogs.accessLog.userName",
      "short" : "userName",
      "definition" : "userName",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "getaccesslogsforpatient.accessLogsResult.accesssLogs.accessLog.userTitle",
      "path" : "getaccesslogsforpatient.accessLogsResult.accesssLogs.accessLog.userTitle",
      "short" : "userTitle",
      "definition" : "userTitle",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "getaccesslogsforpatient.accessLogsResult.accesssLogs.accessLog.purpose",
      "path" : "getaccesslogsforpatient.accessLogsResult.accesssLogs.accessLog.purpose",
      "short" : "purpose",
      "definition" : "purpose",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "getaccesslogsforpatient.accessLogsResult.accesssLogs.accessLog.resourceType",
      "path" : "getaccesslogsforpatient.accessLogsResult.accesssLogs.accessLog.resourceType",
      "short" : "resourceType",
      "definition" : "resourceType",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    }]
  }
}

```
