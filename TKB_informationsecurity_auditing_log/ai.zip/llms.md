# inera.informationsecurity-auditing-log#2.0.8: informationsecurity: auditing: log

## Pages

* [Hem](index.md)
* [7 Tjänstekontrakt](7-tjanstekontrakt.md)
* [5 Tjänstedomänens meddelandemodeller](5-tjanstedomanens-meddelandemodeller.md)
* [Artifacts Summary](artifacts.md)
* [6 Gemensamma informationskomponenter](6-gemensamma-informationskomponenter.md)
* [3 Tjänstedomänens arkitektur](3-tjanstedomanens-arkitektur.md)
* [4 Tjänstedomänens krav och regler](4-tjanstedomanens-krav-och-regler.md)
* [2 Versionsinformation](2-versionsinformation.md)
* [1 Inledning](1-inledning.md)

## Resources

### CodeSystems

* [ResultCode](CodeSystem-auditing-log-resultcode-cs.md)

### ValueSets

* [ResultCode](ValueSet-auditing-log-resultcode-vs.md)

### Logicals

* [GetAccessLogsForPatient — Request](StructureDefinition-getaccesslogsforpatient-request.md)
* [GetAccessLogsForPatient — Response](StructureDefinition-getaccesslogsforpatient.md)
* [GetFilesForOrderId — Request](StructureDefinition-getfilesfororderid-request.md)
* [GetFilesForOrderId — Response](StructureDefinition-getfilesfororderid.md)
* [GetInfoLogs — Request](StructureDefinition-getinfologs-request.md)
* [GetInfoLogs — Response](StructureDefinition-getinfologs.md)
* [GetLogs — Request](StructureDefinition-getlogs-request.md)
* [GetLogs — Response](StructureDefinition-getlogs.md)
* [GetLogsByOrder — Request](StructureDefinition-getlogsbyorder-request.md)
* [GetLogsByOrder — Response](StructureDefinition-getlogsbyorder.md)
* [StoreLog — Request](StructureDefinition-storelog-request.md)
* [StoreLog — Response](StructureDefinition-storelog.md)

### ImplementationGuides

* [informationsecurity: auditing: log](index.md)
