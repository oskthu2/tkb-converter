# inera.se-apotekensservice-pris#2.0.0: se.apotekensservice: pris — Pris och högkostnadsskydd

## Pages

* [Hem](index.md)
* [7 Tjänstekontrakt](7-tjanstekontrakt.md)
* [5 Tjänstedomänens meddelandemodeller](5-tjanstedomanens-meddelandemodeller.md)
* [Artifacts Summary](artifacts.md)
* [6 Gemensamma informationskomponenter](6-gemensamma-informationskomponenter.md)
* [3 Tjänstedomänens arkitektur](3-tjanstedomanens-arkitektur.md)
* [4 Tjänstedomänens krav och regler](4-tjanstedomanens-krav-och-regler.md)
* [2 Versionsinformation](2-versionsinformation.md)
* [1 Inledning](1-inledning.md)

## Resources

### Logicals

* [HamtaBarn — Request](StructureDefinition-hamtabarn-request.md)
* [HamtaBarn — Response](StructureDefinition-hamtabarn.md)
* [HamtaHkdbKonto — Request](StructureDefinition-hamtahkdbkonto-request.md)
* [HamtaHkdbKonto — Response](StructureDefinition-hamtahkdbkonto.md)
* [HamtaHkdbTransaktioner — Request](StructureDefinition-hamtahkdbtransaktioner-request.md)
* [HamtaHkdbTransaktioner — Response](StructureDefinition-hamtahkdbtransaktioner.md)
* [HamtaHkdbTransaktionerWebb — Request](StructureDefinition-hamtahkdbtransaktionerwebb-request.md)
* [HamtaHkdbTransaktionerWebb — Response](StructureDefinition-hamtahkdbtransaktionerwebb.md)
* [KontrolleraForman — Request](StructureDefinition-kontrolleraforman-request.md)
* [KontrolleraForman — Response](StructureDefinition-kontrolleraforman.md)
* [KopplaBarnKonto — Request](StructureDefinition-kopplabarnkonto-request.md)
* [KopplaBarnKonto — Response](StructureDefinition-kopplabarnkonto.md)
* [Prisfraga — Request](StructureDefinition-prisfraga-request.md)
* [Prisfraga — Response](StructureDefinition-prisfraga.md)
* [RegistreraHkdbTransaktion — Request](StructureDefinition-registrerahkdbtransaktion-request.md)
* [RegistreraHkdbTransaktion — Response](StructureDefinition-registrerahkdbtransaktion.md)
* [SkapaHkdbKonto — Request](StructureDefinition-skapahkdbkonto-request.md)
* [SkapaHkdbKonto — Response](StructureDefinition-skapahkdbkonto.md)
* [TaBortHkdbKonto — Request](StructureDefinition-taborthkdbkonto-request.md)
* [TaBortHkdbKonto — Response](StructureDefinition-taborthkdbkonto.md)

### ImplementationGuides

* [se.apotekensservice: pris — Pris och högkostnadsskydd](index.md)
