# Hem - se.apotekensservice: pris — Pris och högkostnadsskydd v2.0.0

* [**Table of Contents**](toc.md)
* **Hem**

## Hem

| | |
| :--- | :--- |
| *Official URL*:https://fhir.inera.se/ig/se-apotekensservice-pris/ImplementationGuide/inera.se-apotekensservice-pris | *Version*:2.0.0 |
| Draft as of 2026-09-26 | *Computable Name*:seapotekensservicepris |
| **Copyright/Legal**: Copyright 2024 Inera AB. Licensieras under Creative Commons Attribution 4.0. | |

# se.apotekensservice: pris — Pris och högkostnadsskydd

## Översikt

FHIR Implementation Guide för tjänstedomänen **se: apotekensservice: pris** version 2.0. Domänen förvaltas av eHälsomyndigheten (tidigare Apotekens Service AB) och innehåller tjänster för prisberäkning vid receptexpedition, kontroll av förmånskod, samt hantering av konton och transaktioner i högkostnadsdatabasen (HKDB), inklusive koppling av barns konton till vårdnadshavares.

**Observera:** källan innehåller ingen tjänstekontraktsbeskrivning (TKB). Denna IG är därför uppbyggd från domänens scheman (XSD/WSDL) och dess dokument med arkitekturella beslut. Avsnitt som i andra IG:er hämtas ur TKB:n är markerade med **SAKNAS I KÄLLDOKUMENT**. Beskrivningar av fält är hämtade ur schemaannoteringarna.

RIV-TA namnrymd: `urn:riv:se.apotekensservice:pris`

Domänen innehåller följande tjänstekontrakt:

| | | |
| :--- | :--- | :--- |
| [HamtaBarn](7-tjanstekontrakt.md#hamtabarn) | 1.0 | Fråga-svar |
| [HamtaHkdbKonto](7-tjanstekontrakt.md#hamtahkdbkonto) | 1.0 | Fråga-svar |
| [HamtaHkdbTransaktioner](7-tjanstekontrakt.md#hamtahkdbtransaktioner) | 1.0 | Fråga-svar |
| [HamtaHkdbTransaktionerWebb](7-tjanstekontrakt.md#hamtahkdbtransaktionerwebb) | 1.0 | Fråga-svar |
| [KontrolleraForman](7-tjanstekontrakt.md#kontrolleraforman) | 1.1 | Fråga-svar |
| [KopplaBarnKonto](7-tjanstekontrakt.md#kopplabarnkonto) | 4.0 | Fråga-svar |
| [Prisfraga](7-tjanstekontrakt.md#prisfraga) | 4.1 | Fråga-svar |
| [RegistreraHkdbTransaktion](7-tjanstekontrakt.md#registrerahkdbtransaktion) | 1.1 | Fråga-svar |
| [SkapaHkdbKonto](7-tjanstekontrakt.md#skapahkdbkonto) | 4.0 | Fråga-svar |
| [TaBortHkdbKonto](7-tjanstekontrakt.md#taborthkdbkonto) | 1.0 | Fråga-svar |

**Källa:** Bitbucket `rivta-domains/riv.se.apotekensservice.pris`, tagg `2.0_RC1` (commit `1cd10e788bdd`, 2017-01-26), samma commit som `master`. Det finns ingen fastställd 2.0-tagg; senaste fastställda är `1.0.0` (2011-09-06).

## Innehåll

* [1 Inledning](1-inledning.md)
* [2 Versionsinformation](2-versionsinformation.md)
* [3 Tjänstedomänens arkitektur](3-tjanstedomanens-arkitektur.md)
* [4 Tjänstedomänens krav och regler](4-tjanstedomanens-krav-och-regler.md)
* [5 Tjänstedomänens meddelandemodeller](5-tjanstedomanens-meddelandemodeller.md)
* [6 Gemensamma informationskomponenter](6-gemensamma-informationskomponenter.md)
* [7 Tjänstekontrakt](7-tjanstekontrakt.md)
* [Artefakter](artifacts.md)

