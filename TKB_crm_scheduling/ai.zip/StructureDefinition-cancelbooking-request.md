# CancelBooking — Request - crm: scheduling v1.1.6

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **CancelBooking — Request**

## Logical Model: CancelBooking — Request 

| | |
| :--- | :--- |
| *Official URL*:https://fhir.inera.se/ig/crm-scheduling/StructureDefinition/cancelbooking-request | *Version*:1.1 |
| Active as of 2026-11-09 | *Computable Name*:CancelBookingRequest |
| **Copyright/Legal**: Copyright 2024 Inera AB. Licensieras under Creative Commons Attribution 4.0. | |

 
Logisk modell för requestparametrar i CancelBooking. 

**Usages:**

* This Logical Model is not used by any profiles in this Specification

You can also check for [usages in the FHIR IG Statistics](https://packages2.fhir.org/xig/resource/inera.crm-scheduling|current/StructureDefinition/StructureDefinition-cancelbooking-request.json)

### Formal Views of Profile Content

 [Description of Profiles, Differentials, Snapshots and how the different presentations work](http://build.fhir.org/ig/FHIR/ig-guidance/readingIgs.html#structure-definitions). 

 

Other representations of profile: [CSV](StructureDefinition-cancelbooking-request.csv), [Excel](StructureDefinition-cancelbooking-request.xlsx) 



## Resource Content

```json
{
  "resourceType" : "StructureDefinition",
  "id" : "cancelbooking-request",
  "extension" : [{
    "url" : "http://hl7.org/fhir/StructureDefinition/structuredefinition-type-characteristics",
    "valueCode" : "can-be-target"
  }],
  "url" : "https://fhir.inera.se/ig/crm-scheduling/StructureDefinition/cancelbooking-request",
  "version" : "1.1",
  "name" : "CancelBookingRequest",
  "title" : "CancelBooking — Request",
  "status" : "active",
  "date" : "2026-11-09T03:26:43+00:00",
  "contact" : [{
    "name" : "Inera Arkitektur",
    "telecom" : [{
      "system" : "url",
      "value" : "https://www.inera.se"
    }]
  }],
  "description" : "Logisk modell för requestparametrar i CancelBooking.",
  "copyright" : "Copyright 2024 Inera AB. Licensieras under Creative Commons Attribution 4.0.",
  "fhirVersion" : "4.0.1",
  "kind" : "logical",
  "abstract" : false,
  "type" : "https://fhir.inera.se/ig/crm-scheduling/StructureDefinition/cancelbooking-request",
  "baseDefinition" : "http://hl7.org/fhir/StructureDefinition/Base",
  "derivation" : "specialization",
  "differential" : {
    "element" : [{
      "id" : "cancelbooking-request",
      "path" : "cancelbooking-request",
      "short" : "CancelBooking — Request",
      "definition" : "Logisk modell för requestparametrar i CancelBooking."
    },
    {
      "id" : "cancelbooking-request.healthcare-facility",
      "path" : "cancelbooking-request.healthcare_facility",
      "short" : "healthcare_facility",
      "definition" : "HSA-id för mottagning/vårdenhet",
      "comment" : "TKB-fält: `healthcare_facility` (`HsaIdType (string)`, kardinalitet 1..1).",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "cancelbooking-request.bookingId",
      "path" : "cancelbooking-request.bookingId",
      "short" : "bookingId",
      "definition" : "Intern bokningsidentitet",
      "comment" : "TKB-fält: `bookingId` (`BookingIdType (string)`, kardinalitet 1..1).",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "cancelbooking-request.message",
      "path" : "cancelbooking-request.message",
      "short" : "message",
      "definition" : "Invånarens beskrivning av orsak för avbokning. Fältet kan bara skickas om värdet på message_allowed är ”true” i svaret från GetBookingDetails.",
      "comment" : "TKB-fält: `message` (`string`, kardinalitet 0..1).",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    }]
  }
}

```
