# GetAllPerformers — Request - crm: scheduling v1.1.6

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **GetAllPerformers — Request**

## Logical Model: GetAllPerformers — Request 

| | |
| :--- | :--- |
| *Official URL*:https://fhir.inera.se/ig/crm-scheduling/StructureDefinition/getallperformers-request | *Version*:1.1 |
| Active as of 2026-11-09 | *Computable Name*:GetAllPerformersRequest |
| **Copyright/Legal**: Copyright 2024 Inera AB. Licensieras under Creative Commons Attribution 4.0. | |

 
Logisk modell för requestparametrar i GetAllPerformers. 

**Usages:**

* This Logical Model is not used by any profiles in this Specification

You can also check for [usages in the FHIR IG Statistics](https://packages2.fhir.org/xig/resource/inera.crm-scheduling|current/StructureDefinition/StructureDefinition-getallperformers-request.json)

### Formal Views of Profile Content

 [Description of Profiles, Differentials, Snapshots and how the different presentations work](http://build.fhir.org/ig/FHIR/ig-guidance/readingIgs.html#structure-definitions). 

 

Other representations of profile: [CSV](StructureDefinition-getallperformers-request.csv), [Excel](StructureDefinition-getallperformers-request.xlsx) 



## Resource Content

```json
{
  "resourceType" : "StructureDefinition",
  "id" : "getallperformers-request",
  "extension" : [{
    "url" : "http://hl7.org/fhir/StructureDefinition/structuredefinition-type-characteristics",
    "valueCode" : "can-be-target"
  }],
  "url" : "https://fhir.inera.se/ig/crm-scheduling/StructureDefinition/getallperformers-request",
  "version" : "1.1",
  "name" : "GetAllPerformersRequest",
  "title" : "GetAllPerformers — Request",
  "status" : "active",
  "date" : "2026-11-09T03:26:43+00:00",
  "contact" : [{
    "name" : "Inera Arkitektur",
    "telecom" : [{
      "system" : "url",
      "value" : "https://www.inera.se"
    }]
  }],
  "description" : "Logisk modell för requestparametrar i GetAllPerformers.",
  "copyright" : "Copyright 2024 Inera AB. Licensieras under Creative Commons Attribution 4.0.",
  "fhirVersion" : "4.0.1",
  "kind" : "logical",
  "abstract" : false,
  "type" : "https://fhir.inera.se/ig/crm-scheduling/StructureDefinition/getallperformers-request",
  "baseDefinition" : "http://hl7.org/fhir/StructureDefinition/Base",
  "derivation" : "specialization",
  "differential" : {
    "element" : [{
      "id" : "getallperformers-request",
      "path" : "getallperformers-request",
      "short" : "GetAllPerformers — Request",
      "definition" : "Logisk modell för requestparametrar i GetAllPerformers."
    },
    {
      "id" : "getallperformers-request.healthcare-facility",
      "path" : "getallperformers-request.healthcare_facility",
      "short" : "healthcare_facility",
      "definition" : "HSA-id för mottagning/vårdenhet.",
      "comment" : "TKB-fält: `healthcare_facility` (`HsaIdType (string)`, kardinalitet 1..1).",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "getallperformers-request.timeTypeIDs",
      "path" : "getallperformers-request.timeTypeIDs",
      "short" : "timeTypeIDs",
      "definition" : "Tidstypid för att begränsa svarslistan.",
      "comment" : "TKB-fält: `timeTypeIDs` (`TimeTypeIDType (string)`, kardinalitet 0..*).",
      "min" : 0,
      "max" : "*",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "getallperformers-request.careTypeIDs",
      "path" : "getallperformers-request.careTypeIDs",
      "short" : "careTypeIDs",
      "definition" : "Vårdtypsid för att begränsa svarslistan. Ska stödjas av producent om GetAllCaretypes stödjs. Konsument får bara skicka värden till producent som stödjer GetAllCaretypes.",
      "comment" : "TKB-fält: `careTypeIDs` (`CareTypeIDType (string)`, kardinalitet 0..*).",
      "min" : 0,
      "max" : "*",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "getallperformers-request.subject-of-care",
      "path" : "getallperformers-request.subject_of_care",
      "short" : "subject_of_care",
      "definition" : "Personnummer enl. yyyymmddxxxx för begränsa/utöka svarslistan.",
      "comment" : "TKB-fält: `subject_of_care` (`SubjectOfCareIdType (string)`, kardinalitet 1..1).",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "string",
        "profile" : ["https://fhir.inera.se/ig/crm-scheduling/StructureDefinition/SubjectOfCareIdType"]
      }]
    }]
  }
}

```
