# inera.crm-scheduling#1.1: crm: scheduling

## Pages

* [Hem](index.md)
* [7 Tjänstekontrakt](7-tjanstekontrakt.md)
* [1 Inledning](1-inledning.md)
* [4 Tjänstedomänens krav och regler](4-tjanstedomanens-krav-och-regler.md)
* [6 Gemensamma informationskomponenter](6-gemensamma-informationskomponenter.md)
* [3 Tjänstedomänens arkitektur](3-tjanstedomanens-arkitektur.md)
* [Artifacts Summary](artifacts.md)
* [2 Versionsinformation](2-versionsinformation.md)
* [5 Tjänstedomänens meddelandemodeller](5-tjanstedomanens-meddelandemodeller.md)

## Resources

### CodeSystems

* [ResultCode](CodeSystem-result-code-cs.md)

### ValueSets

* [ResultCode — ValueSet](ValueSet-result-code-vs.md)

### Logicals

* [CancelBooking — Request](StructureDefinition-cancelbooking-request.md)
* [CancelBooking](StructureDefinition-cancelbooking.md)
* [GetAllCareTypes — Request](StructureDefinition-getallcaretypes-request.md)
* [GetAllCareTypes](StructureDefinition-getallcaretypes.md)
* [GetAllHealthcareFacilities — Request](StructureDefinition-getallhealthcarefacilities-request.md)
* [GetAllHealthcareFacilities](StructureDefinition-getallhealthcarefacilities.md)
* [GetAllPerformers — Request](StructureDefinition-getallperformers-request.md)
* [GetAllPerformers](StructureDefinition-getallperformers.md)
* [GetAllTimeTypes — Request](StructureDefinition-getalltimetypes-request.md)
* [GetAllTimeTypes](StructureDefinition-getalltimetypes.md)
* [GetAvailableDates — Request](StructureDefinition-getavailabledates-request.md)
* [GetAvailableDates](StructureDefinition-getavailabledates.md)
* [GetAvailableTimeslots — Request](StructureDefinition-getavailabletimeslots-request.md)
* [GetAvailableTimeslots](StructureDefinition-getavailabletimeslots.md)
* [GetBookingDetails — Request](StructureDefinition-getbookingdetails-request.md)
* [GetBookingDetails](StructureDefinition-getbookingdetails.md)
* [GetSubjectOfCareSchedule — Request](StructureDefinition-getsubjectofcareschedule-request.md)
* [GetSubjectOfCareSchedule](StructureDefinition-getsubjectofcareschedule.md)
* [MakeBooking — Request](StructureDefinition-makebooking-request.md)
* [MakeBooking](StructureDefinition-makebooking.md)
* [UpdateBooking — Request](StructureDefinition-updatebooking-request.md)
* [UpdateBooking](StructureDefinition-updatebooking.md)

### ImplementationGuides

* [crm: scheduling](index.md)
