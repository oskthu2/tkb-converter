# Hem - crm: scheduling v1.1.6

* [**Table of Contents**](toc.md)
* **Hem**

## Hem

| | |
| :--- | :--- |
| *Official URL*:https://fhir.inera.se/ig/crm-scheduling/ImplementationGuide/inera.crm-scheduling | *Version*:1.1.6 |
| Active as of 2026-10-26 | *Computable Name*:crmscheduling |
| **Copyright/Legal**: Copyright 2024 Inera AB. Licensieras under Creative Commons Attribution 4.0. | |

# crm: scheduling

**TKB-version:** 1.1.6 · **IG-version:** 1.1.6 · **Källa:** Bitbucket-commit `d5bfa3372dce`, efter taggen `1.1.6` 

## Översikt

* Beskrivning: Svenskt kortnamn
  * Tidbokning gör det möjligt för invånaren att själv hantera sina tider i vården. Tills vidare är det beslutat att endast agentanslutningar behöver inkomma med självdeklarationer.: tidbokning
* Beskrivning: Svenskt namn
  * Tidbokning gör det möjligt för invånaren att själv hantera sina tider i vården. Tills vidare är det beslutat att endast agentanslutningar behöver inkomma med självdeklarationer.: individens processtöd:tillgängliggör kontaktväg:tidbokning
* Beskrivning: Typ
  * Tidbokning gör det möjligt för invånaren att själv hantera sina tider i vården. Tills vidare är det beslutat att endast agentanslutningar behöver inkomma med självdeklarationer.: Nationell tjänstedomän
* Beskrivning: Källkod
  * Tidbokning gör det möjligt för invånaren att själv hantera sina tider i vården. Tills vidare är det beslutat att endast agentanslutningar behöver inkomma med självdeklarationer.: [Bitbucket](https://bitbucket.org/rivta-domains/riv.crm.scheduling/src)
* Beskrivning: Ärenden
  * Tidbokning gör det möjligt för invånaren att själv hantera sina tider i vården. Tills vidare är det beslutat att endast agentanslutningar behöver inkomma med självdeklarationer.: [Bitbucket issues](https://bitbucket.org/rivta-domains/riv.crm.scheduling/issues)
* Beskrivning: Informationssida
  * Tidbokning gör det möjligt för invånaren att själv hantera sina tider i vården. Tills vidare är det beslutat att endast agentanslutningar behöver inkomma med självdeklarationer.: [Confluence](https://bitbucket.org/rivta-domains/riv.crm.scheduling/wiki)
* Beskrivning: Underlag för denna IG
  * Tidbokning gör det möjligt för invånaren att själv hantera sina tider i vården. Tills vidare är det beslutat att endast agentanslutningar behöver inkomma med självdeklarationer.: Version 1.1.6 ·[tagg 1.1.6](https://bitbucket.org/rivta-domains/riv.crm.scheduling/src/1.1.6)
* Beskrivning: RIV-TA-portalen
  * Tidbokning gör det möjligt för invånaren att själv hantera sina tider i vården. Tills vidare är det beslutat att endast agentanslutningar behöver inkomma med självdeklarationer.: [Alla tjänstedomäner](https://oskthu2.github.io/tkb-converter/rivta-portal/tjanstedomaner.html)·[Alla tjänstekontrakt](https://oskthu2.github.io/tkb-converter/rivta-portal/tjanstekontrakt.html)

FHIR Implementation Guide för tjänstedomänen **crm: scheduling** version 1.1.6. Genererad från Ineras Tjänstekontraktsbeskrivning (TKB).

Tjänstedomänens omfattning är invånarperspektivet på tidbokning mot en vårdenhet. Den kravställande processen är invånarens behov av e-tjänster för tidbokning — direkt som användare (ex. 1177 Vårdguidens e-tjänster), eller indirekt via vårdpersonal (ex. Rådgivningsstödet, RGS).

Domänen innehåller följande tjänstekontrakt:

| | | |
| :--- | :--- | :--- |
| [CancelBooking](7-tjanstekontrakt.md#cancelbooking) | 1.1 | Avboka en bokning vid en vårdenhet |
| [GetAllCareTypes](7-tjanstekontrakt.md#getallcaretypes) | 1.1 | Hämta lista över bokningsbara vårdtyper hos en vårdenhet |
| [GetAllHealthcareFacilities](7-tjanstekontrakt.md#getallhealthcarefacilities) | 1.1 | Hämta alla vårdenheter tillgängliga för bokning |
| [GetAllPerformers](7-tjanstekontrakt.md#getallperformers) | 1.1 | Hämta lista över bokningsbara utförare |
| [GetAllTimeTypes](7-tjanstekontrakt.md#getalltimetypes) | 1.1 | Hämta alla tidstyper för nybokning |
| [GetAvailableDates](7-tjanstekontrakt.md#getavailabledates) | 1.1 | Hämta datum med lediga tider |
| [GetAvailableTimeslots](7-tjanstekontrakt.md#getavailabletimeslots) | 1.1 | Hämta lediga tider för datumintervall |
| [GetBookingDetails](7-tjanstekontrakt.md#getbookingdetails) | 1.1 | Hämta detaljinformation för en befintlig bokning |
| [GetSubjectOfCareSchedule](7-tjanstekontrakt.md#getsubjectofcareschedule) | 1.1 | Hämta alla bokade tider för en invånare |
| [MakeBooking](7-tjanstekontrakt.md#makebooking) | 1.1 | Skapa nybokning vid en vårdenhet |
| [UpdateBooking](7-tjanstekontrakt.md#updatebooking) | 1.1 | Uppdatera/omboka en befintlig bokning |

### Versioner och granskningar

| | | | |
| :--- | :--- | :--- | :--- |
| 1.1.3 | AB, TKB | [Arkitektur & Regelverk: Teknik: Godkänd](http://rivta.se/downloads//crm_scheduling/1.1.3/T-granskning%20-%20crm_scheduling_1.1.3.docx)[Arkitektur & Regelverk: Säkerhet: Underkänd](http://rivta.se/downloads//crm_scheduling/1.1.3/VIS_gransknings%20-%20crm_scheduling_1.1.3.docx)[Arkitektur & Regelverk: Informatik: Underkänd](http://rivta.se/downloads//crm_scheduling/1.1.3/VIS_gransknings%20-%20crm_scheduling_1.1.3.docx) | [zip](http://rivta.se/downloads//crm_scheduling/1.1.3/ServiceContracts_crm_scheduling_1.1.3.zip)·[källkod](https://bitbucket.org/rivta-domains/riv.crm.scheduling/src/1.1.3) |
| 1.1.1 | TKB | Äldre granskningsprocess: Teknik: Godkänd | [zip](http://rivta.se/downloads/crm_scheduling/1.1.1/TD_SCHEDULING_1_1_1_R.zip)·[källkod](https://bitbucket.org/rivta-domains/riv.crm.scheduling/src/TD_SCHEDULING_1_1_1_R) |
| 1.0.4 | TKB | Äldre granskningsprocess: Teknik: Godkänd | [zip](http://rivta.se/downloads/crm_scheduling/1.0.4/ServiceContracts_crm_scheduling_1.0.4.zip)·[källkod](https://bitbucket.org/rivta-domains/riv.crm.scheduling/src/TD_SCHEDULING_1_0_4_R) |
| trunk |  |  | [källkod](https://bitbucket.org/rivta-domains/riv.crm.scheduling/src/master) |

*Källa: ögonblicksbild av DOMDB från 2021-08-24, via RIV-TA-portalen.*

## Innehåll

* [1 Inledning](1-inledning.md)
* [2 Versionsinformation](2-versionsinformation.md)
* [3 Tjänstedomänens arkitektur](3-tjanstedomanens-arkitektur.md)
* [4 Tjänstedomänens krav och regler](4-tjanstedomanens-krav-och-regler.md)
* [5 Tjänstedomänens meddelandemodeller](5-tjanstedomanens-meddelandemodeller.md)
* [6 Gemensamma informationskomponenter](6-gemensamma-informationskomponenter.md)
* [7 Tjänstekontrakt](7-tjanstekontrakt.md)
* [Artefakter](artifacts.md)

