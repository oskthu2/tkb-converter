# Hem - crm: scheduling v1.1

* [**Table of Contents**](toc.md)
* **Hem**

## Hem

| | |
| :--- | :--- |
| *Official URL*:https://fhir.inera.se/ig/crm-scheduling/ImplementationGuide/inera.crm-scheduling | *Version*:1.1 |
| Draft as of 2026-09-14 | *Computable Name*:crmscheduling |
| **Copyright/Legal**: Copyright 2024 Inera AB. Licensieras under Creative Commons Attribution 4.0. | |

# crm: scheduling

## Översikt

FHIR Implementation Guide för tjänstedomänen **crm: scheduling** version 1.1. Genererad från Ineras Tjänstekontraktsbeskrivning (TKB).

Tjänstedomänens omfattning är invånarperspektivet på tidbokning mot en vårdenhet. Den kravställande processen är invånarens behov av e-tjänster för tidbokning — direkt som användare (ex. 1177 Vårdguidens e-tjänster), eller indirekt via vårdpersonal (ex. Rådgivningsstödet, RGS).

Domänen innehåller följande tjänstekontrakt:

| | | |
| :--- | :--- | :--- |
| [CancelBooking](7-tjanstekontrakt.md#cancelbooking) | 1.1 | Avboka en bokning vid en vårdenhet |
| [GetAllCareTypes](7-tjanstekontrakt.md#getallcaretypes) | 1.1 | Hämta lista över bokningsbara vårdtyper hos en vårdenhet |
| [GetAllHealthcareFacilities](7-tjanstekontrakt.md#getallhealthcarefacilities) | 1.1 | Hämta alla vårdenheter tillgängliga för bokning |
| [GetAllPerformers](7-tjanstekontrakt.md#getallperformers) | 1.1 | Hämta lista över bokningsbara utförare |
| [GetAllTimeTypes](7-tjanstekontrakt.md#getalltimetypes) | 1.1 | Hämta alla tidstyper för nybokning |
| [GetAvailableDates](7-tjanstekontrakt.md#getavailabledates) | 1.1 | Hämta datum med lediga tider |
| [GetAvailableTimeslots](7-tjanstekontrakt.md#getavailabletimeslots) | 1.1 | Hämta lediga tider för datumintervall |
| [GetBookingDetails](7-tjanstekontrakt.md#getbookingdetails) | 1.1 | Hämta detaljinformation för en befintlig bokning |
| [GetSubjectOfCareSchedule](7-tjanstekontrakt.md#getsubjectofcareschedule) | 1.1 | Hämta alla bokade tider för en invånare |
| [MakeBooking](7-tjanstekontrakt.md#makebooking) | 1.1 | Skapa nybokning vid en vårdenhet |
| [UpdateBooking](7-tjanstekontrakt.md#updatebooking) | 1.1 | Uppdatera/omboka en befintlig bokning |

## Innehåll

* [1 Inledning](1-inledning.md)
* [2 Versionsinformation](2-versionsinformation.md)
* [3 Tjänstedomänens arkitektur](3-tjanstedomanens-arkitektur.md)
* [4 Tjänstedomänens krav och regler](4-tjanstedomanens-krav-och-regler.md)
* [5 Tjänstedomänens meddelandemodeller](5-tjanstedomanens-meddelandemodeller.md)
* [6 Gemensamma informationskomponenter](6-gemensamma-informationskomponenter.md)
* [7 Tjänstekontrakt](7-tjanstekontrakt.md)
* [Artefakter](artifacts.md)

