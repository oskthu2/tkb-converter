# Gemensamma datatyper - RIV-TA gemensamma datatyper v1.0.0

* [**Table of Contents**](toc.md)
* **Gemensamma datatyper**

## Gemensamma datatyper

| | |
| :--- | :--- |
| *Official URL*:https://fhir.inera.se/ig/rivta-datatypes/ImplementationGuide/inera.rivta.datatypes | *Version*:1.0.0 |
| Active as of 2026-11-09 | *Computable Name*:RivtaDatatypes |
| **Copyright/Legal**: Copyright 2026 Inera AB. Licensieras under Creative Commons Attribution 4.0. | |

# RIV-TA gemensamma datatyper

Den här IG:n definierar de grunddatatyper som återkommer i RIV-TA-tjänstekontrakten, en gång, så att de logiska modellerna i varje TKB-IG kan referera till samma definition. Typerna följer [RIV-TA Best Practice: De facto-konventioner för datatyper](https://bitbucket.org/rivta-domains/best-practice/src/master/schema/) och har samma namn, element och kardinaliteter som i schemat. HSAIdType och UUIDType finns inte i de facto-konventionerna men definieras likadant i nästan alla domänscheman och är därför också med.

## Hur TKB-IG:erna använder typerna

De logiska modellerna i TKB-IG:erna följer tjänstekontraktets XML-schema: varje fält har samma namn, kardinalitet och typ som i schemat. När domänens schema definierar en typ med samma namn som här gäller:

* **Identisk definition:** fältet refererar direkt till typen här.
* **Samma element men snävare kardinalitet** (t.ex. `IIType.extension` 1..1 i stället för 0..1): domänens IG har en egen typ med samma namn som ärver typen här och skärper kardinaliteten.
* **Annan definition:** domänens IG definierar typen själv, eftersom den inte är samma typ.

Enkla typer (xs:simpleType, t.ex. TimeStampType) är profiler på FHIR-typen `string` med schemats mönster som invariant.

## Typer

| | | | |
| :--- | :--- | :--- | :--- |
| [ActorType](StructureDefinition-ActorType.md) | sammansatt | Medarbetare i vård och omsorg | hsaId : HSAIdType [0..1]personName : string [0..1]personTelecom : string [0..1]personEmail : string [0..1]personAddress : string [0..1] |
| [CVType](StructureDefinition-CVType.md) | sammansatt | Referens till ett begrepp i ett externt kodverk. | code : string [0..1]codeSystem : string [0..1]codeSystemName : string [0..1]codeSystemVersion : string [0..1]displayName : string [0..1]originalText : string [0..1] |
| [DatePeriodType](StructureDefinition-DatePeriodType.md) | sammansatt | Datumintervall med minst ett start- eller slutdatum. | start : DateType [0..1]end : DateType [0..1] |
| [DateType](StructureDefinition-DateType.md) | enkel | Datum på formatet YYYYMMDD utan tidszon. | xs:string, mönster`(19\|20)\d\d(0[1-9]\|1[012])(0[1-9]\|[12][0-9]\|3[01])` |
| [DecimalPrimitiveType](StructureDefinition-DecimalPrimitiveType.md) | enkel | Decimaltal som bevarar signifikanta avslutande nollor. | xs:string, mönster`-?(0\|[1-9][0-9]*)((\.\|,)[0-9]+)?([eE][+-]?[0-9]+)?` |
| [HSAIdType](StructureDefinition-HSAIdType.md) | enkel | HSA-id: identifierare i HSA-katalogen för en person, organisation, enhet eller funktion. | xs:string |
| [HealthcareProfessionalType](StructureDefinition-HealthcareProfessionalType.md) | sammansatt | Vård- och omsorgspersonal samt organisatorisk tillhörighet. | authorTime : TimeStampType [1..1]healthcareProfessionalHSAId : HSAIdType [0..1]healthcareProfessionalName : string [0..1]healthcareProfessionalRoleCode : CVType [0..1]healthcareProfessionalOrgUnit : OrgUnitType [0..1]healthcareProfessionalCareUnitHSAId : HSAIdType [0..1]healthcareProfessionalCareGiverHSAId : HSAIdType [0..1] |
| [IIType](StructureDefinition-IIType.md) | sammansatt | Unik identifierare för ett objekt eller en entitet. | root : string [1..1]extension : string [0..1] |
| [LegalAuthenticatorType](StructureDefinition-LegalAuthenticatorType.md) | sammansatt | Signatur och uppgifter om signerande person. | signatureTime : TimeStampType [1..1]legalAuthenticatorHSAId : HSAIdType [0..1]legalAuthenticatorName : string [0..1]legalAuthenticatorRoleCode : CVType [0..1] |
| [MultimediaType](StructureDefinition-MultimediaType.md) | sammansatt | Multimediaobjekt som binärdata eller extern referens. | id : string [0..1]mediaType : MediaTypeEnum [1..1]value : base64Binary [0..1]reference : anyURI [0..1] |
| [OrgUnitType](StructureDefinition-OrgUnitType.md) | sammansatt | Identitets-, kontakt- och adressuppgifter för en organisationsenhet. | orgUnitHSAId : HSAIdType [0..1]orgUnitName : string [0..1]orgUnitTelecom : string [0..1]orgUnitEmail : string [0..1]orgUnitAddress : string [0..1]orgUnitLocation : string [0..1] |
| [PQIntervalType](StructureDefinition-PQIntervalType.md) | sammansatt | Intervall av mätbara värden med enhet. | low : DecimalPrimitiveType [0..1]lowClosed : boolean [0..1]high : DecimalPrimitiveType [0..1]highClosed : boolean [0..1]unit : string [1..1] |
| [PQType](StructureDefinition-PQType.md) | sammansatt | Mätbart värde med enhet. | value : DecimalPrimitiveType [1..1]unit : string [1..1] |
| [PartialDateType](StructureDefinition-PartialDateType.md) | sammansatt | Datum med variabel noggrannhet. | format : DateTypeFormatEnum [1..1]value : PartialDateValueType [1..1] |
| [PartialDateValueType](StructureDefinition-PartialDateValueType.md) | enkel | Datumvärde på formatet YYYY, YYYYMM eller YYYYMMDD. | xs:string, mönster`-?([1-9][0-9]{3}\|0[0-9]{3})((0[1-9]\|1[0-2])((0[1-9]\|[12][0-9]\|3[01]))?)?` |
| [PersonIdType](StructureDefinition-PersonIdType.md) | sammansatt | Identifierare för en person och typ av identifierare. | id : string [1..1]type : string [1..1] |
| [ResultType](StructureDefinition-ResultType.md) | sammansatt | Resultatkod och valfri text för logiska fel. | resultCode : ResultCodeEnum [1..1]resultText : string [0..1] |
| [TimePeriodType](StructureDefinition-TimePeriodType.md) | sammansatt | Tidsintervall med minst en start- eller sluttidpunkt. | start : TimeStampType [0..1]end : TimeStampType [0..1] |
| [TimeStampType](StructureDefinition-TimeStampType.md) | enkel | Tidpunkt på formatet YYYYMMDDhhmmss utan tidszon. | xs:string, mönster`(19\|20)\d\d(0[1-9]\|1[012])(0[1-9]\|[12][0-9]\|3[01])(0[0-9]\|1[0-9]\|2[0123])([0-5])([0-9])([0-5])([0-9])` |
| [UUIDType](StructureDefinition-UUIDType.md) | enkel | Universellt unik identifierare (UUID/GUID): 32 hexadecimala tecken, med eller utan bindestreck i mönstret 8-4-4-4-12. | xs:string, mönster`[A-Fa-f0-9]{32}\|(\{\|\()?[A-Fa-f0-9]{8}-([A-Fa-f0-9]{4}-){3}[A-Fa-f0-9]{12}(\}\|\))?` |

