# inera.rivta.datatypes#1.0.0: RIV-TA gemensamma datatyper

## Pages

* [Gemensamma datatyper](index.md)
* [Artifacts Summary](artifacts.md)

## Resources

### Logicals

* [ActorType](StructureDefinition-ActorType.md)
* [CVType](StructureDefinition-CVType.md)
* [DatePeriodType](StructureDefinition-DatePeriodType.md)
* [HealthcareProfessionalType](StructureDefinition-HealthcareProfessionalType.md)
* [IIType](StructureDefinition-IIType.md)
* [LegalAuthenticatorType](StructureDefinition-LegalAuthenticatorType.md)
* [MultimediaType](StructureDefinition-MultimediaType.md)
* [OrgUnitType](StructureDefinition-OrgUnitType.md)
* [PQIntervalType](StructureDefinition-PQIntervalType.md)
* [PQType](StructureDefinition-PQType.md)
* [PartialDateType](StructureDefinition-PartialDateType.md)
* [PersonIdType](StructureDefinition-PersonIdType.md)
* [ResultType](StructureDefinition-ResultType.md)
* [TimePeriodType](StructureDefinition-TimePeriodType.md)

### Primitive-type Profiles

* [DateType](StructureDefinition-DateType.md)
* [DecimalPrimitiveType](StructureDefinition-DecimalPrimitiveType.md)
* [HSAIdType](StructureDefinition-HSAIdType.md)
* [PartialDateValueType](StructureDefinition-PartialDateValueType.md)
* [TimeStampType](StructureDefinition-TimeStampType.md)
* [UUIDType](StructureDefinition-UUIDType.md)

### ImplementationGuides

* [RIV-TA gemensamma datatyper](index.md)
