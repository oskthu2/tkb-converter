# Start - RIV Tekniska Anvisningar — tjänstedomäner och regelverk v0.1.0

* [**Table of Contents**](toc.md)
* **Start**

## Start

| | |
| :--- | :--- |
| *Official URL*:https://fhir.inera.se/ig/rivta-portal/ImplementationGuide/inera.rivta-portal | *Version*:0.1.0 |
| Draft as of 2026-10-08 | *Computable Name*:RivtaPortal |
| **Copyright/Legal**: Copyright 2026 Inera AB. Licensieras under Creative Commons Attribution 4.0. | |

Denna webbplats samlar regelverket för RIV Tekniska Anvisningar (RIV-TA): tjänstedomäner, tjänstekontrakt, arkitekturella dokument, nyheter och vanliga frågor. Varje tjänstedomän länkar dessutom till sin FHIR Implementation Guide, där hela tjänstekontraktsbeskrivningen (TKB) finns som webbsidor tillsammans med logiska FHIR-modeller.

### Innehåll

| | |
| :--- | :--- |
| [Tjänstedomäner](tjanstedomaner.md) | 77 tjänstedomäner, varav 70 med FHIR IG |
| [Tjänstekontrakt](tjanstekontrakt.md) | 515 tjänstekontrakt (en rad per huvudversion) |
| [Dokument](dokument.md) | Referensarkitekturer, RIV Tekniska anvisningar, mallar och presentationer |
| [Aktuellt](aktuellt.md) | Nyheter och arkiv sedan 2014, även som[RSS](rss.xml) |
| [Utveckling](utveckling.md) | Anvisningar, mallar och verktyg för tjänstekontrakt, e-tjänster och tjänsteplattform |
| [FAQ](faq.md) | Vanliga frågor och svar |
| [Byggstatus](https://oskthu2.github.io/tkb-converter/index.html) | Kvalitetsrapport för alla FHIR IG:ar |

### Senaste nyheterna

* 2026-06-08 — [RIV-TA Refererade bilagor](aktuellt.md#nyhet-2026-06-08-riv-ta-refererade-bilagor)
* 2026-06-08 — [RIV-TA Basic Profile 2.1, version 3.1, samt RIV-TA Tjänsteplattform, version 2.1 har publicerats](aktuellt.md#nyhet-2026-06-08-riv-ta-basic-profile-2-1-version-3-1-sam)
* 2026-05-11 — [RIV-TA Konfigurationsstyrning tjänstedomäner](aktuellt.md#nyhet-2026-05-11-riv-ta-konfigurationsstyrning-tjanstedom)
* 2026-01-30 — [Behörighetsmodell för vård och omsorg](aktuellt.md#nyhet-2026-01-30-behorighetsmodell-for-vard-och-omsorg)
* 2025-08-11 — [RIV Tekniska Anvisningar - Översikt](aktuellt.md#nyhet-2025-08-11-riv-tekniska-anvisningar-oversikt)

Den gemensamma arkitekturen utvecklas och förvaltas av [Inera](https://www.inera.se/).

