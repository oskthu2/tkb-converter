# Hem - crm: requeststatus v2.0.1-snapshot

* [**Table of Contents**](toc.md)
* **Hem**

## Hem

| | |
| :--- | :--- |
| *Official URL*:https://fhir.inera.se/ig/crm-requeststatus/ImplementationGuide/inera.crm-requeststatus | *Version*:2.0.1-snapshot |
| Draft as of 2026-11-09 | *Computable Name*:crmrequeststatus |
| **Copyright/Legal**: Copyright 2024 Inera AB. Licensieras under Creative Commons Attribution 4.0. | |

# crm: requeststatus

**TKB-version:** 2.0.1 · **IG-version:** 2.0.1-snapshot · **Källa:** Bitbucket-commit `fe868afac3b0` (ingen tagg) 

## Översikt

* Svenskt kortnamn: Svenskt namn
  * remisstatus: vård- och omsorg kärnprocess:hantera aktiviteter:remisstatus
* Svenskt kortnamn: Typ
  * remisstatus: Nationell tjänstedomän
* Svenskt kortnamn: Källkod
  * remisstatus: [Bitbucket](https://bitbucket.org/rivta-domains/riv.crm.requeststatus/src)
* Svenskt kortnamn: Ärenden
  * remisstatus: [Bitbucket issues](https://bitbucket.org/rivta-domains/riv.crm.requeststatus/issues)
* Svenskt kortnamn: Underlag för denna IG
  * remisstatus: Version 2.0.1 ·[commit fe868afac3b0](https://bitbucket.org/rivta-domains/riv.crm.requeststatus/src/fe868afac3b0d9210e48c21a981cf3ac24459a57)·[zip](https://api.bitbucket.org/2.0/repositories/rivta-domains/riv.crm.requeststatus/src/master/%20(no%20zip%20—%20downloaded%20directly%20from%20source))
* Svenskt kortnamn: RIV-TA-portalen
  * remisstatus: [Alla tjänstedomäner](https://oskthu2.github.io/tkb-converter/rivta-portal/tjanstedomaner.html)·[Alla tjänstekontrakt](https://oskthu2.github.io/tkb-converter/rivta-portal/tjanstekontrakt.html)

FHIR Implementation Guide för tjänstedomänen **crm: requeststatus** version 2.0.1. Genererad från Ineras Tjänstekontraktsbeskrivning (TKB).

Domänen (individens processtöd: remisstatus) innehåller följande tjänstekontrakt:

| | | |
| :--- | :--- | :--- |
| [GetRequestActivities](7-tjanstekontrakt.md#getrequestactivities) | 2.0 | Returnerar en lista med status för en patients remisser |

### Versioner och granskningar

| | | | |
| :--- | :--- | :--- | :--- |
| 1.0.5 | AB, TKB | Arkitektur & Regelverk: Informatik: GodkändArkitektur & Regelverk: Teknik: GodkändArkitektur & Regelverk: Säkerhet: Godkänd | [zip](https://bitbucket.org/rivta-domains/riv.crm.requeststatus/get/1.0.5.zip)·[källkod](https://bitbucket.org/rivta-domains/riv.crm.requeststatus/src/1.0.5) |
| trunk | AB, IS, TKB |  | [källkod](https://bitbucket.org/rivta-domains/riv.crm.requeststatus/src/master) |

*Zip-arkiven hämtas från taggarna på Bitbucket. Granskningsprotokollen publicerades på rivta.se och länkas inte härifrån.*

*Källa: ögonblicksbild av DOMDB från 2021-08-24, via RIV-TA-portalen.*

## Innehåll

* [1 Inledning](1-inledning.md)
* [2 Versionsinformation](2-versionsinformation.md)
* [3 Tjänstedomänens arkitektur](3-tjanstedomanens-arkitektur.md)
* [4 Tjänstedomänens krav och regler](4-tjanstedomanens-krav-och-regler.md)
* [5 Tjänstedomänens meddelandemodeller](5-tjanstedomanens-meddelandemodeller.md)
* [6 Gemensamma informationskomponenter](6-gemensamma-informationskomponenter.md)
* [7 Tjänstekontrakt](7-tjanstekontrakt.md)
* [Artefakter](artifacts.md)

