# Hem - crm: requeststatus v2.0.1

* [**Table of Contents**](toc.md)
* **Hem**

## Hem

| | |
| :--- | :--- |
| *Official URL*:https://fhir.inera.se/ig/crm-requeststatus/ImplementationGuide/inera.crm-requeststatus | *Version*:2.0.1 |
| Draft as of 2026-09-26 | *Computable Name*:crmrequeststatus |
| **Copyright/Legal**: Copyright 2024 Inera AB. Licensieras under Creative Commons Attribution 4.0. | |

# crm: requeststatus

## Översikt

FHIR Implementation Guide för tjänstedomänen **crm: requeststatus** version 2.0.1. Genererad från Ineras Tjänstekontraktsbeskrivning (TKB).

Domänen (individens processtöd: remisstatus) innehåller följande tjänstekontrakt:

| | | |
| :--- | :--- | :--- |
| [GetRequestActivities](7-tjanstekontrakt.md#getrequestactivities) | 2.0 | Returnerar en lista med status för en patients remisser |

## Innehåll

* [1 Inledning](1-inledning.md)
* [2 Versionsinformation](2-versionsinformation.md)
* [3 Tjänstedomänens arkitektur](3-tjanstedomanens-arkitektur.md)
* [4 Tjänstedomänens krav och regler](4-tjanstedomanens-krav-och-regler.md)
* [5 Tjänstedomänens meddelandemodeller](5-tjanstedomanens-meddelandemodeller.md)
* [6 Gemensamma informationskomponenter](6-gemensamma-informationskomponenter.md)
* [7 Tjänstekontrakt](7-tjanstekontrakt.md)
* [Artefakter](artifacts.md)

