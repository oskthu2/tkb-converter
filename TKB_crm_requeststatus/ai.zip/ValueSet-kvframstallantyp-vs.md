# Kv framställantyp — ValueSet - crm: requeststatus v2.0.1

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Kv framställantyp — ValueSet**

## ValueSet: Kv framställantyp — ValueSet 

| | |
| :--- | :--- |
| *Official URL*:https://fhir.inera.se/ig/crm-requeststatus/ValueSet/kvframstallantyp-vs | *Version*:2.0.1 |
| Active as of 2026-09-17 | *Computable Name*:KvFramstallantypVS |
| **Copyright/Legal**: Copyright 2024 Inera AB. Licensieras under Creative Commons Attribution 4.0. | |

 
Tillåtna värden för remisstyp (typeOfRequest, request.type) enligt Kv framställantyp (OID: 1.2.752.129.2.2.2.24). 

 **References** 

* [GetRequestActivities](StructureDefinition-getrequestactivities.md)
* [GetRequestActivities — Request](StructureDefinition-getrequestactivities-request.md)

### Logical Definition (CLD)

 

### Expansion

-------

 Explanation of the columns that may appear on this page: 

| | |
| :--- | :--- |
| Level | A few code lists that FHIR defines are hierarchical - each code is assigned a level. In this scheme, some codes are under other codes, and imply that the code they are under also applies |
| System | The source of the definition of the code (when the value set draws in codes defined elsewhere) |
| Code | The code (used as the code in the resource instance) |
| Display | The display (used in the*display*element of a[Coding](http://hl7.org/fhir/R4/datatypes.html#Coding)). If there is no display, implementers should not simply display the code, but map the concept into their application |
| Definition | An explanation of the meaning of the concept |
| Comments | Additional notes about how to use the code |



## Resource Content

```json
{
  "resourceType" : "ValueSet",
  "id" : "kvframstallantyp-vs",
  "url" : "https://fhir.inera.se/ig/crm-requeststatus/ValueSet/kvframstallantyp-vs",
  "version" : "2.0.1",
  "name" : "KvFramstallantypVS",
  "title" : "Kv framställantyp — ValueSet",
  "status" : "active",
  "date" : "2026-09-17T11:07:16+00:00",
  "contact" : [{
    "name" : "Inera Arkitektur",
    "telecom" : [{
      "system" : "url",
      "value" : "https://www.inera.se"
    }]
  }],
  "description" : "Tillåtna värden för remisstyp (typeOfRequest, request.type) enligt Kv framställantyp (OID: 1.2.752.129.2.2.2.24).",
  "copyright" : "Copyright 2024 Inera AB. Licensieras under Creative Commons Attribution 4.0.",
  "compose" : {
    "include" : [{
      "system" : "https://fhir.inera.se/CodeSystem/kvframstallantyp-cs"
    }]
  }
}

```
