# inera.crm-requeststatus#2.0.1: crm: requeststatus

## Pages

* [Hem](index.md)
* [7 Tjänstekontrakt](7-tjanstekontrakt.md)
* [1 Inledning](1-inledning.md)
* [4 Tjänstedomänens krav och regler](4-tjanstedomanens-krav-och-regler.md)
* [6 Gemensamma informationskomponenter](6-gemensamma-informationskomponenter.md)
* [3 Tjänstedomänens arkitektur](3-tjanstedomanens-arkitektur.md)
* [Artifacts Summary](artifacts.md)
* [2 Versionsinformation](2-versionsinformation.md)
* [5 Tjänstedomänens meddelandemodeller](5-tjanstedomanens-meddelandemodeller.md)

## Resources

### CodeSystems

* [Kv Form av framställan](CodeSystem-kvformavframstallan-cs.md)
* [Kv framställantyp](CodeSystem-kvframstallantyp-cs.md)
* [Kv status vårdbegäran](CodeSystem-kvstatusvardbegaran-cs.md)

### ValueSets

* [Kv Form av framställan — ValueSet](ValueSet-kvformavframstallan-vs.md)
* [Kv framställantyp — ValueSet](ValueSet-kvframstallantyp-vs.md)
* [Kv status vårdbegäran — ValueSet](ValueSet-kvstatusvardbegaran-vs.md)

### Logicals

* [GetRequestActivities — Request](StructureDefinition-getrequestactivities-request.md)
* [GetRequestActivities](StructureDefinition-getrequestactivities.md)

### ImplementationGuides

* [crm: requeststatus](index.md)
