# GetRequestActivities — Request - crm: requeststatus v2.0.1-snapshot

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **GetRequestActivities — Request**

## Logical Model: GetRequestActivities — Request 

| | |
| :--- | :--- |
| *Official URL*:https://fhir.inera.se/ig/crm-requeststatus/StructureDefinition/getrequestactivities-request | *Version*:2.0 |
| Draft as of 2026-11-09 | *Computable Name*:GetRequestActivitiesRequest |
| **Copyright/Legal**: Copyright 2024 Inera AB. Licensieras under Creative Commons Attribution 4.0. | |

 
Logisk modell för requestparametrar i tjänstekontraktet GetRequestActivities (RIV-TA urn:riv:crm:requeststatus:GetRequestActivities:2). 

**Usages:**

* This Logical Model is not used by any profiles in this Specification

You can also check for [usages in the FHIR IG Statistics](https://packages2.fhir.org/xig/resource/inera.crm-requeststatus|current/StructureDefinition/StructureDefinition-getrequestactivities-request.json)

### Formal Views of Profile Content

 [Description of Profiles, Differentials, Snapshots and how the different presentations work](http://build.fhir.org/ig/FHIR/ig-guidance/readingIgs.html#structure-definitions). 

 

Other representations of profile: [CSV](StructureDefinition-getrequestactivities-request.csv), [Excel](StructureDefinition-getrequestactivities-request.xlsx) 



## Resource Content

```json
{
  "resourceType" : "StructureDefinition",
  "id" : "getrequestactivities-request",
  "extension" : [{
    "url" : "http://hl7.org/fhir/StructureDefinition/structuredefinition-type-characteristics",
    "valueCode" : "can-be-target"
  }],
  "url" : "https://fhir.inera.se/ig/crm-requeststatus/StructureDefinition/getrequestactivities-request",
  "version" : "2.0",
  "name" : "GetRequestActivitiesRequest",
  "title" : "GetRequestActivities — Request",
  "status" : "draft",
  "date" : "2026-11-09T03:26:19+00:00",
  "contact" : [{
    "name" : "Inera Arkitektur",
    "telecom" : [{
      "system" : "url",
      "value" : "https://www.inera.se"
    }]
  }],
  "description" : "Logisk modell för requestparametrar i tjänstekontraktet GetRequestActivities\n(RIV-TA urn:riv:crm:requeststatus:GetRequestActivities:2).",
  "copyright" : "Copyright 2024 Inera AB. Licensieras under Creative Commons Attribution 4.0.",
  "fhirVersion" : "4.0.1",
  "kind" : "logical",
  "abstract" : false,
  "type" : "https://fhir.inera.se/ig/crm-requeststatus/StructureDefinition/getrequestactivities-request",
  "baseDefinition" : "http://hl7.org/fhir/StructureDefinition/Base",
  "derivation" : "specialization",
  "differential" : {
    "element" : [{
      "id" : "getrequestactivities-request",
      "path" : "getrequestactivities-request",
      "short" : "GetRequestActivities — Request",
      "definition" : "Logisk modell för requestparametrar i tjänstekontraktet GetRequestActivities\n(RIV-TA urn:riv:crm:requeststatus:GetRequestActivities:2)."
    },
    {
      "id" : "getrequestactivities-request.careUnitHSAId",
      "path" : "getrequestactivities-request.careUnitHSAId",
      "short" : "careUnitHSAId",
      "definition" : "Filtrering på vårdenhet vilket motsvarar accountableCareUnit i svaret.\n\nroot sätts till OID (1.2.752.129.2.1.4.1) för HSA\n\nextension sätts till HSA-id på vårdenhet.",
      "comment" : "TKB-fält: `careUnitHSAId` (`IIType`, kardinalitet 0..*).",
      "min" : 0,
      "max" : "*",
      "type" : [{
        "code" : "https://fhir.inera.se/ig/rivta-datatypes/StructureDefinition/IIType"
      }]
    },
    {
      "id" : "getrequestactivities-request.careGiverHSAId",
      "path" : "getrequestactivities-request.careGiverHSAId",
      "short" : "careGiverHSAId",
      "definition" : "Filtrering på vårdgivare vilket motsvarar accountableHealthcareProvider i svaret.\n\nroot sätts till OID (1.2.752.129.2.1.4.1) för HSA\n\nextension sätts till HSA-id på vårdgivare.",
      "comment" : "TKB-fält: `careGiverHSAId` (`IIType`, kardinalitet 0..*).",
      "min" : 0,
      "max" : "*",
      "type" : [{
        "code" : "https://fhir.inera.se/ig/rivta-datatypes/StructureDefinition/IIType"
      }]
    },
    {
      "id" : "getrequestactivities-request.patientId",
      "path" : "getrequestactivities-request.patientId",
      "short" : "patientId",
      "definition" : "Begränsar sökningen till angiven personidentifierare för en patient. Tjänsteproducenten ska i svaret leverera alla uppgifter kopplad till patienten, dvs. även uppgifter som har registrerats på andra, till individen, kopplade personidentifierare.\n\nroot sätts till OID för typ av personidentifierare.\n\nFör personnummer ska Skatteverkets OID för personnummer (1.2.752.129.2.1.3.1) användas.\n\nFör samordningsnummer skall Skatteverkets OID för samordningsnummer (1.2.752.129.2.1.3.3) användas.\n\nFör andra typer av personidentifierare sätts root till aktuell OID.\n\nextension sätts till patientens identifierare. Anges med 12 tecken utan avskiljare.\n\nOBS lokal reservidentitet kan ej användas tillsammans med EI och aggregerande tjänster då dessa komponenter idag inte är anpassade för att stödja typ av id, inga uppdateringar till EI ska göras av en tjänsteproducent för lokal reservidentitet.\n\nEn tjänstekonsument som vill begära mha. lokal reservidentitet måste därmed använda sig av systemadressering och ha vetskap om vilken OID för den specifika lokala reservidentitet som gäller vid anrop mot en specifik tjänsteproducent.",
      "comment" : "TKB-fält: `patientId` (`IIType`, kardinalitet 1..1).",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "https://fhir.inera.se/ig/rivta-datatypes/StructureDefinition/IIType"
      }]
    },
    {
      "id" : "getrequestactivities-request.datePeriod",
      "path" : "getrequestactivities-request.datePeriod",
      "short" : "datePeriod",
      "definition" : "Begränsar sökningen till det angivna intervallet. Begränsningen innebär att samtliga statusrader för en remiss ska returneras där minst en av statusradernas body.eventTime ligger inom sökintervallets start- och slutdatum eller där en av statusradernas body.eventTime ligger före och en annan efter.\n\nNotera att sökintervallet beskrivs som ett datumintervall. Vid jämförelse konverteras datapostens tidpunkter till datum.\n\nOBS! Datumet gäller för remissen, dvs om någon statusrad faller inom intervallet så ska alla statusrader för denna remiss returneras.",
      "comment" : "TKB-fält: `datePeriod` (`DatePeriodType`, kardinalitet 0..1).",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "https://fhir.inera.se/ig/crm-requeststatus/StructureDefinition/DatePeriodType"
      }]
    },
    {
      "id" : "getrequestactivities-request.sourceSystemHSAId",
      "path" : "getrequestactivities-request.sourceSystemHSAId",
      "short" : "sourceSystemHSAId",
      "definition" : "Källsystemets id\n\nBegränsar sökningen till aktivitet som är skapad i det angivna källsystemet. Tjänsteproducenten förväntas enbart returnera poster som tillhör efterfrågat källsystem.\n\nVärdet på detta fält måste överensstämma med värdet på logicalAddress i anropets tekniska kuvertering (ex. SOAP-header).\n\nDet innebär i praktiken att aggregerande tjänster inte används när detta fält anges.\n\nsystemHSAId.root = 1.2.752.129.2.1.4.1\n\n(HSA-id OID)\n\nSka anges vid begäran på reservnummer.",
      "comment" : "TKB-fält: `sourceSystemHSAId` (`IIType`, kardinalitet 0..1).",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "https://fhir.inera.se/ig/rivta-datatypes/StructureDefinition/IIType"
      }]
    },
    {
      "id" : "getrequestactivities-request.typeOfRequest",
      "path" : "getrequestactivities-request.typeOfRequest",
      "short" : "typeOfRequest",
      "definition" : "Remisstyp\n\nKod som anger vilken typ av remiss som avses.\n\nKV framställantyp\n\nOID: 1.2.752.129.2.2.2.24\n\nGiltiga värden:\n\n1 = röntgenremiss\n\n2 = labbremiss\n\n4 = allmänremiss\n\nSe [R5].",
      "comment" : "TKB-fält: `typeOfRequest` (`CVType`, kardinalitet 0..*).",
      "min" : 0,
      "max" : "*",
      "type" : [{
        "code" : "https://fhir.inera.se/ig/rivta-datatypes/StructureDefinition/CVType"
      }]
    }]
  }
}

```
