# inera.followup-qualityregistry-nkrr#1.2.2: followup: qualityregistry: nkrr

## Pages

* [Hem](index.md)
* [7 Tjänstekontrakt](7-tjanstekontrakt.md)
* [5 Tjänstedomänens meddelandemodeller](5-tjanstedomanens-meddelandemodeller.md)
* [Artifacts Summary](artifacts.md)
* [6 Gemensamma informationskomponenter](6-gemensamma-informationskomponenter.md)
* [3 Tjänstedomänens arkitektur](3-tjanstedomanens-arkitektur.md)
* [4 Tjänstedomänens krav och regler](4-tjanstedomanens-krav-och-regler.md)
* [2 Versionsinformation](2-versionsinformation.md)
* [1 Inledning](1-inledning.md)

## Resources

### CodeSystems

* [ResultCodeEnum](CodeSystem-resultcode-cs.md)

### ValueSets

* [ResultCodeEnum — ValueSet](ValueSet-resultcode-vs.md)

### Logicals

* [GetFormData — Request](StructureDefinition-getformdata-request.md)
* [GetFormData](StructureDefinition-getformdata.md)
* [ProcessRegistrationNotification — Request](StructureDefinition-processregistrationnotification-request.md)
* [ProcessRegistrationNotification](StructureDefinition-processregistrationnotification.md)

### ImplementationGuides

* [followup: qualityregistry: nkrr](index.md)
