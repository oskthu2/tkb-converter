# Hem - followup: qualityregistry: nkrr v1.2.2

* [**Table of Contents**](toc.md)
* **Hem**

## Hem

| | |
| :--- | :--- |
| *Official URL*:https://fhir.inera.se/ig/followup-qualityregistry-nkrr/ImplementationGuide/inera.followup-qualityregistry-nkrr | *Version*:1.2.2 |
| Active as of 2026-10-26 | *Computable Name*:followupqualityregistrynkrr |
| **Copyright/Legal**: Copyright 2024 Inera AB. Licensieras under Creative Commons Attribution 4.0. | |

# followup: qualityregistry: nkrr

**TKB-version:** 1.2.2 · **IG-version:** 1.2.2 · **Källa:** Bitbucket-tagg `1.2.2` 

## Översikt

* Beskrivning: Svenskt kortnamn
  * Tjänstedomänen kvalitetsregister, nkrr består idag av ett tjänstekontrakt som hanterar underlag från vårddokumentation för överföring till kvalitetsregister. Primär användargrupp är de Nationella Kvalitetsregistren, men även andra konsumenter har användning av tjänstekontraktet inom domänen. Tjänstekontraktet avser att förenkla för kvalitetsregistren genom att via anrop hämta beslutsunderlag från vårddokumentationen och ställa samman detta till underlag för registrering.: kvalitetsregister, nkrr
* Beskrivning: Svenskt namn
  * Tjänstedomänen kvalitetsregister, nkrr består idag av ett tjänstekontrakt som hanterar underlag från vårddokumentation för överföring till kvalitetsregister. Primär användargrupp är de Nationella Kvalitetsregistren, men även andra konsumenter har användning av tjänstekontraktet inom domänen. Tjänstekontraktet avser att förenkla för kvalitetsregistren genom att via anrop hämta beslutsunderlag från vårddokumentationen och ställa samman detta till underlag för registrering.: uppföljning kärnprocess: kvalitetsregister:nkrr
* Beskrivning: Typ
  * Tjänstedomänen kvalitetsregister, nkrr består idag av ett tjänstekontrakt som hanterar underlag från vårddokumentation för överföring till kvalitetsregister. Primär användargrupp är de Nationella Kvalitetsregistren, men även andra konsumenter har användning av tjänstekontraktet inom domänen. Tjänstekontraktet avser att förenkla för kvalitetsregistren genom att via anrop hämta beslutsunderlag från vårddokumentationen och ställa samman detta till underlag för registrering.: Extern tjänstedomän
* Beskrivning: Förvaltare
  * Tjänstedomänen kvalitetsregister, nkrr består idag av ett tjänstekontrakt som hanterar underlag från vårddokumentation för överföring till kvalitetsregister. Primär användargrupp är de Nationella Kvalitetsregistren, men även andra konsumenter har användning av tjänstekontraktet inom domänen. Tjänstekontraktet avser att förenkla för kvalitetsregistren genom att via anrop hämta beslutsunderlag från vårddokumentationen och ställa samman detta till underlag för registrering.: SKL
* Beskrivning: Källkod
  * Tjänstedomänen kvalitetsregister, nkrr består idag av ett tjänstekontrakt som hanterar underlag från vårddokumentation för överföring till kvalitetsregister. Primär användargrupp är de Nationella Kvalitetsregistren, men även andra konsumenter har användning av tjänstekontraktet inom domänen. Tjänstekontraktet avser att förenkla för kvalitetsregistren genom att via anrop hämta beslutsunderlag från vårddokumentationen och ställa samman detta till underlag för registrering.: [Bitbucket](https://bitbucket.org/rivta-domains/riv.followup.qualityregistry.nkrr/src)
* Beskrivning: Ärenden
  * Tjänstedomänen kvalitetsregister, nkrr består idag av ett tjänstekontrakt som hanterar underlag från vårddokumentation för överföring till kvalitetsregister. Primär användargrupp är de Nationella Kvalitetsregistren, men även andra konsumenter har användning av tjänstekontraktet inom domänen. Tjänstekontraktet avser att förenkla för kvalitetsregistren genom att via anrop hämta beslutsunderlag från vårddokumentationen och ställa samman detta till underlag för registrering.: [Bitbucket issues](https://bitbucket.org/rivta-domains/riv.followup.qualityregistry.nkrr/issues)
* Beskrivning: Underlag för denna IG
  * Tjänstedomänen kvalitetsregister, nkrr består idag av ett tjänstekontrakt som hanterar underlag från vårddokumentation för överföring till kvalitetsregister. Primär användargrupp är de Nationella Kvalitetsregistren, men även andra konsumenter har användning av tjänstekontraktet inom domänen. Tjänstekontraktet avser att förenkla för kvalitetsregistren genom att via anrop hämta beslutsunderlag från vårddokumentationen och ställa samman detta till underlag för registrering.: Version 1.2.2 ·[tagg 1.2.2](https://bitbucket.org/rivta-domains/riv.followup.qualityregistry.nkrr/src/1.2.2)·[zip](https://bitbucket.org/rivta-domains/riv.followup.qualityregistry.nkrr/raw/master/docs/TKB_followup_qualityregistry_nkrr.docx)
* Beskrivning: RIV-TA-portalen
  * Tjänstedomänen kvalitetsregister, nkrr består idag av ett tjänstekontrakt som hanterar underlag från vårddokumentation för överföring till kvalitetsregister. Primär användargrupp är de Nationella Kvalitetsregistren, men även andra konsumenter har användning av tjänstekontraktet inom domänen. Tjänstekontraktet avser att förenkla för kvalitetsregistren genom att via anrop hämta beslutsunderlag från vårddokumentationen och ställa samman detta till underlag för registrering.: [Alla tjänstedomäner](https://oskthu2.github.io/tkb-converter/rivta-portal/tjanstedomaner.html)·[Alla tjänstekontrakt](https://oskthu2.github.io/tkb-converter/rivta-portal/tjanstekontrakt.html)

FHIR Implementation Guide för tjänstedomänen **followup: qualityregistry: nkrr** version 1.2.2. Genererad från Ineras Tjänstekontraktsbeskrivning (TKB).

Tjänstedomänens omfattning är sammanställning av underlag från vårddokumentation för registrering i kvalitetsregister. Den kravställande processen är kvalitetsregistrens behov av att kunna hämta underlag om patient, samt den speciella juridik detta omges av.

Domänen innehåller följande tjänstekontrakt:

| | | |
| :--- | :--- | :--- |
| [ProcessRegistrationNotification](7-tjanstekontrakt.md#processregistrationnotification) | 1.0 | Möjliggör för vårdgivare att notifiera kvalitetsregister om att vårdgivaren har uppgifter om en patient som avses registreras. |
| [GetFormData](7-tjanstekontrakt.md#getformdata) | 1.2 | Hämtar underlag för ett enskilt kvalitetsregisterformulär från vårddokumentation. |

### Versioner och granskningar

| | | | |
| :--- | :--- | :--- | :--- |
| 1.1.1 | TKB, AB, IS | [Arkitektur & Regelverk: Informatik: Godkänd](http://rivta.se/downloads//followup_qualityregistry_nkrr/1.1.1/VIS_granskning_followup_qualityregistry_nkrr_1.1.1.docx)[Arkitektur & Regelverk: Teknik: Godkänd](http://rivta.se/downloads//followup_qualityregistry_nkrr/1.1.1/T-granskning%20-%20followup_qualityregistry_nkrr_1.1.1.docx)[Arkitektur & Regelverk: Säkerhet: Godkänd](http://rivta.se/downloads//followup_qualityregistry_nkrr/1.1.1/VIS_granskning_followup_qualityregistry_nkrr_1.1.1.docx) | [zip](http://rivta.se/downloads//followup_qualityregistry_nkrr/1.1.1/ServiceContracts_followup_qualityregistry_nkrr_1.1.1.zip)·[källkod](https://bitbucket.org/rivta-domains/riv.followup.qualityregistry.nkrr/src/1.1.1) |
| trunk | AB, IS, TKB |  | [källkod](https://bitbucket.org/rivta-domains/riv.followup.qualityregistry.nkrr/src/master) |

*Källa: ögonblicksbild av DOMDB från 2021-08-24, via RIV-TA-portalen.*

## Innehåll

* [1 Inledning](1-inledning.md)
* [2 Versionsinformation](2-versionsinformation.md)
* [3 Tjänstedomänens arkitektur](3-tjanstedomanens-arkitektur.md)
* [4 Tjänstedomänens krav och regler](4-tjanstedomanens-krav-och-regler.md)
* [5 Tjänstedomänens meddelandemodeller](5-tjanstedomanens-meddelandemodeller.md)
* [6 Gemensamma informationskomponenter](6-gemensamma-informationskomponenter.md)
* [7 Tjänstekontrakt](7-tjanstekontrakt.md)
* [Artefakter](artifacts.md)

