# Hem - followup: qualityregistry: nkrr v1.2.2

* [**Table of Contents**](toc.md)
* **Hem**

## Hem

| | |
| :--- | :--- |
| *Official URL*:https://fhir.inera.se/ig/followup-qualityregistry-nkrr/ImplementationGuide/inera.followup-qualityregistry-nkrr | *Version*:1.2.2 |
| Draft as of 2026-09-14 | *Computable Name*:followupqualityregistrynkrr |
| **Copyright/Legal**: Copyright 2024 Inera AB. Licensieras under Creative Commons Attribution 4.0. | |

# followup: qualityregistry: nkrr

## Översikt

FHIR Implementation Guide för tjänstedomänen **followup: qualityregistry: nkrr** version 1.2.2. Genererad från Ineras Tjänstekontraktsbeskrivning (TKB).

Tjänstedomänens omfattning är sammanställning av underlag från vårddokumentation för registrering i kvalitetsregister. Den kravställande processen är kvalitetsregistrens behov av att kunna hämta underlag om patient, samt den speciella juridik detta omges av.

Domänen innehåller följande tjänstekontrakt:

| | | |
| :--- | :--- | :--- |
| [ProcessRegistrationNotification](7-tjanstekontrakt.md#processregistrationnotification) | 1.0 | Möjliggör för vårdgivare att notifiera kvalitetsregister om att vårdgivaren har uppgifter om en patient som avses registreras. |
| [GetFormData](7-tjanstekontrakt.md#getformdata) | 1.2 | Hämtar underlag för ett enskilt kvalitetsregisterformulär från vårddokumentation. |

## Innehåll

* [1 Inledning](1-inledning.md)
* [2 Versionsinformation](2-versionsinformation.md)
* [3 Tjänstedomänens arkitektur](3-tjanstedomanens-arkitektur.md)
* [4 Tjänstedomänens krav och regler](4-tjanstedomanens-krav-och-regler.md)
* [5 Tjänstedomänens meddelandemodeller](5-tjanstedomanens-meddelandemodeller.md)
* [6 Gemensamma informationskomponenter](6-gemensamma-informationskomponenter.md)
* [7 Tjänstekontrakt](7-tjanstekontrakt.md)
* [Artefakter](artifacts.md)

