# Hem - ehr: commission v1.0.0-snapshot

* [**Table of Contents**](toc.md)
* **Hem**

## Hem

| | |
| :--- | :--- |
| *Official URL*:https://fhir.inera.se/ig/ehr-commission/ImplementationGuide/inera.ehr-commission | *Version*:1.0.0-snapshot |
| Draft as of 2026-10-12 | *Computable Name*:ehrcommission |
| **Copyright/Legal**: Copyright 2024 Inera AB. Licensieras under Creative Commons Attribution 4.0. | |

# ehr: commission

**TKB-version:** 1.0 · **IG-version:** 1.0.0-snapshot · **Källa:** Bitbucket-commit `b93f022377f8` (ingen tagg) 

## Översikt

* Svenskt kortnamn: Svenskt namn
  * uppdragsval: infrastruktur:katalogtjänster:behörighetshantering uppdragsval
* Svenskt kortnamn: Typ
  * uppdragsval: Nationell tjänstedomän
* Svenskt kortnamn: Källkod
  * uppdragsval: [Bitbucket](https://bitbucket.org/rivta-domains/riv.ehr.commission/src)
* Svenskt kortnamn: Ärenden
  * uppdragsval: [Bitbucket issues](https://bitbucket.org/rivta-domains/riv.ehr.commission/issues)
* Svenskt kortnamn: Underlag för denna IG
  * uppdragsval: Version 1.0 ·[commit b93f022377f8](https://bitbucket.org/rivta-domains/riv.ehr.commission/src/b93f022377f84ec4c5eb095992de72a2db4e62b4)
* Svenskt kortnamn: RIV-TA-portalen
  * uppdragsval: [Alla tjänstedomäner](https://oskthu2.github.io/tkb-converter/rivta-portal/tjanstedomaner.html)·[Alla tjänstekontrakt](https://oskthu2.github.io/tkb-converter/rivta-portal/tjanstekontrakt.html)

FHIR Implementation Guide för tjänstedomänen **ehr: commission** version 1.0. Genererad från Ineras Tjänstekontraktsbeskrivning (TKB) — dokument `TKB_ehr_commission_1.0_RC1.docx`.

Den svenska benämningen för denna tjänstedomän är **Uppdragsvalstjänsten**. Tjänstekontraktet är baserat på RIV TA 2.1 och hanterar val av medarbetaruppdrag vid autentisering från rik klient eller tunn klient.

Domänen innehåller följande tjänstekontrakt:

| | | |
| :--- | :--- | :--- |
| [GetCommissionsForPerson](7-tjanstekontrakt.md#getcommissionsforperson) | 1.0 | Hämtar lista med de aktuella medarbetaruppdrag som en användare har samt det senaste valda medarbetaruppdraget. |
| [SetSelectedCommissionForPerson](7-tjanstekontrakt.md#setselectedcommissionforperson) | 1.0 | Sätter vilket medarbetaruppdrag som valdes aktivt av användaren. |

### Versioner och granskningar

| | | | |
| :--- | :--- | :--- | :--- |
| 1.0 | AB, TKB | Äldre granskningsprocess: Teknik: Godkänd | [zip](http://rivta.se/downloads/ehr_commission/1.0/ServiceContracts_ehr_commission_1_0.zip)·[källkod](https://bitbucket.org/rivta-domains/riv.ehr.commission/src/ehr_commission_1.0_RC1) |
| trunk | TKB, AB |  | [källkod](https://bitbucket.org/rivta-domains/riv.ehr.commission/src/master) |

*Källa: ögonblicksbild av DOMDB från 2021-08-24, via RIV-TA-portalen.*

## Innehåll

* [1 Inledning](1-inledning.md)
* [2 Versionsinformation](2-versionsinformation.md)
* [3 Tjänstedomänens arkitektur](3-tjanstedomanens-arkitektur.md)
* [4 Tjänstedomänens krav och regler](4-tjanstedomanens-krav-och-regler.md)
* [5 Tjänstedomänens meddelandemodeller](5-tjanstedomanens-meddelandemodeller.md)
* [6 Gemensamma informationskomponenter](6-gemensamma-informationskomponenter.md)
* [7 Tjänstekontrakt](7-tjanstekontrakt.md)
* [Artefakter](artifacts.md)

