# Hem - ehr: commission v1.0.0

* [**Table of Contents**](toc.md)
* **Hem**

## Hem

| | |
| :--- | :--- |
| *Official URL*:https://fhir.inera.se/ig/ehr-commission/ImplementationGuide/inera.ehr-commission | *Version*:1.0.0 |
| Draft as of 2026-09-17 | *Computable Name*:ehrcommission |
| **Copyright/Legal**: Copyright 2024 Inera AB. Licensieras under Creative Commons Attribution 4.0. | |

# ehr: commission

## Översikt

FHIR Implementation Guide för tjänstedomänen **ehr: commission** version 1.0. Genererad från Ineras Tjänstekontraktsbeskrivning (TKB) — dokument `TKB_ehr_commission_1.0_RC1.docx`.

Den svenska benämningen för denna tjänstedomän är **Uppdragsvalstjänsten**. Tjänstekontraktet är baserat på RIV TA 2.1 och hanterar val av medarbetaruppdrag vid autentisering från rik klient eller tunn klient.

Domänen innehåller följande tjänstekontrakt:

| | | |
| :--- | :--- | :--- |
| [GetCommissionsForPerson](7-tjanstekontrakt.md#getcommissionsforperson) | 1.0 | Hämtar lista med de aktuella medarbetaruppdrag som en användare har samt det senaste valda medarbetaruppdraget. |
| [SetSelectedCommissionForPerson](7-tjanstekontrakt.md#setselectedcommissionforperson) | 1.0 | Sätter vilket medarbetaruppdrag som valdes aktivt av användaren. |

## Innehåll

* [1 Inledning](1-inledning.md)
* [2 Versionsinformation](2-versionsinformation.md)
* [3 Tjänstedomänens arkitektur](3-tjanstedomanens-arkitektur.md)
* [4 Tjänstedomänens krav och regler](4-tjanstedomanens-krav-och-regler.md)
* [5 Tjänstedomänens meddelandemodeller](5-tjanstedomanens-meddelandemodeller.md)
* [6 Gemensamma informationskomponenter](6-gemensamma-informationskomponenter.md)
* [7 Tjänstekontrakt](7-tjanstekontrakt.md)
* [Artefakter](artifacts.md)

