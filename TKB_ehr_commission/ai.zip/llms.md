# inera.ehr-commission#1.0.0: ehr: commission

## Pages

* [Hem](index.md)
* [7 Tjänstekontrakt](7-tjanstekontrakt.md)
* [1 Inledning](1-inledning.md)
* [4 Tjänstedomänens krav och regler](4-tjanstedomanens-krav-och-regler.md)
* [6 Gemensamma informationskomponenter](6-gemensamma-informationskomponenter.md)
* [3 Tjänstedomänens arkitektur](3-tjanstedomanens-arkitektur.md)
* [Artifacts Summary](artifacts.md)
* [2 Versionsinformation](2-versionsinformation.md)
* [5 Tjänstedomänens meddelandemodeller](5-tjanstedomanens-meddelandemodeller.md)

## Resources

### CodeSystems

* [ResultCode](CodeSystem-resultcode-cs.md)

### ValueSets

* [ResultCode — ValueSet](ValueSet-resultcode-vs.md)

### Logicals

* [GetCommissionsForPerson — Request](StructureDefinition-getcommissionsforperson-request.md)
* [GetCommissionsForPerson](StructureDefinition-getcommissionsforperson.md)
* [SetSelectedCommissionForPerson — Request](StructureDefinition-setselectedcommissionforperson-request.md)
* [SetSelectedCommissionForPerson](StructureDefinition-setselectedcommissionforperson.md)

### ImplementationGuides

* [ehr: commission](index.md)
