# inera.clinicalprocess-healthcond-rheuma#1.0.0-snapshot: clinicalprocess: healthcond: rheuma — Reumatismdata

## Pages

* [Hem](index.md)
* [7 Tjänstekontrakt](7-tjanstekontrakt.md)
* [2 Versionsinformation](2-versionsinformation.md)
* [3 Tjänstedomänens arkitektur](3-tjanstedomanens-arkitektur.md)
* [1 Inledning](1-inledning.md)
* [Artifacts Summary](artifacts.md)
* [6 Gemensamma informationskomponenter](6-gemensamma-informationskomponenter.md)
* [5 Tjänstedomänens meddelandemodeller](5-tjanstedomanens-meddelandemodeller.md)
* [4 Tjänstedomänens krav och regler](4-tjanstedomanens-krav-och-regler.md)

## Resources

### CodeSystems

* [DoctorsGlobalEnum](CodeSystem-physiciansglobal-cs.md)

### ValueSets

* [DoctorsGlobalEnum](ValueSet-physiciansglobal-vs.md)

### Logicals

* [DatePeriodType](StructureDefinition-DatePeriodType.md)
* [GetRheumatoidArthritisData — Request](StructureDefinition-getrheumatoidarthritisdata-request.md)
* [GetRheumatoidArthritisData — Response](StructureDefinition-getrheumatoidarthritisdata.md)

### ImplementationGuides

* [clinicalprocess: healthcond: rheuma — Reumatismdata](index.md)
