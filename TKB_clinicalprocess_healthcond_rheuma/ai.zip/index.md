# Hem - clinicalprocess: healthcond: rheuma — Reumatismdata v1.0.0-snapshot

* [**Table of Contents**](toc.md)
* **Hem**

## Hem

| | |
| :--- | :--- |
| *Official URL*:https://fhir.inera.se/ig/clinicalprocess-healthcond-rheuma/ImplementationGuide/inera.clinicalprocess-healthcond-rheuma | *Version*:1.0.0-snapshot |
| Draft as of 2026-10-12 | *Computable Name*:clinicalprocesshealthcondrheuma |
| **Copyright/Legal**: Copyright 2024 Inera AB. Licensieras under Creative Commons Attribution 4.0. | |

# clinicalprocess: healthcond: rheuma — Reumatismdata

**TKB-version:** 1.0 · **IG-version:** 1.0.0-snapshot · **Källa:** Bitbucket-commit `fd5d50cd8a84` (ingen tagg) 

## Översikt

* Beskrivning: Svenskt kortnamn
  * Tjänstedomänen syftar till att tillmötesgå behovet av reumatikerpatienters direktåtkomst till sina sjukdomsspecifika data som en del i projektet ”Journal på nätet” och ”4D”. OBS! Version 1.0_RC3 av denna tjänstedomän har endast tillstånd till en begränsad användning i den nationella tjänsteplattformen, se dess Arkitekturella Beslut för mer information. Detta behov hanteras genom att kombinera andra tjänstekontrakt: reumatism data
* Beskrivning: Svenskt namn
  * Tjänstedomänen syftar till att tillmötesgå behovet av reumatikerpatienters direktåtkomst till sina sjukdomsspecifika data som en del i projektet ”Journal på nätet” och ”4D”. OBS! Version 1.0_RC3 av denna tjänstedomän har endast tillstånd till en begränsad användning i den nationella tjänsteplattformen, se dess Arkitekturella Beslut för mer information. Detta behov hanteras genom att kombinera andra tjänstekontrakt: vård- och omsorg kärnprocess:hantera hälsorelaterade tillstånd:reumatism data
* Beskrivning: Typ
  * Tjänstedomänen syftar till att tillmötesgå behovet av reumatikerpatienters direktåtkomst till sina sjukdomsspecifika data som en del i projektet ”Journal på nätet” och ”4D”. OBS! Version 1.0_RC3 av denna tjänstedomän har endast tillstånd till en begränsad användning i den nationella tjänsteplattformen, se dess Arkitekturella Beslut för mer information. Detta behov hanteras genom att kombinera andra tjänstekontrakt: Extern tjänstedomän
* Beskrivning: Anmärkning
  * Tjänstedomänen syftar till att tillmötesgå behovet av reumatikerpatienters direktåtkomst till sina sjukdomsspecifika data som en del i projektet ”Journal på nätet” och ”4D”. OBS! Version 1.0_RC3 av denna tjänstedomän har endast tillstånd till en begränsad användning i den nationella tjänsteplattformen, se dess Arkitekturella Beslut för mer information. Detta behov hanteras genom att kombinera andra tjänstekontrakt: dold på rivta.se
* Beskrivning: Förvaltare
  * Tjänstedomänen syftar till att tillmötesgå behovet av reumatikerpatienters direktåtkomst till sina sjukdomsspecifika data som en del i projektet ”Journal på nätet” och ”4D”. OBS! Version 1.0_RC3 av denna tjänstedomän har endast tillstånd till en begränsad användning i den nationella tjänsteplattformen, se dess Arkitekturella Beslut för mer information. Detta behov hanteras genom att kombinera andra tjänstekontrakt: SLL
* Beskrivning: Källkod
  * Tjänstedomänen syftar till att tillmötesgå behovet av reumatikerpatienters direktåtkomst till sina sjukdomsspecifika data som en del i projektet ”Journal på nätet” och ”4D”. OBS! Version 1.0_RC3 av denna tjänstedomän har endast tillstånd till en begränsad användning i den nationella tjänsteplattformen, se dess Arkitekturella Beslut för mer information. Detta behov hanteras genom att kombinera andra tjänstekontrakt: [Bitbucket](https://bitbucket.org/rivta-domains/riv.clinicalprocess.healthcond.rheuma/src)
* Beskrivning: Ärenden
  * Tjänstedomänen syftar till att tillmötesgå behovet av reumatikerpatienters direktåtkomst till sina sjukdomsspecifika data som en del i projektet ”Journal på nätet” och ”4D”. OBS! Version 1.0_RC3 av denna tjänstedomän har endast tillstånd till en begränsad användning i den nationella tjänsteplattformen, se dess Arkitekturella Beslut för mer information. Detta behov hanteras genom att kombinera andra tjänstekontrakt: [Bitbucket issues](https://bitbucket.org/rivta-domains/riv.clinicalprocess.healthcond.rheuma/issues)
* Beskrivning: Underlag för denna IG
  * Tjänstedomänen syftar till att tillmötesgå behovet av reumatikerpatienters direktåtkomst till sina sjukdomsspecifika data som en del i projektet ”Journal på nätet” och ”4D”. OBS! Version 1.0_RC3 av denna tjänstedomän har endast tillstånd till en begränsad användning i den nationella tjänsteplattformen, se dess Arkitekturella Beslut för mer information. Detta behov hanteras genom att kombinera andra tjänstekontrakt: Version 1.0 ·[commit fd5d50cd8a84](https://bitbucket.org/rivta-domains/riv.clinicalprocess.healthcond.rheuma/src/fd5d50cd8a84361b984fe012d8742d4997f60103)·[zip](https://bitbucket.org/rivta-domains/riv.clinicalprocess.healthcond.rheuma/get/fd5d50cd8a84.zip)
* Beskrivning: RIV-TA-portalen
  * Tjänstedomänen syftar till att tillmötesgå behovet av reumatikerpatienters direktåtkomst till sina sjukdomsspecifika data som en del i projektet ”Journal på nätet” och ”4D”. OBS! Version 1.0_RC3 av denna tjänstedomän har endast tillstånd till en begränsad användning i den nationella tjänsteplattformen, se dess Arkitekturella Beslut för mer information. Detta behov hanteras genom att kombinera andra tjänstekontrakt: [Alla tjänstedomäner](https://oskthu2.github.io/tkb-converter/rivta-portal/tjanstedomaner.html)·[Alla tjänstekontrakt](https://oskthu2.github.io/tkb-converter/rivta-portal/tjanstekontrakt.html)

FHIR Implementation Guide för tjänstedomänen **clinicalprocess: healthcond: rheuma** ("Vård- och omsorgsprocess, hantera hälsorelaterade tillstånd, reumatismdata") version 1.0. Genererad från Ineras Tjänstekontraktsbeskrivning (TKB).

Tjänstedomänen ska tillgodose reumatikerpatienters behov av direktåtkomst till sina sjukdomsspecifika data, som en del i projekten "Journal på nätet" och "4D".

RIV-TA namnrymd: `urn:riv:clinicalprocess:healthcond:rheuma`

Domänen innehåller följande tjänstekontrakt:

| | | |
| :--- | :--- | :--- |
| [GetRheumatoidArthritisData](7-tjanstekontrakt.md#getrheumatoidarthritisdata) | 1.0 | Returnerar patientskattade värden, läkarens bedömningar, labbvärden och läkemedel ur Reuma beslutsstödsjournal eller motsvarande system |

**Källa:** TKB-dokumentet (`Tjanstekontraktsbeskrivning - clinicalprocess_healthcond_rheuma.docx`, senaste revision 1.0.RC3, 2014-02-20) från Bitbucket `rivta-domains/riv.clinicalprocess.healthcond.rheuma`, commit `fd5d50cd8a84` på `master`. Repot har bara RC-taggar; `master` innehåller samma scheman som `1.0_RC3` men den slutliga dokumentuppsättningen.

### Versioner och granskningar

| | | | |
| :--- | :--- | :--- | :--- |
| 1.0_RC3 | AB, TKB | [Arkitektur & Regelverk: Informatik: Underkänd](http://rivta.se/downloads/clinicalprocess_healthcond_rheuma/1.0_RC3/VIS_granskning_rheuma.docx)[Arkitektur & Regelverk: Teknik: Godkänd](http://rivta.se/downloads/clinicalprocess_healthcond_rheuma/1.0_RC3/AL-T%20Granskning%20av%20clinicalprocess_healthcond_rheuma_1.0_RC3%20PA_1.docx)[Arkitektur & Regelverk: Säkerhet: Underkänd](http://rivta.se/downloads/clinicalprocess_healthcond_rheuma/1.0_RC3/VIS_granskning_rheuma.docx) | [zip](http://rivta.se/downloads/clinicalprocess_healthcond_rheuma/1.0_RC3/ServiceContracts_clinicalprocess_healthcond_rheuma_1.0_RC3.zip)·[källkod](https://bitbucket.org/rivta-domains/riv.clinicalprocess.healthcond.rheuma/src/clinicalprocess_healthcond_rheuma_1.0_RC3) |
| trunk |  |  | [källkod](https://bitbucket.org/rivta-domains/riv.clinicalprocess.healthcond.rheuma/src/master) |

*Källa: ögonblicksbild av DOMDB från 2021-08-24, via RIV-TA-portalen.*

## Innehåll

* [1 Inledning](1-inledning.md)
* [2 Versionsinformation](2-versionsinformation.md)
* [3 Tjänstedomänens arkitektur](3-tjanstedomanens-arkitektur.md)
* [4 Tjänstedomänens krav och regler](4-tjanstedomanens-krav-och-regler.md)
* [5 Tjänstedomänens meddelandemodeller](5-tjanstedomanens-meddelandemodeller.md)
* [6 Gemensamma informationskomponenter](6-gemensamma-informationskomponenter.md)
* [7 Tjänstekontrakt](7-tjanstekontrakt.md)
* [Artefakter](artifacts.md)

