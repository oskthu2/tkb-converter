# Hem - clinicalprocess: healthcond: rheuma — Reumatismdata v1.0.0

* [**Table of Contents**](toc.md)
* **Hem**

## Hem

| | |
| :--- | :--- |
| *Official URL*:https://fhir.inera.se/ig/clinicalprocess-healthcond-rheuma/ImplementationGuide/inera.clinicalprocess-healthcond-rheuma | *Version*:1.0.0 |
| Draft as of 2026-09-26 | *Computable Name*:clinicalprocesshealthcondrheuma |
| **Copyright/Legal**: Copyright 2024 Inera AB. Licensieras under Creative Commons Attribution 4.0. | |

# clinicalprocess: healthcond: rheuma — Reumatismdata

## Översikt

FHIR Implementation Guide för tjänstedomänen **clinicalprocess: healthcond: rheuma** ("Vård- och omsorgsprocess, hantera hälsorelaterade tillstånd, reumatismdata") version 1.0. Genererad från Ineras Tjänstekontraktsbeskrivning (TKB).

Tjänstedomänen ska tillgodose reumatikerpatienters behov av direktåtkomst till sina sjukdomsspecifika data, som en del i projekten "Journal på nätet" och "4D".

RIV-TA namnrymd: `urn:riv:clinicalprocess:healthcond:rheuma`

Domänen innehåller följande tjänstekontrakt:

| | | |
| :--- | :--- | :--- |
| [GetRheumatoidArthritisData](7-tjanstekontrakt.md#getrheumatoidarthritisdata) | 1.0 | Returnerar patientskattade värden, läkarens bedömningar, labbvärden och läkemedel ur Reuma beslutsstödsjournal eller motsvarande system |

**Källa:** TKB-dokumentet (`Tjanstekontraktsbeskrivning - clinicalprocess_healthcond_rheuma.docx`, senaste revision 1.0.RC3, 2014-02-20) från Bitbucket `rivta-domains/riv.clinicalprocess.healthcond.rheuma`, commit `fd5d50cd8a84` på `master`. Repot har bara RC-taggar; `master` innehåller samma scheman som `1.0_RC3` men den slutliga dokumentuppsättningen.

## Innehåll

* [1 Inledning](1-inledning.md)
* [2 Versionsinformation](2-versionsinformation.md)
* [3 Tjänstedomänens arkitektur](3-tjanstedomanens-arkitektur.md)
* [4 Tjänstedomänens krav och regler](4-tjanstedomanens-krav-och-regler.md)
* [5 Tjänstedomänens meddelandemodeller](5-tjanstedomanens-meddelandemodeller.md)
* [6 Gemensamma informationskomponenter](6-gemensamma-informationskomponenter.md)
* [7 Tjänstekontrakt](7-tjanstekontrakt.md)
* [Artefakter](artifacts.md)

