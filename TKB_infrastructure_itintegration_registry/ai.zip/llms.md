# inera.infrastructure-itintegration-registry#2: infrastructure: itintegration: registry

## Pages

* [Hem](index.md)
* [7 Tjänstekontrakt](7-tjanstekontrakt.md)
* [1 Inledning](1-inledning.md)
* [4 Tjänstedomänens krav och regler](4-tjanstedomanens-krav-och-regler.md)
* [6 Gemensamma informationskomponenter](6-gemensamma-informationskomponenter.md)
* [3 Tjänstedomänens arkitektur](3-tjanstedomanens-arkitektur.md)
* [Artifacts Summary](artifacts.md)
* [Versionsinformation](2-versionsinformation.md)
* [5 Tjänstedomänens meddelandemodeller](5-tjanstedomanens-meddelandemodeller.md)

## Resources

### Logicals

* [GetLogicalAddresseesByServiceContract](StructureDefinition-getlogicaladdresseesbyservicecontract.md)
* [GetSupportedServiceContracts](StructureDefinition-getsupportedservicecontracts.md)

### ImplementationGuides

* [infrastructure: itintegration: registry](index.md)
