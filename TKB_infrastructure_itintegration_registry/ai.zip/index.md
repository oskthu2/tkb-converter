# Hem - infrastructure: itintegration: registry v2.0.0

* [**Table of Contents**](toc.md)
* **Hem**

## Hem

| | |
| :--- | :--- |
| *Official URL*:https://fhir.inera.se/ig/infrastructure-itintegration-registry/ImplementationGuide/inera.infrastructure-itintegration-registry | *Version*:2.0.0 |
| Active as of 2026-11-06 | *Computable Name*:InfrastructureItintegrationRegistry |
| **Copyright/Legal**: Copyright 2024 Inera AB. Licensieras under Creative Commons Attribution 4.0. | |

# infrastructure: itintegration: registry

**TKB-version:** 2.0 · **IG-version:** 2.0.0 · **Källa:** Bitbucket-tagg `2.0` 

## Översikt

* Beskrivning: Svenskt kortnamn
  * Tjänsteadressering är en stödtjänst som används av en tjänsteplattform. Denna tjänstedomän omfattar informationsstrukturer och tjänster för åtkomst och hantering av tjänsteadressringsinformation. Tjänsteadressering syftar på den i T-boken beskrivna logiska komponenten tjänsteadresseringskatalog.: tjänsteadressering
* Beskrivning: Svenskt namn
  * Tjänsteadressering är en stödtjänst som används av en tjänsteplattform. Denna tjänstedomän omfattar informationsstrukturer och tjänster för åtkomst och hantering av tjänsteadressringsinformation. Tjänsteadressering syftar på den i T-boken beskrivna logiska komponenten tjänsteadresseringskatalog.: infrastruktur:tjänsteförmedlingstjänster:förmedlingsinformation
* Beskrivning: Typ
  * Tjänsteadressering är en stödtjänst som används av en tjänsteplattform. Denna tjänstedomän omfattar informationsstrukturer och tjänster för åtkomst och hantering av tjänsteadressringsinformation. Tjänsteadressering syftar på den i T-boken beskrivna logiska komponenten tjänsteadresseringskatalog.: Nationell tjänstedomän
* Beskrivning: Källkod
  * Tjänsteadressering är en stödtjänst som används av en tjänsteplattform. Denna tjänstedomän omfattar informationsstrukturer och tjänster för åtkomst och hantering av tjänsteadressringsinformation. Tjänsteadressering syftar på den i T-boken beskrivna logiska komponenten tjänsteadresseringskatalog.: [Bitbucket](https://bitbucket.org/rivta-domains/riv.infrastructure.itintegration.registry/src)
* Beskrivning: Ärenden
  * Tjänsteadressering är en stödtjänst som används av en tjänsteplattform. Denna tjänstedomän omfattar informationsstrukturer och tjänster för åtkomst och hantering av tjänsteadressringsinformation. Tjänsteadressering syftar på den i T-boken beskrivna logiska komponenten tjänsteadresseringskatalog.: [Bitbucket issues](https://bitbucket.org/rivta-domains/riv.infrastructure.itintegration.registry/issues)
* Beskrivning: Underlag för denna IG
  * Tjänsteadressering är en stödtjänst som används av en tjänsteplattform. Denna tjänstedomän omfattar informationsstrukturer och tjänster för åtkomst och hantering av tjänsteadressringsinformation. Tjänsteadressering syftar på den i T-boken beskrivna logiska komponenten tjänsteadresseringskatalog.: Version 2.0 ·[tagg 2.0](https://bitbucket.org/rivta-domains/riv.infrastructure.itintegration.registry/src/2.0)·[zip](https://bitbucket.org/rivta-domains/riv.infrastructure.itintegration.registry/get/2.0.zip)
* Beskrivning: RIV-TA-portalen
  * Tjänsteadressering är en stödtjänst som används av en tjänsteplattform. Denna tjänstedomän omfattar informationsstrukturer och tjänster för åtkomst och hantering av tjänsteadressringsinformation. Tjänsteadressering syftar på den i T-boken beskrivna logiska komponenten tjänsteadresseringskatalog.: [Alla tjänstedomäner](https://oskthu2.github.io/tkb-converter/rivta-portal/tjanstedomaner.html)·[Alla tjänstekontrakt](https://oskthu2.github.io/tkb-converter/rivta-portal/tjanstekontrakt.html)

FHIR Implementation Guide för tjänstedomänen **infrastructure: itintegration: registry** version 2.0. Genererad från Ineras Tjänstekontraktsbeskrivning (TKB).

Version 1.0 av tjänsterna (namnrymd `urn:riv:itintegration:registry:1`) finns i IG:n för itintegration: registry.

Tjänsteadressering är en stödtjänst som används av en tjänsteplattform. Denna tjänstedomän omfattar informationsstrukturer och tjänster för åtkomst och hantering av tjänsteadressringsinformation.

Domänen innehåller följande tjänstekontrakt:

| | | |
| :--- | :--- | :--- |
| [GetLogicalAddresseesByServiceContract](7-tjanstekontrakt.md#getlogicaladdresseesbyservicecontract) | 2.0 | Returnerar en lista över logiska adressater som har en tjänsteproducent för angivet tjänstekontrakt och anropsbehörighet för angiven tjänstekonsument. |
| [GetSupportedServiceContracts](7-tjanstekontrakt.md#getsupportedservicecontracts) | 2.0 | Returnerar en lista över tjänstekontrakt som stöds av en specifik logisk adressat. |

### Versioner och granskningar

| | | | |
| :--- | :--- | :--- | :--- |
| 2.0_RC8 | AB, TKB | Arkitektur & Regelverk: Teknik: Godkänd | [zip](https://bitbucket.org/rivta-domains/riv.infrastructure.itintegration.registry/get/infrastructure_itintegration_registry_2.0_RC8.zip)·[källkod](https://bitbucket.org/rivta-domains/riv.infrastructure.itintegration.registry/src/infrastructure_itintegration_registry_2.0_RC8) |
| trunk | AB, TKB |  | [källkod](https://bitbucket.org/rivta-domains/riv.infrastructure.itintegration.registry/src/master) |

*Zip-arkiven hämtas från taggarna på Bitbucket. Granskningsprotokollen publicerades på rivta.se och länkas inte härifrån.*

*Källa: ögonblicksbild av DOMDB från 2021-08-24, via RIV-TA-portalen.*

## Innehåll

* [1 Inledning](1-inledning.md)
* [2 Versionsinformation](2-versionsinformation.md)
* [3 Tjänstedomänens arkitektur](3-tjanstedomanens-arkitektur.md)
* [4 Tjänstedomänens krav och regler](4-tjanstedomanens-krav-och-regler.md)
* [5 Tjänstedomänens meddelandemodeller](5-tjanstedomanens-meddelandemodeller.md)
* [6 Gemensamma informationskomponenter](6-gemensamma-informationskomponenter.md)
* [7 Tjänstekontrakt](7-tjanstekontrakt.md)
* [Artefakter](artifacts.md)

