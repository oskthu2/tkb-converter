# Hem - infrastructure: itintegration: registry v2

* [**Table of Contents**](toc.md)
* **Hem**

## Hem

| | |
| :--- | :--- |
| *Official URL*:https://fhir.inera.se/ig/infrastructure-itintegration-registry/ImplementationGuide/inera.infrastructure-itintegration-registry | *Version*:2 |
| Draft as of 2026-09-26 | *Computable Name*:InfrastructureItintegrationRegistry |
| **Copyright/Legal**: Copyright 2024 Inera AB. Licensieras under Creative Commons Attribution 4.0. | |

# infrastructure: itintegration: registry

## Översikt

FHIR Implementation Guide för tjänstedomänen **infrastructure: itintegration: registry** version 2.0. Genererad från Ineras Tjänstekontraktsbeskrivning (TKB).

Tjänsteadressering är en stödtjänst som används av en tjänsteplattform. Denna tjänstedomän omfattar informationsstrukturer och tjänster för åtkomst och hantering av tjänsteadressringsinformation.

Domänen innehåller följande tjänstekontrakt:

| | | |
| :--- | :--- | :--- |
| [GetLogicalAddresseesByServiceContract](7-tjanstekontrakt.md#getlogicaladdresseesbyservicecontract) | 2.0 | Returnerar en lista över logiska adressater som har en tjänsteproducent för angivet tjänstekontrakt och anropsbehörighet för angiven tjänstekonsument. |
| [GetSupportedServiceContracts](7-tjanstekontrakt.md#getsupportedservicecontracts) | 2.0 | Returnerar en lista över tjänstekontrakt som stöds av en specifik logisk adressat. |

## Innehåll

* [1 Inledning](1-inledning.md)
* [2 Versionsinformation](2-versionsinformation.md)
* [3 Tjänstedomänens arkitektur](3-tjanstedomanens-arkitektur.md)
* [4 Tjänstedomänens krav och regler](4-tjanstedomanens-krav-och-regler.md)
* [5 Tjänstedomänens meddelandemodeller](5-tjanstedomanens-meddelandemodeller.md)
* [6 Gemensamma informationskomponenter](6-gemensamma-informationskomponenter.md)
* [7 Tjänstekontrakt](7-tjanstekontrakt.md)
* [Artefakter](artifacts.md)

