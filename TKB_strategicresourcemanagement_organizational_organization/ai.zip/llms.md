# inera.strategicresourcemanagement-organizational-organization#2.0.0-rc1: strategicresourcemanagement: organizational: organization

## Pages

* [Hem](index.md)
* [7 Tjänstekontrakt](7-tjanstekontrakt.md)
* [8 Bilaga, attributtabeller](8-bilaga-attributtabeller.md)
* [2 Versionsinformation](2-versionsinformation.md)
* [3 Tjänstedomänens arkitektur](3-tjanstedomanens-arkitektur.md)
* [1 Inledning](1-inledning.md)
* [Artifacts Summary](artifacts.md)
* [6 Gemensamma informationskomponenter](6-gemensamma-informationskomponenter.md)
* [5 Tjänstedomänens meddelandemodeller](5-tjanstedomanens-meddelandemodeller.md)
* [4 Tjänstedomänens krav och regler](4-tjanstedomanens-krav-och-regler.md)

## Resources

### Logicals

* [GetHealthCareUnit — Request](StructureDefinition-gethealthcareunit-request.md)
* [GetHealthCareUnit — Response](StructureDefinition-gethealthcareunit.md)
* [GetHealthCareUnitIncludingManager — Request](StructureDefinition-gethealthcareunitincludingmanager-request.md)
* [GetHealthCareUnitIncludingManager — Response](StructureDefinition-gethealthcareunitincludingmanager.md)
* [GetHealthCareUnitList — Request](StructureDefinition-gethealthcareunitlist-request.md)
* [GetHealthCareUnitList — Response](StructureDefinition-gethealthcareunitlist.md)
* [GetHealthCareUnitMembers — Request](StructureDefinition-gethealthcareunitmembers-request.md)
* [GetHealthCareUnitMembers — Response](StructureDefinition-gethealthcareunitmembers.md)
* [GetUnit — Request](StructureDefinition-getunit-request.md)
* [GetUnit — Response](StructureDefinition-getunit.md)

### ImplementationGuides

* [strategicresourcemanagement: organizational: organization](index.md)
