# Hem - strategicresourcemanagement: organizational: organization v2.0.0-rc1

* [**Table of Contents**](toc.md)
* **Hem**

## Hem

| | |
| :--- | :--- |
| *Official URL*:https://fhir.inera.se/ig/strategicresourcemanagement-organizational-organization/ImplementationGuide/inera.strategicresourcemanagement-organizational-organization | *Version*:2.0.0-rc1 |
| Draft as of 2026-10-26 | *Computable Name*:strategicresourcemanagementorganizationalorganization |
| **Copyright/Legal**: Copyright 2024 Inera AB. Licensieras under Creative Commons Attribution 4.0. | |

# strategicresourcemanagement: organizational: organization

**TKB-version:** 2.0_RC1 · **IG-version:** 2.0.0-rc1 · **Källa:** Bitbucket-commit `b349285d18c2`, efter taggen `2.0_RC1` 

## Översikt

* Beskrivning: Svenskt kortnamn
  * Tjänstedomänens ändamål är att förse övriga tjänster med kvalitetssäkrade och aktuella organisations-, enhets- och funktionsuppgifter. Användningsområden utgörs främst av • Publika vårdsökningar efter kontaktinformation till enheter verksamma inom vård och omsorg • Hämtning av information om vårdgivare och vårdenheter kopplade till Patientdatalagen, PDL: organisation
* Beskrivning: Svenskt namn
  * Tjänstedomänens ändamål är att förse övriga tjänster med kvalitetssäkrade och aktuella organisations-, enhets- och funktionsuppgifter. Användningsområden utgörs främst av • Publika vårdsökningar efter kontaktinformation till enheter verksamma inom vård och omsorg • Hämtning av information om vårdgivare och vårdenheter kopplade till Patientdatalagen, PDL: infrastruktur:katalogtjänster:organisation
* Beskrivning: Typ
  * Tjänstedomänens ändamål är att förse övriga tjänster med kvalitetssäkrade och aktuella organisations-, enhets- och funktionsuppgifter. Användningsområden utgörs främst av • Publika vårdsökningar efter kontaktinformation till enheter verksamma inom vård och omsorg • Hämtning av information om vårdgivare och vårdenheter kopplade till Patientdatalagen, PDL: Nationell tjänstedomän
* Beskrivning: Anmärkning
  * Tjänstedomänens ändamål är att förse övriga tjänster med kvalitetssäkrade och aktuella organisations-, enhets- och funktionsuppgifter. Användningsområden utgörs främst av • Publika vårdsökningar efter kontaktinformation till enheter verksamma inom vård och omsorg • Hämtning av information om vårdgivare och vårdenheter kopplade till Patientdatalagen, PDL: dold på rivta.se
* Beskrivning: Källkod
  * Tjänstedomänens ändamål är att förse övriga tjänster med kvalitetssäkrade och aktuella organisations-, enhets- och funktionsuppgifter. Användningsområden utgörs främst av • Publika vårdsökningar efter kontaktinformation till enheter verksamma inom vård och omsorg • Hämtning av information om vårdgivare och vårdenheter kopplade till Patientdatalagen, PDL: [Bitbucket](https://bitbucket.org/rivta-domains/riv.strategicresourcemanagement.organizational.organization/src)
* Beskrivning: Ärenden
  * Tjänstedomänens ändamål är att förse övriga tjänster med kvalitetssäkrade och aktuella organisations-, enhets- och funktionsuppgifter. Användningsområden utgörs främst av • Publika vårdsökningar efter kontaktinformation till enheter verksamma inom vård och omsorg • Hämtning av information om vårdgivare och vårdenheter kopplade till Patientdatalagen, PDL: [Bitbucket issues](https://bitbucket.org/rivta-domains/riv.strategicresourcemanagement.organizational.organization/issues)
* Beskrivning: Underlag för denna IG
  * Tjänstedomänens ändamål är att förse övriga tjänster med kvalitetssäkrade och aktuella organisations-, enhets- och funktionsuppgifter. Användningsområden utgörs främst av • Publika vårdsökningar efter kontaktinformation till enheter verksamma inom vård och omsorg • Hämtning av information om vårdgivare och vårdenheter kopplade till Patientdatalagen, PDL: Version 2.0_RC1 ·[tagg 2.0_RC1](https://bitbucket.org/rivta-domains/riv.strategicresourcemanagement.organizational.organization/src/2.0_RC1)·[zip](https://bitbucket.org/rivta-domains/riv.strategicresourcemanagement.organizational.organization/get/b349285d18c2.zip)
* Beskrivning: RIV-TA-portalen
  * Tjänstedomänens ändamål är att förse övriga tjänster med kvalitetssäkrade och aktuella organisations-, enhets- och funktionsuppgifter. Användningsområden utgörs främst av • Publika vårdsökningar efter kontaktinformation till enheter verksamma inom vård och omsorg • Hämtning av information om vårdgivare och vårdenheter kopplade till Patientdatalagen, PDL: [Alla tjänstedomäner](https://oskthu2.github.io/tkb-converter/rivta-portal/tjanstedomaner.html)·[Alla tjänstekontrakt](https://oskthu2.github.io/tkb-converter/rivta-portal/tjanstekontrakt.html)

FHIR Implementation Guide för tjänstedomänen **strategicresourcemanagement: organizational: organization** (infrastruktur: katalogtjänster: organisation), version 2.0_RC1. Genererad från Ineras Tjänstekontraktsbeskrivning (TKB) och domänens WSDL- och XSD-filer i senaste commit med innehåll (b349285d18c2, 2017-02-27, efter taggen 2.0_RC1).

> **Utgången domän.** Domänen kom aldrig längre än 2.0_RC1. I september 2017 flyttades tjänstekontrakten till infrastructure.directory.organization, som har en egen IG. Domänens repo är sedan dess tomt.

Tjänstedomänens ändamål är att förse övriga tjänster med kvalitetssäkrade och aktuella organisations-, enhets- och funktionsuppgifter ur HSA.

Domänen innehåller följande tjänstekontrakt:

| | | |
| :--- | :--- | :--- |
| [GetHealthCareUnit](7-tjanstekontrakt.md#gethealthcareunit) | 2.0 | Metoden söker ut vilken vårdenhet den angivna enheten eller funktionen är kopplad till. Kan användas av tjänstekonsumenten för att koppla ihop en enhet eller funktion i ett vårdsystem med vårdenhet i enlighet med PDL. Notera särskilt att alla enheter inte är kopplade till en vårdenhet. Om enheten i sig själv är utpekad som vårdenhet markeras detta med en flagga i svaret. |
| [GetHealthCareUnitList](7-tjanstekontrakt.md#gethealthcareunitlist) | 2.0 | Metoden söker fram och listar en angiven vårdgivares alla vårdenheter, definierade enligt PDL. Kan användas av tjänstekonsumenten för att t.ex. skapa en förvalslista i ett användargränssnitt. |
| [GetHealthCareUnitMembers](7-tjanstekontrakt.md#gethealthcareunitmembers) | 2.0 | Metoden söker fram alla kopplade enheter för den angivna vårdenheten. Kan användas av tjänstekonsumenten för att se vilka mottagningar och avdelningar som ingår i en klinik eller för att i ett användargränssnitt skapa en förvalslista med samtliga arbetsplatskoder kopplade till vårdenheten. Notera särskilt att alla enheter inte är kopplade till en vårdenhet och att samtliga arbetsplatskoder inte finns registrerade. |
| [GetUnit](7-tjanstekontrakt.md#getunit) | 2.0 | GetUnit returnerar information om den angivna enheten (med enhet avses här alla typer av organisatoriska objekt, d.v.s. både organisation, enhet och funktion). Kan användas av tjänstekonsumenten för att presentera detaljerad information om en enhet i t.ex. en vårdsökning eller en kontaktlista. Notera särskilt att alla attribut inte är obligatoriska och att ytterst få enheter innehåller samtlig information enligt nedan specifikation. |
| [GetHealthCareUnitIncludingManager](7-tjanstekontrakt.md#gethealthcareunitincludingmanager) | 2.0 | Metoden söker ut vilken vårdenhet den angivna enheten eller funktionen är kopplad till. Kan användas av tjänstekonsumenten för att koppla ihop en enhet eller funktion i ett vårdsystem med vårdenhet i enlighet med PDL. Notera särskilt att alla enheter inte är kopplade till en vårdenhet. Om enheten i sig själv är utpekad som vårdenhet markeras detta med en flagga i svaret. Metoden är identisk med GetHealthCareUnit men innehåller även attribut för utpekad verksamhetschef i söksvaret. |

### Versioner och granskningar

| | | | |
| :--- | :--- | :--- | :--- |
| 2.0_RC1 | AB, TKB | [Arkitektur & Regelverk: Teknik: Godkänd](http://rivta.se/downloads//strategicresourcemanagement_organizational_organization/2.0_RC1/T-granskning%20strategicresourcemanagement_organizational_organization_2.0_RC1.docx) | [zip](http://rivta.se/downloads//strategicresourcemanagement_organizational_organization/2.0_RC1/ServiceContracts_strategicresourcemanagement_organizational_organization_2.0_RC1.zip)·[källkod](https://bitbucket.org/rivta-domains/riv.strategicresourcemanagement.organizational.organization/src/2.0_RC1) |
| trunk |  |  |  |

*Källa: ögonblicksbild av DOMDB från 2021-08-24, via RIV-TA-portalen.*

## Innehåll

* [1 Inledning](1-inledning.md)
* [2 Versionsinformation](2-versionsinformation.md)
* [3 Tjänstedomänens arkitektur](3-tjanstedomanens-arkitektur.md)
* [4 Tjänstedomänens krav och regler](4-tjanstedomanens-krav-och-regler.md)
* [5 Tjänstedomänens meddelandemodeller](5-tjanstedomanens-meddelandemodeller.md)
* [6 Gemensamma informationskomponenter](6-gemensamma-informationskomponenter.md)
* [7 Tjänstekontrakt](7-tjanstekontrakt.md)
* [8 Bilaga, attributtabeller](8-bilaga-attributtabeller.md)
* [Artefakter](artifacts.md)

