# GetUnit — Response - strategicresourcemanagement: organizational: organization v2.0.0-rc1

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **GetUnit — Response**

## Logical Model: GetUnit — Response 

| | |
| :--- | :--- |
| *Official URL*:https://fhir.inera.se/ig/strategicresourcemanagement-organizational-organization/StructureDefinition/getunit | *Version*:2.0.0-rc1 |
| Draft as of 2026-09-28 | *Computable Name*:GetUnit |
| **Copyright/Legal**: Copyright 2024 Inera AB. Licensieras under Creative Commons Attribution 4.0. | |

 
Logisk modell för svaret i GetUnit (urn:riv:strategicresourcemanagement:organizational:organization:GetUnitResponder:2, GetUnitResponseType). 

**Usages:**

* This Logical Model is not used by any profiles in this Specification

You can also check for [usages in the FHIR IG Statistics](https://packages2.fhir.org/xig/resource/inera.strategicresourcemanagement-organizational-organization|current/StructureDefinition/StructureDefinition-getunit.json)

### Formal Views of Profile Content

 [Description of Profiles, Differentials, Snapshots and how the different presentations work](http://build.fhir.org/ig/FHIR/ig-guidance/readingIgs.html#structure-definitions). 

 

Other representations of profile: [CSV](StructureDefinition-getunit.csv), [Excel](StructureDefinition-getunit.xlsx) 



## Resource Content

```json
{
  "resourceType" : "StructureDefinition",
  "id" : "getunit",
  "extension" : [{
    "url" : "http://hl7.org/fhir/StructureDefinition/structuredefinition-type-characteristics",
    "valueCode" : "can-be-target"
  }],
  "url" : "https://fhir.inera.se/ig/strategicresourcemanagement-organizational-organization/StructureDefinition/getunit",
  "version" : "2.0.0-rc1",
  "name" : "GetUnit",
  "title" : "GetUnit — Response",
  "status" : "draft",
  "date" : "2026-09-28T09:21:42+00:00",
  "contact" : [{
    "name" : "Inera Arkitektur",
    "telecom" : [{
      "system" : "url",
      "value" : "https://www.inera.se"
    }]
  }],
  "description" : "Logisk modell för svaret i GetUnit\n(urn:riv:strategicresourcemanagement:organizational:organization:GetUnitResponder:2, GetUnitResponseType).",
  "copyright" : "Copyright 2024 Inera AB. Licensieras under Creative Commons Attribution 4.0.",
  "fhirVersion" : "4.0.1",
  "kind" : "logical",
  "abstract" : false,
  "type" : "https://fhir.inera.se/ig/strategicresourcemanagement-organizational-organization/StructureDefinition/getunit",
  "baseDefinition" : "http://hl7.org/fhir/StructureDefinition/Base",
  "derivation" : "specialization",
  "differential" : {
    "element" : [{
      "id" : "getunit",
      "path" : "getunit",
      "short" : "GetUnit — Response",
      "definition" : "Logisk modell för svaret i GetUnit\n(urn:riv:strategicresourcemanagement:organizational:organization:GetUnitResponder:2, GetUnitResponseType)."
    },
    {
      "id" : "getunit.unit",
      "path" : "getunit.unit",
      "short" : "unit",
      "definition" : "unit",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "BackboneElement"
      }]
    },
    {
      "id" : "getunit.unit.alternateName",
      "path" : "getunit.unit.alternateName",
      "short" : "alternateName",
      "definition" : "alternateName",
      "min" : 0,
      "max" : "*",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "getunit.unit.alternateText",
      "path" : "getunit.unit.alternateText",
      "short" : "alternateText",
      "definition" : "alternateText",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "getunit.unit.businessClassification",
      "path" : "getunit.unit.businessClassification",
      "short" : "businessClassification",
      "definition" : "businessClassification",
      "min" : 0,
      "max" : "*",
      "type" : [{
        "code" : "BackboneElement"
      }]
    },
    {
      "id" : "getunit.unit.businessClassification.businessClassificationName",
      "path" : "getunit.unit.businessClassification.businessClassificationName",
      "short" : "businessClassificationName",
      "definition" : "businessClassificationName",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "getunit.unit.businessClassification.businessClassificationCode",
      "path" : "getunit.unit.businessClassification.businessClassificationCode",
      "short" : "businessClassificationCode",
      "definition" : "businessClassificationCode",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "getunit.unit.businessType",
      "path" : "getunit.unit.businessType",
      "short" : "businessType",
      "definition" : "businessType",
      "min" : 0,
      "max" : "*",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "getunit.unit.careType",
      "path" : "getunit.unit.careType",
      "short" : "careType",
      "definition" : "careType",
      "min" : 0,
      "max" : "*",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "getunit.unit.countyName",
      "path" : "getunit.unit.countyName",
      "short" : "countyName",
      "definition" : "countyName",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "getunit.unit.countyCode",
      "path" : "getunit.unit.countyCode",
      "short" : "countyCode",
      "definition" : "countyCode",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "getunit.unit.description",
      "path" : "getunit.unit.description",
      "short" : "description",
      "definition" : "description",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "getunit.unit.directoryContact",
      "path" : "getunit.unit.directoryContact",
      "short" : "directoryContact",
      "definition" : "directoryContact",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "getunit.unit.displayOption",
      "path" : "getunit.unit.displayOption",
      "short" : "displayOption",
      "definition" : "displayOption",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "getunit.unit.dropInHour",
      "path" : "getunit.unit.dropInHour",
      "short" : "dropInHour",
      "definition" : "dropInHour",
      "min" : 0,
      "max" : "*",
      "type" : [{
        "code" : "BackboneElement"
      }]
    },
    {
      "id" : "getunit.unit.dropInHour.fromDay",
      "path" : "getunit.unit.dropInHour.fromDay",
      "short" : "fromDay",
      "definition" : "fromDay",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "getunit.unit.dropInHour.fromTime",
      "path" : "getunit.unit.dropInHour.fromTime",
      "short" : "fromTime",
      "definition" : "fromTime",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "time"
      }]
    },
    {
      "id" : "getunit.unit.dropInHour.toDay",
      "path" : "getunit.unit.dropInHour.toDay",
      "short" : "toDay",
      "definition" : "toDay",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "getunit.unit.dropInHour.toTime",
      "path" : "getunit.unit.dropInHour.toTime",
      "short" : "toTime",
      "definition" : "toTime",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "time"
      }]
    },
    {
      "id" : "getunit.unit.dropInHour.comment",
      "path" : "getunit.unit.dropInHour.comment",
      "short" : "comment",
      "definition" : "comment",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "getunit.unit.mail",
      "path" : "getunit.unit.mail",
      "short" : "mail",
      "definition" : "mail",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "getunit.unit.facsimileTelephoneNumber",
      "path" : "getunit.unit.facsimileTelephoneNumber",
      "short" : "facsimileTelephoneNumber",
      "definition" : "facsimileTelephoneNumber",
      "min" : 0,
      "max" : "*",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "getunit.unit.geographicalCoordinatesRt90",
      "path" : "getunit.unit.geographicalCoordinatesRt90",
      "short" : "geographicalCoordinatesRt90",
      "definition" : "geographicalCoordinatesRt90",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "BackboneElement"
      }]
    },
    {
      "id" : "getunit.unit.geographicalCoordinatesRt90.xCoordinate",
      "path" : "getunit.unit.geographicalCoordinatesRt90.xCoordinate",
      "short" : "xCoordinate",
      "definition" : "xCoordinate",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "getunit.unit.geographicalCoordinatesRt90.yCoordinate",
      "path" : "getunit.unit.geographicalCoordinatesRt90.yCoordinate",
      "short" : "yCoordinate",
      "definition" : "yCoordinate",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "getunit.unit.geographicalCoordinatesSWEREF99",
      "path" : "getunit.unit.geographicalCoordinatesSWEREF99",
      "short" : "geographicalCoordinatesSWEREF99",
      "definition" : "geographicalCoordinatesSWEREF99",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "BackboneElement"
      }]
    },
    {
      "id" : "getunit.unit.geographicalCoordinatesSWEREF99.nCoordinate",
      "path" : "getunit.unit.geographicalCoordinatesSWEREF99.nCoordinate",
      "short" : "nCoordinate",
      "definition" : "nCoordinate",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "getunit.unit.geographicalCoordinatesSWEREF99.eCoordinate",
      "path" : "getunit.unit.geographicalCoordinatesSWEREF99.eCoordinate",
      "short" : "eCoordinate",
      "definition" : "eCoordinate",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "getunit.unit.healthCareArea",
      "path" : "getunit.unit.healthCareArea",
      "short" : "healthCareArea",
      "definition" : "healthCareArea",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "getunit.unit.destinationIndicator",
      "path" : "getunit.unit.destinationIndicator",
      "short" : "destinationIndicator",
      "definition" : "destinationIndicator",
      "min" : 0,
      "max" : "*",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "getunit.unit.unitHsaId",
      "path" : "getunit.unit.unitHsaId",
      "short" : "unitHsaId",
      "definition" : "unitHsaId",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "getunit.unit.jpegPhoto",
      "path" : "getunit.unit.jpegPhoto",
      "short" : "jpegPhoto",
      "definition" : "jpegPhoto",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "getunit.unit.jpegLogotype",
      "path" : "getunit.unit.jpegLogotype",
      "short" : "jpegLogotype",
      "definition" : "jpegLogotype",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "getunit.unit.labeledUri",
      "path" : "getunit.unit.labeledUri",
      "short" : "labeledUri",
      "definition" : "labeledUri",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "getunit.unit.location",
      "path" : "getunit.unit.location",
      "short" : "location",
      "definition" : "location",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "getunit.unit.webPage1177",
      "path" : "getunit.unit.webPage1177",
      "short" : "webPage1177",
      "definition" : "webPage1177",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "getunit.unit.management",
      "path" : "getunit.unit.management",
      "short" : "management",
      "definition" : "management",
      "min" : 0,
      "max" : "*",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "getunit.unit.municipalityName",
      "path" : "getunit.unit.municipalityName",
      "short" : "municipalityName",
      "definition" : "municipalityName",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "getunit.unit.municipalityCode",
      "path" : "getunit.unit.municipalityCode",
      "short" : "municipalityCode",
      "definition" : "municipalityCode",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "getunit.unit.unitName",
      "path" : "getunit.unit.unitName",
      "short" : "unitName",
      "definition" : "unitName",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "getunit.unit.patientInformation",
      "path" : "getunit.unit.patientInformation",
      "short" : "patientInformation",
      "definition" : "patientInformation",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "getunit.unit.postalAddress",
      "path" : "getunit.unit.postalAddress",
      "short" : "postalAddress",
      "definition" : "postalAddress",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "BackboneElement"
      }]
    },
    {
      "id" : "getunit.unit.postalAddress.addressLine",
      "path" : "getunit.unit.postalAddress.addressLine",
      "short" : "addressLine",
      "definition" : "addressLine",
      "min" : 1,
      "max" : "*",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "getunit.unit.postalCode",
      "path" : "getunit.unit.postalCode",
      "short" : "postalCode",
      "definition" : "postalCode",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "getunit.unit.priceInformation",
      "path" : "getunit.unit.priceInformation",
      "short" : "priceInformation",
      "definition" : "priceInformation",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "getunit.unit.publicName",
      "path" : "getunit.unit.publicName",
      "short" : "publicName",
      "definition" : "publicName",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "getunit.unit.relatedUnitHsaId",
      "path" : "getunit.unit.relatedUnitHsaId",
      "short" : "relatedUnitHsaId",
      "definition" : "relatedUnitHsaId",
      "min" : 0,
      "max" : "*",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "getunit.unit.route",
      "path" : "getunit.unit.route",
      "short" : "route",
      "definition" : "route",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "getunit.unit.smsTelephoneNumber",
      "path" : "getunit.unit.smsTelephoneNumber",
      "short" : "smsTelephoneNumber",
      "definition" : "smsTelephoneNumber",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "getunit.unit.street",
      "path" : "getunit.unit.street",
      "short" : "street",
      "definition" : "street",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "getunit.unit.surgeryHour",
      "path" : "getunit.unit.surgeryHour",
      "short" : "surgeryHour",
      "definition" : "surgeryHour",
      "min" : 0,
      "max" : "*",
      "type" : [{
        "code" : "BackboneElement"
      }]
    },
    {
      "id" : "getunit.unit.surgeryHour.fromDay",
      "path" : "getunit.unit.surgeryHour.fromDay",
      "short" : "fromDay",
      "definition" : "fromDay",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "getunit.unit.surgeryHour.fromTime",
      "path" : "getunit.unit.surgeryHour.fromTime",
      "short" : "fromTime",
      "definition" : "fromTime",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "time"
      }]
    },
    {
      "id" : "getunit.unit.surgeryHour.toDay",
      "path" : "getunit.unit.surgeryHour.toDay",
      "short" : "toDay",
      "definition" : "toDay",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "getunit.unit.surgeryHour.toTime",
      "path" : "getunit.unit.surgeryHour.toTime",
      "short" : "toTime",
      "definition" : "toTime",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "time"
      }]
    },
    {
      "id" : "getunit.unit.surgeryHour.comment",
      "path" : "getunit.unit.surgeryHour.comment",
      "short" : "comment",
      "definition" : "comment",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "getunit.unit.switchboardNumber",
      "path" : "getunit.unit.switchboardNumber",
      "short" : "switchboardNumber",
      "definition" : "switchboardNumber",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "getunit.unit.telephoneHour",
      "path" : "getunit.unit.telephoneHour",
      "short" : "telephoneHour",
      "definition" : "telephoneHour",
      "min" : 0,
      "max" : "*",
      "type" : [{
        "code" : "BackboneElement"
      }]
    },
    {
      "id" : "getunit.unit.telephoneHour.fromDay",
      "path" : "getunit.unit.telephoneHour.fromDay",
      "short" : "fromDay",
      "definition" : "fromDay",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "getunit.unit.telephoneHour.fromTime",
      "path" : "getunit.unit.telephoneHour.fromTime",
      "short" : "fromTime",
      "definition" : "fromTime",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "time"
      }]
    },
    {
      "id" : "getunit.unit.telephoneHour.toDay",
      "path" : "getunit.unit.telephoneHour.toDay",
      "short" : "toDay",
      "definition" : "toDay",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "getunit.unit.telephoneHour.toTime",
      "path" : "getunit.unit.telephoneHour.toTime",
      "short" : "toTime",
      "definition" : "toTime",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "time"
      }]
    },
    {
      "id" : "getunit.unit.telephoneHour.comment",
      "path" : "getunit.unit.telephoneHour.comment",
      "short" : "comment",
      "definition" : "comment",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "getunit.unit.telephoneNumber",
      "path" : "getunit.unit.telephoneNumber",
      "short" : "telephoneNumber",
      "definition" : "telephoneNumber",
      "min" : 0,
      "max" : "*",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "getunit.unit.textTelephoneNumber",
      "path" : "getunit.unit.textTelephoneNumber",
      "short" : "textTelephoneNumber",
      "definition" : "textTelephoneNumber",
      "min" : 0,
      "max" : "*",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "getunit.unit.unitExtraInformation",
      "path" : "getunit.unit.unitExtraInformation",
      "short" : "unitExtraInformation",
      "definition" : "unitExtraInformation",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "getunit.unit.unitFunction",
      "path" : "getunit.unit.unitFunction",
      "short" : "unitFunction",
      "definition" : "unitFunction",
      "min" : 0,
      "max" : "*",
      "type" : [{
        "code" : "BackboneElement"
      }]
    },
    {
      "id" : "getunit.unit.unitFunction.unitFunctionName",
      "path" : "getunit.unit.unitFunction.unitFunctionName",
      "short" : "unitFunctionName",
      "definition" : "unitFunctionName Heter name i schemat.",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "getunit.unit.unitFunction.telephoneHour",
      "path" : "getunit.unit.unitFunction.telephoneHour",
      "short" : "telephoneHour",
      "definition" : "telephoneHour",
      "min" : 0,
      "max" : "*",
      "type" : [{
        "code" : "BackboneElement"
      }]
    },
    {
      "id" : "getunit.unit.unitFunction.telephoneHour.fromDay",
      "path" : "getunit.unit.unitFunction.telephoneHour.fromDay",
      "short" : "fromDay",
      "definition" : "fromDay",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "getunit.unit.unitFunction.telephoneHour.fromTime",
      "path" : "getunit.unit.unitFunction.telephoneHour.fromTime",
      "short" : "fromTime",
      "definition" : "fromTime",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "time"
      }]
    },
    {
      "id" : "getunit.unit.unitFunction.telephoneHour.toDay",
      "path" : "getunit.unit.unitFunction.telephoneHour.toDay",
      "short" : "toDay",
      "definition" : "toDay",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "getunit.unit.unitFunction.telephoneHour.toTime",
      "path" : "getunit.unit.unitFunction.telephoneHour.toTime",
      "short" : "toTime",
      "definition" : "toTime",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "time"
      }]
    },
    {
      "id" : "getunit.unit.unitFunction.telephoneHour.comment",
      "path" : "getunit.unit.unitFunction.telephoneHour.comment",
      "short" : "comment",
      "definition" : "comment",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "getunit.unit.unitFunction.telephoneNumber",
      "path" : "getunit.unit.unitFunction.telephoneNumber",
      "short" : "telephoneNumber",
      "definition" : "telephoneNumber",
      "min" : 0,
      "max" : "*",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "getunit.unit.unitTemporaryInformation",
      "path" : "getunit.unit.unitTemporaryInformation",
      "short" : "unitTemporaryInformation",
      "definition" : "unitTemporaryInformation",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "BackboneElement"
      }]
    },
    {
      "id" : "getunit.unit.unitTemporaryInformation.fromDate",
      "path" : "getunit.unit.unitTemporaryInformation.fromDate",
      "short" : "fromDate",
      "definition" : "fromDate",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "getunit.unit.unitTemporaryInformation.toDate",
      "path" : "getunit.unit.unitTemporaryInformation.toDate",
      "short" : "toDate",
      "definition" : "toDate",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "getunit.unit.unitTemporaryInformation.temporaryInformation",
      "path" : "getunit.unit.unitTemporaryInformation.temporaryInformation",
      "short" : "temporaryInformation",
      "definition" : "temporaryInformation",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "getunit.unit.visitingHour",
      "path" : "getunit.unit.visitingHour",
      "short" : "visitingHour",
      "definition" : "visitingHour",
      "min" : 0,
      "max" : "*",
      "type" : [{
        "code" : "BackboneElement"
      }]
    },
    {
      "id" : "getunit.unit.visitingHour.fromDay",
      "path" : "getunit.unit.visitingHour.fromDay",
      "short" : "fromDay",
      "definition" : "fromDay",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "getunit.unit.visitingHour.fromTime",
      "path" : "getunit.unit.visitingHour.fromTime",
      "short" : "fromTime",
      "definition" : "fromTime",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "time"
      }]
    },
    {
      "id" : "getunit.unit.visitingHour.toDay",
      "path" : "getunit.unit.visitingHour.toDay",
      "short" : "toDay",
      "definition" : "toDay",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "getunit.unit.visitingHour.toTime",
      "path" : "getunit.unit.visitingHour.toTime",
      "short" : "toTime",
      "definition" : "toTime",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "time"
      }]
    },
    {
      "id" : "getunit.unit.visitingHour.comment",
      "path" : "getunit.unit.visitingHour.comment",
      "short" : "comment",
      "definition" : "comment",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "getunit.unit.visitingRuleAge",
      "path" : "getunit.unit.visitingRuleAge",
      "short" : "visitingRuleAge",
      "definition" : "visitingRuleAge",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "BackboneElement"
      }]
    },
    {
      "id" : "getunit.unit.visitingRuleAge.fromAge",
      "path" : "getunit.unit.visitingRuleAge.fromAge",
      "short" : "fromAge",
      "definition" : "fromAge",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "getunit.unit.visitingRuleAge.toAge",
      "path" : "getunit.unit.visitingRuleAge.toAge",
      "short" : "toAge",
      "definition" : "toAge",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "getunit.unit.visitingRuleAge.comment",
      "path" : "getunit.unit.visitingRuleAge.comment",
      "short" : "comment",
      "definition" : "comment",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "getunit.unit.referralRules",
      "path" : "getunit.unit.referralRules",
      "short" : "referralRules",
      "definition" : "referralRules",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "getunit.unit.visitingRules",
      "path" : "getunit.unit.visitingRules",
      "short" : "visitingRules",
      "definition" : "visitingRules",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "getunit.unit.unitStartDate",
      "path" : "getunit.unit.unitStartDate",
      "short" : "unitStartDate",
      "definition" : "unitStartDate",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "dateTime"
      }]
    },
    {
      "id" : "getunit.unit.unitEndDate",
      "path" : "getunit.unit.unitEndDate",
      "short" : "unitEndDate",
      "definition" : "unitEndDate",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "dateTime"
      }]
    },
    {
      "id" : "getunit.unit.feignedUnit",
      "path" : "getunit.unit.feignedUnit",
      "short" : "feignedUnit",
      "definition" : "feignedUnit",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "boolean"
      }]
    }]
  }
}

```
