# inera.clinicalprocess-logistics-cervixscreening#1.0.0-rc4: clinicalprocess: logistics: cervixscreening

## Pages

* [Hem](index.md)
* [7 Tjänstekontrakt](7-tjanstekontrakt.md)
* [5 Tjänstedomänens meddelandemodeller](5-tjanstedomanens-meddelandemodeller.md)
* [Artifacts Summary](artifacts.md)
* [6 Gemensamma informationskomponenter](6-gemensamma-informationskomponenter.md)
* [3 Tjänstedomänens arkitektur](3-tjanstedomanens-arkitektur.md)
* [4 Tjänstedomänens krav och regler](4-tjanstedomanens-krav-och-regler.md)
* [2 Versionsinformation](2-versionsinformation.md)
* [1 Inledning](1-inledning.md)

## Resources

### CodeSystems

* [ResultCode](CodeSystem-CervixScreening-resultcode-cs.md)

### ValueSets

* [ResultCode](ValueSet-CervixScreening-resultcode-vs.md)

### Logicals

* [ProcessCervixScreeningInformation — Request](StructureDefinition-processcervixscreeninginformation-request.md)
* [ProcessCervixScreeningInformation — Response](StructureDefinition-processcervixscreeninginformation.md)

### ImplementationGuides

* [clinicalprocess: logistics: cervixscreening](index.md)
