# Hem - clinicalprocess: logistics: cervixscreening v1.0.0-rc4

* [**Table of Contents**](toc.md)
* **Hem**

## Hem

| | |
| :--- | :--- |
| *Official URL*:https://fhir.inera.se/ig/clinicalprocess-logistics-cervixscreening/ImplementationGuide/inera.clinicalprocess-logistics-cervixscreening | *Version*:1.0.0-rc4 |
| Draft as of 2026-10-08 | *Computable Name*:clinicalprocesslogisticscervixscreening |
| **Copyright/Legal**: Copyright 2024 Inera AB. Licensieras under Creative Commons Attribution 4.0. | |

# clinicalprocess: logistics: cervixscreening

**TKB-version:** 1.0_RC4 · **IG-version:** 1.0.0-rc4 · **Källa:** Bitbucket-tagg `1.0_RC4` 

## Översikt

FHIR Implementation Guide för tjänstedomänen **clinicalprocess: logistics: cervixscreening** (Screeningstöd livmoderhals) version 1.0_RC4. Genererad från Ineras Tjänstekontraktsbeskrivning (TKB), version 1.0_RC4 (2020-12-09), och domänens WSDL- och XSD-filer (tagg 1.0_RC4).

Domänen används för att skicka kallelsegrundande information om screening för livmoderhalscancer mellan regionernas kallelsekanslier, när en kvinna flyttar, lämnar prov eller behandlas i en annan region än hemregionen. Domänen finns bara som release candidate.

Domänen innehåller följande tjänstekontrakt:

| | | |
| :--- | :--- | :--- |
| [ProcessCervixScreeningInformation](7-tjanstekontrakt.md#processcervixscreeninginformation) | 1.0 | Tjänstekontraktet ProcessCervixScreeningInformation stödjer informationsflödet från en region som har kallelsegrundande information om en kvinna till en annan region som har kallelseansvaret för samma kvinna. |

## Innehåll

* [1 Inledning](1-inledning.md)
* [2 Versionsinformation](2-versionsinformation.md)
* [3 Tjänstedomänens arkitektur](3-tjanstedomanens-arkitektur.md)
* [4 Tjänstedomänens krav och regler](4-tjanstedomanens-krav-och-regler.md)
* [5 Tjänstedomänens meddelandemodeller](5-tjanstedomanens-meddelandemodeller.md)
* [6 Gemensamma informationskomponenter](6-gemensamma-informationskomponenter.md)
* [7 Tjänstekontrakt](7-tjanstekontrakt.md)
* [Artefakter](artifacts.md)

